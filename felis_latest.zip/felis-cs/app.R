library(shiny)
library(shinyWidgets)
library(ggplot2)
library(umap)
library(tidyr)
library(dbscan)
library(readr)
library(dplyr)
library(stringr)
library(ComplexHeatmap)
library(RColorBrewer)
library(gt)
library(gtsummary)
library(flextable)
library(Rediscover)
library(survival)
library(gridExtra)
library(survminer)
library(tranSurv)
library(rstan)
library(DT)
library(ggsci)
library(scales)
library(patchwork)
library(sjPlot)
library(sjlabelled)
library(forcats)
library(markdown)
library(PropCIs)
library(shinythemes)
library(plyr)
library(httr)
library(drawProteins)
library(ggrepel)
library(rms)
library(blorr)
library(dcurves)
library(Matching)
library(survRM2)
library(shinydashboard)
library(pROC)
library(tidymodels)
library(withr)
library(rpart)
library(ranger)
library(bonsai)
library(probably)
library(discrim)
library(partykit)

tidymodels_prefer()
options(pillar.advice = FALSE, pillar.min_title_chars = Inf)

nietzsche = read.csv(header = TRUE,
                     file("source/nietzsche.csv",
                          encoding='UTF-8-BOM'))$text

# Rstan options
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())

# Specify the application port
options(shiny.host = "0.0.0.0")
options(shiny.port = 3838)

ht_opt$message = FALSE
options(shiny.maxRequestSize=16*1024^3)

Abs = function(x){
  x = as.numeric(x)
  x[is.na(x)]=1
  return(x)
}

fun_zero <- function(a, b){
  if(length(a) != length(b)){
    if(length(a) / length(b) == as.integer(length(a) / length(b))){
      b = rep(b,length(a) / length(b))
    }
  }
  return(ifelse(b == 0, 0, a / b))
}

gg_empty = function(){
  g = ggplot()
  g = g + geom_blank()
  g = g + ggtitle("Few data, not analyzed")
  plot(g)
}

ggsurvplot_empty = function(){
  g = ggsurvplot(survfit(Surv(time, status) ~ 1, data = lung),
                 title = "",
                 palette = "white",
                 ggtheme=theme_void())
  g$plot <- g$plot + theme(axis.text.x = element_blank(),
                           axis.text.y = element_blank(),
                           plot.title = element_blank(),
                           plot.subtitle = element_blank(),
                           legend.title=element_blank(),
                           legend.text=element_blank(),
                           axis.ticks=element_blank(),
                           axis.ticks.x = element_blank())
  return(g)
}

gg_drug_plot = function(data, x_name, y_name, x_lab, y_lab, Total_pts, x_max_patients){
  Cor = round(cor.test(data[,colnames(data) == x_name], data[,colnames(data) == y_name])$estimate,3)
  P = round(cor.test(data[,colnames(data) == x_name], data[,colnames(data) == y_name])$p.value,3)
  cor = data.frame(Cor, P)
  Max_x = max(data[,colnames(data) == x_name],na.rm = T) * 1.05
  Max_y = max(data[,colnames(data) == y_name],na.rm = T)
  g <- ggplot(data, aes_(x = as.name(x_name), y = as.name(y_name), color = as.name("Cancers")))
  g <- g + geom_point(size = Total_pts/x_max_patients*10, alpha = .5)
  g <- g + scale_fill_nejm()
  g <- g + coord_cartesian(xlim = c(0, Max_x), ylim = c(0, Max_y*1.05))
  g <- g + theme_bw()
  g <- g + labs(x = x_lab,y = y_lab, color = "Cancer type")
  g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
  g <- g + geom_text(data=cor, colour = "red", mapping = aes(x = 0.3*Max_x, y = Max_y*1.03, label = paste("r =",Cor, ", p =",P)))
}

shannon.entropy = function(x, x_length){ 
  x = x[(!is.na(x))]
  x = x[(x != 0)]
  if(sum(x) <= 0) {
    return(log(x_length, base=2)) 
  } else {
    p = x/sum(x)
    score = -sum(p * log(p, base=2))
    return(score)
  }
} 

odds.ratio <- function(a, b, c, d, correct=FALSE){
  cl <- function(x){
    or*exp(c(1,-1)*qnorm(x)*sqrt(1/a+1/b+1/c+1/d))
  }
  if (correct || a*b*c*d==0) {
    a <- a+0.5
    b <- b+0.5
    c <- c+0.5
    d <- d+0.5
  }
  or <- a*d/(b*c)
  conf <- rbind(cl90=cl(0.05), cl95=cl(0.025), cl99=cl(0.005), cl999=cl(0.0005))
  conf <- data.frame(conf)
  colnames(conf) <- paste(c("lower","upper"), " limit" , sep="")
  rownames(conf) <- paste(c(90, 95, 99, 99.9), "%CI" , sep="")
  list(or=or, conf=conf)
}


fun_oncoprint = function(Data_MAF_target,
                         Data_case_target,
                         oncogenic_genes,
                         gene,
                         gene_no,
                         gene_group_1,
                         gene_group_2,
                         oncoprint_option,
                         mid_age){
  withProgress(message = sample(nietzsche)[1], {
      col = c("amplification" = "red",
            "loss" = "blue",
            "nonsense_frameshift" = "green4",
            "TMB_high" = "orange",
            "exon_skipping" = "red4",
            "small_scale_variant" = "green",
            "duplication" = "pink",
            "rearrangement" = "purple",
            "fusion" = "gray",
            "truncation" = "black",
            "deletion" = "yellow")
    alter_fun = list(
      background = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h-unit(2, "pt"), 
                  gp = gpar(fill = "#EEEEEE", col = NA))
      },
      amplification = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h-unit(2, "pt"), 
                  gp = gpar(fill = col["amplification"], col = NA))
      },
      loss = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*1.0, 
                  gp = gpar(fill = col["loss"], col = NA))
      },
      nonsense_frameshift = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.9, 
                  gp = gpar(fill = col["nonsense_frameshift"], col = NA))
      },
      TMB_high = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.8, 
                  gp = gpar(fill = col["TMB_high"], col = NA))
      },
      exon_skipping = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.7, 
                  gp = gpar(fill = col["exon_skipping"], col = NA))
      },
      small_scale_variant = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.6, 
                  gp = gpar(fill = col["small_scale_variant"], col = NA))
      },
      duplication = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.5, 
                  gp = gpar(fill = col["duplication"], col = NA))
      },
      rearrangement = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["rearrangement"], col = NA))
      },
      fusion = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.3, 
                  gp = gpar(fill = col["fusion"], col = NA))
      },
      truncation = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.2, 
                  gp = gpar(fill = col["truncation"], col = NA))
      },
      deletion = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                  gp = gpar(fill = col["deletion"], col = NA))
      }
    )
    Data_oncoprint = Data_case_target %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                    症例.基本情報.がん種.OncoTree.,
                    YoungOld,
                    Lymph_met,
                    Brain_met,
                    Lung_met,
                    Bone_met,
                    Liver_met,
                    Other_met) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all=TRUE) %>%
      dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
    gene = gene[gene %in% Data_MAF_target$Hugo_Symbol]
    if(length(gene) > 0){
      oncogenic_genes = unique(c(gene, oncogenic_genes))
    }
    gene_no = min(length(oncogenic_genes),
                  gene_no)
    mat_oncoprint = matrix("",
                           nrow = length(Data_oncoprint$症例.基本情報.がん種.OncoTree.),
                           ncol = gene_no)
    rownames(mat_oncoprint) = Data_oncoprint$C.CAT調査結果.基本項目.ハッシュID
    colnames(mat_oncoprint) = oncogenic_genes[1:gene_no]
    Data_TMB = (Data_MAF_target %>%
                  dplyr::distinct(Tumor_Sample_Barcode, TMB))
    colnames(Data_TMB) = c("C.CAT調査結果.基本項目.ハッシュID", "TMB")
    Data_oncoprint = left_join(Data_oncoprint,
                               Data_TMB,
                               by = "C.CAT調査結果.基本項目.ハッシュID")
    Data_TMB = Data_oncoprint$TMB
    Data_TMB[is.na(Data_TMB)] <- 0
    incProgress(1 / 4)
    Data_major_gene = Data_MAF_target %>%
      dplyr::filter(Hugo_Symbol %in% colnames(mat_oncoprint)) %>%
      dplyr::arrange(Tumor_Sample_Barcode)
    
    for(i in 1:length(Data_major_gene$Tumor_Sample_Barcode)){
        mat_oncoprint[Data_major_gene[i,"Tumor_Sample_Barcode"],
                      Data_major_gene[i,"Hugo_Symbol"]] =
          paste(mat_oncoprint[Data_major_gene[i,"Tumor_Sample_Barcode"],
                              Data_major_gene[i,"Hugo_Symbol"]],
                Data_major_gene[i,"Variant_Classification"],
                sep=";")
    }
    incProgress(1 / 4)
    
    rownames(mat_oncoprint) = Data_oncoprint$症例.基本情報.がん種.OncoTree.
    mat_oncoprint = t(mat_oncoprint)
    column_title = paste("OncoPrint for frequent gene mutations")
    tmp = mat_oncoprint
    tmp[tmp != ""] = 1
    tmp[tmp == ""] = 0
    tmp = matrix(as.numeric(tmp), ncol = ncol(tmp))
    tmp2 = order(apply(tmp, FUN=sum, MARGIN=1))
    if(!is.null(gene_group_1)){
      if(!is.null(gene_group_2)){
    tmp2 = c(tmp2[-which(tmp2 %in%
                   c(which(oncogenic_genes %in% c(gene_group_1, gene_group_2))))],
                 tmp2[which(tmp2 %in% which(oncogenic_genes %in% gene_group_2))],
                 tmp2[which(tmp2 %in% which(oncogenic_genes %in%  gene_group_1))])
      } else{
        tmp2 = c(tmp2[-which(tmp2 %in% which(oncogenic_genes %in% gene_group_1))],
                 tmp2[which(tmp2 %in% which(oncogenic_genes %in% gene_group_1))])
      }
    }
    tmp = data.frame(tmp)
    colnames(tmp) = 1:ncol(tmp)
    sample_order = 1:ncol(tmp)
    colPal3 <- colorRampPalette(brewer.pal(11, "Spectral"))
    anno_diag = colnames(mat_oncoprint)
    anno_age = Data_oncoprint$YoungOld
    Data_oncoprint = Data_oncoprint %>%
      dplyr::mutate(anno_meta = case_when(
        Lymph_met == "Yes" ~ "(+)",
        Brain_met == "Yes" ~ "(+)", 
        Lung_met == "Yes" ~ "(+)",
        Bone_met == "Yes" ~ "(+)",
        Liver_met == "Yes" ~ "(+)",
        Other_met == "Yes" ~ "(+)",
        TRUE ~ "(-)"))
    anno_meta = Data_oncoprint$anno_meta
    diag_list = names(sort(table(anno_diag),decreasing = TRUE))
    diag_list = factor(diag_list, levels = diag_list)
    diag_col = colPal3(length(diag_list))
    meta_list = unique(anno_meta)
    age_list = unique(anno_age)
    names(diag_col) = diag_list
    diag_list2 = sort(unique(anno_diag))
    diag_col2 = diag_col
    names(diag_col2) = diag_list2
    
    tmp3 = matrix(as.numeric(as.factor(mat_oncoprint)) - 1,
                  ncol = ncol(mat_oncoprint))
    tmp3 = data.frame(tmp3)
    colnames(tmp3) = 1:ncol(tmp3)
    for(l in rev(tmp2)){
      if(max(tmp3[l,]) != min(tmp3[l,])){
        sample_order_tmp = sample_order
        sample_order = NULL
        tmp4 = tmp3
        tmp5 = tmp
        tmp3 = tmp4[,0]
        tmp = tmp5[,0]
        for(m in sort(unique(unlist(as.vector(tmp4[l,]))),decreasing = F)){
          sample_order = c(sample_order, sample_order_tmp[tmp4[l,] == m])
          tmp3 = cbind(tmp3, tmp4[,tmp4[l,] == m])
          tmp = cbind(tmp, tmp5[,tmp4[l,] == m])
        }
      }
    }
    
    for(l in tmp2){
      if(!all(tmp[l,] == 1) & !all(tmp[l,] == 0)){
        sample_order = c(sample_order[tmp[l,] == 1], sample_order[tmp[l,] == 0])
        tmp = cbind(tmp[,tmp[l,] == 1], tmp[,tmp[l,] == 0])
      }
    }
    sample_order_simple = sample_order
    if(oncoprint_option == "Sort by pathology"){
      sample_order_final = NULL
      for(l in diag_list){
        sample_order_final = c(sample_order_final,
                               sample_order[sample_order %in% (1:length(sample_order))[(anno_diag == l)]])
      }
    } else if(oncoprint_option == "Sort by age"){
      sample_order_final_age = NULL
      for(l in age_list){
        sample_order_final_age = c(sample_order_final_age,
                               sample_order[sample_order %in% (1:length(sample_order))[(anno_age == l)]])
      }
    } else if(oncoprint_option == "Sort by metastasis status at CGP"){
      sample_order_final_meta = NULL
      for(l in meta_list){
        sample_order_final_meta = c(sample_order_final_meta,
                                   sample_order[sample_order %in% (1:length(sample_order))[(anno_meta == l)]])
      }
    }
    incProgress(1 / 4)
    
    ha = HeatmapAnnotation(Diagnosis = anno_diag,
                           Age = anno_age,
                           Metastasis = anno_meta,
                           col = list(Diagnosis = diag_col2,
                                      Age = c("Older" = "green", "Younger" = "blue"),
                                      Metastasis = c("(+)" = "purple1", "(-)" = "orange")),
                           annotation_height = unit(15, "mm"),
                           annotation_legend_param = list(Age = list(title = paste(mid_age, ">= Age, or older")),
                                                          Metastasis = list(title = "Metastasis"),
                                                          Diagnosis = list(title = "Diagnosis",at = diag_list)))
    hb = HeatmapAnnotation(TMB = anno_points(Data_TMB, ylim = c(0, 30),
                                             axis_param = list(
                                               side = "right",
                                               at = c(0, 10, 20, 30), 
                                               labels = c("0", "10", "20", ">30")
                                             )),
                           annotation_height = unit(15, "mm"))
    if(oncoprint_option == "Sort by mutation frequency"){
      ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                     column_order = sample_order_simple, row_order = rev(tmp2),
                     alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                     column_title = column_title,
                     remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                     bottom_annotation = ha,
                     top_annotation = hb,
                     use_raster = FALSE,
                     #height = unit(200, "mm"),
                     alter_fun_is_vectorized = TRUE)
    } else if(oncoprint_option == "Sort by age"){
      ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                     column_order = sample_order_final_age, row_order = rev(tmp2),
                     alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                     column_title = column_title,
                     remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                     bottom_annotation = ha,
                     top_annotation = hb,
                     use_raster = FALSE,
                     #height = unit(200, "mm"),
                     alter_fun_is_vectorized = TRUE)
    } else if(oncoprint_option == "Sort by metastasis status at CGP"){
      ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                     column_order = sample_order_final_meta, row_order = rev(tmp2),
                     alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                     column_title = column_title,
                     remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                     bottom_annotation = ha,
                     top_annotation = hb,
                     use_raster = FALSE,
                     #height = unit(200, "mm"),
                     alter_fun_is_vectorized = TRUE)
    } else{
      ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                     column_order = sample_order_final, row_order = rev(tmp2),
                     alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                     column_title = column_title,
                     remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                     bottom_annotation = ha,
                     top_annotation = hb,
                     use_raster = FALSE,
                     #height = unit(200, "mm"),
                     alter_fun_is_vectorized = TRUE)
    }
    draw(ht)
    incProgress(1 / 4)
  })
}

save_table_docx <- function(Data_summary, separate_var, title, filename){
  tmp = Data_summary %>%
    tbl_summary(
      by = separate_var,
      statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                            "{mean} ({sd})",
                                            "{median} ({p25}, {p75})", 
                                            "{min}, {max}"),
                       all_categorical() ~ "{n} / {N} ({p}%)"),
      type = list(all_continuous() ~ "continuous2",
                  all_dichotomous() ~ "categorical"),
      digits = all_continuous() ~ 2,
      missing = "ifany")
  if(!is.null(separate_var)){
    tmp = tmp %>%
      add_p(pvalue_fun = ~style_pvalue(.x, digits = 2)) %>%
      add_overall()
  }
  tmp %>%
    add_n() %>%
    modify_header(label ~ "**Variable**") %>%
    modify_caption(title) %>%
    bold_labels() %>% as_flex_table() %>% save_as_docx(path = filename)
}

surv_curv_entry <- function(fit, data, title, legend_, diff_0, diff_1){
  g = ggsurvplot(
    fit = fit,
    combine = TRUE,
    data = data,
    xlab = "Time from enrollment (days)",
    ylab = "Survival Probability",
    censor = TRUE,
    conf.int = FALSE,
    surv.scale = "percent",
    font.title = 8,
    font.subtitle = 8,
    font.main = 8,
    font.submain = 8,
    font.caption = 8,
    font.legend = 8,
    pval = FALSE,
    surv.median.line = "v",
    palette = "Dark2",
    risk.table = TRUE,
    risk.table.y.text = FALSE,
    tables.theme = clean_theme(), 
    legend = c(0.8,0.8),
    xlim = c(0, max(data$time_enroll_final) * 1.05),
    break.x.by = ceiling(max(data$time_enroll_final) / 500) * 100,
    legend.labs = legend_
  )
  if(is.null(diff_0)){
    tmp = summary(fit)$table
    legends = paste0(tmp[[7]], " (", tmp[[8]], "-", tmp[[9]],")")
    g = g +
      labs(title = title,
           subtitle = paste0("Median OS, ", legends, " days"))
  } else{
    tmp = data.frame(summary(fit)$table)
    legends = paste0(tmp$median[1], " (", tmp$X0.95LCL[1], "-", tmp$X0.95UCL[1],")")
    for(i in 2:length(tmp$median)){
      legends = paste(legends, paste0(tmp$median[i], " (", tmp$X0.95LCL[i], "-", tmp$X0.95UCL[i],")"), sep=", ")
    }
    g = g +
      labs(title = paste0(title, ": log-rank, p=", format(
        1 - pchisq(diff_0$chisq, length(diff_0$n)-1, lower.tail = TRUE),digits=3),
        "/Gehan-Wilcoxon, p=", format(
          1 - pchisq(diff_1$chisq, length(diff_1$n)-1, lower.tail = TRUE),digits=3)),
        subtitle = paste0("Median OS, ", legends, " days"))
  }
  g$table <- g$table + theme(plot.title = element_blank(),
                             plot.subtitle = element_blank())
  return(g)
}

surv_curv_drug <- function(fit, data, title, diff_0, diff_1){
  g = ggsurvplot(
    fit = fit,
    combine = TRUE,
    data = data,
    xlab = "Time from drug initiation (days)",
    ylab = "Survival Probability",
    censor = TRUE,
    surv.scale = "percent",
    conf.int = FALSE,
    font.title = 8,
    font.subtitle = 8,
    font.main = 8,
    font.submain = 8,
    font.caption = 8,
    font.legend = 8,
    pval = FALSE,
    surv.median.line = "v",
    palette = "Dark2",
    risk.table = TRUE,
    risk.table.y.text = FALSE,
    tables.theme = clean_theme(), 
    legend = c(0.8,0.8),
    xlim = c(0, 1000),
    break.x.by = 200
  )
  if(is.null(diff_0)){
    tmp = summary(fit)$table
    legends = paste0(tmp[[7]], " (", tmp[[8]], "-", tmp[[9]],")")
    g = g +
      labs(title = title,
           subtitle = paste0("Median OS, ", legends, " days"))
  } else{
    tmp = data.frame(summary(fit)$table)
    legends = paste0(tmp$median[1], " (", tmp$X0.95LCL[1], "-", tmp$X0.95UCL[1],")")
    for(i in 2:length(tmp$median)){
      legends = paste(legends, paste0(tmp$median[i], " (", tmp$X0.95LCL[i], "-", tmp$X0.95UCL[i],")"), sep=", ")
    }
    g = g +
      labs(title = paste0(title, ": log-rank, p=", format(
        1 - pchisq(diff_0$chisq, length(diff_0$n)-1, lower.tail = TRUE),digits=3),
        "/Gehan-Wilcoxon, p=", format(
          1 - pchisq(diff_1$chisq, length(diff_1$n)-1, lower.tail = TRUE),digits=3)),
        subtitle = paste0("Median OS, ", legends," days"))
    g$table <- g$table + theme(plot.title = element_blank(),
                               plot.subtitle = element_blank())
  }
  return(g)
}

# Define UI for application that draws a histogram
ui <- dashboardPage(skin = "black",
  dashboardHeader(tags$li(class = "dropdown",
                          tags$table(style="80%;align:center;border-collapse:seperate;border-spacing:20px;"),
                          tags$style(".main-header {max-height: 30px}"),
                          tags$style(".main-header .logo {height: 30px;}"),
                          tags$style(".sidebar-toggle {height: 30px; padding-top: 1px !important;}"),
                          tags$style(".navbar {min-height:30px !important}")),
                  title = HTML(
                    "<div style = 'background-color:FFFFFF; vertical-align:top'>
       <a href='https://github.com/MANO-B/FELIS'><img src = 'FELIS.png', align = 'left', height = '30px'></a> 
       </div><h6>FELIS version 1.7.2</h6>")
  ),
  dashboardSidebar(
    tags$style(".sidebar {height: calc(100vh - 50px); overflow-y: scroll; scrollbar-width: none;.left-side}, .main-sidebar {padding-top: 30px}"),
    sidebarMenu(style = "white-space: normal;",
      h3("Settings"),
      menuItem("Input C-CAT files", tabName = "InputC-CATfiles", icon = icon("dashboard")),
      menuItem("Setting", tabName = "Setting", icon = icon("dashboard")),
      menuItem("Analysis", tabName = "Analysis", icon = icon("th")),
      hr(),
      h3("Results"),
      menuItem("Case summary", icon = icon("th"),
               hr(),
               p("Tables"),
               menuSubItem("Summarized by mutation pattern", tabName = "Summarizedbymutationpattern", icon = icon("angle-right")),
               menuSubItem("Summarized by histology", tabName = "Summarizedbyhistology", icon = icon("angle-right")),
               hr()
      ),
      menuItem("Oncoprint", icon = icon("th"),
               hr(),
               p("Figures"),
               menuSubItem("Oncoprint", tabName = "Oncoprint", icon = icon("angle-right")),
               menuSubItem("Lolliplot for the selected gene", tabName = "Lolliplotfortheselectedgene", icon = icon("angle-right")),
               hr(),
               p("Downloadable table"),
               menuSubItem("Table of clinical and mutation information per patient", tabName = "Tableofclinicalandmutationinformationperpatient", icon = icon("angle-right")),
               hr()
      ),
      menuItem("Mutual exclusivity", tabName = "Mutualexclusivity", icon = icon("th")),
      menuItem("Variation by histology", tabName = "Variationbyhistology", icon = icon("th")),
      menuItem("Clustering analysis", icon = icon("th"),
               hr(),
               p("Mutation-based clustering"),
               menuSubItem("Basic data", tabName = "Basicdata", icon = icon("angle-right")),
               menuSubItem("UMAP clustering based on mutations", tabName = "UMAPclusteringbasedonmutations", icon = icon("angle-right")),
               menuSubItem("Cluster and age relationship", tabName = "Clusterandagerelationship", icon = icon("angle-right")),
               menuSubItem("Cluster and histology relationship", tabName = "Clusterandhistologyrelationship", icon = icon("angle-right")),
               menuSubItem("Heterogeneity within histologic types", tabName = "Heterogeneitywithinhistologictypes", icon = icon("angle-right")),
               menuSubItem("Table of clusters and histologies", tabName = "Tableofclustersandhistologies", icon = icon("angle-right")),
               menuSubItem("Table of clusters and genetic variants", tabName = "Tableofclustersandgeneticvariants", icon = icon("angle-right")),
               hr(),
               p("Factors leading to treatment"),
               menuSubItem("Frequency of patients with targeted therapy", tabName = "Frequencyofpatientswithtargetedtherapy", icon = icon("angle-right")),
               menuSubItem("Relationship between pre-CGP and post-CGP periods", tabName = "Relationshipbetweenpre-CGPandpost-CGPperiods", icon = icon("angle-right")),
               menuSubItem("Patients per histology and treatment reach rate", tabName = "Patientsperhistologyandtreatmentreachrate", icon = icon("angle-right")),
               menuSubItem("Pre-CGP period and treatment reach rate", tabName = "Pre-CGPperiodandtreatmentreachrate", icon = icon("angle-right")),
               menuSubItem("Post-CGP period and treatment reach rate", tabName = "Post-CGPperiodandtreatmentreachrate", icon = icon("angle-right")),
               menuSubItem("Age and treatment reach rate", tabName = "Ageandtreatmentreachrate", icon = icon("angle-right")),
               hr()
      ),
      menuItem("Survival after CGP", icon = icon("th"),
               hr(),
               p("Survival analysis"),
               menuSubItem("Survival and treatment after CGP", tabName = "SurvivalandtreatmentafterCGP", icon = icon("angle-right")),
               menuSubItem("Survival after CGP and performance status", tabName = "SurvivalafterCGPandperformancestatus", icon = icon("angle-right")),
               menuSubItem("Survival after CGP and previous treatment", tabName = "SurvivalafterCGPandprevioustreatment", icon = icon("angle-right")),
               menuSubItem("Survival after CGP and mutations, forest plot", tabName = "SurvivalafterCGPandmutationsforestplot", icon = icon("angle-right")),
               menuSubItem("Survival after CGP and mutations, KM-curve", tabName = "SurvivalafterCGPandmutationsKM-curve", icon = icon("angle-right")),
               menuSubItem("Hazard ratio for survival after CGP", tabName = "HazardratioforsurvivalafterCGP", icon = icon("angle-right")),
               hr(),
               p("Factors leading to treatment"),
               menuSubItem("Factors leading to Treatment, pre-CGP, Nomogram", tabName = "FactorsleadingtoTreatmentpre-CGPNomogram", icon = icon("angle-right")),
               menuSubItem("Factors leading to Treatment, post-CGP, Nomogram", tabName = "FactorsleadingtoTreatmentpost-CGPNomogram", icon = icon("angle-right")),
               menuSubItem("Factors leading to Treatment, pre-CGP, Odds ratio", tabName = "FactorsleadingtoTreatmentpre-CGPOddsratio", icon = icon("angle-right")),
               menuSubItem("Factors leading to Treatment, post-CGP, Odds ratio", tabName = "FactorsleadingtoTreatmentpost-CGPOddsratio", icon = icon("angle-right")),
               menuSubItem("Factors leading to Treatment, decision curve", tabName = "FactorsleadingtoTreatmentdecisioncurve", icon = icon("angle-right")),
               menuSubItem("ROC curve of nomogram", tabName = "ROCnomogram", icon = icon("angle-right")),
               menuSubItem("Machine learning prediction", tabName = "preCGPMachinelearning", icon = icon("angle-right")),
               menuSubItem("Factors leading to Treatment, table", tabName = "FactorsleadingtoTreatmenttable", icon = icon("angle-right")),
               menuSubItem("Prediction result table", tabName = "Table_prediction", icon = icon("angle-right")),
               menuSubItem("Analyze your data", tabName = "Input_data", icon = icon("th")),
               hr()
      ),
      menuItem("Survival after CTx", icon = icon("th"),
               hr(),
               menuSubItem("Survival corrected for left-truncation bias", tabName = "Survivalcorrectedforleft-truncationbias", icon = icon("angle-right")),
               menuSubItem("Genetic variants and survival, forest plot", tabName = "Geneticvariantsandsurvivalforestplot", icon = icon("angle-right")),
               menuSubItem("Genetic variants and survival, KM-curve", tabName = "GeneticvariantsandsurvivalKM-curve", icon = icon("angle-right")),
               hr()
      ),
      menuItem("Drug response", icon = icon("th"),
               hr(),
               p("Tables"),
               menuSubItem("Drug use, by line of treatment", tabName = "Drugusebylineoftreatment", icon = icon("angle-right")),
               menuSubItem("Drug use, by treatment effect", tabName = "Drugusebytreatmenteffect", icon = icon("angle-right")),
               menuSubItem("Use of designated line agents, by mutation pattern", tabName = "Useofdesignatedlineagentsbymutationpattern", icon = icon("angle-right")),
               menuSubItem("Use of designated line agents, by histology", tabName = "Useofdesignatedlineagentsbyhistology", icon = icon("angle-right")),
               menuSubItem("Use of designated line agents, by mutated genes", tabName = "Useofdesignatedlineagentsbymutatedgenes", icon = icon("angle-right")),
               menuSubItem("Use of designated lines and drugs with ToT information, by mutation pattern", tabName = "UseofdesignatedlinesanddrugswithToTinformationbymutationpattern", icon = icon("angle-right")),
               menuSubItem("Use of designated lines and drugs with ToT information, by histology", tabName = "UseofdesignatedlinesanddrugswithToTinformationbyhistology", icon = icon("angle-right")),
               menuSubItem("Use of designated lines and drugs with ToT information, by mutated genes", tabName = "UseofdesignatedlinesanddrugswithToTinformationbymutatedgenes", icon = icon("angle-right")),
               menuSubItem("Use of designated lines and drugs with RECIST information, by mutation pattern", tabName = "UseofdesignatedlinesanddrugswithRECISTinformationbymutationpattern", icon = icon("angle-right")),
               menuSubItem("Use of designated lines and drugs with RECIST information, by histology", tabName = "UseofdesignatedlinesanddrugswithRECISTinformationbyhistology", icon = icon("angle-right")),
               menuSubItem("Use of designated lines and drugs with RECIST information, by mutated genes", tabName = "UseofdesignatedlinesanddrugswithRECISTinformationbymutatedgenes", icon = icon("angle-right")),
               hr(),
               p("Time on Treatment"),
               menuSubItem("Time on treatment and pre-treatment for the specified treatment, scatter plot", tabName = "Timeontreatmentandpre-treatmentforthespecifiedtreatmentscatterplot", icon = icon("angle-right")),
               menuSubItem("Time on treatment and pre-treatment for the specified treatment, KM-curve", tabName = "Timeontreatmentandpre-treatmentforthespecifiedtreatmentKM-curve", icon = icon("angle-right")),
               menuSubItem("Time on treatment by tissue type, KM-curve", tabName = "TimeontreatmentbytissuetypeKM-curve", icon = icon("angle-right")),
               menuSubItem("Time on treatment by gene mutation cluster, KM-curve", tabName = "TimeontreatmentbygenemutationclusterKM-curve", icon = icon("angle-right")),
               menuSubItem("Time on treatment by mutated genes, forest plot", tabName = "Timeontreatmentbymutatedgenesforestplot", icon = icon("angle-right")),
               menuSubItem("Time on treatment by mutated genes, KM-curve", tabName = "TimeontreatmentbymutatedgenesKM-curve", icon = icon("angle-right")),
               menuSubItem("Time on treatment and mutations of interest, KM-curve", tabName = "TimeontreatmentandmutationsofinterestKM-curve", icon = icon("angle-right")),
               menuSubItem("Hazard ratio on time on treatment", tabName = "Hazardratioontimeontreatment", icon = icon("angle-right")),
               hr(),
               p("Response rate"),
               menuSubItem("Odds ratio on objective response rate", tabName = "Oddsratioonobjectiveresponserate", icon = icon("angle-right")),
               menuSubItem("Odds ratio on disease control rate", tabName = "Oddsratioondiseasecontrolrate", icon = icon("angle-right")),
               menuSubItem("Mutation clustering and RECIST", tabName = "MutationclusteringandRECIST", icon = icon("angle-right")),
               menuSubItem("Mutation pattern and RECIST", tabName = "MutationpatternandRECIST", icon = icon("angle-right")),
               menuSubItem("Histology and RECIST", tabName = "HistologyandRECIST", icon = icon("angle-right")),
               menuSubItem("Mutated genes and RECIST", tabName = "MutatedgenesandRECIST", icon = icon("angle-right"))
      ),
      hr(),
      h3("Instruction"),
      menuItem("About FELIS", tabName = "Instruction", icon = icon("th")),
      hr()
    )
  ),
  ## Body content
  dashboardBody(style='overflow-x: scroll;overflow-y: scroll;',
                tags$head(tags$style(HTML('
      .main-header .sidebar-toggle:before {
        content: "\\e068";}'))),
    tabItems(
      # First tab content
      tabItem(tabName = "InputC-CATfiles",
              fluidRow(
                column(4,
                       strong("Required: C-CAT data files (zipped files are acceptable)"),
                       hr(),
                       fileInput(inputId = "clinical_files",
                                 label = "Choose case CSV Files",
                                 multiple = TRUE
                       ),
                       hr(),
                       fileInput(inputId = "report_files",
                                 label = "Choose report CSV Files",
                                 multiple = TRUE
                       ),
                       br(),
                       br(),
                       downloadButton('download_test_clinical_data', 'Download sample clinical data'),
                       br(),
                       br(),
                       downloadButton('download_test_report_data', 'Download sample report data')
                ),
                column(4,
                       strong("Option files"),
                       hr(),
                       fileInput(inputId = "ID_histology",
                                 label = "Correspondence table between ID and histology (CSV)",
                                 multiple = TRUE,
                                 accept = c(
                                   "text/csv",
                                   "text/comma-separated-values,text/plain",
                                   ".csv")
                       ),
                       "Specify the ID of the patient whose diagnosis you want to correct and the modified histology.",
                       br(),
                       br(),
                       downloadButton('download_ID_histology', 'Download CSV file template'),
                       br(),
                       br(),
                       hr(),
                       fileInput(inputId = "ID_drug",
                                 label = "Correspondence table between ID and drug information (CSV)",
                                 multiple = TRUE,
                                 accept = c(
                                   "text/csv",
                                   "text/comma-separated-values,text/plain",
                                   ".csv")
                       ),
                       "To analyze only the drug after curation",
                       br(),
                       br(),
                       downloadButton('download_ID_drug_pre_CGP', 'Download CSV template (before CGP)'),
                       br(),
                       br(),
                       downloadButton('download_ID_drug_post_CGP', 'Download CSV template (after CGP)'),
                       br(),
                       br(),
                       hr(),
                       fileInput(inputId = "drug_rename",
                                 label = "Correspondence table for drug renaming (CSV)",
                                 multiple = TRUE,
                                 accept = c(
                                   "text/csv",
                                   "text/comma-separated-values,text/plain",
                                   ".csv")
                       ),
                       "To analyze similar drugs together by renaming the drugs",
                       br(),
                       "Reclassified as molecular targeted therapies, immune checkpoint inhibitors, etc.",
                       br(),
                       "Drugs are listed in ABC order, separated by commas",
                       br(),
                       br(),
                       downloadButton('download_drug_rename', 'Download CSV template'),
                       br(),
                       br()
                ),
                column(4,
                       strong("Option files"),
                       hr(),
                       fileInput(inputId = "mutation_rename",
                                 label = "Correspondence table for mutation renaming (CSV)",
                                 multiple = TRUE,
                                 accept = c(
                                   "text/csv",
                                   "text/comma-separated-values,text/plain",
                                   ".csv")
                       ),
                       "To analyze similar mutations together by renaming mutations",
                       br(),
                       "Reclassified as Exon 19 mutation, Exon 20 mutation, gene amplification, etc.",
                       br(),
                       "'Other' if there is an unspecified mutation in the designated gene",
                       br(),
                       br(),
                       downloadButton('download_mutation_rename', 'Download CSV template'),
                       br(),
                       br(),
                       hr(),
                       fileInput(inputId = "histology_rename",
                                 label = "Correspondence table of organization type renaming (CSV)",
                                 multiple = TRUE,
                                 accept = c(
                                   "text/csv",
                                   "text/comma-separated-values,text/plain",
                                   ".csv")
                       ),
                       "To analyze similar tissue types together by renaming them",
                       br(),
                       "Reclassified as differentiated gastric cancer, undifferentiated gastric cancer, etc.",
                       br(),
                       br(),
                       downloadButton('download_histology_rename', 'Download CSV template'),
                       br(),
                       br(),
                       hr(),
                       fileInput(inputId = "regimen_rename",
                                 label = "Correspondence table for drug renaming based on regimen (CSV)",
                                 multiple = TRUE,
                                 accept = c(
                                   "text/csv",
                                   "text/comma-separated-values,text/plain",
                                   ".csv")
                       ),
                       "Provide the drug name if the drug name is unknown and the regimen is known.",
                       br(),
                       "Conversion from MAP therapy to 'Cisplatin,Doxorubicin,Methotrexate'",
                       br(),
                       br(),
                       downloadButton('download_regimen_rename', 'Download CSV template'),
                       br(),
                       br()
                ),
              ),
              hr(),
              h6("FELIS; Functions Especially for LIquid and Solid tumor clinical sequencing."),
              a(href="https://github.com/MANO-B/FELIS",h6("https://github.com/MANO-B/FELIS"))
      ),
      
      # Second tab content
      tabItem(tabName = "Setting",
              actionButton("start_setting", "Start file loading/analysis settings"),
              br(),
              hr(),
              fluidRow(
                column(3,strong("Filter on histology"),
                       hr(),
                       htmlOutput("select_histology"),
                       htmlOutput("select_histology_group_1"),
                       htmlOutput("select_histology_group_1_name"),
                       htmlOutput("select_histology_group_2"),
                       htmlOutput("select_histology_group_2_name"),
                       htmlOutput("select_histology_group_3"),
                       htmlOutput("select_histology_group_3_name"),
                       htmlOutput("select_histology_group_4"),
                       htmlOutput("select_histology_group_4_name"),
                       htmlOutput("select_minimum_pts")
                ),
                column(3,strong("Filters for clinical information"),
                       hr(),
                       htmlOutput("select_sex"),
                       h5("女: Female, 男: Male, 未入力・不明: Unknown"),
                       br(),
                       htmlOutput("select_panel"),
                       htmlOutput("select_age"),
                       htmlOutput("select_mid_age"),
                       htmlOutput("select_PS"),
                       h5("不明: Unknown"),
                       br(),
                       htmlOutput("select_smoking"),
                       h5("あり: Yes, なし: No, 不明: Unknown"),
                       br(),
                       htmlOutput("select_year")
                ),
                column(3,strong("Filters on genes"),
                       hr(),
                       htmlOutput("select_gene"),
                       htmlOutput("select_gene_group_1"),
                       htmlOutput("select_gene_group_2"),
                       htmlOutput("select_gene_group_analysis"),
                       htmlOutput("select_lolliplot_gene"),
                       htmlOutput("select_lolliplot_no"),
                       br(),
                       br(),
                       strong("Filter on mutation types"),
                       hr(),
                       strong("For detailed study of mutations of a gene"),
                       br(),
                       htmlOutput("select_special_gene"),
                       htmlOutput("select_special_gene_mutation_1"),
                       htmlOutput("select_special_gene_mutation_1_name"),
                       htmlOutput("select_special_gene_mutation_2"),
                       htmlOutput("select_special_gene_mutation_2_name"),
                       htmlOutput("select_special_gene_annotation"),
                       htmlOutput("select_special_gene_independent")
                ),
                column(3,strong("Other Settings"),
                       hr(),
                       htmlOutput("select_gene_no"),
                       htmlOutput("select_oncoprint_option"),
                       htmlOutput("select_patho"),
                       htmlOutput("select_fusion"),
                       htmlOutput("select_eps"),
                       htmlOutput("select_RMST_CGP"),
                       htmlOutput("select_RMST_drug"),
                       htmlOutput("select_target_line"),
                       htmlOutput("select_MSI"),
                       htmlOutput("select_MMR"),
                       htmlOutput("select_HER2")
                ),
              )
      ),
      tabItem(tabName = "Analysis",
              fluidRow(
                column(4,
                       strong("Standard Analysis"),
                       hr(),
                       actionButton("summary_base", "Case summary"),
                       br(),
                       br(),
                       actionButton("oncoprint", "Oncoprint"),
                       br(),
                       br(),
                       actionButton("mutually_exclusive", "Mutually exclusive or co-occurring mutation"),
                       br(),
                       br(),
                       actionButton("mut_subtype", "Mutation rate of each gene for each histology"),
                       br(),
                       br(),
                       actionButton("custering_analysis", "Clustering based on variants"),
                       br(),
                       br(),
                       actionButton("survival_CGP_analysis", "Survival analysis after CGP test"),
                       br(),
                       br(),
                       actionButton("survival_CTx_analysis", "Survival analysis after CTx induction (takes time)"),
                       br(),
                ),
                column(4,
                       strong("Drug response analysis"),
                       hr(),
                       actionButton("drug_table", "List of drugs used in Palliative CTx (1st-4th line)"),
                       br(),
                       htmlOutput("select_drug"),
                       br(),
                       htmlOutput("select_drug_group_1"),
                       br(),
                       htmlOutput("select_drug_group_1_name"),
                       br(),
                       htmlOutput("select_drug_group_2"),
                       br(),
                       htmlOutput("select_drug_group_2_name"),
                       br(),
                       htmlOutput("select_drug_group_3"),
                       br(),
                       htmlOutput("select_drug_group_3_name"),
                       br(),
                       htmlOutput("select_drug_group_4"),
                       br(),
                       htmlOutput("select_drug_group_4_name"),
                       br(),
                       actionButton("drug_analysis", "Analyze with the setting selected above"),
                       br(),
                )#,
                # column(4,
                # strong("CGP以外のbiomarkerとCGPの薬剤奏効性予測比較"),
                # hr(),
                # actionButton("extract_biomarker", "Biomarkerと薬剤を抽出"),
                # br(),
                # htmlOutput("select_biomarker_common"),
                # br(),
                # htmlOutput("select_biomarker_CGP"),
                # br(),
                # htmlOutput("select_biomarker_drug"),
                # br(),
                # actionButton("analysis_biomarker", "上記の設定で解析"),
                # br()
                # )
              ),
              hr(),
              h5("Figures in results are downloadable as png files.")
      ),
      tabItem(tabName = "Summarizedbymutationpattern",
              gt_output("table_summary_1"),
                       hr(),
                       h6(paste("Table. Characteristics for selected patients.",
                                "The present, retrospective cohort study was performed with clinicogenomic,",
                                "real-world data on the patients who were registered in the C-CAT database",
                                "from June 1, 2019. The patients were registered by hospitals throughout Japan",
                                "and provided written informed consent to the secondary use of their clinicogenomic",
                                "data for research."))
      ),
      tabItem(tabName = "Summarizedbyhistology",
              gt_output("table_summary_2"),
                       hr(),
                       h6("Table. Characteristics for selected patients.")
      ),
      tabItem(tabName = "Oncoprint",
              plotOutput('figure_oncoprint', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Recurrent oncogenic mutations in selected cases. The 30 genes with the highest frequency of oncogenic mutations are shown. Mutational landscapes were created using ComplexHeatmap package for R.")
      ),
      tabItem(tabName = "Lolliplotfortheselectedgene",
              plotOutput('figure_lolliplot2', 
                                  height = "500px",
                                  width = "1500px"),
                       hr(),
                       h6("Figure. Frequency of oncogenic mutations in the selected gene. The most frequent oncogenic mutations are shown with amino acid change."),
                       h6("Mutplot by Zhang W, PMID:31091262. If error occurs, correct 'source/UniPlot.txt'."),
                       h6("Protein structure source: Uniprot"),
                       HTML("<p>Github for Mutplot. <a href='https://github.com/VivianBailey/Mutplot'>Link for the website</a></p>")
      ),
      tabItem(tabName = "Tableofclinicalandmutationinformationperpatient",
              DT::dataTableOutput("table_patient")
      ),
      tabItem(tabName = "Mutualexclusivity",
              plotOutput('figure_mutually_exclusive', 
                                  height = "1000px",
                                  width = "1000px"),
                       hr(),
                       h6("Figure. Alterations among mutually exclusive or co-occurring pairs. The 30 genes with the highest frequency of oncogenic mutations were selected to determine whether oncogenic mutations are likely to occur simultaneously between the two genes. Blue boxes indicates mutually exclusivity and red boxes indicates co-occurrence. An asterisk shows a significant correlation (p < 0.001). Analysis was performed with Rediscover package in R language.")
      ),
      tabItem(tabName = "Variationbyhistology",
              plotOutput('figure_mut_subtype', 
                                  height = "1000px",
                                  width = "1000px"),
                       hr(),
                       h6("Figure. Recurrent oncogenic mutations across subtypes. The 30 genes with the highest frequency of oncogenic mutations were displayed.")
      ),
      tabItem("Basicdata",
              fluidRow(plotOutput('figure_base', 
                                  height = "1500px",
                                  width = "1000px"),
                       hr(),
                       h6("Figure. Distribution of age, sex, detected oncogenic mutations, tumor mutation burden (TMB), metastasis pattern, patients with treatment option recommended by the expert panel, patients received recommended chemotherapy, mediantime from the initiation date of the first palliative chemotherapy to CGP, and median time from CGP to final observation. In the boxplots of age and TMB, the box borders indicate the 25th and 75th percentiles, the inner line the median, and the whiskers 1.5× the interquartile range.")
              )
      ),
      tabItem("UMAPclusteringbasedonmutations",
              plotOutput('figure_cluster', 
                         height = "1000px",
                         width = "1200px"),
              hr(),
              h6("Figure. Unsupervised clustering of the patients based on the detected oncogenic mutations. Two-dimensional mutational pattern mapping was generated using Uniform Manifold Approximation and Projection (UMAP). The three variants and histotypes with the highest odds ratios that were more common than the other clusters at p<0.05. Clustering analysis was performed as follows. All pathogenic mutations detected by the cancer-related genes were assembled into a binary matrix format per patient. The dimension of this input matrix was reduced using Uniform Manifold Approximation and Projection (UMAP) via the umap package for R (with default hyperparameters). Clustering analysis was performed using the Hierarchical Density-Based Spatial Clustering of Applications with Noise (HDBSCAN) via the dbscan package for R (EPS: 1.0; minimum points: 3)."),
              HTML("<p>Mochizuki T, et al., Factors predictive of second-line chemotherapy in soft tissue sarcoma: An analysis of the National Genomic Profiling Database. Cancer Science, 2023. <a href='https://doi.org/10.1111/cas.16050'>Link for the paper</a></p>")
      ),
      tabItem("Clusterandagerelationship",
              plotOutput('figure_cluster_age', 
                         height = "1000px",
                         width = "1200px")
      ),
      tabItem("Clusterandhistologyrelationship",
              plotOutput('figure_cluster_subtype', 
                         height = "1000px",
                         width = "1200px")
      ),
      tabItem("Heterogeneitywithinhistologictypes",
              plotOutput('figure_entropy', 
                         height = "1000px",
                         width = "1500px"),
              hr(),
              h6("Figure. Unsupervised clustering based on oncogenic mutations. For each histology, the percentage of cases belonging to one of the clusters is shown as a bar graph. Characteristic oncogenic mutations were found in each cluster. There was a tendency for each histologic type to cluster in specific clusters. Heterogeneity of genetic variation within histologic types was assessed by Shannon's entropy.")
      ),
      tabItem("Tableofclustersandhistologies",
              DT::dataTableOutput("table_disease")
      ),
      tabItem("Tableofclustersandgeneticvariants",
              DT::dataTableOutput("table_mutation")
      ),
      tabItem("Frequencyofpatientswithtargetedtherapy",
              plotOutput('figure_drug_evidence', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Level of evidence for targeted therapy for detected gene mutations. The highest level of evidence was extracted for each patient. Evidence levels of C-CAT are defined as A for biomarkers that predict a response to Japanese Pharmaceuticals and Medical Devices Agency (PMDA)– or FDA-approved therapies or are described in professional guidelines, B for biomarkers that predict a response based on well-powered studies with consensus of experts in the field, C for biomarkers that predict a response to therapies approved by the PMDA or FDA in another type of tumor or that predict a response based on clinical studies, D for biomarkers that predict a response based on case reports, E for biomarkers that show plausible therapeutic significance based on preclinical studies.")
      ),
      tabItem("Relationshipbetweenpre-CGPandpost-CGPperiods",
              plotOutput('figure_CGP_pre_post', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Relationship between pre-CGP and post-CGP periods. Pearson's product-rate correlation coefficients, P-values, and regression lines were calculated in the R language.")
      ),
      tabItem("Patientsperhistologyandtreatmentreachrate",
              plotOutput('figure_patient_treatment', 
                         height = "2000px",
                         width = "2000px"),
              hr(),
              h6("Figure. Patients per histology and treatment reach rate. Pearson's product-rate correlation coefficients, P-values, and regression lines were calculated in the R language.")
              
      ),
      tabItem("Pre-CGPperiodandtreatmentreachrate",
              plotOutput('figure_Pre_CGP_treatment', 
                         height = "2000px",
                         width = "2000px"),
              hr(),
              h6("Figure. Pre-CGP period and treatment reach rate. Pearson's product-rate correlation coefficients, P-values, and regression lines were calculated in the R language.")
              
      ),
      tabItem("Post-CGPperiodandtreatmentreachrate",
              plotOutput('figure_Post_CGP_treatment', 
                         height = "2000px",
                         width = "2000px"),
              hr(),
              h6("Figure. Post-CGP period and treatment reach rate. Pearson's product-rate correlation coefficients, P-values, and regression lines were calculated in the R language.")
              
      ),
      tabItem("Ageandtreatmentreachrate",
              plotOutput('figure_Age_and_treatment', 
                         height = "2000px",
                         width = "2000px"),
              hr(),
              h6("Figure. Age and treatment reach rate. Pearson's product-rate correlation coefficients, P-values, and regression lines were calculated in the R language.")
      ),
      tabItem("SurvivalandtreatmentafterCGP",
              plotOutput('figure_survival_CGP_1', 
                         height = "2500px",
                         width = "1500px"),
              hr(),
              h6("Figure. Survival analysis using the conventional Kaplan–Meier estimator, log–rank test, and the Kaplan–Meier estimator with number-at-risk adjustment were undertaken with survival package for R. EP: expert panel.")
      ),
      tabItem("SurvivalafterCGPandperformancestatus",
              plotOutput('figure_survival_CGP_2', 
                         height = "3200px",
                         width = "1500px")
      ),
      tabItem("SurvivalafterCGPandprevioustreatment",
              plotOutput('figure_survival_CGP_CTx', 
                         height = "2500px",
                         width = "1500px")
      ),
      tabItem("SurvivalafterCGPandmutationsforestplot",
              plotOutput('figure_survival_CGP_3', 
                         height = "1000px",
                         width = "1200px"),
              hr(),
              h6("Figure. Suvival periods after CGP and gene mutations. Restricted mean survival time in two years were estimated with survRM2 package in R.")
      ),
      tabItem("SurvivalafterCGPandmutationsKM-curve",
              plotOutput('figure_survival_CGP_4', 
                         height = "3000px",
                         width = "1500px")
      ),
      tabItem("HazardratioforsurvivalafterCGP",
              gt_output('figure_survival_CGP_5'),
              hr(),
              h6("Table. Univariable and multiple variable regression analysis were performed with gtsummary package for R. Factors in the multivariable analysis were selected by variable decreasing method based on the Akaike information criterion with stat package for R.")
      ),
      tabItem("FactorsleadingtoTreatmentpre-CGPNomogram",
              plotOutput('figure_nomogram_treat_pre_CGP', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Based on clinical information obtained prior to CGP testing, a nomogram was developed to predict the likelihood of actually receiving treatment based on the genetic mutations after CGP. The nomogram was created with the lrm function of the rms package for R with a setting of penalty=0.1. Cox-Snell R2 was calculated with blorr package for R. Possible sampling bias was corrected with 500-time bootstrap sampilng and then concordance index was estimated.")
      ),
      tabItem("FactorsleadingtoTreatmentpost-CGPNomogram",
              plotOutput('figure_nomogram_treat_post_CGP', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Based on clinical and genetic information, a nomogram was developed to predict the likelihood of actually receiving treatment for patients with treatment options recommended by the expert panel. The nomogram was created with the lrm function of the rms package for R with a setting of penalty=0.1. Cox-Snell R2 was calculated with blorr package for R. Possible sampling bias was corrected with 500-time bootstrap sampilng and then concordance index was estimated.")
      ),
      tabItem("FactorsleadingtoTreatmentpre-CGPOddsratio",
              gt_output('figure_survival_CGP_7'),
              hr(),
              h6("Table. Univariable and multiple variable regression analysis were performed with gtsummary package for R. Factors selected in the multivariable analysis were selected by variable decreasing method based on the Akaike information criterionwith stat package for R.")
      ),
      tabItem("FactorsleadingtoTreatmentpost-CGPOddsratio",
              gt_output('figure_survival_CGP_6'),
              hr(),
              h6("Table. Univariable and multiple variable regression analysis were performed with gtsummary package for R. Factors selected in the multivariable analysis were selected by variable decreasing method based on the Akaike information criterionwith stat package for R.")
      ),
      tabItem("FactorsleadingtoTreatmentdecisioncurve",
              plotOutput('figure_DCA_pre_CGP_1', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Decision curve analysis was performed to verify the usefulness of the nomogram with dcurves package for R. Ten-fold cross-validation was performed to prevent overfitting. If the blue line is located above the other lines, then the nomogram-based decision to perform CGP testing may be worthwhile.")
      ),
      tabItem("ROCnomogram",
              plotOutput('figure_DCA_pre_CGP_ROC', 
                         height = "3000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Predicted treatment reach rate and Receiver Operatorating Characteristic curve of the nomogram using pre-CGP information by pROC package for R.")
      ),
      tabItem("preCGPMachinelearning",
              plotOutput('figure_DCA_pre_CGP_Machine_learning', 
                         height = "2500px",
                         width = "1000px"),
              hr(),
              h6("Figure. Predicted treatment reach rate with Random forest and LightGBM models using pre-CGP information by tidymodels package for R. Generalized additive model was used for calibration. 10-fold cross validation was performed.")
      ),
      
      tabItem("FactorsleadingtoTreatmenttable",
              gt_output('table_DCA_pre_CGP_2')
      ),
      tabItem(tabName = "Table_prediction",
              DT::dataTableOutput("table_prediction")
      ),
      tabItem(tabName = "Input_data",
              actionButton("predict_nomogram_setting", "Start prediction setting"),
              br(),
              hr(),
              fluidRow(
                column(4,strong("Clinical information"),
                       hr(),
                       htmlOutput("input_age"),
                       htmlOutput("input_sex"),
                       htmlOutput("input_PS"),
                       htmlOutput("input_Lines"),
                       htmlOutput("input_organ"),
                       htmlOutput("input_Panel"),
                       br(),
                       hr()
                ),
                column(4,strong("Metastasis information"),
                       hr(),
                       htmlOutput("input_Lymph_met"),
                       htmlOutput("input_Brain_met"),
                       htmlOutput("input_Lung_met"),
                       htmlOutput("input_Bone_met"),
                       htmlOutput("input_Liver_met")
                ),
              ),
              br(),
              hr(),
              br(),
              actionButton("start_prediction", "Start prediction"),
              hr(),
              verbatimTextOutput("prediction_nomogram"),
              br(),
              br(),
              hr()
      ),
      tabItem("Survivalcorrectedforleft-truncationbias",
              plotOutput('figure_survival_CTx_1', 
                         height = "2500px",
                         width = "1500px"),
              hr(),
              h6(paste0("Figure. Overall survival after the first survival-prolonging chemotherapy after adjusting for left-truncation bias. To evaluate the association between oncogenic mutations and survival, a Bayesian survival simulation based on a semi-independent, two-hit model was performed to adjust for left-truncation bias. ",
                        "Two survival curves from the date of commencement of chemotherapy for prolonging survival to the date of CGP and from the CGP testing date to the date of death were fitted with Weibull distribution and log-logistic distribution, respectively. The overall survival curve from the first SPT was approximated by merging these survival curves. ",
                        "Survival curves were obtained from each of the 8000 iterations of inference, and the median survival and 95% equal-tailed CIs were calculated. Bayesian inference was performed with the rstan package for R. P value of conditional Kendall tau statistics was calculated, and the survival curves were adjusted for length bias, using a structural transformation method with tranSurv package for R.")),
              HTML("<p>Tamura T, et al., Selection bias due to delayed comprehensive genomic profiling in Japan. Cancer Science, 2022. <a href='https://doi.org/10.1111/cas.15651'>Link for the paper</a></p>")
      ),
      tabItem("Geneticvariantsandsurvivalforestplot",
              plotOutput('figure_survival_CTx_2', 
                         height = "1000px",
                         width = "1000px")
      ),
      tabItem("GeneticvariantsandsurvivalKM-curve",
              plotOutput('figure_survival_CTx_3', 
                         height = "3600px",
                         width = "1500px"),
              hr(),
              h6("Figure. Overall survival after the first survival-prolonging chemotherapy after adjusting for left-truncation bias. To evaluate the association between oncogenic mutations and survival, a Bayesian survival simulation based on a semi-independent, two-hit model was performed to adjust for left-truncation bias. Two survival curves from the date of commencement of chemotherapy for prolonging survival to the date of CGP and from the CGP testing date to the date of death were fitted with Weibull distribution and log-logistic distribution, respectively. The overall survival curve from the first SPT was approximated by merging these survival curves. Survival curves were obtained from each of the 8000 iterations of inference, and the median survival and 95% equal-tailed CIs were calculated. Bayesian inference was performed with the rstan package for R."),
              HTML("<p>Tamura T, et al., Selection bias due to delayed comprehensive genomic profiling in Japan. Cancer Science, 2022. <a href='https://doi.org/10.1111/cas.15651'></a>!</p>")
      ),
      tabItem("Drugusebylineoftreatment",
              gt_output("table_drug_all_1")
      ),
      tabItem("Drugusebytreatmenteffect",
              gt_output("table_drug_all_2")
      ),
      tabItem("Useofdesignatedlineagentsbymutationpattern",
              gt_output("table_drug_line_1")
      ),
      tabItem("Useofdesignatedlineagentsbyhistology",
              gt_output("table_drug_line_2")
      ),
      tabItem("Useofdesignatedlineagentsbymutatedgenes",
              gt_output("table_drug_line_3")
      ),
      tabItem("UseofdesignatedlinesanddrugswithToTinformationbymutationpattern",
              gt_output("table_drug_ToT_1")
      ),
      tabItem("UseofdesignatedlinesanddrugswithToTinformationbyhistology",
              gt_output("table_drug_ToT_2")
      ),
      tabItem("UseofdesignatedlinesanddrugswithToTinformationbymutatedgenes",
              gt_output("table_drug_ToT_3")
      ),
      tabItem("UseofdesignatedlinesanddrugswithRECISTinformationbymutationpattern",
              gt_output("table_drug_RECIST_1")
      ),
      tabItem("UseofdesignatedlinesanddrugswithRECISTinformationbyhistology",
              gt_output("table_drug_RECIST_2")
      ),
      tabItem("UseofdesignatedlinesanddrugswithRECISTinformationbymutatedgenes",
              gt_output("table_drug_RECIST_3")
      ),
      tabItem("Timeontreatmentandpre-treatmentforthespecifiedtreatmentscatterplot",
              plotOutput('figure_drug_1', 
                         height = "2500px",
                         width = "1500px")
      ),
      tabItem("Timeontreatmentandpre-treatmentforthespecifiedtreatmentKM-curve",
              plotOutput('figure_drug_2', 
                         height = "3200px",
                         width = "1500px")
      ),
      tabItem("TimeontreatmentbytissuetypeKM-curve",
              plotOutput('figure_drug_3', 
                         height = "2500px",
                         width = "1500px")
      ),
      tabItem("TimeontreatmentbygenemutationclusterKM-curve",
              plotOutput('figure_drug_cluster', 
                         height = "2500px",
                         width = "1500px")
      ),
      tabItem("Timeontreatmentbymutatedgenesforestplot",
              plotOutput('figure_drug_4', 
                         height = "3000px",
                         width = "1500px")
      ),
      tabItem("TimeontreatmentbymutatedgenesKM-curve",
              plotOutput('figure_drug_5', 
                         height = "2500px",
                         width = "1500px")
      ),
      tabItem("TimeontreatmentandmutationsofinterestKM-curve",
              plotOutput('figure_drug_pattern', 
                         height = "2500px",
                         width = "1500px")
      ),
      tabItem("Hazardratioontimeontreatment",
              gt_output('figure_drug_6'),
              hr(),
              h6("Table. Univariable and multiple variable regression analysis were performed with gtsummary package for R. Factors selected in the multivariable analysis were selected by variable decreasing method based on the Akaike information criterionwith stat package for R.")
      ),
      tabItem("Oddsratioonobjectiveresponserate",
              gt_output('figure_drug_7'),
              hr(),
              h6("Table. Univariable and multiple variable regression analysis were performed with gtsummary package for R. Factors selected in the multivariable analysis were selected by variable decreasing method based on the Akaike information criterionwith stat package for R."),
              h6("Objective response: CR or PR.")
      ),
      tabItem("Oddsratioondiseasecontrolrate",
              gt_output('figure_drug_8'),
              hr(),
              h6("Table. Univariable and multiple variable regression analysis were performed with gtsummary package for R. Factors selected in the multivariable analysis were selected by variable decreasing method based on the Akaike information criterionwith stat package for R."),
              h6("Disease control: CR, PR, or SD.")
      ),
      tabItem("MutationclusteringandRECIST",
              DT::dataTableOutput("table_outcome_cluster"),
              hr(),
              h6("95% confidence intervals were calculated using the Clopper-Pearson method.")
      ),
      tabItem("MutationpatternandRECIST",
              DT::dataTableOutput("table_outcome_1"),
              hr(),
              h6("95% confidence intervals were calculated using the Clopper-Pearson method.")
      ),
      tabItem("HistologyandRECIST",
              DT::dataTableOutput("table_outcome_2"),
              hr(),
              h6("95% confidence intervals were calculated using the Clopper-Pearson method.")
      ),
      tabItem("MutatedgenesandRECIST",
              DT::dataTableOutput("table_outcome_3"),
              hr(),
              h6("95% confidence intervals were calculated using the Clopper-Pearson method.")
      ),
      tabItem("Instruction",
              includeMarkdown("www/README.md")
      )
    )
  )
)

  
# Define server logic required to draw a histogram
server <- function(input, output, session) {
  Data_case_raw =  reactive({
    withProgress(message = "Clinical data loading.", {
      Encode = guess_encoding(input$clinical_files[[1, 'datapath']])[[1]][[1]]
      if(Encode == "Shift_JIS"){
        Encode = "CP932"
      }
      clin_tmp <- read_csv(col_names = TRUE,
                           file = input$clinical_files$datapath,
                           locale = locale(encoding=Encode),
                           num_threads=max(1, parallel::detectCores() - 1, na.rm = TRUE),
                           progress=FALSE,
                           name_repair=make.names,
                           col_types = cols(
                             症例.管理情報.登録日 = col_character(),
                             症例.転帰情報.最終生存確認日 = col_character(),
                             症例.転帰情報.死亡日 = col_character(),
                             症例.背景情報.ECOG.PS.名称. = col_character(),
                             症例.基本情報.症例関係区分 = col_integer(),
                             症例.基本情報.症例関係区分.名称. = col_character(),
                             症例.背景情報.発症年齢 = col_integer(),
                             症例.EP前レジメン情報.投与開始日 = col_character(),
                             症例.EP後レジメン情報.投与開始日 = col_character(),
                             症例.EP前レジメン情報.投与終了日 = col_character(),
                             症例.EP後レジメン情報.投与終了日 = col_character(),
                             症例.EP後レジメン情報.エキスパートパネル開催日 = col_character(),
                             症例.背景情報.診断日 = col_character(),
                             症例.管理情報.登録日 = col_character(),
                             症例.転帰情報.最終生存確認日 = col_character(),
                             症例.転帰情報.死亡日 = col_character(),
                             症例.症例CGP後がん種情報.がん種区分 = col_character(),
                             症例.症例CGP後がん種情報.がん種区分.名称. = col_character(),
                             症例.症例CGP後がん種情報.がん種.OncoTree. = col_character(),
                             症例.症例CGP後がん種情報.がん種.OncoTree..名称. = col_character(),
                             症例.症例CGP後がん種情報.がん種区分_OncoTree.ver = col_character(),
                             症例.症例CGP後がん種情報.がん種.OncoTree.LEVEL1. = col_character(),
                             症例.症例CGP後がん種情報.がん種.OncoTree.LEVEL1..名称. = col_character(),
                             症例.がん種情報.肺.EGFR.名称. = col_character(),
                             症例.基本情報.がん種区分その他= col_character(),
                             症例.背景情報.重複がん.その他 = col_character(),
                             症例.背景情報.既知の遺伝性疾患名.その他. = col_character(),
                             症例.検体情報.検体種別.その他. = col_character(),
                             症例.がん種情報.肝.HCV抗体.名称. = col_character(),
                             症例.がん種情報.肝.HBs抗体.名称. = col_character(),
                             症例.がん種情報.肝.HBsAg.名称.= col_character(),
                             症例.がん種情報.食道.胃.腸.BRAF.V600..検査方法.名称. = col_character(),
                             症例.がん種情報.肺.PD.L1.IHC..名称.= col_character(),
                             症例.がん種情報.肺.アスベスト曝露歴.名称. = col_character(),
                             症例.がん種情報.肺.陽性率 = col_character(),
                             症例.がん種情報.肺.ROS1.検査方法.名称. = col_character(),
                             症例.がん種情報.肺.ROS1.名称. = col_character(),
                             症例.がん種情報.肺.ALK.検査方法.名称. = col_character(),
                             症例.がん種情報.肺.EGFR.検査方法.名称. = col_character(),
                             症例.がん種情報.肺.EGFR.検査方法 = col_character(),
                             症例.がん種情報.肺.PD.L1.IHC..検査方法 = col_character(),
                             症例.がん種情報.肺.PD.L1.IHC..検査方法.名称. = col_character(),
  
                             症例.検体情報.解析不良の理由.名称. = col_character(),
                             症例.検体情報.原発臓器 = col_character(),
                             症例.検体情報.病理診断名 = col_character(),
                             症例.がん種情報.固形がん.ミスマッチ修復機能欠損.検査方法.名称. = col_character(),
                             症例.がん種情報.乳.HER2.IHC..名称. = col_character(),
                             症例.がん種情報.乳.HER2.FISH..名称. = col_character(),
                             症例.がん種情報.乳.ER.名称. = col_character(),
                             症例.がん種情報.乳.PgR.名称. = col_character(),
                             症例.がん種情報.乳.gBRCA1.名称. = col_character(),
                             症例.がん種情報.乳.gBRCA1.検査方法.名称. = col_character(),
                             症例.がん種情報.乳.gBRCA2.名称. = col_character(),
                             症例.EP前副作用情報.CTCAEv5.0コード = col_character(),
                             症例.がん種情報.皮膚.BRAF遺伝.変異.名称. = col_character(),
                             症例.EP後レジメン情報.不明.名称. = col_character(),
                             症例.基本情報.がん種区分.名称. = col_character(),
                             症例.基本情報.がん種.OncoTree..名称. = col_character(),
                             症例.基本情報.がん種.OncoTree. = col_character(),
                             症例.基本情報.がん種区分 = col_character(),
                             症例.背景情報.重複がん.部位 = col_character(),
                             症例.背景情報.重複がん.部位.名称. = col_character(),
                             症例.EP前レジメン情報.薬剤状況.名称. = col_character(),
                             症例.EP後レジメン情報.薬剤状況.名称. = col_character(),
                             症例.がん種情報.肝.HCV.RNA = col_character(),
                             症例.背景情報.家族歴.罹患年齢 = col_character(),
                             症例.がん種情報.肺.ALK融合.名称. = col_character(),
                             症例.がん種情報.肺.BRAF.V600..名称. = col_character(),
                             症例.背景情報.既知の遺伝性疾患名.名称. = col_character(),
                             症例.がん種情報.肺.アスベスト曝露歴.名称. = col_character(),
                             症例.がん種情報.肺.EGFR.TKI耐性後EGFR.T790M.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.KRAS.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.KRAS.type = col_character(),
                             症例.がん種情報.食道.胃.腸.KRAS.type.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.KRAS.検査方法.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.NRAS.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.NRAS.type = col_character(),
                             症例.がん種情報.食道.胃.腸.NRAS.type.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.NRAS.検査方法.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.HER2.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.BRAF.V600..名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.BRAF.V600..検査方法.名称. = col_character(),
                             症例.がん種情報.食道.胃.腸.EGFR.IHC. = col_character(),
                             症例.がん種情報.食道.胃.腸.EGFR.IHC..名称. = col_character(),
                             症例.EP後副作用情報.CTCAEv5.0コード = col_character(),
                             症例.検体情報.検体採取方法.その他. = col_character(),
                             症例.がん種情報.唾液腺.HER2遺伝子増幅度.検査方法.名称. = col_character(),
                             症例.がん種情報.唾液腺.HER2遺伝子増幅度.検査方法 = col_character(),
                             症例.がん種情報.唾液腺.HER2遺伝子増幅度.名称. = col_character(),
                             症例.がん種情報.唾液腺.HER2遺伝子増幅度 = col_character(),
                             症例.がん種情報.唾液腺.HER2タンパク = col_character(),
                             症例.がん種情報.唾液腺.HER2タンパク.名称. = col_character(),
                             症例.がん種情報.唾液腺.HER2タンパク.検査方法 = col_character(),
                             症例.がん種情報.唾液腺.HER2タンパク.検査方法.名称. = col_character(),
                             症例.がん種情報.甲状腺.RET融合遺伝子 = col_character(),
                             症例.がん種情報.甲状腺.RET融合遺伝子.名称. = col_character(),
                             症例.がん種情報.甲状腺.RET融合遺伝子.検査方法 = col_character(),
                             症例.がん種情報.甲状腺.RET融合遺伝子.検査方法.名称. = col_character(),
                             症例.がん種情報.甲状腺.RET遺伝子変異 = col_character(),
                             症例.がん種情報.甲状腺.RET遺伝子変異.名称. = col_character(),
                             症例.がん種情報.甲状腺.RET遺伝子変異.検査方法 = col_character(),
                             症例.がん種情報.甲状腺.RET遺伝子変異.検査方法.名称. = col_character(),
                             症例.がん種情報.胆道.FGFR2融合遺伝子 = col_character(),
                             症例.がん種情報.胆道.FGFR2融合遺伝子.名称. = col_character(),
                             症例.がん種情報.胆道.FGFR2融合遺伝子.検査方法 = col_character(),
                             症例.がん種情報.胆道.FGFR2融合遺伝子.検査方法.名称. = col_character(),
                             症例.がん種情報.膵臓.gBRCA1 = col_character(),
                             症例.がん種情報.膵臓.gBRCA1.名称. = col_character(),
                             症例.がん種情報.膵臓.gBRCA1.検査方法 = col_character(),
                             症例.がん種情報.膵臓.gBRCA1.検査方法.名称. = col_character(),
                             症例.がん種情報.膵臓.gBRCA2 = col_character(),
                             症例.がん種情報.膵臓.gBRCA2.名称. = col_character(),
                             症例.がん種情報.膵臓.gBRCA2.検査方法 = col_character(),
                             症例.がん種情報.固形がん.NTRK1.2.3融合遺伝子.検査方法.名称. = col_character(),
                             症例.がん種情報.固形がん.NTRK1.2.3融合遺伝子.検査方法 = col_character(),
                             症例.がん種情報.固形がん.NTRK1.2.3融合遺伝子.名称. = col_character(),
                             症例.がん種情報.固形がん.NTRK1.2.3融合遺伝子 = col_character(),
                             症例.がん種情報.固形がん.マイクロサテライト不安定性.名称. = col_character(),
                             症例.がん種情報.固形がん.マイクロサテライト不安定性.検査方法 = col_character(),
                             症例.がん種情報.固形がん.ミスマッチ修復機能欠損.名称. = col_character(),
                             症例.がん種情報.固形がん.マイクロサテライト不安定性.検査方法.名称. = col_character(),
                             症例.がん種情報.固形がん.腫瘍遺伝子変異量.検査方法 = col_character(),
                             症例.がん種情報.固形がん.腫瘍遺伝子変異量.検査方法.名称. = col_character(),
                             症例.EP前レジメン情報.Grade3以上有害事象の有無.名称. = col_character(),
                             症例.EP前レジメン情報.中止に至った有害事象名.日本語. = col_character(),
                             症例.EP前レジメン情報.中止に至った有害事象名.英語. = col_character(),
                             症例.EP前レジメン情報.中止に至った有害事象名.CTCAEv5.0コード. = col_character(),
                             症例.EP前レジメン情報.最悪Grade = col_character(),
                             症例.EP前レジメン情報.最悪Grade.名称. = col_character(),
                             症例.EP前レジメン情報.不明 = col_character(),
                             症例.EP前レジメン情報.不明.名称. = col_character(),
                             症例.がん種情報.肺.EGFR.type = col_character(),
                             症例.がん種情報.肺.KRAS.G12C遺伝子変異.検査方法 = col_character(),
                             症例.がん種情報.肺.KRAS.G12C遺伝子変異.検査方法.名称. = col_character(),
                             症例.がん種情報.肺.RET融合遺伝子.検査方法 = col_character(),
                             症例.がん種情報.肺.RET融合遺伝子.検査方法.名称. = col_character(),
                             症例.EP後レジメン情報.中止に至った有害事象名.日本語. = col_character(),
                             症例.EP後レジメン情報.中止に至った有害事象名.英語. = col_character(),
                             症例.EP後レジメン情報.中止に至った有害事象名.CTCAEv5.0コード. = col_character(),
                             症例.EP後レジメン情報.最悪Grade = col_character(),
                             症例.EP後レジメン情報.最悪Grade.名称. = col_character(),
                             症例.がん種情報.肝.HBV.DNA = col_character(),
                             症例.がん種情報.皮膚.BRAF遺伝子変異.検査方法 = col_character(),
                             症例.がん種情報.皮膚.BRAF遺伝子変異.検査方法.名称. = col_character(),
                             症例.がん種情報.皮膚.BRAF.type = col_character(),
                             症例.がん種情報.皮膚.BRAF.type.名称. = col_character(),
                             症例.がん種情報.前立腺.gBRCA1.名称. = col_character(),
                             症例.がん種情報.前立腺.gBRCA1 = col_character(),
                             症例.がん種情報.前立腺.gBRCA1.検査方法 = col_character(),
                             症例.がん種情報.前立腺.gBRCA1.検査方法.名称. = col_character(),
                             症例.がん種情報.前立腺.gBRCA2 = col_character(),
                             症例.がん種情報.前立腺.gBRCA2.名称. = col_character(),
                             症例.がん種情報.前立腺.gBRCA2.検査方法 = col_character(),
                             症例.がん種情報.前立腺.gBRCA2.検査方法.名称. = col_character(),
                             症例.がん種情報.卵巣卵管.gBRCA1 = col_character(),
                             症例.がん種情報.卵巣卵管.gBRCA1.名称. = col_character(),
                             症例.がん種情報.卵巣卵管.gBRCA1.検査方法 = col_character(),
                             症例.がん種情報.卵巣卵管.gBRCA1.検査方法.名称. = col_character(),
                             症例.がん種情報.卵巣卵管.gBRCA2 = col_character(),
                             症例.がん種情報.卵巣卵管.gBRCA2.名称. = col_character(),
                             症例.がん種情報.卵巣卵管.gBRCA2.検査方法 = col_character(),
                             症例.がん種情報.卵巣卵管.gBRCA2.検査方法.名称. = col_character(),
                             症例.がん種情報.卵巣卵管.相同組換え修復欠損 = col_character(),
                             症例.がん種情報.卵巣卵管.相同組換え修復欠損.名称. = col_character(),
                             症例.がん種情報.卵巣卵管.相同組換え修復欠損.検査方法 = col_character(),
                             症例.がん種情報.卵巣卵管.相同組換え修復欠損.検査方法.名称. = col_character(),
                             症例.がん種情報.固形がん.腫瘍遺伝子変異量 = col_character(),
                             症例.背景情報.臨床診断名 = col_character(),
                             症例.がん種情報.固形がん.腫瘍遺伝子変異量.名称. = col_character(),
                             症例.EP後レジメン情報.初回投与量 = col_character(),
                             症例.EP後レジメン情報.前治療継続の有無.名称. = col_character(),
                             症例.EP後レジメン情報.提示された治療薬とは異なる薬剤の投与有無 = col_character(),
                             症例.EP後レジメン情報.提示された治療薬とは異なる薬剤の投与有無.名称. = col_character(),
                             
                             症例.がん種情報.肺.EGFR = col_integer(),
                             症例.がん種情報.肺.ALK融合 = col_integer(),
                             症例.がん種情報.肺.ROS1 = col_integer(),
                             症例.がん種情報.肝.HCV抗体 = col_integer(),
                             症例.がん種情報.肝.HBs抗体 = col_integer(),
                             症例.がん種情報.肝.HBsAg = col_integer(),
                             症例.がん種情報.食道.胃.腸.BRAF.V600..検査方法 = col_integer(),
                             症例.がん種情報.肺.PD.L1.IHC. = col_integer(),
                             症例.がん種情報.肺.アスベスト曝露歴 = col_integer(),
                             症例.がん種情報.肺.ROS1.検査方法 = col_integer(),
                             症例.がん種情報.肺.ALK.検査方法 = col_integer(),
                             症例.背景情報.既知の遺伝性疾患名 = col_integer(),
                             症例.検体情報.解析不良の理由 = col_integer(),
                             症例.がん種情報.固形がん.ミスマッチ修復機能欠損.検査方法 = col_integer(),
                             症例.がん種情報.乳.HER2.IHC. = col_integer(),
                             症例.がん種情報.乳.HER2.FISH. = col_integer(),
                             症例.がん種情報.乳.ER = col_integer(),
                             症例.がん種情報.乳.PgR = col_integer(),
                             症例.がん種情報.乳.gBRCA1 = col_integer(),
                             症例.がん種情報.乳.gBRCA1.検査方法 = col_integer(),
                             症例.がん種情報.乳.gBRCA2 = col_integer(),
                             症例.がん種情報.皮膚.BRAF遺伝.変異 = col_integer(),
                             症例.EP後レジメン情報.不明 = col_integer(),
                             症例.EP前レジメン情報.薬剤状況 = col_integer(),
                             症例.がん種情報.肺.BRAF.V600. = col_integer(),
                             症例.がん種情報.肺.EGFR.TKI耐性後EGFR.T790M = col_integer(),
                             症例.がん種情報.食道.胃.腸.KRAS = col_integer(),
                             症例.がん種情報.食道.胃.腸.KRAS.検査方法 = col_integer(),
                             症例.がん種情報.食道.胃.腸.NRAS = col_integer(),
                             症例.がん種情報.食道.胃.腸.NRAS.検査方法 = col_integer(),
                             症例.がん種情報.食道.胃.腸.HER2 = col_integer(),
                             症例.がん種情報.食道.胃.腸.BRAF.V600. = col_integer(),
                             症例.がん種情報.固形がん.マイクロサテライト不安定性 = col_integer(),
                             症例.がん種情報.固形がん.ミスマッチ修復機能欠損 = col_integer(),
                             .default = col_guess()
                           ),
                           show_col_types=FALSE)
      incProgress(1 / 4)
      clin_tmp = as.data.frame(clin_tmp)
      clin_tmp$症例.背景情報.ECOG.PS.名称. = as.character(clin_tmp$症例.背景情報.ECOG.PS.名称.)
      clin_tmp$症例.基本情報.がん種.OncoTree..名称. = 
        str_split(str_replace(clin_tmp$症例.基本情報.がん種.OncoTree..名称.,
                              "\\)_", "\\)__"), "__", simplify = TRUE)[,1]
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          str_detect(症例.基本情報.がん種.OncoTree..名称., paste0(" \\(", 症例.基本情報.がん種.OncoTree.LEVEL1., "\\)")) ~ 症例.基本情報.がん種.OncoTree.LEVEL1.,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        ))
      
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.背景情報.ECOG.PS.名称. = case_when(
          is.na(症例.背景情報.ECOG.PS.名称.) ~ "不明",
          症例.背景情報.ECOG.PS.名称. == "" ~ "不明",
          TRUE ~ 症例.背景情報.ECOG.PS.名称.
        )
      )
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.性別.名称. = case_when(
          is.na(症例.基本情報.性別.名称.) ~ "未入力・不明",
          症例.基本情報.性別.名称. == "" ~ "未入力・不明",
          TRUE ~ 症例.基本情報.性別.名称.
        )
      )
      if(!is.null(input$ID_histology)){
        ID_histology_list = data.frame(NULL)
        for(i in 1:length(input$ID_histology[,1])){
          ID_histology_list <- rbind(ID_histology_list,
                            read.csv(header = TRUE,
                              file(input$ID_histology[[i, 'datapath']],
                                   encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.基本情報.がん種.OncoTree..名称._tmp = unlist(lapply(list(clin_tmp$C.CAT調査結果.基本項目.ハッシュID), function(x) {
          as.vector(ID_histology_list$Histology[match(x, ID_histology_list$ID)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.基本情報.がん種.OncoTree..名称. = case_when(
            !is.na(症例.基本情報.がん種.OncoTree..名称._tmp) ~ 症例.基本情報.がん種.OncoTree..名称._tmp,
            TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
          )
        )
      }
      if(!is.null(input$regimen_rename)){
        RenList = data.frame(NULL)
        for(i in 1:length(input$regimen_rename[,1])){
          RenList <- rbind(RenList,
                           read.csv(header = TRUE,
                                    file(input$regimen_rename[[i, 'datapath']],
                                         encoding='UTF-8-BOM')))
        }
        for(i in 1:length(RenList$P1)){
          clin_tmp = clin_tmp %>% dplyr::mutate(
            症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = case_when(
              症例.EP前レジメン情報.薬剤名.YJ一般名.EN. == "" &
                症例.EP前レジメン情報.化学療法レジメン名称 == RenList$P1[i] ~ RenList$P2[i],
              TRUE ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN.
            ))
        }
      }
      if(!is.null(input$drug_rename)){
        drug_rename_list = data.frame(NULL)
        for(i in 1:length(input$drug_rename[,1])){
          drug_rename_list <- rbind(drug_rename_list,
                                     read.csv(header = TRUE,
                                       file(input$drug_rename[[i, 'datapath']],
                                            encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp = unlist(lapply(list(clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN.), function(x) {
          as.vector(drug_rename_list$Rename[match(x, drug_rename_list$Drug)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = case_when(
            !is.na(症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp) ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp,
            TRUE ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN.
          )
        )
      }
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          is.na(症例.基本情報.がん種.OncoTree..名称.) ~ 症例.基本情報.がん種.OncoTree.LEVEL1.,
          症例.基本情報.がん種.OncoTree..名称. == "" ~ 症例.基本情報.がん種.OncoTree.LEVEL1.,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
      if(!is.null(input$histology_rename)){
        histology_rename_list = data.frame(NULL)
        for(i in 1:length(input$histology_rename[,1])){
          histology_rename_list <- rbind(histology_rename_list,
                                         read.csv(header = TRUE,
                                           file(input$histology_rename[[i, 'datapath']],
                                                encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.基本情報.がん種.OncoTree..名称._tmp = unlist(lapply(list(clin_tmp$症例.基本情報.がん種.OncoTree..名称.), function(x) {
          as.vector(histology_rename_list$Rename[match(x, histology_rename_list$Histology)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.基本情報.がん種.OncoTree..名称. = case_when(
            !is.na(症例.基本情報.がん種.OncoTree..名称._tmp) ~ 症例.基本情報.がん種.OncoTree..名称._tmp,
            TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
          )
        )
      }
      
  
      clin_tmp$症例.背景情報.重複がん有無.異なる臓器..名称.[is.na(clin_tmp$症例.背景情報.重複がん有無.異なる臓器..名称.)] = "不明"
      clin_tmp$症例.背景情報.多発がん有無.同一臓器..名称.[is.na(clin_tmp$症例.背景情報.多発がん有無.同一臓器..名称.)] = "不明"
      clin_tmp$症例.背景情報.喫煙歴有無.名称.[is.na(clin_tmp$症例.背景情報.喫煙歴有無.名称.)] = ""
      clin_tmp$症例.背景情報.ECOG.PS.名称.[is.na(clin_tmp$症例.背景情報.ECOG.PS.名称.)] = ""
      clin_tmp$症例.検体情報.パネル.名称.[is.na(clin_tmp$症例.検体情報.パネル.名称.)] = ""
      clin_tmp$症例.がん種情報.登録時転移部位.名称.[is.na(clin_tmp$症例.がん種情報.登録時転移部位.名称.)] = ""
      clin_tmp$症例.転帰情報.死亡日[is.na(clin_tmp$症例.転帰情報.死亡日)] = ""
      clin_tmp$症例.転帰情報.最終生存確認日[is.na(clin_tmp$症例.転帰情報.最終生存確認日)] = ""
      clin_tmp$症例.管理情報.登録日[is.na(clin_tmp$症例.管理情報.登録日)] = ""
      clin_tmp$症例.EP前レジメン情報.投与開始日[is.na(clin_tmp$症例.EP前レジメン情報.投与開始日)] = ""
      clin_tmp$症例.EP前レジメン情報.投与終了日[is.na(clin_tmp$症例.EP前レジメン情報.投与終了日)] = ""
      clin_tmp$症例.EP後レジメン情報.投与開始日[is.na(clin_tmp$症例.EP後レジメン情報.投与開始日)] = ""
      clin_tmp$症例.EP後レジメン情報.投与終了日[is.na(clin_tmp$症例.EP後レジメン情報.投与終了日)] = ""
      clin_tmp$症例.管理情報.登録日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.管理情報.登録日)
      clin_tmp$症例.転帰情報.最終生存確認日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.転帰情報.最終生存確認日)
      clin_tmp$症例.転帰情報.死亡日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.転帰情報.死亡日)
      clin_tmp$症例.検体情報.検体採取日.腫瘍組織. = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.検体情報.検体採取日.腫瘍組織.)
      clin_tmp$症例.EP前レジメン情報.投与開始日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP前レジメン情報.投与開始日)
      clin_tmp$症例.EP後レジメン情報.投与開始日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP後レジメン情報.投与開始日)
      clin_tmp$症例.EP前レジメン情報.投与終了日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP前レジメン情報.投与終了日)
      clin_tmp$症例.EP後レジメン情報.投与終了日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP後レジメン情報.投与終了日)
      clin_tmp$症例.EP後レジメン情報.エキスパートパネル開催日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP後レジメン情報.エキスパートパネル開催日)
      clin_tmp$症例.背景情報.診断日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.背景情報.診断日)
      clin_tmp$症例.管理情報.登録日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.管理情報.登録日)
      clin_tmp$症例.転帰情報.最終生存確認日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.転帰情報.最終生存確認日)
      clin_tmp$症例.転帰情報.死亡日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.転帰情報.死亡日)
      clin_tmp$症例.検体情報.検体採取日.腫瘍組織. = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.検体情報.検体採取日.腫瘍組織.)
      clin_tmp$症例.EP前レジメン情報.投与開始日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.EP前レジメン情報.投与開始日)
      clin_tmp$症例.EP後レジメン情報.投与開始日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.EP後レジメン情報.投与開始日)
      clin_tmp$症例.EP前レジメン情報.投与終了日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.EP前レジメン情報.投与終了日)
      clin_tmp$症例.EP後レジメン情報.投与終了日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.EP後レジメン情報.投与終了日)
      clin_tmp$症例.EP後レジメン情報.エキスパートパネル開催日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.EP後レジメン情報.エキスパートパネル開催日)
      clin_tmp$症例.背景情報.診断日 = str_replace_all(replacement = "_", pattern = "/", string = clin_tmp$症例.背景情報.診断日)
      clin_tmp$症例.基本情報.年齢 = as.integer(clin_tmp$症例.基本情報.年齢)
      incProgress(1 / 4)
      
      clin_tmp$症例.基本情報.がん種.OncoTree..名称. = 
        str_split(str_replace(clin_tmp$症例.基本情報.がん種.OncoTree..名称.,
                              "\\)_", "\\)__"), "__", simplify = TRUE)[,1]
      if(!is.null(input$ID_histology)){
        ID_histology_list = data.frame(NULL)
        for(i in 1:length(input$ID_histology[,1])){
          ID_histology_list <- rbind(ID_histology_list,
                                     read.csv(header = TRUE,
                                              file(input$clinical_files[[i, 'datapath']],
                                                   encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.基本情報.がん種.OncoTree..名称._tmp = unlist(lapply(list(clin_tmp$症例.基本情報.がん種.OncoTree..名称.), function(x) {
          as.vector(ID_histology_list$Histology[match(x, ID_histology_list$ID)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.基本情報.がん種.OncoTree..名称. = case_when(
            !is.na(症例.基本情報.がん種.OncoTree..名称._tmp) ~ 症例.基本情報.がん種.OncoTree..名称._tmp,
            TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
          )
        )
      }
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. == "" ~ 症例.基本情報.がん種.OncoTree.LEVEL1.,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree. == "" ~ 症例.基本情報.がん種.OncoTree.LEVEL1.,
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        )
      )
      if(!is.null(input$histology_rename)){
        histology_rename_list = data.frame(NULL)
        for(i in 1:length(input$histology_rename[,1])){
          histology_rename_list <- rbind(histology_rename_list,
                                         read.csv(header = TRUE,
                                                  file(input$histology_rename[[i, 'datapath']],
                                                       encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.基本情報.がん種.OncoTree..名称._tmp = unlist(lapply(list(clin_tmp$症例.基本情報.がん種.OncoTree..名称.), function(x) {
          as.vector(histology_rename_list$Rename[match(x, histology_rename_list$Histology)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.基本情報.がん種.OncoTree..名称. = case_when(
            !is.na(症例.基本情報.がん種.OncoTree..名称._tmp) ~ 症例.基本情報.がん種.OncoTree..名称._tmp,
            TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
          )
        )
      }
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = str_replace(str_replace(症例.基本情報.がん種.OncoTree..名称., "\\)", ""), ".*\\(","")
      )
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.背景情報.アルコール多飲有無.名称. = case_when(
          is.na(症例.背景情報.アルコール多飲有無.名称.) ~ "不明",
          症例.背景情報.アルコール多飲有無.名称. == "" ~ "不明",
          TRUE ~ 症例.背景情報.アルコール多飲有無.名称.
        ),
        症例.背景情報.重複がん有無.異なる臓器..名称. = case_when(
          症例.背景情報.重複がん有無.異なる臓器..名称. == "" ~ "不明",
          TRUE ~ 症例.背景情報.重複がん有無.異なる臓器..名称.
        ),
        症例.背景情報.多発がん有無.同一臓器..名称. = case_when(
          症例.背景情報.多発がん有無.同一臓器..名称. == "" ~ "不明",
          TRUE ~ 症例.背景情報.多発がん有無.同一臓器..名称.
        ),
        症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. = case_when(
          is.na(症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.) ~ "いいえ",
          症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. == "" ~ "いいえ",
          TRUE ~ 症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.
        ),
        症例.EP後レジメン情報.提示された治療薬を投与した.名称. = case_when(
          is.na(症例.EP後レジメン情報.提示された治療薬を投与した.名称.) ~ "投与しなかった",
          症例.EP後レジメン情報.提示された治療薬を投与した.名称. == "不明" ~ "投与しなかった",
          症例.EP後レジメン情報.提示された治療薬を投与した.名称. == "" ~ "投与しなかった",
          TRUE ~ 症例.EP後レジメン情報.提示された治療薬を投与した.名称.
        ),
        症例.背景情報.喫煙歴有無.名称. = case_when(
          症例.背景情報.喫煙歴有無.名称. == "" ~ "不明",
          TRUE ~ 症例.背景情報.喫煙歴有無.名称.
        )
      )
      clin_tmp = clin_tmp %>% 
        dplyr::mutate(症例.EP前レジメン情報.投与開始日 = case_when(
          症例.EP前レジメン情報.投与開始日 < "1924-02-19"  & 症例.EP前レジメン情報.投与開始日 > "1901-01-01"~ paste0("20", str_sub(症例.EP前レジメン情報.投与開始日, 3,10)),
          TRUE ~ 症例.EP前レジメン情報.投与開始日)) %>% 
        dplyr::mutate(症例.EP後レジメン情報.投与開始日 = case_when(
          症例.EP後レジメン情報.投与開始日 < "1924-02-19"  & 症例.EP後レジメン情報.投与開始日 > "1901-01-01"~ paste0("20", str_sub(症例.EP後レジメン情報.投与開始日, 3,10)),
          TRUE ~ 症例.EP後レジメン情報.投与開始日)) %>% 
        dplyr::mutate(症例.EP前レジメン情報.投与終了日 = case_when(
          症例.EP前レジメン情報.投与終了日 < "1924-02-19"  & 症例.EP前レジメン情報.投与終了日 > "1901-01-01"~ paste0("20", str_sub(症例.EP前レジメン情報.投与終了日, 3,10)),
          TRUE ~ 症例.EP前レジメン情報.投与終了日)) %>% 
        dplyr::mutate(症例.EP後レジメン情報.投与終了日 = case_when(
          症例.EP後レジメン情報.投与終了日 < "1924-02-19"  & 症例.EP後レジメン情報.投与終了日 > "1901-01-01"~ paste0("20", str_sub(症例.EP後レジメン情報.投与終了日, 3,10)),
          TRUE ~ 症例.EP後レジメン情報.投与終了日)) %>% 
        dplyr::mutate(症例.EP後レジメン情報.エキスパートパネル開催日 = case_when(
          症例.EP後レジメン情報.エキスパートパネル開催日 < "1924-02-19"  & 症例.EP後レジメン情報.エキスパートパネル開催日 > "1901-01-01"~ paste0("20", str_sub(症例.EP後レジメン情報.エキスパートパネル開催日, 3,10)),
          TRUE ~ 症例.EP後レジメン情報.エキスパートパネル開催日))
      ID_lymph_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. %in% c("リンパ節", "リンパ節/リンパ管")))$C.CAT調査結果.基本項目.ハッシュID
      ID_brain_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. %in% c("脳", "中枢神経系")))$C.CAT調査結果.基本項目.ハッシュID
      ID_lung_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. == "肺"))$C.CAT調査結果.基本項目.ハッシュID
      ID_bone_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. %in% c("骨髄", "骨")))$C.CAT調査結果.基本項目.ハッシュID
      ID_liver_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. == "肝"))$C.CAT調査結果.基本項目.ハッシュID
      ID_other_met = (clin_tmp %>% dplyr::filter(!症例.がん種情報.登録時転移部位.名称. %in%
                                                   c("リンパ節", "リンパ節/リンパ管", "脳", "中枢神経系", "肺", "骨髄", "骨", "肝", "")))$C.CAT調査結果.基本項目.ハッシュID
      clin_tmp =  clin_tmp %>% dplyr::mutate(
        Lymph_met = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_lymph_met ~ "Yes",
          TRUE ~ "No"
        ),
        Brain_met = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_brain_met ~ "Yes",
          TRUE ~ "No"
        ),
        Lung_met = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_lung_met ~ "Yes",
          TRUE ~ "No"
        ),
        Bone_met = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_bone_met ~ "Yes",
          TRUE ~ "No"
        ),
        Liver_met = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_liver_met ~ "Yes",
          TRUE ~ "No"
        ),
        Other_met = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_other_met ~ "Yes",
          TRUE ~ "No"
        )
      )
      
      RenList = read.csv(file("source/drug_rename.csv",
                              encoding='UTF-8-BOM'), header = T)
      for(i in 1:length(RenList$P1)){
        clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = str_replace_all(clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN., RenList$P1[i], RenList$P2[i])
        clin_tmp$症例.EP後レジメン情報.薬剤名.YJ一般名.EN. = str_replace_all(clin_tmp$症例.EP後レジメン情報.薬剤名.YJ一般名.EN., RenList$P1[i], RenList$P2[i])
      }
      
      if(!is.null(input$regimen_rename)){
        RenList = data.frame(NULL)
        for(i in 1:length(input$regimen_rename[,1])){
          RenList <- rbind(RenList,
                           read.csv(header = TRUE,
                                    file(input$regimen_rename[[i, 'datapath']],
                                         encoding='UTF-8-BOM')))
        }
        for(i in 1:length(RenList$P1)){
          clin_tmp = clin_tmp %>% dplyr::mutate(
            症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = case_when(
              症例.EP前レジメン情報.薬剤名.YJ一般名.EN. == "" &
                症例.EP前レジメン情報.化学療法レジメン名称 == RenList$P1[i] ~ RenList$P2[i],
              TRUE ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN.
            ))
        }
      }
      if(!is.null(input$drug_rename)){
        drug_rename_list = data.frame(NULL)
        for(i in 1:length(input$drug_rename[,1])){
          drug_rename_list <- rbind(drug_rename_list,
                                    read.csv(header = TRUE,
                                             file(input$drug_rename[[i, 'datapath']],
                                                  encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp = unlist(lapply(list(clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN.), function(x) {
          as.vector(drug_rename_list$Rename[match(x, drug_rename_list$Drug)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = case_when(
            !is.na(症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp) ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp,
            TRUE ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN.
          )
        )
      }
      incProgress(1 / 4)
      clin_tmp = clin_tmp %>%
        dplyr::mutate(HER2_IHC = case_when(
          症例.がん種情報.乳.HER2.IHC..名称. == "陽性（3+）" |
            症例.がん種情報.食道.胃.腸.HER2.名称. == "陽性（3+）" |
            症例.がん種情報.乳.HER2.IHC..名称. == "境界域（2+）" & 症例.がん種情報.乳.HER2.FISH..名称. == "陽性" |
            症例.がん種情報.食道.胃.腸.HER2.名称. == "境界域（2+）" & 症例.がん種情報.食道.胃.腸.HER2遺伝子増幅..ISH法..名称. == "陽性" ~ "Positive",
          症例.がん種情報.乳.HER2.IHC..名称. %in% c("陰性",  "陰性（1+）") |
            症例.がん種情報.食道.胃.腸.HER2.名称. %in% c("陰性",  "陰性（1+）") |
            症例.がん種情報.乳.HER2.IHC..名称. == "境界域（2+）" & 症例.がん種情報.乳.HER2.FISH..名称. %in% c("equivocal", "陰性") |
            症例.がん種情報.食道.胃.腸.HER2.名称. == "境界域（2+）" & 症例.がん種情報.食道.胃.腸.HER2遺伝子増幅..ISH法..名称. %in% c("equivocal", "陰性") ~ "Negative",
          TRUE ~ "Unknown"
        ),
        MSI_PCR = case_when(
          症例.がん種情報.固形がん.マイクロサテライト不安定性.名称. == "陽性" ~ "Positive",
          症例.がん種情報.固形がん.マイクロサテライト不安定性.名称. == "陰性" ~ "Negative",
          TRUE ~ "Unknown"
        ),
        MMR_IHC = case_when(
          症例.がん種情報.固形がん.ミスマッチ修復機能欠損.名称. == "dMMR(欠損)" ~ "dMMR",
          症例.がん種情報.固形がん.ミスマッチ修復機能欠損.名称. == "pMMR(正常)" ~ "pMMR",
          TRUE ~ "Unknown"
        )
      )

      clin_tmp = clin_tmp %>%
        dplyr::mutate(EP_option = case_when(
          症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. ==
            "はい" ~ 1,
          TRUE ~ 0)) %>%
        dplyr::mutate(EP_treat = case_when(
          症例.EP後レジメン情報.提示された治療薬を投与した.名称. ==
            "投与した" ~ 1,
          TRUE ~ 0))
      clin_tmp = clin_tmp %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                      症例.基本情報.年齢,
                      Lymph_met,
                      Brain_met,
                      Lung_met,
                      Bone_met,
                      Liver_met,
                      Other_met,
                      EP_option,
                      EP_treat,
                      症例.基本情報.性別.名称.,
                      症例.基本情報.がん種.OncoTree.,
                      症例.基本情報.がん種.OncoTree..名称.,
                      症例.基本情報.がん種.OncoTree.LEVEL1.,
                      症例.検体情報.パネル.名称.,
                      症例.背景情報.ECOG.PS.名称.,
                      症例.背景情報.喫煙歴有無.名称.,
                      症例.背景情報.喫煙年数,
                      症例.背景情報.喫煙１日本数,
                      症例.背景情報.アルコール多飲有無.名称.,
                      症例.背景情報.重複がん有無.異なる臓器..名称.,
                      症例.背景情報.多発がん有無.同一臓器..名称.,
                      症例.がん種情報.登録時転移部位.名称.,
                      症例.検体情報.腫瘍細胞含有割合,
                      症例.検体情報.検体採取部位.名称.,
                      症例.EP前レジメン情報.治療ライン.名称.,
                      症例.EP前レジメン情報.実施目的.名称.,
                      症例.EP前レジメン情報.化学療法レジメン名称,
                      症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.投与終了日,
                      症例.EP前レジメン情報.終了理由.名称.,
                      症例.EP前レジメン情報.レジメン継続区分.名称.,
                      症例.EP前レジメン情報.最良総合効果.名称.,
                      症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                      症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                      症例.EP後レジメン情報.治療ライン,
                      症例.EP後レジメン情報.治療ライン.名称.,
                      症例.EP後レジメン情報.化学療法レジメン名称,
                      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP後レジメン情報.投与開始日,
                      症例.EP後レジメン情報.投与終了日,
                      症例.EP後レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.レジメン継続区分.名称.,
                      症例.EP後レジメン情報.最良総合効果.名称.,
                      症例.転帰情報.転帰.名称.,
                      症例.背景情報.診断日,
                      症例.管理情報.登録日,
                      症例.転帰情報.最終生存確認日,
                      症例.転帰情報.死亡日,
                      症例.がん種情報.固形がん.マイクロサテライト不安定性.名称.,
                      # 症例.がん種情報.固形がん.マイクロサテライト不安定性.検査方法.名称.,
                      症例.がん種情報.固形がん.ミスマッチ修復機能欠損.名称.,
                      # 症例.がん種情報.固形がん.ミスマッチ修復機能欠損.検査方法.名称.,
                      # 症例.がん種情報.固形がん.腫瘍遺伝子変異量.名称.,
                      # 症例.がん種情報.固形がん.腫瘍遺伝子変異量.検査方法.名称.,
                      # 症例.がん種情報.唾液腺.HER2遺伝子増幅度.名称.,
                      # 症例.がん種情報.唾液腺.HER2遺伝子増幅度.検査方法.名称.,
                      # 症例.がん種情報.甲状腺.RET融合遺伝子.名称.,
                      # 症例.がん種情報.甲状腺.RET融合遺伝子.検査方法.名称.,
                      # 症例.がん種情報.甲状腺.RET遺伝子変異.名称.,
                      # 症例.がん種情報.甲状腺.RET遺伝子変異.検査方法.名称.,
                      症例.がん種情報.肺.EGFR.名称.,
                      # 症例.がん種情報.肺.EGFR.type.名称.,
                      # 症例.がん種情報.肺.EGFR.検査方法.名称.,
                      # 症例.がん種情報.肺.EGFR.TKI耐性後EGFR.T790M.名称.,
                      症例.がん種情報.肺.ALK融合.名称.,
                      # 症例.がん種情報.肺.ALK.検査方法.名称.,
                      症例.がん種情報.肺.ROS1.名称.,
                      # 症例.がん種情報.肺.ROS1.検査方法.名称.,
                      症例.がん種情報.肺.BRAF.V600..名称.,
                      # 症例.がん種情報.肺.BRAF.V600..検査方法.名称.,
                      症例.がん種情報.肺.MET遺伝子エクソン14スキッピング変異.名称.,
                      # 症例.がん種情報.肺.MET遺伝子エクソン14スキッピング変異.検査方法.名称.,
                      症例.がん種情報.肺.KRAS.G12C遺伝子変異.名称.,
                      # 症例.がん種情報.肺.KRAS.G12C遺伝子変異.検査方法.名称.,
                      症例.がん種情報.肺.RET融合遺伝子.名称.,
                      # 症例.がん種情報.肺.RET融合遺伝子.検査方法.名称.,
                      症例.がん種情報.肺.PD.L1.IHC..名称.,
                      # 症例.がん種情報.肺.PD.L1.IHC..検査方法.名称.,
                      # 症例.がん種情報.肺.陽性率,
                      症例.がん種情報.乳.HER2.IHC..名称.,
                      症例.がん種情報.乳.HER2.FISH..名称.,
                      症例.がん種情報.乳.ER.名称.,
                      症例.がん種情報.乳.PgR.名称.,
                      # 症例.がん種情報.乳.PD.L1タンパク.名称.,
                      # 症例.がん種情報.乳.PD.L1タンパク.検査方法.名称.,
                      # 症例.がん種情報.乳.ERBB2コピー数異常.名称.,
                      # 症例.がん種情報.乳.ERBB2コピー数異常.検査方法.名称.,
                      # 症例.がん種情報.乳.gBRCA1.名称.,
                      # 症例.がん種情報.乳.gBRCA1.検査方法.名称.,
                      # 症例.がん種情報.乳.gBRCA2.名称.,
                      # 症例.がん種情報.乳.gBRCA2.検査方法.名称.,
                      # 症例.がん種情報.食道.胃.腸.KRAS.名称.,
                      # 症例.がん種情報.食道.胃.腸.KRAS.type.名称.,
                      # 症例.がん種情報.食道.胃.腸.KRAS.検査方法.名称.,
                      # 症例.がん種情報.食道.胃.腸.NRAS.名称.,
                      # 症例.がん種情報.食道.胃.腸.NRAS.type.名称.,
                      # 症例.がん種情報.食道.胃.腸.NRAS.検査方法.名称.,
                      症例.がん種情報.食道.胃.腸.HER2.名称.,
                      # 症例.がん種情報.食道.胃.腸.HER2タンパク.検査方法.名称.,
                      # 症例.がん種情報.食道.胃.腸.HER2遺伝子増幅..ISH法..検査方法.名称.,
                      症例.がん種情報.食道.胃.腸.HER2遺伝子増幅..ISH法..名称.,
                      # 症例.がん種情報.食道.胃.腸.BRAF.V600..名称.,
                      # 症例.がん種情報.食道.胃.腸.BRAF.V600..検査方法.名称.,
                      # 症例.がん種情報.食道.胃.腸.EGFR.IHC..名称.,
                      # 症例.がん種情報.胆道.FGFR2融合遺伝子.名称.,
                      # 症例.がん種情報.胆道.FGFR2融合遺伝子.検査方法.名称.,
                      # 症例.がん種情報.膵臓.gBRCA1.名称.,
                      # 症例.がん種情報.膵臓.gBRCA1.検査方法.名称.,
                      # 症例.がん種情報.膵臓.gBRCA2.名称.,
                      # 症例.がん種情報.膵臓.gBRCA2.検査方法.名称.,
                      # 症例.がん種情報.皮膚.BRAF遺伝.変異.名称.,
                      # 症例.がん種情報.皮膚.BRAF遺伝子変異.検査方法.名称.,
                      # 症例.がん種情報.皮膚.BRAF.type.名称.,
                      # 症例.がん種情報.前立腺.gBRCA1.名称.,
                      # 症例.がん種情報.前立腺.gBRCA1.検査方法.名称.,
                      # 症例.がん種情報.前立腺.gBRCA2.名称.,
                      # 症例.がん種情報.前立腺.gBRCA2.検査方法.名称.,
                      # 症例.がん種情報.卵巣卵管.gBRCA1.名称.,
                      # 症例.がん種情報.卵巣卵管.gBRCA1.検査方法.名称.,
                      # 症例.がん種情報.卵巣卵管.gBRCA2.名称.,
                      # 症例.がん種情報.卵巣卵管.gBRCA2.検査方法.名称.,
                      # 症例.がん種情報.卵巣卵管.相同組換え修復欠損.名称.,
                      # 症例.がん種情報.卵巣卵管.相同組換え修復欠損.検査方法.名称.
                      HER2_IHC,
                      MSI_PCR,
                      MMR_IHC
        )
      incProgress(1 / 4)
    })  
    return(clin_tmp)
  })

  Data_report_raw =  reactive({
    withProgress(message = "Mutation data loading.", {
      Encode = guess_encoding(input$report_files[[1, 'datapath']])[[1]][[1]]
      if(Encode == "Shift_JIS"){
        Encode = "CP932"
      }
      clin_tmp <- read_csv(col_names = TRUE,
                           file = input$report_files$datapath,
                           locale = locale(encoding=Encode),
                           num_threads=max(1, parallel::detectCores() - 1, na.rm = TRUE),
                           progress=FALSE,
                           name_repair=make.names,
                           col_types = cols(
                             C.CAT調査結果.変異情報.マーカー詳細 = col_character(),
                             C.CAT調査結果.変異情報.遺伝子のエビデンスレベルF変異の頻度2 = col_character(),
                             C.CAT調査結果.基本項目.年齢.月齢. = col_character(),
                             C.CAT調査結果.エビデンス.遺伝性疾患名 = col_character(),
                             C.CAT調査結果.変異情報.ToMMoアレル頻度 = col_character(),
                             C.CAT調査結果.変異情報.腫瘍リード数 = col_character(),
                             C.CAT調査結果.変異情報.ExACアレル頻度.東アジア人種. = col_character(),
                             C.CAT調査結果.変異情報.1000人ゲノムアレル頻度.東アジア人種. = col_character(),
                             C.CAT調査結果.エビデンス.臨床的意義 = col_character(),
                             C.CAT調査結果.変異情報.ToMMoアレル頻度 = col_character(),
                             C.CAT調査結果.変異情報.C.CAT登録データがん種別頻度 = col_character(),
                             C.CAT調査結果.変異情報.遺伝子のエビデンスレベルF変異の頻度1 = col_character(),
                             C.CAT調査結果.変異情報.TPM.腫瘍発現量. = col_character(),
                             C.CAT調査結果.変異情報.TPM.正常発現量. = col_character(),
                             C.CAT調査結果.変異情報.コピー数変化 = col_character(),
                             C.CAT調査結果.変異情報.転写産物ID = col_character(),
                             C.CAT調査結果.変異情報.C.CAT登録データ頻度 = col_character(),
                             C.CAT調査結果.変異情報.変異アレル頻度 = col_character(),
                             .default = col_guess()
                           ),
                           show_col_types=FALSE)
      incProgress(1 / 4)
      clin_tmp = as.data.frame(clin_tmp)
      clin_tmp = clin_tmp %>%
        dplyr::filter(
          !str_detect(C.CAT調査結果.変異情報.マーカー, ",") &
            C.CAT調査結果.変異情報.マーカー != "" &
            C.CAT調査結果.変異情報.変異種類 != "expression"
        )
      clin_tmp = clin_tmp %>% dplyr::mutate(
        C.CAT調査結果.変異情報.変異種類 = case_when(
          C.CAT調査結果.変異情報.変異種類 == "rearrangement" &
            C.CAT調査結果.変異情報.変異内容 == "rearrangements" ~ "rearrangement",
          C.CAT調査結果.変異情報.変異種類 == "rearrangement" &
            C.CAT調査結果.変異情報.変異内容 == "long deletion" ~ "deletion",
          C.CAT調査結果.変異情報.変異種類 == "rearrangement" ~ C.CAT調査結果.変異情報.変異内容,
          C.CAT調査結果.変異情報.変異種類 == "copy_number_alteration" ~ C.CAT調査結果.変異情報.変異内容,
          C.CAT調査結果.変異情報.変異種類 == "small_scale_variant" &
           str_detect(C.CAT調査結果.変異情報.変異内容, "\\*") ~ "nonsense_frameshift",
          C.CAT調査結果.変異情報.変異種類 == "small_scale_variant"  ~ "small_scale_variant",
          C.CAT調査結果.変異情報.変異種類 == "other_biomarker" ~ "TMB_high",
          TRUE ~ C.CAT調査結果.変異情報.変異種類
        ))
      clin_tmp = clin_tmp %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "NKX2\\-1", "NKX2XXXX1")
        ) %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "H1\\-2", "H1XXXX2")
        ) %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "H3\\-4", "H3XXXX4")
        ) %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "H3\\-5", "H3XXXX5")
        ) %>%
        dplyr::mutate(
        C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "H3\\-3A", "H3XXXX3A")
      )
      clin_tmp = clin_tmp %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "-", "_")
        )
      
      if(input$fusion == "Split into two and treat as mutation in each gene"){
        clin_tmp_base = clin_tmp %>%
          dplyr::filter(!str_detect(C.CAT調査結果.変異情報.マーカー, "_"))
        clin_tmp_fusion = clin_tmp %>%
          dplyr::filter(str_detect(C.CAT調査結果.変異情報.マーカー, "_"))
        clin_tmp_fusion_1 = clin_tmp_fusion %>%
          dplyr::mutate(C.CAT調査結果.変異情報.変異内容 = C.CAT調査結果.変異情報.マーカー,
                        C.CAT調査結果.変異情報.マーカー = str_split(C.CAT調査結果.変異情報.マーカー, "_",simplify = T)[,1])
        clin_tmp_fusion_2 = clin_tmp_fusion %>%
          dplyr::mutate(C.CAT調査結果.変異情報.変異内容 = C.CAT調査結果.変異情報.マーカー,
                        C.CAT調査結果.変異情報.マーカー = str_split(C.CAT調査結果.変異情報.マーカー, "_",simplify = T)[,2])
        clin_tmp = rbind(clin_tmp_base, clin_tmp_fusion_1, clin_tmp_fusion_2)
      } else if(input$fusion == "All fusion genes are named as 'fusion_genes'"){
        clin_tmp_base = clin_tmp %>%
          dplyr::filter(!str_detect(C.CAT調査結果.変異情報.マーカー, "_"))
        clin_tmp_fusion = clin_tmp %>%
          dplyr::filter(str_detect(C.CAT調査結果.変異情報.マーカー, "_"))
        clin_tmp_fusion = clin_tmp_fusion %>%
          dplyr::mutate(C.CAT調査結果.変異情報.変異内容 = C.CAT調査結果.変異情報.マーカー,
                        C.CAT調査結果.変異情報.マーカー = "fusion_genes")
        clin_tmp = rbind(clin_tmp_base, clin_tmp_fusion)
      }
      
      clin_tmp = clin_tmp %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "NKX2XXXX1", "NKX2_1")
        ) %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "H1XXXX2", "H1_2")
        ) %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "H3XXXX4", "H3_4")
        ) %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "H3XXXX5", "H3_5")
        ) %>%
        dplyr::mutate(
        C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "H3XXXX3A", "H3_3A")
      )
      incProgress(1 / 4)
      if(!is.null(input$mutation_rename)){
        mutation_rename_list = data.frame(NULL)
        for(i in 1:length(input$mutation_rename[,1])){
          mutation_rename_list <- rbind(mutation_rename_list,
                                    read.csv(header = TRUE,
                                      file(input$mutation_rename[[i, 'datapath']],
                                           encoding='UTF-8-BOM')))
        }
        Gene_list = sort(unique(mutation_rename_list$Gene))
        clin = clin_tmp %>% dplyr::filter(!C.CAT調査結果.変異情報.マーカー %in% Gene_list)
        for(i in 1:length(Gene_list)){
          mutation_rename_list_tmp = mutation_rename_list[mutation_rename_list$Gene == Gene_list[i],]
          clin_tmp2 = clin_tmp %>% dplyr::filter(C.CAT調査結果.変異情報.マーカー == Gene_list[i])
          clin_tmp2$C.CAT調査結果.変異情報.変異内容_tmp = unlist(lapply(list(clin_tmp2$C.CAT調査結果.変異情報.変異内容), function(x) {
            as.vector(mutation_rename_list_tmp$Rename[match(x, mutation_rename_list_tmp$Mutation)])}))
          clin_tmp2 = clin_tmp2 %>% dplyr::mutate(
            C.CAT調査結果.変異情報.変異内容 = case_when(
              !is.na(C.CAT調査結果.変異情報.変異内容_tmp) ~ C.CAT調査結果.変異情報.変異内容_tmp,
              TRUE ~ "Other"
            )
          )
          clin_tmp2 = clin_tmp2 %>% dplyr::select(-C.CAT調査結果.変異情報.変異内容_tmp)
          clin = rbind(clin, clin_tmp2)
        }
        clin_tmp = clin
      }
      Data_MAF = clin_tmp
      Data_MAF$C.CAT調査結果.変異情報.物理位置2 =
        Data_MAF$C.CAT調査結果.変異情報.物理位置
      Data_MAF = Data_MAF %>%
        dplyr::select(C.CAT調査結果.変異情報.マーカー,
                      C.CAT調査結果.変異情報.クロモソーム番号,
                      C.CAT調査結果.変異情報.物理位置,
                      C.CAT調査結果.変異情報.物理位置2,
                      C.CAT調査結果.変異情報.リファレンス塩基,
                      C.CAT調査結果.変異情報.塩基変化,
                      C.CAT調査結果.変異情報.変異種類,
                      C.CAT調査結果.エビデンス.エビデンスレベル,
                      C.CAT調査結果.エビデンス.薬剤,
                      C.CAT調査結果.基本項目.ハッシュID,
                      C.CAT調査結果.変異情報.変異アレル頻度,
                      C.CAT調査結果.変異情報.変異内容,
                      C.CAT調査結果.変異情報TMB.TMB)
      colnames(Data_MAF) = c("Hugo_Symbol",
                             "Chromosome",
                             "Start_Position",
                             "End_Position",
                             "Reference_Allele",
                             "Tumor_Seq_Allele2",
                             "Variant_Classification",
                             "Evidence_level",
                             "Drug",
                             "Tumor_Sample_Barcode",
                             "VAF",
                             "amino.acid.change",
                             "TMB")
      Data_MAF = Data_MAF %>% dplyr::mutate(
        Variant_Type = case_when(
          nchar(Reference_Allele) == 1 &
            nchar(Tumor_Seq_Allele2) == 1 ~ "SNP",
          nchar(Reference_Allele) == 2 &
            nchar(Tumor_Seq_Allele2) == 2 ~ "DNP",
          nchar(Reference_Allele) == 3 &
            nchar(Tumor_Seq_Allele2) == 3 ~ "TNP",
          nchar(Reference_Allele) == 1 &
            Reference_Allele != "-" &
            nchar(Tumor_Seq_Allele2) > 1 ~ "INS",
          nchar(Reference_Allele) > 1 &
            Tumor_Seq_Allele2 != "-" ~ Variant_Classification,
          TRUE ~ "Other"
        ))
      incProgress(1 / 4)
      TMB_tmp = str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1]
      TMB_tmp = str_split(TMB_tmp, "mutations", simplify = TRUE)[,1]
      Data_MAF$TMB = as.numeric(TMB_tmp)
      if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
        Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
      }
      if(length(Data_MAF[is.na(Data_MAF$Evidence_level),]$Evidence_level) > 0){
        Data_MAF[is.na(Data_MAF$Evidence_level),]$Evidence_level = ""
      }
      Data_report_TMB = Data_MAF %>%
        dplyr::filter(Hugo_Symbol == "TMB") %>%
        dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
        dplyr::arrange(Tumor_Sample_Barcode) %>%
        dplyr::mutate(
          Evidence_level = case_when(
            TMB < 10 ~ "",
            TMB >= 10 ~ "F",
            TRUE ~ ""
          ),
          amino.acid.change = case_when(
            TMB < 10 ~ "",
            TMB >= 10 ~ "high",
            TRUE ~ ""
          )
        )
      Data_MAF = Data_MAF %>%
        dplyr::arrange(Tumor_Sample_Barcode) %>%
        dplyr::filter(Hugo_Symbol != "TMB")
      Data_MAF = rbind(Data_MAF, Data_report_TMB)
      incProgress(1 / 4)
    })
    return(Data_MAF)
  })

  Data_case =  reactive({
    clin_tmp = Data_case_raw()
    if(!is.null(input$histology_group_1)){
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_1 ~ str_replace(str_replace(input$histology_group_1_name, "\\)", ""), ".*\\(",""),
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        ),
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_1 ~ input$histology_group_1_name,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
        
      )
    }
    if(!is.null(input$histology_group_2)){
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_2 ~ str_replace(str_replace(input$histology_group_2_name, "\\)", ""), ".*\\(",""),
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        ),
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_2 ~ input$histology_group_2_name,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
    }
    if(!is.null(input$histology_group_3)){
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_3 ~ str_replace(str_replace(input$histology_group_3_name, "\\)", ""), ".*\\(",""),
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        ),
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_3 ~ input$histology_group_3_name,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
    }
    if(!is.null(input$histology_group_4)){
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_4 ~ str_replace(str_replace(input$histology_group_4_name, "\\)", ""), ".*\\(",""),
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        ),
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_4 ~ input$histology_group_4_name,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
    }
    if(!is.null(input$minimum_pts)){
      Cancername = table((clin_tmp %>% dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, 症例.基本情報.がん種.OncoTree.)
                          )$症例.基本情報.がん種.OncoTree.)
      Cancername = names(Cancername[Cancername >= input$minimum_pts])
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree. %in% Cancername ~ 症例.基本情報.がん種.OncoTree..名称.,
          TRUE ~ 症例.基本情報.がん種.OncoTree.LEVEL1.
      ))
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree. %in% Cancername ~ 症例.基本情報.がん種.OncoTree.,
          TRUE ~ 症例.基本情報.がん種.OncoTree.LEVEL1.
        ))
    }
    if(!is.null(input$histology)){
      clin_tmp = clin_tmp %>%
      dplyr::filter(
        症例.基本情報.がん種.OncoTree..名称. %in% input$histology
      )
    }
    if(!is.null(input$panel)){
      clin_tmp = clin_tmp %>%
        dplyr::filter(
          症例.検体情報.パネル.名称. %in% input$panel
        )
    }
    if(!is.null(input$PS)){
      clin_tmp = clin_tmp %>%
        dplyr::filter(
          症例.背景情報.ECOG.PS.名称. %in% input$PS
        )
    }
    if(!is.null(input$sex)){
      clin_tmp = clin_tmp %>%
        dplyr::filter(
          症例.基本情報.性別.名称. %in% input$sex
        )
    }
    if(!is.null(input$smoking)){
      clin_tmp = clin_tmp %>%
        dplyr::filter(
          症例.背景情報.喫煙歴有無.名称. %in% input$smoking
        )
    }
    if(!is.null(input$year)){
      if(!sum(as.integer(input$year)) == sum(2019:2024)){
        clin_tmp = clin_tmp %>%
          dplyr::mutate(
            症例.管理情報.登録日 = as.Date(症例.管理情報.登録日)
          ) %>%
          dplyr::filter(
            !is.null(症例.管理情報.登録日)
          ) %>%
          dplyr::filter(
            (as.POSIXlt(症例.管理情報.登録日)$year + 1900) %in% as.integer(input$year)
          )
        clin_tmp = clin_tmp %>%
          dplyr::mutate(
            症例.管理情報.登録日 = as.character(症例.管理情報.登録日)
          )
      }
    }
    if(!is.null(input$age)){
      if(any(input$age != c(min(Data_case_raw()$症例.基本情報.年齢, na.rm = TRUE),
                            max(Data_case_raw()$症例.基本情報.年齢, na.rm = TRUE)))){
        clin_tmp$症例.基本情報.年齢 = tidyr::replace_na(clin_tmp$症例.基本情報.年齢, -1) 
        clin_tmp = clin_tmp %>% dplyr::filter(
          症例.基本情報.年齢 >= input$age[1] &
            症例.基本情報.年齢 <= input$age[2]
        )
      }
    }
    if(!is.null(input$mid_age)){
      clin_tmp = clin_tmp %>% dplyr::mutate(YoungOld = case_when(
        症例.基本情報.年齢 <= input$mid_age ~ "Younger",
        TRUE ~ "Older"))
    }
    clin_tmp = clin_tmp %>% dplyr::distinct() %>% dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
    return(clin_tmp)
  })

  Data_report =  reactive({
    Data_MAF = Data_report_raw()
    if(!is.null(input$special_gene_annotation)){
      if(input$special_gene_annotation == "This gene is also analyzed for VUS and Benign" &
         !is.null(input$special_gene)){
        Data_MAF = Data_MAF %>% dplyr::mutate(
          Evidence_level = case_when(
            Hugo_Symbol == input$special_gene &
              Evidence_level == "" ~ "F",
            TRUE ~ Evidence_level
          )
        )
      }
    }
    if(!is.null(input$special_gene_independent)){
      if(input$special_gene_independent == "Treat as independent genes in oncoprint" &
       !is.null(input$special_gene)){
        Data_MAF = Data_MAF %>% dplyr::mutate(
          Hugo_Symbol = case_when(
            Hugo_Symbol == input$special_gene &
              amino.acid.change %in% input$special_gene_mutation_1 ~ paste0(Hugo_Symbol, "_", input$special_gene_mutation_1_name),
            Hugo_Symbol == input$special_gene &
              amino.acid.change %in% input$special_gene_mutation_2 ~ paste0(Hugo_Symbol, "_", input$special_gene_mutation_2_name),
            Hugo_Symbol == input$special_gene ~ paste0(Hugo_Symbol, "_NOS"),
            TRUE ~ Hugo_Symbol
          )
        )
      }
    }
    if(!is.null(input$gene_group_analysis)){
      if(input$gene_group_analysis == "Only cases with mutations in the gene set are analyzed" &
       !is.null(input$gene)){
        if(input$patho == "Only pathogenic muts"){
          ID_geneset = unique((Data_MAF %>% dplyr::filter(
            Hugo_Symbol %in% input$gene & Evidence_level == "F"
          ))$Tumor_Sample_Barcode)
        } else if(input$patho == "All muts"){
          ID_geneset = unique((Data_MAF %>% dplyr::filter(
            Hugo_Symbol %in% input$gene
          ))$Tumor_Sample_Barcode)
        }
        Data_MAF = Data_MAF %>%
          dplyr::filter(Tumor_Sample_Barcode %in%
                          ID_geneset)
      }
      if(input$gene_group_analysis == "Only cases without mutations in the gene set are analyzed" &
         !is.null(input$gene)){
        if(input$patho == "Only pathogenic muts"){
          ID_geneset = unique((Data_MAF %>% dplyr::filter(
            Hugo_Symbol %in% input$gene & Evidence_level == "F"
          ))$Tumor_Sample_Barcode)
        } else if(input$patho == "All muts"){
          ID_geneset = unique((Data_MAF %>% dplyr::filter(
            Hugo_Symbol %in% input$gene
          ))$Tumor_Sample_Barcode)
        }
        Data_MAF = Data_MAF %>%
          dplyr::filter(!Tumor_Sample_Barcode %in% ID_geneset)
        ALL_ID =  (Data_case_raw() %>% dplyr::filter(
          !C.CAT調査結果.基本項目.ハッシュID %in% ID_geneset
        ))$C.CAT調査結果.基本項目.ハッシュID
        DEFF_ID = ALL_ID[!ALL_ID %in% Data_MAF$Tumor_Sample_Barcode]
        if(length(DEFF_ID)>0){
          TEST_ALL = NULL
          TEST = (Data_MAF %>% dplyr::filter(
            Hugo_Symbol == "TMB"
          ))[1,]
          TEST$TMB=0
          TEST$Evidence_level = ""
          TEST$Drug = ""
          for(i in 1:length(DEFF_ID)){
            TEST$Tumor_Sample_Barcode = DEFF_ID[i]
            TEST_ALL = rbind(TEST_ALL, TEST)
          }
          Data_MAF = rbind(Data_MAF, TEST_ALL)
        }
      }
    }
    Data_MAF = Data_MAF %>% dplyr::distinct() %>% dplyr::arrange(Tumor_Sample_Barcode)
    return(Data_MAF)}
  )
  
  observeEvent(input$start_setting, {
    withProgress(message = sample(nietzsche)[1], {
      output$select_histology = renderUI({ 
        pickerInput("histology", "Filter by histology",
                    choices = sort(unique(Data_case_raw()$症例.基本情報.がん種.OncoTree..名称.)), 
                    options = list(`actions-box` = TRUE),
                    selected = sort(unique(Data_case_raw()$症例.基本情報.がん種.OncoTree..名称.)), multiple = TRUE)
      })
      output$select_histology_group_1 = renderUI({ 
        pickerInput("histology_group_1", "Histology type 1 to be analyzed (if none, not selected)",
                    options = list(`actions-box` = TRUE),
                    input$histology, multiple = TRUE)
      })
      incProgress(1 / 8)
      output$select_histology_group_1_name = renderUI({ 
        pickerInput("histology_group_1_name", "Name for histology type 1",
                    options = list(`actions-box` = TRUE),
                    input$histology_group_1, multiple = FALSE)
      })
      output$select_histology_group_2 = renderUI({ 
        pickerInput("histology_group_2", "Histology type 2 to be analyzed",
                    options = list(`actions-box` = TRUE),
                    input$histology[-which(input$histology %in%
                                             input$histology_group_1)], multiple = TRUE)
      })
      output$select_histology_group_2_name = renderUI({ 
        pickerInput("histology_group_2_name", "Name for histology type 2",
                    input$histology_group_2, multiple = FALSE)
      })
      incProgress(1 / 8)
      output$select_histology_group_3 = renderUI({ 
        pickerInput("histology_group_3", "Histology type 3 to be analyzed",
                    options = list(`actions-box` = TRUE),
                    input$histology[-which(input$histology %in%
                                             c(input$histology_group_1,
                                               input$histology_group_2))], multiple = TRUE)
      })
      incProgress(1 / 8)
      output$select_histology_group_3_name = renderUI({ 
        pickerInput("histology_group_3_name", "Name for histology type 3",
                    options = list(`actions-box` = TRUE),
                    input$histology_group_3, multiple = FALSE)
      })
      output$select_histology_group_4 = renderUI({ 
        pickerInput("histology_group_4", "Histology type 4 to be analyzed",
                    options = list(`actions-box` = TRUE),
                    input$histology[-which(input$histology %in%
                                             c(input$histology_group_1,
                                               input$histology_group_2,
                                               input$histology_group_3))], multiple = TRUE)
      })
      output$select_histology_group_4_name = renderUI({ 
        pickerInput("histology_group_4_name", "Name for histology type 4",
                    options = list(`actions-box` = TRUE),
                    input$histology_group_4, multiple = FALSE)
      })
      output$select_sex = renderUI({ 
        pickerInput("sex", "Filter by sex",
                    choices = sort(unique(Data_case_raw()$症例.基本情報.性別.名称.)), 
                    selected = sort(unique(Data_case_raw()$症例.基本情報.性別.名称.)), multiple = TRUE)
      })
      output$select_minimum_pts = renderUI({ 
        numericInput("minimum_pts", "Minimum patients for each histology",
                     value = 1,
                     min = 1,
                     max = length((Data_case_raw() %>% dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID))$C.CAT調査結果.基本項目.ハッシュID),
                     step = 1)
      })
      incProgress(1 / 8)
      output$select_eps = renderUI({ 
        numericInput("eps", "Distance value for DBSCAN clustering",
                     value = 1.0,
                     min = 0,
                     max = 10,
                     step = 1)
      })
      output$select_panel = renderUI({ 
        pickerInput("panel", "Filter by panel",
                    choices = sort(unique(Data_case_raw()$症例.検体情報.パネル.名称.)), 
                    selected = sort(unique(Data_case_raw()$症例.検体情報.パネル.名称.)), multiple = TRUE)
      })
      output$select_year = renderUI({ 
        pickerInput("year", "Filter by test-year",
                    choices = 2019:2024,
                    selected = 2019:2024, multiple = TRUE)
      })
      output$select_age = renderUI({ 
        sliderInput(inputId = "age", label = "Age for analysis",
                    value = c(
                      min(Data_case_raw()$症例.基本情報.年齢, na.rm = TRUE),
                      max(Data_case_raw()$症例.基本情報.年齢, na.rm = TRUE)),
                    min = min(Data_case_raw()$症例.基本情報.年齢, na.rm = TRUE),
                    max = max(Data_case_raw()$症例.基本情報.年齢, na.rm = TRUE),
                    step = 1)
      })
      output$select_mid_age = renderUI({
        tmp = Data_case_raw() %>% dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, 症例.基本情報.年齢)
        sliderInput(inputId = "mid_age", label = "Threshold age for oncoprint",
                    value = median(tmp$症例.基本情報.年齢, na.rm = TRUE),
                    min = min(tmp$症例.基本情報.年齢, na.rm = TRUE),
                    max = max(tmp$症例.基本情報.年齢, na.rm = TRUE),
                    step = 1)
      })
      incProgress(1 / 8)
      output$select_PS = renderUI({ 
        pickerInput("PS", "Filter by performance status",
                    choices = sort(unique(Data_case_raw()$症例.背景情報.ECOG.PS.名称.)), 
                    selected = sort(unique(Data_case_raw()$症例.背景情報.ECOG.PS.名称.)), multiple = TRUE)
      })
      output$select_smoking = renderUI({ 
        pickerInput("smoking", "Filter by smoking status",
                    choices = sort(unique(Data_case_raw()$症例.背景情報.喫煙歴有無.名称.)), 
                    selected = sort(unique(Data_case_raw()$症例.背景情報.喫煙歴有無.名称.)), multiple = TRUE)
      })
      output$select_gene = renderUI({ 
        pickerInput("gene", "Genes of interest (if any)", sort(unique(Data_report_raw()$Hugo_Symbol)),
                    options = list(`actions-box` = TRUE),
                    multiple = TRUE)
      })
      output$select_lolliplot_gene = renderUI({ 
        pickerInput("lolliplot_gene", "Genes for lolliplot (if any)",
                    choices = c("", sort(unique(Data_report_raw()$Hugo_Symbol))), multiple = FALSE)
      })
      output$select_lolliplot_no = renderUI({
        tmp = Data_case_raw() %>% dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, 症例.基本情報.年齢)
        sliderInput(inputId = "lolliplot_no", label = "Threshold mutation count for lolliplot",
                    value = 5,
                    min = 1,
                    max = 100,
                    step = 1)
      })
      
      
      output$select_gene_group_1 = renderUI({ 
        pickerInput("gene_group_1", "Gene-set 1 of interest (if any)",
                    input$gene,
                    options = list(`actions-box` = TRUE),
                    multiple = TRUE)
      })
      output$select_gene_group_2 = renderUI({ 
        pickerInput("gene_group_2", "Gene-set 2 of interest (if any)",
                    input$gene[-which(input$gene %in% input$gene_group_1)],
                    options = list(`actions-box` = TRUE),
                    multiple = TRUE)
      })
      incProgress(1 / 8)
      output$select_special_gene = renderUI({
        pickerInput("special_gene", "Gene to analyze (if any)", c("", sort(unique(Data_report_raw()$Hugo_Symbol))), multiple = FALSE)
      })
      output$select_special_gene_mutation_1 = renderUI({
        if(!is.null(input$special_gene)){
          pickerInput("special_gene_mutation_1", "Variants 1", sort(unique(
            (Data_report_raw() %>% dplyr::filter(Hugo_Symbol == input$special_gene | (input$special_gene != "" & str_detect(Hugo_Symbol, paste0(input$special_gene, "_")))))$amino.acid.change)),
            options = list(`actions-box` = TRUE),
            multiple = TRUE)
        } else {
          pickerInput("special_gene_mutation_1", "Variants 1", NULL,
                      options = list(`actions-box` = TRUE),
                      multiple = TRUE)
        }
      })
      output$select_special_gene_mutation_1_name = renderUI({
        if(!is.null(input$special_gene_mutation_1)){
          textInput(inputId = "special_gene_mutation_1_name", label = "Name for variants 1",
                  value = input$special_gene_mutation_1[[1]])
        } else {
          textInput(inputId = "special_gene_mutation_1_name", label = "Name for variants 1",
                    value = NULL)
        }
      })
      output$select_special_gene_mutation_2 = renderUI({
        if(!is.null(input$special_gene)){
          tmp_mut = sort(unique(
            (Data_report_raw() %>% dplyr::filter(Hugo_Symbol == input$special_gene | (input$special_gene != "" & str_detect(Hugo_Symbol, paste0(input$special_gene, "_")))))$amino.acid.change))
          pickerInput("special_gene_mutation_2", "Variants 2", tmp_mut[!tmp_mut %in% input$special_gene_mutation_1],
                      options = list(`actions-box` = TRUE),
                      multiple = TRUE)
        } else{
          pickerInput("special_gene_mutation_2", "Variants 2", NULL,
                      options = list(`actions-box` = TRUE),
                      multiple = TRUE)
        }
      })
      output$select_special_gene_mutation_2_name = renderUI({
        if(!is.null(input$special_gene_mutation_2)){
          textInput(inputId = "special_gene_mutation_2_name", label = "Name for variants 2",
                  value = input$special_gene_mutation_2[[1]])
        } else{
          textInput(inputId = "special_gene_mutation_2_name", label = "Name for variants 2",
                    value = NULL)
        }
      })
      output$select_gene_no = renderUI({ 
        numericInput(inputId = "gene_no", label = "Gene number for oncoprint",
                     value = min(30, length(sort(unique(Data_report_raw()$Hugo_Symbol)))),
                     min = max(1, length(input$gene)),
                     max = length(sort(unique(Data_report_raw()$Hugo_Symbol))),
                     step = 1)
      })
      incProgress(1 / 8)
      output$select_patho = renderUI({ 
        radioButtons(
          "patho", "Variants for analysis",
          choices = c("Only pathogenic muts", "All muts"),
          selected = "Only pathogenic muts")
      })
      output$select_oncoprint_option = renderUI({ 
        radioButtons(
          "oncoprint_option", "Oncoprint setting",
          choices = c("Sort by mutation frequency", "Sort by pathology", "Sort by age", "Sort by metastasis status at CGP"),
          selected = "Sort by mutation frequency")
      })
      output$select_target_line = renderUI({ 
        pickerInput("target_line", "CTx lines to analyze",
                    choices = c("1","2","3","4"), 
                    selected =  c("1","2","3","4"),
                    options = list(`actions-box` = TRUE),
                    multiple = TRUE)
      })
      output$select_gene_group_analysis = renderUI({ 
        radioButtons(
          "gene_group_analysis", "Case selection based on the mutations",
          choices = c("Only cases with mutations in the gene set are analyzed",
                      "Only cases without mutations in the gene set are analyzed",
                      "All cases"),
          selected = "All cases")
      })
      output$select_special_gene_annotation = renderUI({ 
        radioButtons(
          "special_gene_annotation", "Pathological significance of the genes",
          choices = c("Only pathological mutations are included in the analysis",
                      "This gene is also analyzed for VUS and Benign"),
          selected = "Only pathological mutations are included in the analysis")
      })
      output$select_special_gene_independent = renderUI({ 
        radioButtons(
          "special_gene_independent", "Treat specified variants independently?",
          choices = c("Treat as independent genes in oncoprint",
                      "All cases"),
          selected = "All cases")
      })
      output$select_RMST_CGP = renderUI({ 
        numericInput("RMST_CGP", "Timing for RMST measuring in survival analysis (years)",
                     value = 2,
                     min = 1,
                     max = 5,
                     step = 1)
      })
      output$select_RMST_drug = renderUI({ 
        numericInput("RMST_drug", "Timing for RMST measuring in drug analysis (months)",
                     value = 6,
                     min = 1,
                     max = 60,
                     step = 1)
      })
      
      incProgress(1 / 8)
    })
  })
  output$select_MSI = renderUI({ 
    radioButtons(
      "MSI", "Analyze MSI-PCR test results",
      choices = c("Yes, additional analysis in survival after CGP and drug response",
                  "No"),
      selected = "No")
  })
  output$select_MMR = renderUI({ 
    radioButtons(
      "MMR", "Analyze MMR-IHC test results",
      choices = c("Yes, additional analysis in survival after CGP and drug response",
                  "No"),
      selected = "No")
  })
  output$select_HER2 = renderUI({ 
    radioButtons(
      "HER2", "Analyze HER2-IHC test results",
      choices = c("Yes, additional analysis in survival after CGP and drug response",
                  "No"),
      selected = "No")
  })
  output$select_fusion = renderUI({ 
    radioButtons(
      "fusion", "How to analyze fusion genes",
      choices = c("Split into two and treat as mutation in each gene",
                  "All fusion genes are named as 'fusion_genes'",
                  "As is"),
      selected = "Split into two and treat as mutation in each gene")
  })
  output$download_ID_histology = downloadHandler(
    filename = "ID_histology.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/ID_histology.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )
  output$download_test_clinical_data = downloadHandler(
    filename = "sample_clinical.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/sample_clinical.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )
  output$download_test_report_data = downloadHandler(
    filename = "sample_report.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/sample_report.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )
  output$download_ID_drug_pre_CGP = downloadHandler(
    filename = "ID_drug_pre_CGP.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/ID_drug_pre_CGP.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )
  output$download_ID_drug_post_CGP = downloadHandler(
    filename = "ID_drug_post_CGP.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/ID_drug_post_CGP.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )
  output$download_drug_rename = downloadHandler(
    filename = "table_drug_rename.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/table_drug_rename.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )
  output$download_regimen_rename = downloadHandler(
    filename = "table_regimen_rename.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/table_regimen_rename.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )
  output$download_histology_rename = downloadHandler(
    filename = "table_histology_rename.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/table_histology_rename.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )
  output$download_mutation_rename = downloadHandler(
    filename = "table_mutation_rename.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/table_mutation_rename.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )

  
  
  Data_cluster_ID = reactive({
    if(is.null(input$patho)){
      return(NULL)
    } else {
      withProgress(message = "Clustering based on gene mutation pattern.", {
        Data_case_target = Data_case() %>%
          dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = T)
        if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
          Data_case_target = Data_case_target %>%
            dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                            Data_report()$Tumor_Sample_Barcode)
        }
        Data_MAF_target = Data_report() %>%
          dplyr::filter(
            !str_detect(Hugo_Symbol, ",") &
              Hugo_Symbol != "" &
              Evidence_level %in% c("","A","B","C","D","E","F") &
              Variant_Classification != "expression"
          ) %>% 
          dplyr::arrange(desc(Evidence_level)) %>%
          dplyr::distinct(Tumor_Sample_Barcode,
                          Hugo_Symbol,
                          Start_Position,
                          .keep_all = TRUE)
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Tumor_Sample_Barcode %in%
                          Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
        if(input$patho == "Only pathogenic muts"){
          Data_MAF_target = Data_MAF_target %>%
            dplyr::filter(Evidence_level == "F")
        } else {
          Data_MAF_target = Data_MAF_target %>%
            dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
        }
        Data_MAF_target = Data_MAF_target  %>%
          dplyr::distinct(Tumor_Sample_Barcode,
                          Hugo_Symbol,
                          .keep_all = TRUE)
        Gene_list = unique(names(sort(table(Data_MAF_target$Hugo_Symbol),
                                      decreasing = T)))
        Data_mutation = data.frame(matrix(0,
                                          nrow=length(Data_case_target$C.CAT調査結果.基本項目.ハッシュID),
                                          ncol=length(Gene_list)))
        colnames(Data_mutation) = Gene_list
        rownames(Data_mutation) = Data_case_target$C.CAT調査結果.基本項目.ハッシュID
        for(i in 1:length(Data_MAF_target$Hugo_Symbol)){
          Data_mutation[Data_MAF_target$Tumor_Sample_Barcode[i],
                        Data_MAF_target$Hugo_Symbol[i]] = 1
        }
        if(length(Data_mutation[is.na(Data_mutation)])> 0){
          Data_mutation[is.na(Data_mutation)] <- 0
        }
        n_neighbors_ = min(15, dim(Data_mutation)[1])
        set.seed(1)
        Data_mutation_umap = umap(Data_mutation, random_state=1, n_neighbors = n_neighbors_)
        Data_mutation_cord = Data_mutation_umap$layout %>% as.data.frame()
        EPS = input$eps
        MINPTS = 3
        set.seed(1)
        dbscan_res_changed <- dbscan(Data_mutation_cord, eps = EPS, minPts = MINPTS)
        if(min(dbscan_res_changed$cluster) == 0){
          dbscan_res_changed$cluster = (dbscan_res_changed$cluster + 1)
        }
        Data_mutation_cord$C.CAT調査結果.基本項目.ハッシュID = rownames(Data_mutation)
        Data_mutation_cord$driver_mutations = rowSums(Data_mutation)
        Data_mutation_cord$cluster = dbscan_res_changed$cluster
        return(Data_mutation_cord)
      })
    }
  })
  
  observeEvent(input$summary_base, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
        Data_case_target = Data_case_target %>%
          dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                          Data_report()$Tumor_Sample_Barcode)
      }
      incProgress(1 / 8)
      Data_summary = Data_case_target %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID,.keep_all=TRUE) %>%
        dplyr::select(
          C.CAT調査結果.基本項目.ハッシュID,
          症例.基本情報.がん種.OncoTree.,
          症例.基本情報.がん種.OncoTree..名称.,
          症例.基本情報.がん種.OncoTree.LEVEL1.,
          症例.基本情報.性別.名称.,
          症例.基本情報.年齢,
          症例.背景情報.喫煙歴有無.名称.,
          症例.背景情報.アルコール多飲有無.名称.,
          症例.背景情報.ECOG.PS.名称.,
          症例.背景情報.重複がん有無.異なる臓器..名称.,
          症例.背景情報.多発がん有無.同一臓器..名称.,
          症例.検体情報.パネル.名称.,
          症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
          症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
          症例.がん種情報.肺.EGFR.名称.,
          症例.がん種情報.肺.ALK融合.名称.,
          症例.がん種情報.肺.ROS1.名称.,
          症例.がん種情報.肺.BRAF.V600..名称.,
          症例.がん種情報.肺.MET遺伝子エクソン14スキッピング変異.名称.,
          症例.がん種情報.肺.KRAS.G12C遺伝子変異.名称.,
          症例.がん種情報.肺.RET融合遺伝子.名称.,
          症例.がん種情報.肺.PD.L1.IHC..名称.,
          症例.がん種情報.乳.HER2.IHC..名称.,
          症例.がん種情報.乳.HER2.FISH..名称.,
          症例.がん種情報.乳.ER.名称.,
          症例.がん種情報.乳.PgR.名称.,
          症例.がん種情報.固形がん.マイクロサテライト不安定性.名称.,
          症例.がん種情報.固形がん.ミスマッチ修復機能欠損.名称.,
          症例.がん種情報.食道.胃.腸.HER2.名称.,
          症例.がん種情報.食道.胃.腸.HER2遺伝子増幅..ISH法..名称.,
          Lymph_met,
          Brain_met,
          Lung_met,
          Bone_met,
          Liver_met,
          Other_met)
      incProgress(1 / 8)
      if(!"BOWEL" %in% Data_summary$症例.基本情報.がん種.OncoTree.LEVEL1. &
         !"STOMACH" %in% Data_summary$症例.基本情報.がん種.OncoTree.LEVEL1.){
        Data_summary = Data_summary %>% dplyr::select(
          -症例.がん種情報.食道.胃.腸.HER2.名称.,
          -症例.がん種情報.食道.胃.腸.HER2遺伝子増幅..ISH法..名称.
        )
      }
      if(!"LUNG" %in% Data_summary$症例.基本情報.がん種.OncoTree.LEVEL1.){
        Data_summary = Data_summary %>% dplyr::select(
          -症例.がん種情報.肺.EGFR.名称.,
          -症例.がん種情報.肺.ALK融合.名称.,
          -症例.がん種情報.肺.ROS1.名称.,
          -症例.がん種情報.肺.BRAF.V600..名称.,
          -症例.がん種情報.肺.MET遺伝子エクソン14スキッピング変異.名称.,
          -症例.がん種情報.肺.KRAS.G12C遺伝子変異.名称.,
          -症例.がん種情報.肺.RET融合遺伝子.名称.,
          -症例.がん種情報.肺.PD.L1.IHC..名称.
        )
      }
      if(!"BREAST" %in% Data_summary$症例.基本情報.がん種.OncoTree.LEVEL1.){
        Data_summary = Data_summary %>% dplyr::select(
          -症例.がん種情報.乳.HER2.IHC..名称.,
          -症例.がん種情報.乳.HER2.FISH..名称.,
          -症例.がん種情報.乳.ER.名称.,
          -症例.がん種情報.乳.PgR.名称.
        )
      }
      Data_summary = Data_summary %>% dplyr::select(
        -症例.基本情報.がん種.OncoTree.LEVEL1.,
      )
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
      if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }
      incProgress(1 / 8)

      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      } else {
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
      }
      incProgress(1 / 8)
      Data_MAF_target = Data_MAF_target %>%
        dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change, .keep_all = T) %>%
        dplyr::arrange(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change)
      incProgress(1 / 8)
      if(!input$special_gene == ""){
        ID_special_gene = (Data_MAF_target %>%
          dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_"))))$Tumor_Sample_Barcode
        ID_special_gene_mutation_1 = (Data_MAF_target %>%
                             dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                             amino.acid.change %in% input$special_gene_mutation_1))$Tumor_Sample_Barcode
        ID_special_gene_mutation_2 = (Data_MAF_target %>%
                             dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                             amino.acid.change %in% input$special_gene_mutation_2))$Tumor_Sample_Barcode
        Data_summary = Data_summary %>% dplyr::mutate(
          separation_value = case_when(
            C.CAT調査結果.基本項目.ハッシュID %in% ID_special_gene_mutation_1 ~ paste0(input$special_gene_mutation_1_name, " in ", input$special_gene),
            C.CAT調査結果.基本項目.ハッシュID %in% ID_special_gene_mutation_2 ~ paste0(input$special_gene_mutation_2_name, " in ", input$special_gene),
            C.CAT調査結果.基本項目.ハッシュID %in% ID_special_gene ~ paste0("Other mut in ", input$special_gene),
            TRUE ~ paste0("No mut in ", input$special_gene)
          )
        )
      } else {
        Data_summary = Data_summary %>% dplyr::mutate(
          separation_value = "No mutation pattern")
      }
      incProgress(1 / 8)
      Data_summary = Data_summary %>% dplyr::select(
        -C.CAT調査結果.基本項目.ハッシュID)

      Data_summary$Lymph_met = as.character(Data_summary$Lymph_met)
      Data_summary$Brain_met = as.character(Data_summary$Brain_met)
      Data_summary$Lung_met = as.character(Data_summary$Lung_met)
      Data_summary$Bone_met = as.character(Data_summary$Bone_met)
      Data_summary$Liver_met = as.character(Data_summary$Liver_met)
      Data_summary$Other_met = as.character(Data_summary$Other_met)
      
      colnames_tmp = colnames(Data_summary)
      colnames_tmp[colnames_tmp == "症例.基本情報.がん種.OncoTree."] = "Diagnosis"
      colnames_tmp[colnames_tmp == "症例.基本情報.がん種.OncoTree..名称."] = "Diagnosis (OncoTree)"
      colnames_tmp[colnames_tmp == "症例.基本情報.性別.名称."] = "Sex"
      colnames_tmp[colnames_tmp == "症例.基本情報.年齢"] = "Age"
      colnames_tmp[colnames_tmp == "症例.背景情報.喫煙歴有無.名称."] = "Smoking history"
      colnames_tmp[colnames_tmp == "症例.背景情報.アルコール多飲有無.名称."] = "Alcoholic history"
      colnames_tmp[colnames_tmp == "症例.背景情報.ECOG.PS.名称."] = "Performance status"
      colnames_tmp[colnames_tmp == "症例.背景情報.重複がん有無.異なる臓器..名称."] = "Double cancer in a different organ"
      colnames_tmp[colnames_tmp == "症例.背景情報.多発がん有無.同一臓器..名称."] = "Multiple tumor nodules in the organ"
      colnames_tmp[colnames_tmp == "症例.検体情報.パネル.名称."] = "Cancer gene panel"
      colnames_tmp[colnames_tmp == "症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称."] = "Treatment recommended by expert panel"
      colnames_tmp[colnames_tmp == "症例.EP後レジメン情報.提示された治療薬を投与した.名称."] = "Indicated treatment administered"
      colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
      colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
      colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
      colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
      colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
      colnames_tmp[colnames_tmp == "Other_met"] = "Other organ metastasis"
      colnames_tmp[colnames_tmp == "症例.がん種情報.肺.EGFR.名称."] = "EGFR IHC in lung"
      colnames_tmp[colnames_tmp == "症例.がん種情報.肺.ALK融合.名称."] = "ALK fusion in lung"
      colnames_tmp[colnames_tmp == "症例.がん種情報.肺.ROS1.名称."] = "ROS1 fusion in lung"
      colnames_tmp[colnames_tmp == "症例.がん種情報.肺.BRAF.V600..名称."] = "BRAF V600E in lung"
      colnames_tmp[colnames_tmp == "症例.がん種情報.肺.MET遺伝子エクソン14スキッピング変異.名称."] = "MET ex14 skipping in lung"
      colnames_tmp[colnames_tmp == "症例.がん種情報.肺.KRAS.G12C遺伝子変異.名称."] = "KRAS G12C in lung"
      colnames_tmp[colnames_tmp == "症例.がん種情報.肺.RET融合遺伝子.名称."] = "RET fusion in lung"
      colnames_tmp[colnames_tmp == "症例.がん種情報.肺.PD.L1.IHC..名称."] = "PD-L1 IHC in lung"
      colnames_tmp[colnames_tmp == "症例.がん種情報.乳.HER2.IHC..名称."] = "HER2 IHC in breast"
      colnames_tmp[colnames_tmp == "症例.がん種情報.乳.HER2.FISH..名称."] = "HER2 FISH in breast"
      colnames_tmp[colnames_tmp == "症例.がん種情報.乳.ER.名称."] = "ER IHC in breast"
      colnames_tmp[colnames_tmp == "症例.がん種情報.乳.PgR.名称."] = "PgR IHC in breast"
      colnames_tmp[colnames_tmp == "症例.がん種情報.固形がん.マイクロサテライト不安定性.名称."] = "MSI PCR"
      colnames_tmp[colnames_tmp == "症例.がん種情報.固形がん.ミスマッチ修復機能欠損.名称."] = "MMR IHC"
      colnames_tmp[colnames_tmp == "症例.がん種情報.食道.胃.腸.HER2.名称."] = "HER2 IHC in stomach/bowel"
      colnames_tmp[colnames_tmp == "症例.がん種情報.食道.胃.腸.HER2遺伝子増幅..ISH法..名称."] = "HER2 FISH in stomach/bowel"

      colnames(Data_summary) = colnames_tmp

      if("EGFR IHC in lung" %in% colnames_tmp){
        Data_summary$`EGFR IHC in lung`[is.na(Data_summary$`EGFR IHC in lung`)] = "Unknown"
        Data_summary$`EGFR IHC in lung`[Data_summary$`EGFR IHC in lung` == "陽性"] = "Positive"
        Data_summary$`EGFR IHC in lung`[Data_summary$`EGFR IHC in lung` == "陰性"] = "Negative"
        Data_summary$`EGFR IHC in lung`[Data_summary$`EGFR IHC in lung` == "不明or未検査"] = "Unknown"
        Data_summary$`EGFR IHC in lung`[Data_summary$`EGFR IHC in lung` == "判定不能"] = "Unknown"
      }
      if("ALK fusion in lung" %in% colnames_tmp){
        Data_summary$`ALK fusion in lung`[is.na(Data_summary$`ALK fusion in lung`)] = "Unknown"
        Data_summary$`ALK fusion in lung`[Data_summary$`ALK fusion in lung` == "陽性"] = "Positive"
        Data_summary$`ALK fusion in lung`[Data_summary$`ALK fusion in lung` == "陰性"] = "Negative"
        Data_summary$`ALK fusion in lung`[Data_summary$`ALK fusion in lung` == "不明or未検査"] = "Unknown"
        Data_summary$`ALK fusion in lung`[Data_summary$`ALK fusion in lung` == "判定不能"] = "Unknown"
      }
      if("ROS1 fusion in lung" %in% colnames_tmp){
        Data_summary$`ROS1 fusion in lung`[is.na(Data_summary$`ROS1 fusion in lung`)] = "Unknown"
        Data_summary$`ROS1 fusion in lung`[Data_summary$`ROS1 fusion in lung` == "陽性"] = "Positive"
        Data_summary$`ROS1 fusion in lung`[Data_summary$`ROS1 fusion in lung` == "陰性"] = "Negative"
        Data_summary$`ROS1 fusion in lung`[Data_summary$`ROS1 fusion in lung` == "不明or未検査"] = "Unknown"
        Data_summary$`ROS1 fusion in lung`[Data_summary$`ROS1 fusion in lung` == "判定不能"] = "Unknown"
      }
      if("BRAF V600E in lung" %in% colnames_tmp){
        Data_summary$`BRAF V600E in lung`[is.na(Data_summary$`BRAF V600E in lung`)] = "Unknown"
        Data_summary$`BRAF V600E in lung`[Data_summary$`BRAF V600E in lung` == "陽性"] = "Positive"
        Data_summary$`BRAF V600E in lung`[Data_summary$`BRAF V600E in lung` == "陰性"] = "Negative"
        Data_summary$`BRAF V600E in lung`[Data_summary$`BRAF V600E in lung` == "不明or未検査"] = "Unknown"
        Data_summary$`BRAF V600E in lung`[Data_summary$`BRAF V600E in lung` == "判定不能"] = "Unknown"
      }
      if("MET ex14 skipping in lung" %in% colnames_tmp){
        Data_summary$`MET ex14 skipping in lung`[is.na(Data_summary$`MET ex14 skipping in lung`)] = "Unknown"
        Data_summary$`MET ex14 skipping in lung`[Data_summary$`MET ex14 skipping in lung` == "陽性"] = "Positive"
        Data_summary$`MET ex14 skipping in lung`[Data_summary$`MET ex14 skipping in lung` == "陰性"] = "Negative"
        Data_summary$`MET ex14 skipping in lung`[Data_summary$`MET ex14 skipping in lung` == "不明or未検査"] = "Unknown"
        Data_summary$`MET ex14 skipping in lung`[Data_summary$`MET ex14 skipping in lung` == "判定不能"] = "Unknown"
      }
      if("KRAS G12C in lung" %in% colnames_tmp){
        Data_summary$`KRAS G12C in lung`[is.na(Data_summary$`KRAS G12C in lung`)] = "Unknown"
        Data_summary$`KRAS G12C in lung`[Data_summary$`KRAS G12C in lung` == "陽性"] = "Positive"
        Data_summary$`KRAS G12C in lung`[Data_summary$`KRAS G12C in lung` == "陰性"] = "Negative"
        Data_summary$`KRAS G12C in lung`[Data_summary$`KRAS G12C in lung` == "不明or未検査"] = "Unknown"
        Data_summary$`KRAS G12C in lung`[Data_summary$`KRAS G12C in lung` == "判定不能"] = "Unknown"
      }
      if("RET fusion in lung" %in% colnames_tmp){
        Data_summary$`RET fusion in lung`[is.na(Data_summary$`RET fusion in lung`)] = "Unknown"
        Data_summary$`RET fusion in lung`[Data_summary$`RET fusion in lung` == "陽性"] = "Positive"
        Data_summary$`RET fusion in lung`[Data_summary$`RET fusion in lung` == "陰性"] = "Negative"
        Data_summary$`RET fusion in lung`[Data_summary$`RET fusion in lung` == "不明or未検査"] = "Unknown"
        Data_summary$`RET fusion in lung`[Data_summary$`RET fusion in lung` == "判定不能"] = "Unknown"
      }
      if("PD-L1 IHC in lung" %in% colnames_tmp){
        Data_summary$`PD-L1 IHC in lung`[is.na(Data_summary$`PD-L1 IHC in lung`)] = "Unknown"
        Data_summary$`PD-L1 IHC in lung`[Data_summary$`PD-L1 IHC in lung` == "陽性"] = "Positive"
        Data_summary$`PD-L1 IHC in lung`[Data_summary$`PD-L1 IHC in lung` == "陰性"] = "Negative"
        Data_summary$`PD-L1 IHC in lung`[Data_summary$`PD-L1 IHC in lung` == "不明or未検査"] = "Unknown"
        Data_summary$`PD-L1 IHC in lung`[Data_summary$`PD-L1 IHC in lung` == "判定不能"] = "Unknown"
      }
      if("HER2 IHC in breast" %in% colnames_tmp){
        Data_summary$`HER2 IHC in breast`[is.na(Data_summary$`HER2 IHC in breast`)] = "Unknown"
        Data_summary$`HER2 IHC in breast`[Data_summary$`HER2 IHC in breast` == "陽性（3+）"] = "Positive"
        Data_summary$`HER2 IHC in breast`[Data_summary$`HER2 IHC in breast` %in% c("陰性",  "陰性（1+）")] = "Negative"
        Data_summary$`HER2 IHC in breast`[Data_summary$`HER2 IHC in breast` == "境界域（2+）"] = "Intermediate"
        Data_summary$`HER2 IHC in breast`[Data_summary$`HER2 IHC in breast` == "不明or未検査"] = "Unknown"
        Data_summary$`HER2 IHC in breast`[Data_summary$`HER2 IHC in breast` == "判定不能"] = "Unknown"
      }
      if("HER2 FISH in breast" %in% colnames_tmp){
        Data_summary$`HER2 FISH in breast`[is.na(Data_summary$`HER2 FISH in breast`)] = "Unknown"
        Data_summary$`HER2 FISH in breast`[Data_summary$`HER2 FISH in breast` == "陽性"] = "Positive"
        Data_summary$`HER2 FISH in breast`[Data_summary$`HER2 FISH in breast` == "陰性"] = "Negative"
        Data_summary$`HER2 FISH in breast`[Data_summary$`HER2 FISH in breast` == "不明or未検査"] = "Unknown"
        Data_summary$`HER2 FISH in breast`[Data_summary$`HER2 FISH in breast` == "equivocal"] = "Equivocal"
        Data_summary$`HER2 FISH in breast`[Data_summary$`HER2 FISH in breast` == "判定不能"] = "Unknown"
      }
      if("ER IHC in breast" %in% colnames_tmp){
        Data_summary$`ER IHC in breast`[is.na(Data_summary$`ER IHC in breast`)] = "Unknown"
        Data_summary$`ER IHC in breast`[Data_summary$`ER IHC in breast` == "陽性"] = "Positive"
        Data_summary$`ER IHC in breast`[Data_summary$`ER IHC in breast` == "陰性"] = "Negative"
        Data_summary$`ER IHC in breast`[Data_summary$`ER IHC in breast` == "不明or未検査"] = "Unknown"
        Data_summary$`ER IHC in breast`[Data_summary$`ER IHC in breast` == "判定不能"] = "Unknown"
      }
      if("PgR IHC in breast" %in% colnames_tmp){
        Data_summary$`PgR IHC in breast`[is.na(Data_summary$`PgR IHC in breast`)] = "Unknown"
        Data_summary$`PgR IHC in breast`[Data_summary$`PgR IHC in breast` == "陽性"] = "Positive"
        Data_summary$`PgR IHC in breast`[Data_summary$`PgR IHC in breast` == "陰性"] = "Negative"
        Data_summary$`PgR IHC in breast`[Data_summary$`PgR IHC in breast` == "不明or未検査"] = "Unknown"
        Data_summary$`PgR IHC in breast`[Data_summary$`PgR IHC in breast` == "判定不能"] = "Unknown"
      }
      if("MSI PCR" %in% colnames_tmp){
        Data_summary$`MSI PCR`[is.na(Data_summary$`MSI PCR`)] = "Unknown"
        Data_summary$`MSI PCR`[Data_summary$`MSI PCR` == "陽性"] = "Positive"
        Data_summary$`MSI PCR`[Data_summary$`MSI PCR` == "陰性"] = "Negative"
        Data_summary$`MSI PCR`[Data_summary$`MSI PCR` == "不明or未検査"] = "Unknown"
        Data_summary$`MSI PCR`[Data_summary$`MSI PCR` == "判定不能"] = "Unknown"
      }
      if("MMR IHC" %in% colnames_tmp){
        Data_summary$`MMR IHC`[is.na(Data_summary$`MMR IHC`)] = "Unknown"
        Data_summary$`MMR IHC`[Data_summary$`MMR IHC` == "dMMR(欠損)"] = "dMMR"
        Data_summary$`MMR IHC`[Data_summary$`MMR IHC` == "pMMR(正常)"] = "pMMR"
        Data_summary$`MMR IHC`[Data_summary$`MMR IHC` == "不明or未検査"] = "Unknown"
        Data_summary$`MMR IHC`[Data_summary$`MMR IHC` == "判定不能"] = "Unknown"
      }
      if("HER2 IHC in stomach/bowel" %in% colnames_tmp){
        Data_summary$`HER2 IHC in stomach/bowel`[is.na(Data_summary$`HER2 IHC in stomach/bowel`)] = "Unknown"
        Data_summary$`HER2 IHC in stomach/bowel`[Data_summary$`HER2 IHC in stomach/bowel` == "陽性（3+）"] = "Positive"
        Data_summary$`HER2 IHC in stomach/bowel`[Data_summary$`HER2 IHC in stomach/bowel` == "境界域（2+）"] = "Intermediate"
        Data_summary$`HER2 IHC in stomach/bowel`[Data_summary$`HER2 IHC in stomach/bowel` %in% c("陰性",  "陰性（1+）")] = "Negative"
        Data_summary$`HER2 IHC in stomach/bowel`[Data_summary$`HER2 IHC in stomach/bowel` == "不明or未検査"] = "Unknown"
        Data_summary$`HER2 IHC in stomach/bowel`[Data_summary$`HER2 IHC in stomach/bowel` == "判定不能"] = "Unknown"
      }
      if("HER2 FISH in stomach/bowel" %in% colnames_tmp){
        Data_summary$`HER2 FISH in stomach/bowel`[is.na(Data_summary$`HER2 FISH in stomach/bowel`)] = "Unknown"
        Data_summary$`HER2 FISH in stomach/bowel`[Data_summary$`HER2 FISH in stomach/bowel` == "陽性"] = "Positive"
        Data_summary$`HER2 FISH in stomach/bowel`[Data_summary$`HER2 FISH in stomach/bowel` == "陰性"] = "Negative"
        Data_summary$`HER2 FISH in stomach/bowel`[Data_summary$`HER2 FISH in stomach/bowel` == "equivocal"] = "Equivocal"
        Data_summary$`HER2 FISH in stomach/bowel`[Data_summary$`HER2 FISH in stomach/bowel` == "不明or未検査"] = "Unknown"
        Data_summary$`HER2 FISH in stomach/bowel`[Data_summary$`HER2 FISH in stomach/bowel` == "判定不能"] = "Unknown"
      }
      Data_summary = Data_summary %>%
        dplyr::mutate(
          Sex = case_when(
            Sex == "女" ~ "Female",
            Sex == "未入力・不明" ~ "Unknown",
            Sex == "男" ~ "Male"
          ),
          `Smoking history` = case_when(
            `Smoking history` == "あり" ~ "Yes",
            `Smoking history` == "不明" ~ "Unknown",
            `Smoking history` == "なし" ~ "No"
          ),
          `Alcoholic history` = case_when(
            `Alcoholic history` == "あり" ~ "Yes",
            `Alcoholic history` == "不明" ~ "Unknown",
            `Alcoholic history` == "なし" ~ "No"
          ),
          `Performance status` = case_when(
            `Performance status` == "不明" ~ "Unknown",
            TRUE ~ `Performance status`
          ),
          `Double cancer in a different organ` = case_when(
            `Double cancer in a different organ` == "あり" ~ "Yes",
            `Double cancer in a different organ` == "不明" ~ "Unknown",
            `Double cancer in a different organ` == "なし" ~ "No"
          ),
          `Multiple tumor nodules in the organ` = case_when(
            `Multiple tumor nodules in the organ` == "あり" ~ "Yes",
            `Multiple tumor nodules in the organ` == "不明" ~ "Unknown",
            `Multiple tumor nodules in the organ` == "なし" ~ "No"
          ),
          `Treatment recommended by expert panel` = case_when(
            `Treatment recommended by expert panel` == "いいえ" ~ "No",
            `Treatment recommended by expert panel` == "はい" ~ "Yes"
          ),
          `Indicated treatment administered` = case_when(
            `Indicated treatment administered` == "投与した" ~ "Yes",
            `Indicated treatment administered` == "投与しなかった" ~ "No"
          )
        )
      output$table_summary_1 <- render_gt({
        Data_summary %>% dplyr::select(
          -`Diagnosis`) %>%
          tbl_summary(
            by = "separation_value",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
                          type = list(all_continuous() ~ "continuous2",
                                      all_dichotomous() ~ "categorical"),
                          digits = all_continuous() ~ 2,
                          missing = "ifany") %>%
          modify_caption("**Patient Characteristics** (N = {N})") %>%
          add_n() %>%
          bold_labels() %>% as_gt()
      })
      incProgress(1 / 8)
      output$table_summary_2 <- render_gt({
        Data_summary %>% dplyr::select(
          -"Diagnosis (OncoTree)",
          -separation_value) %>%
          tbl_summary(
            by = "Diagnosis",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Patient Characteristics, by diagnosis** (N = {N})") %>%
          add_n() %>%
          bold_labels() %>% as_gt()
      })
      incProgress(1 / 8)
    })
  })

  observeEvent(input$oncoprint, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
        Data_case_target = Data_case_target %>%
          dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                          Data_report()$Tumor_Sample_Barcode)
      }
      Data_MAF = Data_report() %>%
       dplyr::filter(
         !str_detect(Hugo_Symbol, ",") &
         Hugo_Symbol != "" &
         Evidence_level %in% c("","A","B","C","D","E","F") &
         Variant_Classification != "expression"
       ) %>% 
       dplyr::arrange(desc(Evidence_level)) %>%
       dplyr::distinct(Tumor_Sample_Barcode,
                       Hugo_Symbol,
                       Start_Position,
                       .keep_all = TRUE)
     if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
       Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
     }

     incProgress(1 / 8)
     
     Data_MAF_target = Data_MAF %>%
       dplyr::filter(Tumor_Sample_Barcode %in%
                       Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
     if(input$patho == "Only pathogenic muts"){
       Data_MAF_target = Data_MAF_target %>%
         dplyr::filter(Evidence_level == "F")
     } else {
       Data_MAF_target = Data_MAF_target %>%
         dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
     }

     incProgress(1 / 8)
     Data_MAF_target_tmp = Data_MAF_target %>%
       dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change, .keep_all = T) %>%
       dplyr::arrange(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change)
     Data_MAF_target = Data_MAF_target_tmp #%>%
      #  dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, .keep_all = T) %>%
     #   dplyr::arrange(Hugo_Symbol, Tumor_Sample_Barcode)
     output$figure_oncoprint = renderPlot({
       fun_oncoprint(Data_MAF_target,
                     Data_case_target,
                     names(sort(table(Data_MAF_target$Hugo_Symbol),
                                decreasing = T)),
                     input$gene,
                     input$gene_no,
                     input$gene_group_1,
                     input$gene_group_2,
                     input$oncoprint_option,
                     input$mid_age)
     })
     incProgress(1 / 8)
     output$figure_lolliplot2 = renderPlot({
       withProgress(message = "Internet access is necessary", {
         lolliplot_gene = input$lolliplot_gene
         if(is.null(lolliplot_gene)){
           lolliplot_gene = "TP53"
         } else if(lolliplot_gene == ""){
           lolliplot_gene = "TP53"
         }
         data_lolliplot = Data_MAF_target %>%
           dplyr::select(Chromosome,
                         Start_Position,
                         End_Position,
                         Reference_Allele,
                         Tumor_Seq_Allele2,
                         Tumor_Sample_Barcode,
                         Hugo_Symbol,
                         Variant_Classification,
                         amino.acid.change)
         data_lolliplot = data_lolliplot %>%
           dplyr::filter(!Variant_Classification %in% c("rearrangement",
                                             "truncation",
                                             "amplification",
                                             "fusion",
                                             "TMB_high",
                                             "duplication",
                                             "exon_skipping",
                                             "deletion",
                                             "loss")) %>%
           dplyr::filter(!str_detect(amino.acid.change, "c.")) %>%
           dplyr::filter(!str_detect(amino.acid.change, "_")) %>%
           dplyr::filter(Hugo_Symbol == lolliplot_gene) 
         if(length(data_lolliplot$Chromosome) == 0){
           gg_empty()
         } else {
           var<-unique(data_lolliplot[!duplicated(data_lolliplot),])#remove duplicates
           var[order(var$Hugo_Symbol,gsub("([A-Z]+)([0-9]+)","\\2",var$amino.acid.change)),]#order
           var.freq<-plyr::count(var,c("Hugo_Symbol","amino.acid.change","Variant_Classification"))
           var.aanum<-unlist(lapply(regmatches(var.freq$amino.acid.change,gregexpr(pattern="*(\\d+)",var.freq$amino.acid.change)),function(x) x[[1]]))
           var.plot.data<-cbind(var.freq,as.numeric(as.character(var.aanum)))#hard way to remove factor
           colnames(var.plot.data)[5]<-"var.aanum"
           var.plot.data = var.plot.data[var.plot.data$var.aanum >=1 & is.finite(var.plot.data$var.aanum) & !is.na(var.plot.data$var.aanum),]
           
           var.plot<-isolate(var.plot.data)
           var.plot<-var.plot[var.plot$Hugo_Symbol==lolliplot_gene,]
           var.plot<-var.plot[order(var.plot$var.aanum),]
           var.plot$amino.acid.change<-as.character(var.plot$amino.acid.change)
           
           incProgress(1 / 4)
  
           p<-ggplot(var.plot,aes(var.aanum,freq,color=Variant_Classification,label=amino.acid.change)) +
             geom_segment(aes(x=var.aanum,y=0,xend=var.aanum,yend=freq),
                          color=ifelse(var.plot$freq>=input$lolliplot_no,"orange","grey50"),
                          linewidth=ifelse(var.plot$freq>=input$lolliplot_no,1.3,0.7)) +
             geom_point(size=5) +
             geom_text_repel(nudge_y=0.2,
                             color=ifelse(var.plot$freq>=input$lolliplot_no,"orange","NA"),
                             size=ifelse(var.plot$freq>=input$lolliplot_no,5,5),
                             fontface="bold", max.overlaps=Inf) +
             theme_classic()
           proteins_acc<-read.table(file("source/UniProt.txt",
                                         encoding='UTF-8-BOM'),header=T)
           if(length(proteins_acc[proteins_acc$Hugo_Symbol==lolliplot_gene,2]) == 1){
             proteins_acc<-proteins_acc[proteins_acc$Hugo_Symbol==lolliplot_gene,2]
             proteins_acc_url<-gsub(" ","%2C",proteins_acc)
             baseurl<-"https://www.ebi.ac.uk/proteins/api/features?offset=0&size=100&accession="
             url<-paste0(baseurl,proteins_acc_url)
             incProgress(1 / 6)
             flag_lolliplot = 0
             if(file.exists(paste0("source/lolliplot/", lolliplot_gene, ".rda"))){
               load(paste0("source/lolliplot/", lolliplot_gene, ".rda"))
               flag_lolliplot = 1
             } else {
               prots_feat<-try(GET(url,accept_json()), silent = FALSE)
               if (class(prots_feat) != "try-error"){
                 flag_lolliplot = 1
                 save(prots_feat, file=paste0("source/lolliplot/", lolliplot_gene, ".rda"))
               }
             }
             if (flag_lolliplot == 1){
               prots_feat_red<-(httr::content(prots_feat))
               incProgress(1 / 6)
               features_total_plot<-NULL
               for(i in 1:length(prots_feat_red)){ 
                 features_temp<-drawProteins::extract_feat_acc(prots_feat_red[[i]])#the extract_feat_acc() function takes features into a data.frame
                 features_temp$order<-i # this order is needed for plotting later
                 features_total_plot<-rbind(features_total_plot,features_temp)
               }
               plot_start<-0#starts 0
               plot_end<-max(features_total_plot$end)
               if("CHAIN"%in%(unique(features_total_plot$type))){
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="CHAIN",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.1*max(var.plot$freq),ymax=-0.04*max(var.plot$freq)),
                             colour="grey",
                             fill="grey",
                             inherit.aes=F)
               }
               incProgress(1 / 6)
               if("DNA_BIND"%in%(unique(features_total_plot$type))) {
                 features_total_plot[features_total_plot$type=="DNA_BIND","description"] <- features_total_plot[features_total_plot$type=="DNA_BIND","type"]
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="DNA_BIND",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.12*max(var.plot$freq),ymax=-0.02*max(var.plot$freq),fill=description),
                             inherit.aes=F)
               }
               if("DOMAIN"%in%(unique(features_total_plot$type))){
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="DOMAIN",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.12*max(var.plot$freq),ymax=-0.02*max(var.plot$freq),fill=description),
                             inherit.aes=F)
               }
               if("MOTIF"%in%(unique(features_total_plot$type))){
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="MOTIF",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.12*max(var.plot$freq),ymax=-0.02*max(var.plot$freq),fill=description),
                             inherit.aes=F)
               }
               if("REPEAT"%in%(unique(features_total_plot$type))){
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="REPEAT",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.12*max(var.plot$freq),ymax=-0.02*max(var.plot$freq),fill=description),
                             inherit.aes=F)
               }
               p <- p +
                 scale_x_continuous(breaks=round(seq(plot_start,plot_end,by=50)),name="Amino acid number")
             }
           }
           p <- p +
             theme(plot.title=element_text(face="bold",size=(15),hjust=0),axis.text.x=element_text(angle=90,hjust=1)) +
             labs(y="Mutation frequency in our dataset",
                  title=paste("Mutation frequency at ",lolliplot_gene," in the dataset",sep="")) +
             scale_y_continuous(breaks=seq(0,max(var.plot$freq),max(floor(max(var.plot$freq)/100)*10,5)),name="Frequency")
           print(p)
           incProgress(1 / 6)
         }
       })
     })
     incProgress(1 / 8)

     Data_case_target = Data_case_target %>%
       dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE) %>%
       dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                     症例.基本情報.年齢,
                     YoungOld,
                     Lymph_met,
                     Brain_met,
                     Lung_met,
                     Bone_met,
                     Liver_met,
                     Other_met,
                     EP_option,
                     EP_treat,
                     症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                     症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                     症例.基本情報.性別.名称.,
                     症例.基本情報.がん種.OncoTree.,
                     症例.基本情報.がん種.OncoTree..名称.,
                     症例.基本情報.がん種.OncoTree.LEVEL1.,
                     症例.検体情報.パネル.名称.,
                     症例.背景情報.ECOG.PS.名称.,
                     症例.背景情報.喫煙歴有無.名称.,
                     症例.背景情報.アルコール多飲有無.名称.,
                     症例.背景情報.重複がん有無.異なる臓器..名称.,
                     症例.背景情報.多発がん有無.同一臓器..名称.,
                     症例.がん種情報.登録時転移部位.名称.,
                     症例.検体情報.腫瘍細胞含有割合,
                     症例.検体情報.検体採取部位.名称.,
                     症例.転帰情報.転帰.名称.,
                     症例.背景情報.診断日,
                     症例.管理情報.登録日,
                     症例.転帰情報.最終生存確認日,
                     症例.転帰情報.死亡日
                     ) %>%
       dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE) %>%
       dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
     incProgress(1 / 8)
     gene_list = unique(c(input$gene,
                   names(sort(table(Data_MAF_target$Hugo_Symbol),
                            decreasing = T))))
     gene_list = gene_list[gene_list %in% unique(Data_MAF_target$Hugo_Symbol)]
     gene_list = gene_list[1:min(input$gene_no, length(gene_list))]
     gene_table = data.frame(matrix(rep(rep("", length(gene_list)),
                                        length(Data_case_target$C.CAT調査結果.基本項目.ハッシュID)),
                                    nrow=length(Data_case_target$C.CAT調査結果.基本項目.ハッシュID)))
     rownames(gene_table) = Data_case_target$C.CAT調査結果.基本項目.ハッシュID
     colnames(gene_table) = gene_list
     incProgress(1 / 8)
     for(i in 1:length(gene_list)){
       tmp_mut = Data_MAF_target_tmp %>%
         dplyr::filter(Hugo_Symbol == gene_list[i])
       ID_mut = tmp_mut$Tumor_Sample_Barcode
       Variant_mut = tmp_mut$amino.acid.change
       for(j in 1:length(ID_mut)){
         if(gene_table[ID_mut[j],i] == ""){
           gene_table[ID_mut[j],i] = Variant_mut[j]
         } else{
           gene_table[ID_mut[j],i] = paste(gene_table[ID_mut[j],i], Variant_mut[j], sep=",")
         }
       }
     }
     incProgress(1 / 8)
     gene_table$C.CAT調査結果.基本項目.ハッシュID = rownames(gene_table)

     Data_case_target = left_join(Data_case_target,
                                  gene_table,
                                  by = "C.CAT調査結果.基本項目.ハッシュID")
     Data_case_target_table = Data_case_target %>% dplyr::select(-症例.基本情報.がん種.OncoTree.)
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                              "C.CAT調査結果\\.基本項目\\.",
                                              "")
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                              "症例\\.EP後レジメン情報\\.",
                                              "")
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                              "症例\\.基本情報\\.",
                                              "")
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                              "症例\\.検体情報\\.",
                                              "")
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                              "症例\\.背景情報\\.",
                                              "")
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                              "症例\\.がん種情報\\.",
                                              "")
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                              "症例\\.転帰情報\\.",
                                              "")
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                              "症例\\.管理情報\\.",
                                              "")
     colnames(Data_case_target_table) = str_replace(colnames(Data_case_target_table),
                                                    "\\.名称\\.",
                                                    "")
     output$table_patient = DT::renderDataTable(Data_case_target_table,
                                                server = FALSE,
                                                filter = 'top', 
                                                extensions = c('Buttons'), 
                                                options = list(pageLength = 100, 
                                                               scrollX = TRUE,
                                                               scrollY = "1000px",
                                                               scrollCollapse = TRUE,
                                                               dom="Blfrtip",
                                                               buttons = c('csv', 'copy')))
     incProgress(1 / 1)
    })
  })
  
  # Mutually exclusive or co-occurrence
  observeEvent(input$mutually_exclusive, {
    withProgress(message = sample(nietzsche)[1], {
      output$figure_mutually_exclusive = renderPlot({
        Data_case_target = Data_case()
        if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
          Data_case_target = Data_case_target %>%
            dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                            Data_report()$Tumor_Sample_Barcode)
        }
        Data_case_target = Data_case_target %>%
          dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                        症例.基本情報.年齢,
                        症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                        症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                        症例.基本情報.性別.名称.,
                        症例.基本情報.がん種.OncoTree.,
                        症例.基本情報.がん種.OncoTree..名称.,
                        症例.基本情報.がん種.OncoTree.LEVEL1.,
                        症例.検体情報.パネル.名称.,
                        症例.背景情報.ECOG.PS.名称.,
                        症例.背景情報.喫煙歴有無.名称.,
                        症例.背景情報.アルコール多飲有無.名称.,
                        症例.背景情報.重複がん有無.異なる臓器..名称.,
                        症例.背景情報.多発がん有無.同一臓器..名称.,
                        症例.がん種情報.登録時転移部位.名称.,
                        症例.検体情報.腫瘍細胞含有割合,
                        症例.検体情報.検体採取部位.名称.,
                        症例.転帰情報.転帰.名称.,
                        症例.背景情報.診断日,
                        症例.管理情報.登録日,
                        症例.転帰情報.最終生存確認日,
                        症例.転帰情報.死亡日
          )
        Data_MAF = Data_report() %>%
          dplyr::filter(
            !str_detect(Hugo_Symbol, ",") &
              Hugo_Symbol != "" &
              Evidence_level %in% c("","A","B","C","D","E","F") &
              Variant_Classification != "expression"
          ) %>% 
          dplyr::arrange(desc(Evidence_level)) %>%
          dplyr::distinct(Tumor_Sample_Barcode,
                          Hugo_Symbol,
                          Start_Position,
                          .keep_all = TRUE)
        if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
          Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
        }

        
        Data_MAF_target = Data_MAF %>%
          dplyr::filter(Tumor_Sample_Barcode %in%
                          Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
        if(input$patho == "Only pathogenic muts"){
          Data_MAF_target = Data_MAF_target %>%
            dplyr::filter(Evidence_level == "F")
        } else {
          Data_MAF_target = Data_MAF_target %>%
            dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
          
        }
        Data_MAF_target = Data_MAF_target  %>%
          dplyr::distinct(Tumor_Sample_Barcode,
                          Hugo_Symbol,
                          .keep_all = TRUE)
        Gene_names = unique(c(input$gene,
                              names(sort(table(Data_MAF_target$Hugo_Symbol),
                                         decreasing = T))))
        Gene_names = Gene_names[Gene_names %in% unique(Data_MAF_target$Hugo_Symbol)]
        Gene_names = Gene_names[1:min(length(unique(Data_MAF_target$Hugo_Symbol)),input$gene_no)]
        Patient_names = unique(Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
        Mutation_matrix = matrix(rep(0, length(Gene_names) * length(Patient_names)),
                                 nrow = length(Gene_names),
                                 ncol = length(Patient_names))
        rownames(Mutation_matrix) = Gene_names
        colnames(Mutation_matrix) = Patient_names
        
        Mutation_list_for_matrix = Data_MAF_target %>%
          dplyr::filter(Hugo_Symbol %in% Gene_names)
        for(i in 1:length(Mutation_list_for_matrix$Hugo_Symbol)){
          Mutation_matrix[Mutation_list_for_matrix$Hugo_Symbol[i],
                          Mutation_list_for_matrix$Tumor_Sample_Barcode[i]] = 1
        }
        PMA <- getPM(Mutation_matrix)
        mutually_exclusive <- getMutex(A=Mutation_matrix,PM=PMA)
        colnames(mutually_exclusive) = Gene_names
        rownames(mutually_exclusive) = Gene_names
        mutually_exclusive[lower.tri(mutually_exclusive,diag=TRUE)] <- NA
        Data_mut_ex = expand.grid(Gene_names, Gene_names)
        colnames(Data_mut_ex) = c("Gene_1", "Gene_2")
        Data_mut_ex$P_value = mutually_exclusive@x
        Data_mut_ex = Data_mut_ex %>%
          dplyr::mutate(P_value = case_when(
            P_value > 1-10^-10 ~ 1-10^-10,
            P_value < 10^-10 ~ 10^-10,
            TRUE ~ P_value
          ))
        Data_mut_ex = Data_mut_ex %>%
          dplyr::mutate(P_co_or_ex = case_when(
            P_value > 0.5 ~ log(1-P_value,base=10),
            TRUE ~ -log(P_value,base=10)
          ))
        Data_mut_ex = Data_mut_ex %>%
          dplyr::mutate(P_figure = case_when(
            P_co_or_ex > 3 ~ 3,
            P_co_or_ex < -3 ~ -3,
            TRUE ~ P_co_or_ex
          ))
        Data_mut_ex = Data_mut_ex %>%
          dplyr::mutate(P_signif = case_when(
            P_value <= 0.001 | P_value >= 0.999 ~ "*",
            TRUE ~ ""
          ))
        
        Data_mut_ex$Gene_1 <- factor(Data_mut_ex$Gene_1, levels = Gene_names)
        Data_mut_ex$Gene_2 <- factor(Data_mut_ex$Gene_2, levels = Gene_names)
        
        Data_mut_ex %>% 
          ggplot(aes(x = Gene_1, y = Gene_2, fill = P_figure)) + 
          geom_tile(color = "white") + 
          scale_fill_gradient2(low = "red", high = "blue", mid = "white", 
                               midpoint = 0, limit = c(-3, 3), 
                               breaks = -3:3,
                               labels = c(3,2,1,0,1,2,3),
                               name = "-log10(P-value)", space = "Lab",
                               na.value = "white") +
          geom_text(aes(label = P_signif),
                    color = "black", size = 4)+
          scale_y_discrete(limits = rev(levels(Data_mut_ex$Gene_2))) +
          theme_classic() +
          ggtitle("Mutually exclusive (blue) or co-occurrence (red)\n*: p<0.001, estimated with Rediscover package") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1))
      })
      incProgress(1 / 1)
    })
  })
  
  observeEvent(input$mut_subtype, {
    withProgress(message = sample(nietzsche)[1], {
      output$figure_mut_subtype = renderPlot({
        Data_case_target = Data_case()
        if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
          Data_case_target = Data_case_target %>%
            dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                            Data_report()$Tumor_Sample_Barcode)
        }
        Data_case_target = Data_case_target %>%
          dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                        症例.基本情報.年齢,
                        Lymph_met,
                        Brain_met,
                        Lung_met,
                        Bone_met,
                        Liver_met,
                        Other_met,
                        EP_option,
                        EP_treat,
                        症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                        症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                        症例.基本情報.性別.名称.,
                        症例.基本情報.がん種.OncoTree.,
                        症例.基本情報.がん種.OncoTree..名称.,
                        症例.基本情報.がん種.OncoTree.LEVEL1.,
                        症例.検体情報.パネル.名称.,
                        症例.背景情報.ECOG.PS.名称.,
                        症例.背景情報.喫煙歴有無.名称.,
                        症例.背景情報.アルコール多飲有無.名称.,
                        症例.背景情報.重複がん有無.異なる臓器..名称.,
                        症例.背景情報.多発がん有無.同一臓器..名称.,
                        症例.がん種情報.登録時転移部位.名称.,
                        症例.検体情報.腫瘍細胞含有割合,
                        症例.検体情報.検体採取部位.名称.,
                        症例.転帰情報.転帰.名称.,
                        症例.背景情報.診断日,
                        症例.管理情報.登録日,
                        症例.転帰情報.最終生存確認日,
                        症例.転帰情報.死亡日
          )
        Data_MAF = Data_report() %>%
          dplyr::filter(
            !str_detect(Hugo_Symbol, ",") &
              Hugo_Symbol != "" &
              Evidence_level %in% c("","A","B","C","D","E","F") &
              Variant_Classification != "expression"
          ) %>% 
          dplyr::arrange(desc(Evidence_level)) %>%
          dplyr::distinct(Tumor_Sample_Barcode,
                          Hugo_Symbol,
                          Start_Position,
                          .keep_all = TRUE)
         if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
          Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
        }

        
        Data_MAF_target = Data_MAF %>%
          dplyr::filter(Tumor_Sample_Barcode %in%
                          Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
        if(input$patho == "Only pathogenic muts"){
          Data_MAF_target = Data_MAF_target %>%
            dplyr::filter(Evidence_level == "F")
        } else {
          Data_MAF_target = Data_MAF_target %>%
            dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
          
        }
        Data_MAF_target = Data_MAF_target  %>%
          dplyr::distinct(Tumor_Sample_Barcode,
                          Hugo_Symbol,
                          .keep_all = TRUE)
        gene_to_analyze = unique(c(input$gene,
                              names(sort(table(Data_MAF_target$Hugo_Symbol),
                                         decreasing = T))))
        gene_to_analyze = gene_to_analyze[gene_to_analyze %in% unique(Data_MAF_target$Hugo_Symbol)]
        gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_MAF_target$Hugo_Symbol)),input$gene_no)]
        Diseases = sort(unique(Data_case_target$症例.基本情報.がん種.OncoTree.))
        Summary_Gene_alteration = data.frame(matrix(0,
                                                    nrow=length(Diseases),
                                                    ncol=length(gene_to_analyze)))
        colnames(Summary_Gene_alteration) = gene_to_analyze
        rownames(Summary_Gene_alteration) = Diseases
        
        for(i in Diseases){
          Data_tmp = Data_case_target %>%
            dplyr::filter(症例.基本情報.がん種.OncoTree. == i)
          Data_tmp = unique(Data_tmp$C.CAT調査結果.基本項目.ハッシュID)
          patient_no = length(Data_tmp)
          for(j in gene_to_analyze){
            Summary_Gene_alteration[i,j] =
              length((Data_MAF_target %>% dplyr::filter(
                Hugo_Symbol == j &
                  Tumor_Sample_Barcode %in% Data_tmp))$Hugo_Symbol) / patient_no * 100
          }
        }
        
        Data_tmp = Summary_Gene_alteration
        Data_tmp$Disease = rownames(Data_tmp)
        Data_tmp = Data_tmp %>% gather(value = "freq", key = Gene, -Disease)
        Data_tmp <- transform(Data_tmp, Disease= factor(Disease, levels = sort(unique(Disease), decreasing = TRUE)))
        ggplot(Data_tmp, aes(as.factor(Gene), as.factor(Disease))) +
          geom_tile(aes(fill = freq), color = "black",
                    #            lwd = 1,
                    linetype = 1) + 
          geom_text(aes(label = round(freq, 0))) +
          scale_fill_gradient(low = "white", high = "red", limit=c(0,100), name="Frequency (%)") +
          theme_classic() +
          labs(title = "Frequently mutated genes and diagnoses") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1),
                axis.title.x = element_blank(),
                axis.title.y = element_blank(),
                axis.ticks.x = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.x = element_blank(),
                axis.line.y = element_blank())
      })
    })
  })

  
  observeEvent(input$custering_analysis, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
        Data_case_target = Data_case_target %>%
          dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                          Data_report()$Tumor_Sample_Barcode)
      }
      Data_case_target = Data_case_target %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                      症例.基本情報.年齢,
                      Lymph_met,
                      Brain_met,
                      Lung_met,
                      Bone_met,
                      Liver_met,
                      Other_met,
                      EP_option,
                      EP_treat,
                      YoungOld,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.実施目的.名称.,
                      症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                      症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                      症例.基本情報.性別.名称.,
                      症例.基本情報.がん種.OncoTree.,
                      症例.基本情報.がん種.OncoTree..名称.,
                      症例.基本情報.がん種.OncoTree.LEVEL1.,
                      症例.検体情報.パネル.名称.,
                      症例.背景情報.ECOG.PS.名称.,
                      症例.背景情報.喫煙歴有無.名称.,
                      症例.背景情報.アルコール多飲有無.名称.,
                      症例.背景情報.重複がん有無.異なる臓器..名称.,
                      症例.背景情報.多発がん有無.同一臓器..名称.,
                      症例.がん種情報.登録時転移部位.名称.,
                      症例.検体情報.腫瘍細胞含有割合,
                      症例.検体情報.検体採取部位.名称.,
                      症例.転帰情報.転帰.名称.,
                      症例.背景情報.診断日,
                      症例.管理情報.登録日,
                      症例.転帰情報.最終生存確認日,
                      症例.転帰情報.死亡日
        )
      incProgress(1 / 13)      
      Data_case_target$Cancers = Data_case_target$症例.基本情報.がん種.OncoTree.
      Data_survival = Data_case_target %>%
        dplyr::mutate(final_observe = case_when(
          症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
          症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
          症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
          TRUE ~ 症例.管理情報.登録日))
      Data_survival = Data_survival %>%
        dplyr::arrange(desc(final_observe)) %>%
        dplyr::mutate(censor = case_when(
          症例.転帰情報.死亡日 != "" ~ 1,
          TRUE ~ 0)) %>%
        dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
      
      Data_survival = Data_survival %>%
        dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
        dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
      
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, censor) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      
      Data_survival = Data_survival %>%
        dplyr::mutate(final_observe = as.Date(Data_survival$final_observe)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(Data_survival$症例.管理情報.登録日)) %>%
        dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                        as.Date(症例.EP前レジメン情報.投与開始日))
      
      Data_survival = Data_survival %>%
        dplyr::mutate(time_enroll_final =
                        as.integer(difftime(Data_survival$final_observe,
                                            Data_survival$症例.管理情報.登録日,
                                            units = "days")))
      Data_survival = Data_survival %>%
        dplyr::mutate(time_palliative_final =
                        as.integer(difftime(Data_survival$final_observe,
                                            Data_survival$症例.EP前レジメン情報.投与開始日,
                                            units = "days")))
      Data_survival = Data_survival %>%
        dplyr::mutate(time_palliative_enroll =
                        Data_survival$time_palliative_final -
                        Data_survival$time_enroll_final)
  
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, final_observe) %>%
        dplyr::arrange(desc(final_observe)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
  
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_enroll_final) %>%
        dplyr::arrange(desc(time_enroll_final)) %>%
        dplyr::filter(time_enroll_final > 0 & !is.na(time_enroll_final) & is.finite(time_enroll_final)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      incProgress(1 / 13)
      Data_survival_tmp = Data_survival %>%
        dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                        c("その他", "緩和")) %>%
        dplyr::arrange(症例.EP前レジメン情報.投与開始日) %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_palliative_enroll, time_palliative_final) %>%
        dplyr::filter(time_palliative_enroll > 0 & time_palliative_enroll < 10000 & !is.na(time_palliative_enroll) & is.finite(time_palliative_enroll)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
  
      Data_case_target = Data_case_target %>%
        dplyr::distinct(.keep_all = TRUE, C.CAT調査結果.基本項目.ハッシュID)
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
      if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }

      Data_report_TMB = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
        dplyr::select(Tumor_Sample_Barcode, TMB) %>%
        dplyr::distinct(Tumor_Sample_Barcode, .keep_all=T)
      colnames(Data_report_TMB) = c("C.CAT調査結果.基本項目.ハッシュID", "TMB")
      Data_case_target = left_join(Data_case_target, Data_report_TMB,
                                   by = "C.CAT調査結果.基本項目.ハッシュID")
      
      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      } else {
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
        
      }
      Data_MAF_target = Data_MAF_target  %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        .keep_all = TRUE)
      incProgress(1 / 13)
      Cancername = sort(unique(Data_case_target$Cancers))
      Total_pts = as.vector(table((Data_case_target %>%
                                     dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = T))$Cancers))
      Gene_list = unique(names(sort(table(Data_MAF_target$Hugo_Symbol),
                                      decreasing = T)))

      Data_mutation_cord = Data_cluster_ID() %>% dplyr::select(-C.CAT調査結果.基本項目.ハッシュID, -cluster, -driver_mutations)
      Data_case_target = left_join(Data_case_target,
                                   Data_cluster_ID() %>% dplyr::select(C.CAT調査結果.基本項目.ハッシュID, cluster, driver_mutations),
                                   by = "C.CAT調査結果.基本項目.ハッシュID")      
      
      Data_report_tmp = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Variant_Classification != "expression"
        )

      Data_report_tmp = Data_report_tmp %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      
      Data_disease = (Data_case_target %>%
                    dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID,
                                    症例.基本情報.がん種.OncoTree.))
      colnames(Data_disease) = c("Tumor_Sample_Barcode", "Cancers")
      Data_MAF_target = left_join(Data_MAF_target,
                                  Data_disease,
                                  by = "Tumor_Sample_Barcode")
      Data_MAF_target$Cancers = as.factor(Data_MAF_target$Cancers)
      Data_report_tmp = left_join(Data_report_tmp,
                                  Data_disease,
                                 by = "Tumor_Sample_Barcode")
      Data_report_tmp$Cancers = as.factor(Data_report_tmp$Cancers)
      Data_report_tmp = Data_report_tmp %>% dplyr::mutate(
        Evidence_level = case_when(
          Evidence_level == "F" & Hugo_Symbol == "TMB" ~ "A",
          Evidence_level == "" ~ "G",
          TRUE ~ Evidence_level)
        ) %>% dplyr::mutate(Drug = case_when(
          Evidence_level == "A" &
            Hugo_Symbol == "TMB" &
            Drug == "" ~ "pembrolizumab",
            TRUE ~ Drug)
        ) %>% dplyr::mutate(Resistance = case_when(
          Evidence_level %in% c("R2*","R1*","R3*","R2","R3","R","R1") ~ 1,
          TRUE ~ 0)
        ) %>%
        dplyr::distinct(Tumor_Sample_Barcode, Evidence_level, Drug, .keep_all = T)
      incProgress(1 / 13)
      
      Data_report_tmp = Data_report_tmp  %>%
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::filter(Resistance != 1) %>%
        dplyr::filter(!Evidence_level %in% c("F", "G")) %>%
        dplyr::distinct(Tumor_Sample_Barcode, .keep_all = T)
      Data_report_tmp$Level = as.factor(Data_report_tmp$Evidence_level)
      data_figure = Data_report_tmp %>% dplyr::select(Cancers,Level) %>% dplyr::filter(!is.na(Cancers)&!is.na(Level))
      Num_A = rep(0, length(Cancername))
      names(Num_A) = Cancername
      Num_tmp = table((data_figure %>% dplyr::filter(Level == "A"))$Cancers)
      if(length(Num_tmp) > 0){
        for(i in 1:length(Num_tmp)){
          Num_A[names(Num_tmp)[i]] = Num_tmp[i]
        }
        Num_A = fun_zero(Num_A, Total_pts)
      }
      Num_B = rep(0, length(Cancername))
      names(Num_B) =  Cancername
      Num_tmp = table((data_figure %>% dplyr::filter(Level == "B"))$Cancers)
      if(length(Num_tmp) > 0){
        for(i in 1:length(Num_tmp)){
          Num_B[names(Num_tmp)[i]] = Num_tmp[i]
        }
        Num_B = fun_zero(Num_B, Total_pts)
      }
      Num_C = rep(0, length(Cancername))
      names(Num_C) =  Cancername
      Num_tmp = table((data_figure %>% dplyr::filter(Level == "C"))$Cancers)
      if(length(Num_tmp) > 0){
        for(i in 1:length(Num_tmp)){
          Num_C[names(Num_tmp)[i]] = Num_tmp[i]
        }
        Num_C = fun_zero(Num_C, Total_pts)
      }
      Num_D = rep(0, length(Cancername))
      names(Num_D) =  Cancername
      Num_tmp = table((data_figure %>% dplyr::filter(Level == "D"))$Cancers)
      if(length(Num_tmp) > 0){
        for(i in 1:length(Num_tmp)){
          Num_D[names(Num_tmp)[i]] = Num_tmp[i]
        }
        Num_D = fun_zero(Num_D, Total_pts)
      }
      Num_E = rep(0, length(Cancername))
      names(Num_E) =  Cancername
      Num_tmp = table((data_figure %>% dplyr::filter(Level == "E"))$Cancers)
      if(length(Num_tmp) > 0){
        for(i in 1:length(Num_tmp)){
          Num_E[names(Num_tmp)[i]] = Num_tmp[i]
        }
        Num_E = fun_zero(Num_E, Total_pts)
      }
      Num_Option = rep(0, length(Cancername))
      names(Num_Option) =  Cancername
      Num_tmp = table((Data_case_target %>% dplyr::filter(症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. == "はい"))$Cancers)
      if(length(Num_tmp) > 0){
        for(i in 1:length(Num_tmp)){
          Num_Option[names(Num_tmp)[i]] = Num_tmp[i]
        }
      }
      Num_Option = fun_zero(Num_Option, Total_pts)
      Num_Receive_Tx = rep(0, length(Cancername))
      names(Num_Receive_Tx) =  Cancername
      Num_tmp =table((Data_case_target %>% dplyr::filter(症例.EP後レジメン情報.提示された治療薬を投与した.名称. == "投与した"))$Cancers)
      if(length(Num_tmp) > 0){
        for(i in 1:length(Num_tmp)){
          Num_Receive_Tx[names(Num_tmp)[i]] = Num_tmp[i]
        }
      }
      Num_Receive_Tx = fun_zero(Num_Receive_Tx, Total_pts)
      Num_Receive_Tx_per_Option = fun_zero(Num_Receive_Tx, Num_Option)
      Total_pts_short = rep(0, length(Cancername))
      Total_pts_long = rep(0, length(Cancername))
      Num_pre_CGP = rep(0, length(Cancername))
      Num_post_CGP = rep(0, length(Cancername))
  
      Total_pts_Bone_no = rep(0, length(Cancername))
      Total_pts_Bone = rep(0, length(Cancername))
      Total_pts_Brain_no = rep(0, length(Cancername))
      Total_pts_Brain = rep(0, length(Cancername))
      Total_pts_Lung_no = rep(0, length(Cancername))
      Total_pts_Lung = rep(0, length(Cancername))
      Total_pts_Liver_no = rep(0, length(Cancername))
      Total_pts_Liver = rep(0, length(Cancername))
  

      Disease_cluster = data.frame(matrix(rep(0, length(Cancername) * max(Data_case_target$cluster)),
                                          ncol = max(Data_case_target$cluster)))
      colnames(Disease_cluster) = seq(1,max(Data_case_target$cluster))
      rownames(Disease_cluster) = Cancername
      
      Data_case_target$diagnosis = Data_case_target$症例.基本情報.がん種.OncoTree.
      Data_survival = Data_case_target
  
      for(i in 1:length(Cancername)){
        Data_survival_tmp = Data_survival %>%
          dplyr::filter(Cancers == Cancername[i])
        if(length(Data_survival_tmp$Cancers) > 0){
          if(sum(Data_survival_tmp$time_palliative_enroll, na.rm = TRUE) > 0){
            survival_simple = survfit(Surv(time_palliative_enroll,
                                           rep(1, length(time_palliative_enroll)))~1,
                                      data=Data_survival_tmp)
            Num_pre_CGP[i] = median(survival_simple)[[1]]
          } else{
            Num_pre_CGP[i] = 0
          }
          if(sum(Data_survival_tmp$time_enroll_final, na.rm = TRUE) > 0){
            survival_simple = survfit(Surv(time_enroll_final,
                                         censor)~1,
                                    data=Data_survival_tmp)
            Num_post_CGP[i] = median(survival_simple)[[1]]
          } else{
            Num_post_CGP[i] = 0
          }
  
          Data_survival_tmp2 = Data_survival_tmp %>%
            dplyr::filter(Bone_met == "Yes")
          Total_pts_Bone[i] = dim(Data_survival_tmp2)[1]
          Data_survival_tmp2 = Data_survival_tmp %>%
            dplyr::filter(Bone_met == "No")
          Total_pts_Bone_no[i] = dim(Data_survival_tmp2)[1]
          Data_survival_tmp2 = Data_survival_tmp %>%
            dplyr::filter(Brain_met == "Yes")
          Total_pts_Brain[i] = dim(Data_survival_tmp2)[1]
          Data_survival_tmp2 = Data_survival_tmp %>%
            dplyr::filter(Brain_met == "No")
          Total_pts_Brain_no[i] = dim(Data_survival_tmp2)[1]
          Data_survival_tmp2 = Data_survival_tmp %>%
            dplyr::filter(Lung_met == "Yes")
          Total_pts_Lung[i] = dim(Data_survival_tmp2)[1]
          Data_survival_tmp2 = Data_survival_tmp %>%
            dplyr::filter(Lung_met == "No")
          Total_pts_Lung_no[i] = dim(Data_survival_tmp2)[1]
          Data_survival_tmp2 = Data_survival_tmp %>%
            dplyr::filter(Liver_met == "Yes")
          Total_pts_Liver[i] = dim(Data_survival_tmp2)[1]
          Data_survival_tmp2 = Data_survival_tmp %>%
            dplyr::filter(Liver_met == "No")
          Total_pts_Liver_no[i] = dim(Data_survival_tmp2)[1]
        }
      }
      incProgress(1 / 13)
      Data_survival$timing = "Pre"
      for(i in 1:length(Cancername)){
        Data_survival[Data_survival$Cancers == unique(Data_survival$Cancers)[i],]$timing = ifelse(
          Data_survival[Data_survival$Cancers == unique(Data_survival$Cancers)[i],]$time_palliative_enroll < Num_pre_CGP[i],
          "Pre", "Post"
        )
      }
      Diseases = Cancername
      Summary_Table = data.frame(Diseases)
      Summary_Table$sample_is_primary_tumor = 0
      Summary_Table$sample_is_metastatic_tumor = 0
      Summary_Table$sample_is_unknown_tumor = 0
      Summary_Table$tumor_purity_0_25 = 0
      Summary_Table$tumor_purity_25_50 = 0
      Summary_Table$tumor_purity_50_75 = 0
      Summary_Table$tumor_purity_75_100 = 0
      Summary_Table$tumor_purity_NA = 0
      Summary_Table$age_median = 0
      Summary_Table$age_lowest = 0
      Summary_Table$age_highest = 0
      Summary_Table$age_range_25 = 0
      Summary_Table$age_range_75 = 0
      Summary_Table$male = 0
      Summary_Table$female = 0
      Summary_Table$sex_unknown = 0
      Summary_Table$oncogenic_driver_plus = 0
      Summary_Table$oncogenic_driver_minus = 0
      Summary_Table$TMB_median = 0
      Summary_Table$TMB_lowest = 0
      Summary_Table$TMB_highest = 0
      Summary_Table$TMB_range_25 = 0
      Summary_Table$TMB_range_75 = 0
      Summary_Table$entropy = 0
  
      Summary_Table$brain = Total_pts_Brain
      Summary_Table$brain_no = Total_pts_Brain_no
      Summary_Table$bone = Total_pts_Bone
      Summary_Table$bone_no = Total_pts_Bone_no
      Summary_Table$lung = Total_pts_Lung
      Summary_Table$lung_no = Total_pts_Lung_no
      Summary_Table$liver = Total_pts_Liver
      Summary_Table$liver_no = Total_pts_Liver_no
  
      Summary_Table$option = Num_Option * 100
      Summary_Table$treat = Num_Receive_Tx * 100
      Summary_Table$time_before_CGP = Num_pre_CGP
      Summary_Table$time_after_CGP = Num_post_CGP
  
  
      for(i in 1:length(Diseases)){
        Summary_Table$sample_is_primary_tumor[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    症例.検体情報.検体採取部位.名称. == "原発巣"))$症例.検体情報.検体採取部位.名称.)
        Summary_Table$sample_is_metastatic_tumor[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    症例.検体情報.検体採取部位.名称. == "転移巣"))$症例.検体情報.検体採取部位.名称.)
        Summary_Table$sample_is_unknown_tumor[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    症例.検体情報.検体採取部位.名称. %in% c("不明","")))$症例.検体情報.検体採取部位.名称.)
        Summary_Table$tumor_purity_0_25[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.検体情報.腫瘍細胞含有割合) &
                                    症例.検体情報.腫瘍細胞含有割合 < 25))$症例.検体情報.腫瘍細胞含有割合)
        Summary_Table$tumor_purity_25_50[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.検体情報.腫瘍細胞含有割合) &
                                    症例.検体情報.腫瘍細胞含有割合 >= 25 &
                                    症例.検体情報.腫瘍細胞含有割合 < 50))$症例.検体情報.腫瘍細胞含有割合)
        Summary_Table$tumor_purity_50_75[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.検体情報.腫瘍細胞含有割合) &
                                    症例.検体情報.腫瘍細胞含有割合 >= 50 &
                                    症例.検体情報.腫瘍細胞含有割合 < 75))$症例.検体情報.腫瘍細胞含有割合)
        Summary_Table$tumor_purity_75_100[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.検体情報.腫瘍細胞含有割合) &
                                    症例.検体情報.腫瘍細胞含有割合 >= 75 &
                                    症例.検体情報.腫瘍細胞含有割合 <= 100))$症例.検体情報.腫瘍細胞含有割合)
        Summary_Table$tumor_purity_NA[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    is.na(症例.検体情報.腫瘍細胞含有割合)))$症例.検体情報.腫瘍細胞含有割合)
        Summary_Table$age_median[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[3]]
        Summary_Table$age_lowest[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[1]]
        Summary_Table$age_highest[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[5]]
        Summary_Table$age_range_25[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[2]]
        Summary_Table$age_range_75[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[4]]
        Summary_Table$male[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.基本情報.性別.名称.) &
                                    症例.基本情報.性別.名称. == "男"))$症例.基本情報.性別.名称.)
        Summary_Table$female[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.基本情報.性別.名称.) &
                                    症例.基本情報.性別.名称. == "女"))$症例.基本情報.性別.名称.)
        Summary_Table$sex_unknown[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.基本情報.性別.名称.) &
                                    症例.基本情報.性別.名称. == "未入力・不明"))$症例.基本情報.性別.名称.)
        Summary_Table$oncogenic_driver_plus[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    driver_mutations > 0))$driver_mutations)
        Summary_Table$oncogenic_driver_minus[i] =
          length((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    driver_mutations == 0))$driver_mutations)
        Summary_Table$TMB_median[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(TMB)))$TMB)[[3]]
        Summary_Table$TMB_lowest[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(TMB)))$TMB)[[1]]
        Summary_Table$TMB_highest[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(TMB)))$TMB)[[5]]
        Summary_Table$TMB_range_25[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(TMB)))$TMB)[[2]]
        Summary_Table$TMB_range_75[i] =
          quantile((Data_case_target %>%
                      dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                      !is.na(TMB)))$TMB)[[4]]
        tmp_cluster = as.data.frame(table((Data_case_target %>%
                                             dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i]))$cluster))
        Summary_Table$entropy[i] =
          shannon.entropy(as.numeric(as.character(tmp_cluster[,2])), max(Data_case_target$cluster))
        for(j in 1:length(tmp_cluster[,1])){
          Disease_cluster[i,as.numeric(as.character(tmp_cluster[j,1]))] =
            as.numeric(as.character(tmp_cluster[j,2]))
        }
      }
      incProgress(1 / 13)
      
      testSummary = data.frame(as.vector(t(matrix(rep(1:max(Data_case_target$cluster),
                                                      length(Diseases)),
                                                      ncol =length(Diseases)))))
      colnames(testSummary) = "Cluster"
      testSummary$Histology = rep(Diseases, max(Data_case_target$cluster))
      testSummary$All_patients = rep(rep(0, length(Diseases)), max(Data_case_target$cluster))
      testSummary$Positive_patients = rep(rep(0, length(Diseases)), max(Data_case_target$cluster))
      testSummary$OddsRatio = rep(rep(1, length(Diseases)), max(Data_case_target$cluster))
      testSummary$Pvalue = rep(rep(1, length(Diseases)), max(Data_case_target$cluster))
      
      selected_genes = rep("", max(Data_survival$cluster))
      for(i in 1:max(Data_survival$cluster)){
        pos_num = data.frame(Diseases)
        pos_num$n = 0
        colnames(pos_num) = c("diagnosis", "n")
        Data_cluster_plus = Data_survival %>%
          dplyr::filter(cluster == i) %>%
          dplyr::count(diagnosis) %>%
          dplyr::arrange(-n)
        Data_cluster_plus = dplyr::full_join(Data_cluster_plus, pos_num, by = join_by(diagnosis))
        Data_cluster_plus = Data_cluster_plus[,1:2]
        colnames(Data_cluster_plus) = c("diagnosis", "n")
        Data_cluster_plus$n = replace_na(Data_cluster_plus$n, 0)
        Data_cluster_plus = Data_cluster_plus %>% dplyr::arrange(diagnosis)
        Data_cluster_plus = Data_cluster_plus$n
        pos_num = data.frame(Diseases)
        pos_num$n = 0
        colnames(pos_num) = c("diagnosis", "n")
        Data_cluster_minus = Data_survival %>%
          dplyr::filter(cluster != i) %>%
          dplyr::count(diagnosis) %>%
          dplyr::arrange(-n)
        Data_cluster_minus = dplyr::full_join(Data_cluster_minus, pos_num, by = join_by(diagnosis))
        Data_cluster_minus = Data_cluster_minus[,1:2]
        colnames(Data_cluster_minus) = c("diagnosis", "n")
        Data_cluster_minus$n = replace_na(Data_cluster_minus$n, 0)
        Data_cluster_minus = Data_cluster_minus %>% dplyr::arrange(diagnosis)
        Data_cluster_minus = Data_cluster_minus$n
        No_plus_neg = length((Data_survival %>% dplyr::filter(cluster == i))[,1]) -
          Data_cluster_plus
        No_minus_neg = length((Data_survival %>% dplyr::filter(cluster != i))[,1]) -
          Data_cluster_minus
        testSummary[((1+(i-1)*length(Diseases)):(i*length(Diseases))),3] = length((Data_survival %>% dplyr::filter(cluster == i))[,1])
        testSummary[((1+(i-1)*length(Diseases)):(i*length(Diseases))),4] = Data_cluster_plus
        for(j in 1:length(Data_cluster_plus)){
          mutation_matrix = matrix(c(Data_cluster_plus[j],
                                     Data_cluster_minus[j],
                                     No_plus_neg[j],
                                     No_minus_neg[j]),
                                   nrow = 2,
                                   dimnames = list(Cancer = c("CancerType", "OtherCancerType"),
                                                   Cluster = c(paste("cluster", i), "Other clusters")))
          testSummary[(j+(i-1)*length(Diseases)),5] =
            round(fisher.test(mutation_matrix)$estimate[[1]], digits = 3)
          testSummary[(j+(i-1)*length(Diseases)),6] =
            round(fisher.test(mutation_matrix)$p.value, digits = 3)
        }
        top_genes = testSummary[((1+(i-1)*length(Diseases)):(i*length(Diseases))),] %>%
          dplyr::arrange(desc(OddsRatio)) %>%
          dplyr::filter(OddsRatio > 1 & Pvalue < 0.05) 
        if(length(top_genes$OddsRatio) >= 1){
          top_genes = top_genes[1:min(3, length(top_genes$OddsRatio)),]$Histology
        } else{
          top_genes = ""
        }
        selected_genes[i] = paste0(i, ":", paste(top_genes,collapse = ";"))
      }
      testSummary[,"OddsRatio"] = ifelse(is.infinite(testSummary[,"OddsRatio"]), 99999, testSummary[,"OddsRatio"])
      testSummary_disease = testSummary
      
      incProgress(1 / 13)
  
      Data_cluster = Data_case_target %>% dplyr::select(C.CAT調査結果.基本項目.ハッシュID, cluster)
      colnames(Data_cluster) = c("Tumor_Sample_Barcode", "cluster")
      Data_MAF_target = left_join(Data_MAF_target, Data_cluster, by = "Tumor_Sample_Barcode")
      Mutations = sort(unique(Data_MAF_target$Hugo_Symbol))
      testSummary = data.frame(as.vector(t(matrix(rep(1:max(Data_MAF_target$cluster),
                                                      length(Mutations)),
                                                  ncol =length(Mutations)))))
      colnames(testSummary) = "Cluster"
      testSummary$mutation = rep(Mutations, max(Data_MAF_target$cluster))
      testSummary$All_patients = rep(rep(0, length(Mutations)), max(Data_MAF_target$cluster))
      testSummary$Positive_patients = rep(rep(0, length(Mutations)), max(Data_MAF_target$cluster))
      testSummary$OddsRatio = rep(rep(1, length(Mutations)), max(Data_MAF_target$cluster))
      testSummary$Pvalue = rep(rep(1, length(Mutations)), max(Data_MAF_target$cluster))
      
      for(i in 1:max(Data_MAF_target$cluster)){
        pos_num = data.frame(Mutations)
        pos_num$n = 0
        colnames(pos_num) = c("Hugo_Symbol", "n")
        Data_cluster_plus = Data_MAF_target %>%
          dplyr::filter(cluster == i) %>%
          dplyr::count(Hugo_Symbol) %>%
          dplyr::arrange(-n)
        Data_cluster_plus = dplyr::full_join(Data_cluster_plus, pos_num, by = join_by(Hugo_Symbol))
        Data_cluster_plus = Data_cluster_plus[,1:2]
        colnames(Data_cluster_plus) = c("Hugo_Symbol", "n")
        Data_cluster_plus$n = replace_na(Data_cluster_plus$n, 0)
        Data_cluster_plus = Data_cluster_plus %>% dplyr::arrange(Hugo_Symbol)
        Data_cluster_plus = Data_cluster_plus$n
        pos_num = data.frame(Mutations)
        pos_num$n = 0
        colnames(pos_num) = c("Hugo_Symbol", "n")
        Data_cluster_minus = Data_MAF_target %>%
          dplyr::filter(cluster != i) %>%
          dplyr::count(Hugo_Symbol) %>%
          dplyr::arrange(-n)
        Data_cluster_minus = dplyr::full_join(Data_cluster_minus, pos_num, by = join_by(Hugo_Symbol))
        Data_cluster_minus = Data_cluster_minus[,1:2]
        colnames(Data_cluster_minus) = c("Hugo_Symbol", "n")
        Data_cluster_minus$n = replace_na(Data_cluster_minus$n, 0)
        Data_cluster_minus = Data_cluster_minus %>% dplyr::arrange(Hugo_Symbol)
        Data_cluster_minus = Data_cluster_minus$n
        No_plus_neg = length((Data_MAF_target %>%
                                dplyr::filter(cluster == i) %>%
                                dplyr::distinct(Tumor_Sample_Barcode))[,1]) -
          Data_cluster_plus
        No_minus_neg = length((Data_MAF_target %>%
                                 dplyr::filter(cluster != i) %>%
                                 dplyr::distinct(Tumor_Sample_Barcode))[,1]) -
          Data_cluster_minus
        testSummary[((1+(i-1)*length(Mutations)):(i*length(Mutations))),3] = length((Data_MAF_target %>%
                                                                                       dplyr::filter(cluster == i) %>%
                                                                                       dplyr::distinct(Tumor_Sample_Barcode))[,1])
        testSummary[((1+(i-1)*length(Mutations)):(i*length(Mutations))),4] = Data_cluster_plus
        for(j in 1:length(Data_cluster_plus)){
          mutation_matrix = matrix(c(Data_cluster_plus[j],
                                     Data_cluster_minus[j],
                                     No_plus_neg[j],
                                     No_minus_neg[j]),
                                   nrow = 2,
                                   dimnames = list(Cancer = c("CancerType", "OtherCancerType"),
                                                   Cluster = c(paste("cluster", i), "Other clusters")))
          testSummary[(j+(i-1)*length(Mutations)),5] =
            round(fisher.test(mutation_matrix)$estimate[[1]], digits = 3)
          testSummary[(j+(i-1)*length(Mutations)),6] =
            round(fisher.test(mutation_matrix)$p.value, digits = 3)
        }
        top_genes = testSummary[((1+(i-1)*length(Mutations)):(i*length(Mutations))),] %>%
          dplyr::arrange(desc(OddsRatio)) %>%
          dplyr::filter(OddsRatio > 1 & Pvalue < 0.05) 
        if(length(top_genes$OddsRatio) >= 1){
          top_genes = top_genes[1:min(3, length(top_genes$OddsRatio)),]$mutation
        } else{
          top_genes = ""
        }
        selected_genes[i] = paste0(selected_genes[i], "/", paste(top_genes,collapse = ";"))
      }
      incProgress(1 / 13)
      testSummary[,"OddsRatio"] = ifelse(is.infinite(testSummary[,"OddsRatio"]), 99999, testSummary[,"OddsRatio"])
      testSummary_mutation = testSummary
      
      output$table_disease = DT::renderDataTable(testSummary_disease,
                                                 server = FALSE,
                                                 filter = 'top', 
                                                 extensions = c('Buttons'), 
                                         options = list(pageLength = 100, 
                                                        scrollX = TRUE,
                                                        scrollY = "1000px",
                                                        scrollCollapse = TRUE,
                                                        dom="Blfrtip",
                                                        buttons = c('csv', 'copy')))
      output$table_mutation = DT::renderDataTable(testSummary_mutation,
                                                 server = FALSE,
                                                 filter = 'top', 
                                                 extensions = c('Buttons'), 
                                                 options = list(pageLength = 100, 
                                                                scrollX = TRUE,
                                                                scrollY = "1000px",
                                                                scrollCollapse = TRUE,
                                                                dom="Blfrtip",
                                                                buttons = c('csv', 'copy')))
      
      Disease_cluster$Disease = rownames(Disease_cluster)
      Disease_cluster <- transform(Disease_cluster, Disease= factor(Disease, levels = sort(unique(Disease_cluster$Disease), decreasing = TRUE)))
      colnames(Disease_cluster) = c(seq(1,max(Data_survival$cluster)), "Disease")
      Data_entropy = gather(Disease_cluster, key = cluster, value = samples, -Disease)
      Data_entropy$cluster = as.numeric(Data_entropy$cluster)
      Summary_Table = transform(Summary_Table, Diseases= factor(Diseases, levels = sort(unique(Disease_cluster$Disease), decreasing = FALSE)))
      Data_entropy = transform(Data_entropy, Disease= factor(Disease, levels = sort(unique(Disease_cluster$Disease), decreasing = FALSE)))
      
      x <- data.frame(
        Cancers   = Diseases,
        Patients = Total_pts,
        Age = Summary_Table$age_median,
        Level_A = (Num_A * 100),
        Level_AB = (Num_A + Num_B) * 100,
        Level_ABC = (Num_A + Num_B + Num_C) * 100,
        Treatment_option = Num_Option * 100,
        Receive_Recom_Tx = Num_Receive_Tx * 100,
        Receive_Tx_rate_with_opt = Num_Receive_Tx_per_Option * 100,
        Survival_pre_CGP = Num_pre_CGP,
        Survival_post_CGP = Num_post_CGP
      )
      x$Cancers = factor(x$Cancers)
      x_max_patients = max(x$Patients)
      
      y <- data.frame(
        Cancers   = rep(Diseases,5),
        Level = c(rep("A", length(Diseases)),
                  rep("B", length(Diseases)),
                  rep("C", length(Diseases)),
                  rep("D", length(Diseases)),
                  rep("E", length(Diseases))),
        weight = c(Num_A, Num_B, Num_C, Num_D, Num_E)
      )
      y$Cancers = factor(y$Cancers)
      y$Level = factor(y$Level)
      
      output$figure_entropy = renderPlot({
        g1 = ggplot(Summary_Table, aes(x=Diseases, y=entropy, fill="black")) +
          geom_point(stat = "identity") +
          coord_flip() +
          theme_classic() +
          theme(legend.position = "none")
        
        # g2 = ggplot(Data_entropy, aes(x=Disease, y=samples, fill=cluster)) +
        #   geom_bar(stat = "identity") +
        #   scale_fill_gradientn(colours = c("green", "black", "magenta", "darkred", "orange", "blue", "yellow")) +
        #   coord_flip() +
        #   theme_classic()
        g3 = ggplot(Data_entropy, aes(x=Disease, y=samples, fill=cluster)) +
          geom_bar(stat = "identity", position = "fill") +
          scale_fill_gradientn(colours = c("green", "black", "magenta", "darkred", "orange", "blue", "yellow")) +
          coord_flip() +
          theme_classic()
        grid.arrange(g1, g3, ncol = 2)
      })
      output$figure_base = renderPlot({
        # Data_tmp_1 =data.frame(Summary_Table$Diseases)
        # Data_tmp_1$primary = Summary_Table$sample_is_primary_tumor
        # Data_tmp_1$Primary = "Yes"
        # Data_tmp_2 =data.frame(Summary_Table$Diseases)
        # Data_tmp_2$primary = Summary_Table$sample_is_metastatic_tumor
        # Data_tmp_2$Primary = "No"
        # Data_tmp_3 =data.frame(Summary_Table$Diseases)
        # Data_tmp_3$primary = Summary_Table$sample_is_unknown_tumor
        # Data_tmp_3$Primary = "Unknown"
        # Data_tmp = rbind(Data_tmp_1, Data_tmp_2, Data_tmp_3)
        # cancer_freq_order = c("Unknown", "No", "Yes")
        # Data_tmp <- transform(Data_tmp, Primary= factor(Primary, levels = cancer_freq_order))
        # #Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Diseases), decreasing = TRUE)))
        # 
        # chart_1 = ggplot(data = Data_tmp, aes(x = Diseases, y = primary, fill=Primary)) +
        #   geom_col(position="fill") +
        #   coord_flip() +
        #   theme_classic() + 
        #   theme(legend.position = "none",
        #         axis.ticks.y =  element_blank(),
        #         axis.text.y = element_blank(),
        #         axis.title.y = element_blank(),
        #         axis.line.y = element_blank())
        # 
        # Data_tmp_1 =data.frame(Summary_Table$Diseases)
        # Data_tmp_1$purity = Summary_Table$tumor_purity_0_25
        # Data_tmp_1$Purity = "0-25%"
        # Data_tmp_2 =data.frame(Summary_Table$Diseases)
        # Data_tmp_2$purity = Summary_Table$tumor_purity_25_50
        # Data_tmp_2$Purity = "25-49%"
        # Data_tmp_3 =data.frame(Summary_Table$Diseases)
        # Data_tmp_3$purity = Summary_Table$tumor_purity_50_75
        # Data_tmp_3$Purity = "50-74%"
        # Data_tmp_4 =data.frame(Summary_Table$Diseases)
        # Data_tmp_4$purity = Summary_Table$tumor_purity_75_100
        # Data_tmp_4$Purity = "75-100%"
        # Data_tmp_5 =data.frame(Summary_Table$Diseases)
        # Data_tmp_5$purity = Summary_Table$tumor_purity_NA
        # Data_tmp_5$Purity = "NA"
        # Data_tmp = rbind(Data_tmp_1, Data_tmp_2, Data_tmp_3, Data_tmp_4, Data_tmp_5)
        # cancer_freq_order = c("NA", "75-100%", "50-74%", "25-49%", "0-25%")
        # Data_tmp <- transform(Data_tmp, Purity= factor(Purity, levels = cancer_freq_order))
        # Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Diseases), decreasing = TRUE)))
        # 
        # chart_2 = ggplot(data = Data_tmp, aes(x = Diseases, y = purity, fill=Purity)) +
        #   geom_col(position="fill") +
        #   coord_flip() +
        #   theme_classic() + 
        #   theme(legend.position = "none",
        #         axis.ticks.y =  element_blank(),
        #         axis.text.y = element_blank(),
        #         axis.title.y = element_blank(),
        #         axis.line.y = element_blank())
        # 
        Data_tmp = Data_case_target
        Data_tmp$Age = Data_tmp$症例.基本情報.年齢
        Data_tmp <- transform(Data_tmp, diagnosis= factor(diagnosis, levels = sort(unique(Data_tmp$diagnosis), decreasing = TRUE)))
        
        chart_3 = ggplot(data = Data_tmp, aes(x = diagnosis, y = Age)) +
          geom_boxplot(outlier.colour = NA) +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                #axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank())
  
        Data_tmp_1 =data.frame(Summary_Table$Diseases)
        Data_tmp_1$sex = Summary_Table$male
        Data_tmp_1$Sex = "Male"
        Data_tmp_2 =data.frame(Summary_Table$Diseases)
        Data_tmp_2$sex = Summary_Table$female
        Data_tmp_2$Sex = "Female"
        Data_tmp_3 =data.frame(Summary_Table$Diseases)
        Data_tmp_3$sex = Summary_Table$sex_unknown
        Data_tmp_3$Sex = "Unknown"
        Data_tmp = rbind(Data_tmp_1, Data_tmp_2, Data_tmp_3)
        Total_pts_num = sum(Data_tmp$sex)
        Data_tmp$sex = fun_zero(Data_tmp$sex, Total_pts_num)
        cancer_freq_order = c("Unknown", "Female", "Male")
        Data_tmp <- transform(Data_tmp, Sex= factor(Sex, levels = cancer_freq_order))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Diseases), decreasing = TRUE)))
        
        chart_4 = ggplot(data = Data_tmp, aes(x = Diseases, y = sex, fill=Sex)) +
          geom_col(position="fill") +
          coord_flip() +
          theme_classic() + 
          theme(#legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(lim = c(0,1), labels = percent) +
          scale_fill_manual(values = rev(brewer.pal(5, "Paired")[1:length(unique(Data_tmp$Sex))])) +
          ylab("Sex") +
          guides(fill = guide_legend(reverse = TRUE))
  
        Data_tmp_1 =data.frame(Summary_Table$Diseases)
        Data_tmp_1$driver = Summary_Table$oncogenic_driver_plus
        Data_tmp_1$Driver = "Yes"
        Data_tmp_2 =data.frame(Summary_Table$Diseases)
        Data_tmp_2$driver = Summary_Table$oncogenic_driver_minus
        Data_tmp_2$Driver = "No"
        Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
        Total_pts_num = sum(Data_tmp$driver)
        Data_tmp$driver = fun_zero(Data_tmp$driver, Total_pts_num)
        cancer_freq_order = c("Unknown", "No", "Yes")
        Data_tmp <- transform(Data_tmp, Driver= factor(Driver, levels = cancer_freq_order))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Diseases), decreasing = TRUE)))
        
        chart_5 = ggplot(data = Data_tmp, aes(x = Diseases, y = driver, fill=Driver)) +
          geom_col(position="fill") +
          coord_flip() +
          theme_classic() + 
          theme(#legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(lim = c(0,1), labels = percent) +
          scale_fill_manual(values = rev(brewer.pal(5, "Paired")[1:length(unique(Data_tmp$Driver))])) +
          ylab("Oncogenic muts detected") +
          guides(fill = guide_legend(reverse = TRUE))
  
        Data_tmp = Data_case_target
        Data_tmp <- transform(Data_tmp, diagnosis= factor(diagnosis, levels = sort(unique(Diseases), decreasing = TRUE)))
        chart_6 = ggplot(data = Data_tmp, aes(x = diagnosis, y = TMB)) +
          geom_boxplot(outlier.colour = NA) +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(limits = c(0, NA))
        
        Data_tmp_1 =data.frame(Summary_Table$Diseases)
        Data_tmp_1$brain_meta = Summary_Table$brain
        Data_tmp_1$Brain_meta = "(+)"
        Data_tmp_2 =data.frame(Summary_Table$Diseases)
        Data_tmp_2$brain_meta = Summary_Table$brain_no
        Data_tmp_2$Brain_meta = "(-)"
        Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
        Total_pts_num = sum(Data_tmp$brain_meta)
        Data_tmp$brain_meta = fun_zero(Data_tmp$brain_meta, Total_pts_num)
        cancer_freq_order = c("(-)", "(+)")
        Data_tmp <- transform(Data_tmp, Brain_meta= factor(Brain_meta, levels = cancer_freq_order))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
        
        chart_7 = ggplot(data = Data_tmp, aes(x = Diseases, y = brain_meta, fill=Brain_meta)) +
          geom_col(position="fill") +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                #axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(lim = c(0,1), labels = percent) +
          scale_fill_manual(values = rev(brewer.pal(5, "Paired")[1:length(unique(Data_tmp$Brain_meta))])) +
          ylab("Brain metastasis") +
          guides(fill = guide_legend(reverse = TRUE))
  
        Data_tmp_1 =data.frame(Summary_Table$Diseases)
        Data_tmp_1$bone_meta = Summary_Table$bone
        Data_tmp_1$Bone_meta = "(+)"
        Data_tmp_2 =data.frame(Summary_Table$Diseases)
        Data_tmp_2$bone_meta = Summary_Table$bone_no
        Data_tmp_2$Bone_meta = "(-)"
        Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
        Total_pts_num = sum(Data_tmp$bone_meta)
        Data_tmp$bone_meta = fun_zero(Data_tmp$bone_meta, Total_pts_num)
        cancer_freq_order = c("(-)", "(+)")
        Data_tmp <- transform(Data_tmp, Bone_meta= factor(Bone_meta, levels = cancer_freq_order))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
        
        chart_8 = ggplot(data = Data_tmp, aes(x = Diseases, y = bone_meta, fill=Bone_meta)) +
          geom_col(position="fill") +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(lim = c(0,1), labels = percent) +
          scale_fill_manual(values = rev(brewer.pal(5, "Paired")[1:length(unique(Data_tmp$Bone_meta))])) +
          ylab("Bone metastasis") +
          guides(fill = guide_legend(reverse = TRUE))
  
        Data_tmp_1 =data.frame(Summary_Table$Diseases)
        Data_tmp_1$lung_meta = Summary_Table$lung
        Data_tmp_1$Lung_meta = "(+)"
        Data_tmp_2 =data.frame(Summary_Table$Diseases)
        Data_tmp_2$lung_meta = Summary_Table$lung_no
        Data_tmp_2$Lung_meta = "(-)"
        Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
        Total_pts_num = sum(Data_tmp$lung_meta)
        Data_tmp$lung_meta = fun_zero(Data_tmp$lung_meta, Total_pts_num)
        cancer_freq_order = c("(-)", "(+)")
        Data_tmp <- transform(Data_tmp, Lung_meta= factor(Lung_meta, levels = cancer_freq_order))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
        
        chart_9 = ggplot(data = Data_tmp, aes(x = Diseases, y = lung_meta, fill=Lung_meta)) +
          geom_col(position="fill") +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(lim = c(0,1), labels = percent) +
          scale_fill_manual(values = rev(brewer.pal(5, "Paired")[1:length(unique(Data_tmp$Lung_meta))])) +
          ylab("Lung metastasis") +
          guides(fill = guide_legend(reverse = TRUE))
  
        Data_tmp_1 =data.frame(Summary_Table$Diseases)
        Data_tmp_1$liver_meta = Summary_Table$liver
        Data_tmp_1$Liver_meta = "(+)"
        Data_tmp_2 =data.frame(Summary_Table$Diseases)
        Data_tmp_2$liver_meta = Summary_Table$liver_no
        Data_tmp_2$Liver_meta = "(-)"
        Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
        Total_pts_num = sum(Data_tmp$liver_meta)
        Data_tmp$liver_meta = fun_zero(Data_tmp$liver_meta, Total_pts_num)
        cancer_freq_order = c("(-)", "(+)")
        Data_tmp <- transform(Data_tmp, Liver_meta= factor(Liver_meta, levels = cancer_freq_order))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
        
        chart_10 = ggplot(data = Data_tmp, aes(x = Diseases, y = liver_meta, fill=Liver_meta)) +
          geom_col(position="fill") +
          coord_flip() +
          theme_classic() + 
          theme(# legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(lim = c(0,1), labels = percent) +
          ylab("Liver metastasis") + 
          scale_fill_manual(values = rev(brewer.pal(5, "Paired")[1:length(unique(Data_tmp$Liver_meta))]), name = "Metastasis") +
          guides(fill = guide_legend(reverse = TRUE))
          
        Data_tmp =data.frame(Summary_Table$Diseases)
        Data_tmp$option = Summary_Table$option / 100
        Data_tmp$Option = "(+)"
        Data_tmp <- transform(Data_tmp, Option= factor(Option))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
        
        chart_11 = ggplot(data = Data_tmp, aes(x = Diseases, y = option, fill=Option)) +
          geom_point() +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                #axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(lim = c(0,NA), labels = percent, name = "Pts with recommended CTx")
  
        Data_tmp =data.frame(Summary_Table$Diseases)
        Data_tmp$treat = Summary_Table$treat / 100
        Data_tmp$Treat = "(+)"
        Data_tmp <- transform(Data_tmp, Treat= factor(Treat))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
        
        chart_12 = ggplot(data = Data_tmp, aes(x = Diseases, y = treat, fill=Treat)) +
          geom_point() +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(lim = c(0,NA), labels = percent, name = "Pts received recommended CTx")
          
  
        Data_tmp =data.frame(Summary_Table$Diseases)
        Data_tmp$time_before_CGP = Summary_Table$time_before_CGP
        Data_tmp$Time_before_CGP = "(+)"
        Data_tmp <- transform(Data_tmp, Time_before_CGP= factor(Time_before_CGP))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
        
        chart_13 = ggplot(data = Data_tmp, aes(x = Diseases, y = time_before_CGP, fill=Time_before_CGP)) +
          geom_col() +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(limits = c(0, NA)) +
          ylab("Median time from CTx to CGP (days)") + 
          scale_fill_manual(values = brewer.pal(3, "Paired")[1])
  
        Data_tmp =data.frame(Summary_Table$Diseases)
        Data_tmp$time_after_CGP = Summary_Table$time_after_CGP
        Data_tmp$Time_after_CGP = "(+)"
        Data_tmp <- transform(Data_tmp, Time_after_CGP= factor(Time_after_CGP))
        Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
        
        chart_14 = ggplot(data = Data_tmp, aes(x = Diseases, y = time_after_CGP, fill=Time_after_CGP)) +
          geom_col() +
          coord_flip() +
          theme_classic() + 
          theme(legend.position = "none",
                axis.ticks.y =  element_blank(),
                axis.text.y = element_blank(),
                axis.title.y = element_blank(),
                axis.line.y = element_blank()) +
          scale_y_continuous(limits = c(0, NA)) +
          ylab("Median time from CGP to death (days)") + 
          scale_fill_manual(values = brewer.pal(3, "Paired")[1])
  
        grid.arrange(chart_3, chart_4, chart_5, chart_6, chart_7, chart_8, chart_9, chart_10, chart_11, chart_12, chart_13, chart_14, ncol = 4)
      })
      incProgress(1 / 13)
      
      output$figure_drug_evidence = renderPlot({
        g <- ggplot(y, aes(x= reorder(Cancers, desc(Cancers)), y = weight, fill = reorder(Level, desc(Level))))
        g <- g + geom_bar(stat = "identity")
        g <- g + scale_y_continuous(labels = percent)
        g <- g + scale_fill_nejm()
        g <- g + theme_bw()
        g <- g + labs(y = "Frequency of druggable mutation",x = "Cancer type", fill = "Evidence level")
        g <- g + coord_flip() +
          guides(fill = guide_legend(reverse = TRUE))
        g
      })
      
      output$figure_CGP_pre_post = renderPlot({
        cor_A = x %>% 
          summarise(cor = round(cor.test(Survival_pre_CGP, Survival_post_CGP)$estimate,3), p = round(cor.test(Survival_pre_CGP, Survival_post_CGP)$p.value,3)) %>% 
          as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
        max_x = max(x$Survival_pre_CGP,na.rm = T)*1.05
        max_y = max(x$Survival_post_CGP,na.rm = T)*1.05
        g <- ggplot(x, aes(x = Survival_pre_CGP, y = Survival_post_CGP, color = Cancers))
        g <- g + geom_point(size = Total_pts/x_max_patients*10, alpha = .5)
        g <- g + scale_fill_nejm()
        g <- g + theme_bw()
        g <- g + coord_cartesian(xlim = c(0, max_x), ylim = c(0, max_y))
        g <- g + labs(x = "Survival before CGP (days)",y = "Survival after CGP (days)", color = "Cancer type")
        g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
        g <- g + geom_text(data=cor_A, colour = "red", mapping = aes(x = max_x * 0.5, y = 30, label = paste("r =",cor, ", p =",p)))
        g
      })
      incProgress(1 / 13)
      
      output$figure_patient_treatment = renderPlot({
        h = list()
        h[[1]] = gg_drug_plot(x, "Patients", "Level_A",
                              "Patients",
                              "Frequency of Evidence level A (%)",
                              Total_pts, x_max_patients)
        h[[2]] = gg_drug_plot(x, "Patients", "Level_AB",
                              "Patients",
                              "Frequency of Evidence level A/B (%)",
                              Total_pts, x_max_patients)
        h[[3]] = gg_drug_plot(x, "Patients", "Level_ABC",
                              "Patients",
                              "Frequency of Evidence level A/B/C (%)",
                              Total_pts, x_max_patients)
        h[[4]] = gg_drug_plot(x, "Patients", "Treatment_option",
                              "Patients",
                              "Patients with treatment option (%)",
                              Total_pts, x_max_patients)
        h[[5]] = gg_drug_plot(x, "Patients", "Receive_Recom_Tx",
                              "Patients",
                              "Patients received recommended treatment (%)",
                              Total_pts, x_max_patients)
        h[[6]] = gg_drug_plot(x, "Patients", "Receive_Tx_rate_with_opt",
                              "Patients",
                              "Rate of receiving recommended treatment (%)",
                              Total_pts, x_max_patients)
        grid.arrange(h[[1]], h[[2]], h[[3]], h[[4]], h[[5]], h[[6]], ncol = 2)
      })
      incProgress(1 / 13)
      
      output$figure_Pre_CGP_treatment = renderPlot({
        h = list()
        h[[1]] = gg_drug_plot(x, "Survival_pre_CGP", "Level_A",
                              "Survival before CGP (days)",
                              "Frequency of Evidence level A (%)",
                              Total_pts, x_max_patients)
        h[[2]] = gg_drug_plot(x, "Survival_pre_CGP", "Level_AB",
                              "Survival before CGP (days)",
                              "Frequency of Evidence level A/B (%)",
                              Total_pts, x_max_patients)
        h[[3]] = gg_drug_plot(x, "Survival_pre_CGP", "Level_ABC",
                              "Survival before CGP (days)",
                              "Frequency of Evidence level A/B/C (%)",
                              Total_pts, x_max_patients)
        h[[4]] = gg_drug_plot(x, "Survival_pre_CGP", "Treatment_option",
                              "Survival before CGP (days)",
                              "Patients with treatment option (%)",
                              Total_pts, x_max_patients)
        h[[5]] = gg_drug_plot(x, "Survival_pre_CGP", "Receive_Recom_Tx",
                              "Survival before CGP (days)",
                              "Patients received recommended treatment (%)",
                              Total_pts, x_max_patients)
        h[[6]] = gg_drug_plot(x, "Survival_pre_CGP", "Receive_Tx_rate_with_opt",
                              "Survival before CGP (days)",
                              "Rate of receiving recommended treatment (%)",
                              Total_pts, x_max_patients)
        grid.arrange(h[[1]], h[[2]], h[[3]], h[[4]], h[[5]], h[[6]], ncol = 2)
      })
      
      incProgress(1 / 13)
      
      output$figure_Post_CGP_treatment = renderPlot({
        h = list()
        h[[1]] = gg_drug_plot(x, "Survival_post_CGP", "Level_A",
                              "Survival after CGP (days)",
                              "Frequency of Evidence level A (%)",
                              Total_pts, x_max_patients)
        h[[2]] = gg_drug_plot(x, "Survival_post_CGP", "Level_AB",
                              "Survival after CGP (days)",
                              "Frequency of Evidence level A/B (%)",
                              Total_pts, x_max_patients)
        h[[3]] = gg_drug_plot(x, "Survival_post_CGP", "Level_ABC",
                              "Survival after CGP (days)",
                              "Frequency of Evidence level A/B/C (%)",
                              Total_pts, x_max_patients)
        h[[4]] = gg_drug_plot(x, "Survival_post_CGP", "Treatment_option",
                              "Survival after CGP (days)",
                              "Patients with treatment option (%)",
                              Total_pts, x_max_patients)
        h[[5]] = gg_drug_plot(x, "Survival_post_CGP", "Receive_Recom_Tx",
                              "Survival after CGP (days)",
                              "Patients received recommended treatment (%)",
                              Total_pts, x_max_patients)
        h[[6]] = gg_drug_plot(x, "Survival_post_CGP", "Receive_Tx_rate_with_opt",
                              "Survival after CGP (days)",
                              "Rate of receiving recommended treatment (%)",
                              Total_pts, x_max_patients)
        grid.arrange(h[[1]], h[[2]], h[[3]], h[[4]], h[[5]], h[[6]], ncol = 2)
      })
      
      output$figure_Age_and_treatment = renderPlot({
        h = list()
        h[[1]] = gg_drug_plot(x, "Age", "Level_A",
                              "Median age (years old)",
                              "Frequency of Evidence level A (%)",
                              Total_pts, x_max_patients)
        h[[2]] = gg_drug_plot(x, "Age", "Level_AB",
                              "Median age (years old)",
                              "Frequency of Evidence level A/B (%)",
                              Total_pts, x_max_patients)
        h[[3]] = gg_drug_plot(x, "Age", "Level_ABC",
                              "Median age (years old)",
                              "Frequency of Evidence level A/B/C (%)",
                              Total_pts, x_max_patients)
        h[[4]] = gg_drug_plot(x, "Age", "Treatment_option",
                              "Median age (years old)",
                              "Patients with treatment option (%)",
                              Total_pts, x_max_patients)
        h[[5]] = gg_drug_plot(x, "Age", "Receive_Recom_Tx",
                              "Median age (years old)",
                              "Patients received recommended treatment (%)",
                              Total_pts, x_max_patients)
        h[[6]] = gg_drug_plot(x, "Age", "Receive_Tx_rate_with_opt",
                              "Median age (years old)",
                              "Rate of receiving recommended treatment (%)",
                              Total_pts, x_max_patients)
        grid.arrange(h[[1]], h[[2]], h[[3]], h[[4]], h[[5]], h[[6]], ncol = 2)
      })

      output$figure_cluster_subtype = renderPlot({
        ggplot(Data_mutation_cord, aes(V1,V2,color = Data_case_target$Cancers)) +
          geom_point() + 
          labs(x = "UMAP 1", y = "UMAP 2",
               title = "Unsupervised clustering of oncogenic alterations") +
          theme_classic() +
          guides(color = guide_legend(title = "Histology", nrow=30))
      })
      output$figure_cluster_age = renderPlot({
        ggplot(Data_mutation_cord, aes(V1,V2,color = Data_case_target$YoungOld)) +
          geom_point() + 
          labs(x = "UMAP 1", y = "UMAP 2",
               title = "Unsupervised clustering of oncogenic alterations") +
          theme_classic() + labs(color = "年齢") +
          guides(color = guide_legend(title = "Age"))
      })
      output$figure_cluster = renderPlot({
        if(min(Data_case_target$cluster) == 0){
          Data_case_target$cluster = as.factor(Data_case_target$cluster + 1)
          Data_mutation_cord$cluster = Data_case_target$cluster
          ggplot(Data_mutation_cord, aes(V1,V2,color = cluster)) +
            geom_point() + 
            labs(x = "UMAP 1", y = "UMAP 2",
                 title = paste(
                   "DBSCAN clustering, cluster-1 is NOT-ASSIGNED, EPS:",
                   input$eps, ", minPts:", 3, sep="")) +
            theme_classic() +
            guides(color = guide_legend(title = "TOP3 histology/mutated gene", nrow=30)) +
            scale_color_discrete(labels = selected_genes) 
        } else{
          Data_case_target$cluster = as.factor(Data_case_target$cluster + 1)
          Data_mutation_cord$cluster = Data_case_target$cluster
          ggplot(Data_mutation_cord, aes(V1,V2,color = cluster)) +
            geom_point() + 
            labs(x = "UMAP 1", y = "UMAP 2",
                 title = paste(
                   "DBSCAN clustering, EPS:",
                   input$eps, ", minPts:", 3, sep="")) +
            theme_classic() +
            guides(color = guide_legend(title = "TOP3 histology/mutated gene"), nrow=30) +
            scale_color_discrete(labels = selected_genes)
        }
      })
      incProgress(1 / 13)
    })
  })
  
  
  
  observeEvent(input$survival_CGP_analysis, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
        Data_case_target = Data_case_target %>%
          dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                          Data_report()$Tumor_Sample_Barcode)
      }
      Data_case_target = Data_case_target %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                      症例.基本情報.年齢,
                      Lymph_met,
                      Brain_met,
                      Lung_met,
                      Bone_met,
                      Liver_met,
                      Other_met,
                      EP_option,
                      EP_treat,
                      YoungOld,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.投与終了日,
                      症例.EP前レジメン情報.実施目的.名称.,
                      症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP前レジメン情報.レジメン継続区分.名称.,
                      症例.EP前レジメン情報.最良総合効果.名称.,
                      症例.EP前レジメン情報.治療ライン.名称.,
                      症例.EP前レジメン情報.実施目的.名称.,
                      症例.EP前レジメン情報.化学療法レジメン名称,
                      症例.EP前レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                      症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                      症例.EP後レジメン情報.治療ライン,
                      症例.EP後レジメン情報.治療ライン.名称.,
                      症例.EP後レジメン情報.化学療法レジメン名称,
                      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                      症例.EP後レジメン情報.投与開始日,
                      症例.EP後レジメン情報.投与終了日,
                      症例.EP後レジメン情報.レジメン継続区分.名称.,
                      症例.EP後レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.最良総合効果.名称.,
                      症例.基本情報.性別.名称.,
                      症例.基本情報.がん種.OncoTree.,
                      症例.基本情報.がん種.OncoTree..名称.,
                      症例.基本情報.がん種.OncoTree.LEVEL1.,
                      症例.検体情報.パネル.名称.,
                      症例.背景情報.ECOG.PS.名称.,
                      症例.背景情報.喫煙歴有無.名称.,
                      症例.背景情報.アルコール多飲有無.名称.,
                      症例.背景情報.重複がん有無.異なる臓器..名称.,
                      症例.背景情報.多発がん有無.同一臓器..名称.,
                      症例.がん種情報.登録時転移部位.名称.,
                      症例.検体情報.腫瘍細胞含有割合,
                      症例.検体情報.検体採取部位.名称.,
                      症例.転帰情報.転帰.名称.,
                      症例.背景情報.診断日,
                      症例.管理情報.登録日,
                      症例.転帰情報.最終生存確認日,
                      症例.転帰情報.死亡日,
                      HER2_IHC,
                      MSI_PCR,
                      MMR_IHC
        )
      if(input$HER2 == "No"){
        Data_case_target = Data_case_target %>%
          dplyr::select(-HER2_IHC)
      } else {
        Data_case_target = Data_case_target %>%
          dplyr::filter(
            HER2_IHC != "Unknown"
          )
      }
      if(input$MSI == "No"){
        Data_case_target = Data_case_target %>%
          dplyr::select(-MSI_PCR)
      } else {
        Data_case_target = Data_case_target %>%
          dplyr::filter(
            MSI_PCR != "Unknown"
          )
      }
      if(input$MMR == "No"){
        Data_case_target = Data_case_target %>%
          dplyr::select(-MMR_IHC)
      } else {
        Data_case_target = Data_case_target %>%
          dplyr::filter(
            MMR_IHC != "Unknown"
          )
      }
      Data_case_target$Cancers = Data_case_target$症例.基本情報.がん種.OncoTree.
      Data_survival = Data_case_target %>%
        dplyr::mutate(final_observe = case_when(
          症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
          症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
          症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
          TRUE ~ 症例.管理情報.登録日))
      Data_survival = Data_survival %>%
        dplyr::arrange(desc(final_observe)) %>%
        dplyr::mutate(censor = case_when(
          症例.転帰情報.死亡日 != "" ~ 1,
          TRUE ~ 0)) %>%
        dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
      
      Data_survival = Data_survival %>%
        dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
        dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
      
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, censor) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      
      Data_survival = Data_survival %>%
        dplyr::mutate(final_observe = as.Date(Data_survival$final_observe)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(Data_survival$症例.管理情報.登録日)) %>%
        dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                        as.Date(症例.EP前レジメン情報.投与開始日))
      incProgress(1 / 13)
      
      Data_survival = Data_survival %>%
        dplyr::mutate(time_enroll_final =
                        as.integer(difftime(Data_survival$final_observe,
                                            Data_survival$症例.管理情報.登録日,
                                            units = "days")))
      Data_survival = Data_survival %>%
        dplyr::mutate(time_palliative_final =
                        as.integer(difftime(Data_survival$final_observe,
                                            Data_survival$症例.EP前レジメン情報.投与開始日,
                                            units = "days")))
      Data_survival = Data_survival %>%
        dplyr::mutate(time_palliative_enroll =
                        Data_survival$time_palliative_final -
                        Data_survival$time_enroll_final)
      
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, final_observe) %>%
        dplyr::arrange(desc(final_observe)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_enroll_final) %>%
        dplyr::arrange(desc(time_enroll_final)) %>%
        dplyr::filter(time_enroll_final > 0 & !is.na(time_enroll_final) & is.finite(time_enroll_final)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      
      Data_survival_tmp = Data_survival %>%
        dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                        c("その他", "緩和")) %>%
        dplyr::arrange(症例.EP前レジメン情報.投与開始日) %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_palliative_enroll, time_palliative_final) %>%
        dplyr::filter(time_palliative_enroll > 0 & time_palliative_enroll < 10000 & !is.na(time_palliative_enroll) & is.finite(time_palliative_enroll)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      
      tmp1 = Data_case_target %>%
        dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                        c("その他", "緩和")) %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                      症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP前レジメン情報.化学療法レジメン名称,
                      症例.EP前レジメン情報.治療ライン.名称.,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.投与終了日,
                      症例.EP前レジメン情報.レジメン継続区分.名称.,
                      症例.管理情報.登録日,
                      症例.EP前レジメン情報.実施目的.名称.,
                      final_observe,
                      censor,
                      症例.EP前レジメン情報.終了理由.名称.,
                      症例.EP前レジメン情報.最良総合効果.名称.) %>%
        dplyr::distinct()
      tmp1 = tmp1 %>%
        dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                        as.Date(tmp1$症例.EP前レジメン情報.投与開始日)) %>%
        dplyr::mutate(症例.EP前レジメン情報.投与終了日 =
                        as.Date(tmp1$症例.EP前レジメン情報.投与終了日)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(tmp1$症例.管理情報.登録日))
      tmp1 = tmp1 %>%
        dplyr::mutate(Drug_length =
                        as.integer(difftime(tmp1$症例.EP前レジメン情報.投与終了日,
                                            tmp1$症例.EP前レジメン情報.投与開始日,
                                            units = "days")))
      colnames(tmp1) = c("ID",
                         "Drug",
                         "レジメン",
                         "治療ライン",
                         "投与開始日",
                         "投与終了日",
                         "Ongoing",
                         "登録日",
                         "実施目的",
                         "final_observe",
                         "censor",
                         "終了理由",
                         "最良総合効果",
                         "Drug_length")
      tmp1$TxCGP = "Pre"
      tmp2 = Data_case_target %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP後レジメン情報.化学療法レジメン名称,
                      症例.EP後レジメン情報.治療ライン.名称.,
                      症例.EP後レジメン情報.投与開始日,
                      症例.EP後レジメン情報.投与終了日,
                      症例.EP後レジメン情報.レジメン継続区分.名称.,
                      症例.管理情報.登録日,
                      症例.EP前レジメン情報.実施目的.名称.,
                      final_observe,
                      censor,
                      症例.EP後レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.最良総合効果.名称.) %>%
        dplyr::distinct()
      tmp2$症例.EP前レジメン情報.実施目的.名称. = "緩和"
      tmp2 = tmp2 %>%
        dplyr::mutate(症例.EP後レジメン情報.投与開始日 =
                        as.Date(tmp2$症例.EP後レジメン情報.投与開始日)) %>%
        dplyr::mutate(症例.EP後レジメン情報.投与終了日 =
                        as.Date(tmp2$症例.EP後レジメン情報.投与終了日)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(tmp2$症例.管理情報.登録日))
      
      tmp2 = tmp2 %>%
        dplyr::mutate(Drug_length =
                        as.integer(difftime(tmp2$症例.EP後レジメン情報.投与終了日,
                                            tmp2$症例.EP後レジメン情報.投与開始日,
                                            units = "days")))
      colnames(tmp2) = c("ID",
                         "Drug",
                         "レジメン",
                         "治療ライン",
                         "投与開始日",
                         "投与終了日",
                         "Ongoing",
                         "登録日",
                         "実施目的",
                         "final_observe",
                         "censor",
                         "終了理由",
                         "最良総合効果",
                         "Drug_length")
      tmp2$TxCGP = "Post"
      Data_drug = rbind(tmp1, tmp2)
      
      if(!is.null(input$ID_drug)){
        Data_drug = data.frame(NULL)
        for(i in 1:length(input$ID_drug[,1])){
          tmp = read.csv(header = TRUE, file(input$ID_drug[[i, 'datapath']],
                                             encoding='UTF-8-BOM'))
          if("症例.EP前レジメン情報.投与開始日" %in% colnames(tmp)){
            colnames(tmp) = c("ID",
                              "登録日",
                              "治療ライン",
                              "実施目的",
                              "レジメン",
                              "Drug",
                              "投与開始日",
                              "投与終了日",
                              "Ongoing",
                              "終了理由",
                              "最良総合効果",
                              "最終生存確認日",
                              "死亡日")
            tmp = tmp %>%
              dplyr::mutate(
                Drug_length = as.integer(difftime(tmp$投与終了日,
                                                  tmp$投与開始日,
                                                  units = "days")),
                censor = case_when(
                  死亡日 != "" ~ 1,
                  TRUE ~ 0
                ),
                final_observe = case_when(
                  最終生存確認日 == "           " ~ 死亡日,
                  最終生存確認日 != "" ~ 最終生存確認日,
                  死亡日 != "" ~ 死亡日,
                  TRUE ~ 登録日)
              )
            tmp = tmp %>%
              dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
              dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
            tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
            tmp$TxCGP = "Pre"
          } else{
            colnames(tmp) = c("ID",
                              "登録日",
                              "治療ライン",
                              "レジメン",
                              "Drug",
                              "投与開始日",
                              "投与終了日",
                              "Ongoing",
                              "終了理由",
                              "最良総合効果",
                              "最終生存確認日",
                              "死亡日")
            tmp = tmp %>%
              dplyr::mutate(
                Drug_length = as.integer(difftime(tmp$投与終了日,
                                                  tmp$投与開始日,
                                                  units = "days")),
                censor = case_when(
                  死亡日 != "" ~ 1,
                  TRUE ~ 0
                ),
                final_observe = case_when(
                  最終生存確認日 == "           " ~ 死亡日,
                  最終生存確認日 != "" ~ 最終生存確認日,
                  死亡日 != "" ~ 死亡日,
                  TRUE ~ 登録日)
              )
            tmp = tmp %>%
              dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
              dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
            tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
            tmp$実施目的 = "緩和"
            tmp$TxCGP = "Post"
          }
          Data_drug = rbind(Data_drug, tmp)
        }
      }
      
      Data_drug = Data_drug %>%
        dplyr::mutate(final_observe =
                        as.Date(Data_drug$final_observe))
      Data_drug = Data_drug %>%
        dplyr::arrange(投与開始日) %>%
        dplyr::arrange(治療ライン) %>%
        dplyr::arrange(ID)
      
      Data_drug = Data_drug %>% dplyr::mutate(RECIST = case_when(
        最良総合効果 == "CR" ~ "5",
        最良総合効果 == "PR" ~ "4",
        最良総合効果 == "SD" ~ "3",
        最良総合効果 == "PD" ~ "2",
        最良総合効果 == "NE" ~ "1",
        最良総合効果 == "NoData" ~ "0",
        TRUE ~ "0"
      ))
      Data_drug = Data_drug %>%
        dplyr::filter(治療ライン %in% c("１次治療","２次治療","３次治療","４次治療"))
      
      Data_drug_RECIST = (Data_drug %>%
                            dplyr::arrange(desc(RECIST),ID,desc(レジメン),治療ライン) %>%
                            dplyr::distinct(ID,治療ライン,.keep_all = T)) %>%
        dplyr::select(ID,治療ライン,RECIST)

      Data_drug = Data_drug %>% dplyr::select(-投与開始日, -投与終了日, -RECIST, -Ongoing, -Drug)
      Data_drug = left_join(Data_drug, Data_drug_RECIST, by = c('ID','治療ライン'))
      Data_drug = Data_drug %>%
        dplyr::arrange(ID) %>%
        dplyr::distinct(ID,治療ライン, .keep_all = T)
      
      Data_drug <- data.frame(Data_drug %>% 
                                dplyr::arrange(ID) %>%
                                dplyr::group_by(ID) %>%
                                dplyr::mutate(治療ライン = row_number()))
      Data_drug$治療ライン = as.character(Data_drug$治療ライン)

      ID_pre_CGP_lines = Data_drug %>%
        dplyr::select(ID, 治療ライン) %>%
        dplyr::arrange(desc(治療ライン)) %>%
      dplyr::distinct()
      colnames(ID_pre_CGP_lines) = c("ID", "CTx_lines_before_CGP")
      
      ID_pre_CGP_RECIST = Data_drug %>%
        dplyr::select(ID, RECIST) %>%
        dplyr::arrange(desc(RECIST)) %>%
      dplyr::distinct()
      colnames(ID_pre_CGP_RECIST) = c("ID", "RECIST")
      
      ID_pre_CGP_RECIST = ID_pre_CGP_RECIST %>% dplyr::mutate(RECIST = case_when(
        RECIST == "5" ~ "CR",
        RECIST == "4" ~ "PR",
        RECIST == "3" ~ "SD",
        RECIST == "2" ~ "PD",
        RECIST == "1" ~ "NE",
        RECIST == "0" ~ "NE",
        TRUE ~ "NE"
      ))
      Data_case_target$CTx_lines_before_CGP = unlist(lapply(list(Data_case_target$C.CAT調査結果.基本項目.ハッシュID), function(x) {
        as.vector(ID_pre_CGP_lines$CTx_lines_before_CGP[match(x, ID_pre_CGP_lines$ID)])}))
      Data_case_target$RECIST = unlist(lapply(list(Data_case_target$C.CAT調査結果.基本項目.ハッシュID), function(x) {
        as.vector(ID_pre_CGP_RECIST$RECIST[match(x, ID_pre_CGP_RECIST$ID)])}))
      if(sum(is.na(Data_case_target$CTx_lines_before_CGP)>0)){
        Data_case_target[is.na(Data_case_target$CTx_lines_before_CGP),]$CTx_lines_before_CGP = "0"
      }
      if(sum(is.na(Data_case_target$RECIST)>0)){
        Data_case_target[is.na(Data_case_target$RECIST),]$RECIST = "CTx naive"
      }
      
      Data_case_target = Data_case_target %>%
        dplyr::distinct(.keep_all = TRUE, C.CAT調査結果.基本項目.ハッシュID)
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
        if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }

      Data_report_TMB = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
        dplyr::select(Tumor_Sample_Barcode, TMB) %>%
        dplyr::distinct(Tumor_Sample_Barcode, .keep_all=T)
      colnames(Data_report_TMB) = c("C.CAT調査結果.基本項目.ハッシュID", "TMB")
      Data_case_target = left_join(Data_case_target, Data_report_TMB,
                                   by = "C.CAT調査結果.基本項目.ハッシュID")
      
      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      }
      Data_MAF_target = Data_MAF_target %>%
        dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, .keep_all = T)
      Gene_list = unique(names(sort(table(Data_MAF_target$Hugo_Symbol),
                                    decreasing = T)))
      if(length(Data_case_target$censor[is.na(Data_case_target$censor)])> 0){
        Data_case_target$censor[is.na(Data_case_target$censor)] = 0
      }
      incProgress(1 / 13)
      
      Data_case_target = Data_case_target %>%
      dplyr::mutate(EP_option = case_when(
        症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. ==
          "はい" ~ 1,
        TRUE ~ 0)) %>%
      dplyr::mutate(EP_treat = case_when(
        症例.EP後レジメン情報.提示された治療薬を投与した.名称. ==
          "投与した" ~ 1,
        TRUE ~ 0))
      
      Data_tmp = Data_case_target %>% dplyr::select(
        C.CAT調査結果.基本項目.ハッシュID,
        症例.EP後レジメン情報.治療ライン,
        症例.EP後レジメン情報.化学療法レジメン名称,
        症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
        症例.EP後レジメン情報.提示された治療薬を投与した.名称.
        ) %>%
        dplyr::distinct()
      Data_tmp = tidyr::replace_na(Data_tmp,
                                   replace = list(症例.EP後レジメン情報.治療ライン = 0,
                                                  症例.EP後レジメン情報.化学療法レジメン名称 = "",
                                                  症例.EP後レジメン情報.薬剤名.YJ一般名.EN. = ""))
      Data_tmp = Data_tmp %>%
        dplyr::filter(症例.EP後レジメン情報.治療ライン != 0 &(
          症例.EP後レジメン情報.化学療法レジメン名称 != "" |
            症例.EP後レジメン情報.薬剤名.YJ一般名.EN. != "" |
            症例.EP後レジメン情報.提示された治療薬を投与した.名称. == "投与した"))
      ID_tmp = unique(Data_tmp$C.CAT調査結果.基本項目.ハッシュID)
      Data_survival = Data_case_target %>% dplyr::filter(
          !is.na(time_enroll_final) &
          is.finite(time_enroll_final) & 
          time_enroll_final > 0 &
          !is.na(censor) &
          is.finite(censor)
      )  
      Data_survival$afterCGPtreat = Data_survival$EP_treat
      for(i in ID_tmp){
        Data_survival[Data_survival$C.CAT調査結果.基本項目.ハッシュID == i, "afterCGPtreat"] = 1
      }
      Data_survival = Data_survival %>%
        dplyr::mutate(treat_group = case_when(
          afterCGPtreat == 1 & EP_treat == 1 ~ "Option(+)RecomTreat(+)",
          afterCGPtreat == 1 & EP_option == 1 ~ "Option(+)UnrecomTreat(+)",
          afterCGPtreat == 1 & EP_option == 0 ~ "Option(-)UnrecomTreat(+)",
          afterCGPtreat == 0 & EP_option == 1 ~ "Option(+)Treat(-)",
          afterCGPtreat == 0 & EP_option == 0 ~ "Option(-)Treat(-)"
        ))
      Data_survival = Data_survival %>%
        dplyr::mutate(treat_group_2 = case_when(
          afterCGPtreat == 1 & EP_treat == 1 ~ "RecomTreat(+)",
          afterCGPtreat == 1 & EP_option == 1 ~ "UnrecomTreat(+)",
          afterCGPtreat == 1 & EP_option == 0 ~ "UnrecomTreat(+)",
          afterCGPtreat == 0 & EP_option == 1 ~ "Treat(-)",
          afterCGPtreat == 0 & EP_option == 0 ~ "Treat(-)"
        ))
      Data_survival = Data_survival %>%
        dplyr::mutate(treat_group_3 = case_when(
          afterCGPtreat == 1 & EP_treat == 1 ~ "Treat(+)",
          afterCGPtreat == 1 & EP_option == 1 ~ "Treat(+)",
          afterCGPtreat == 1 & EP_option == 0 ~ "Treat(+)",
          afterCGPtreat == 0 & EP_option == 1 ~ "Treat(-)",
          afterCGPtreat == 0 & EP_option == 0 ~ "Treat(-)"
        ))
      Data_survival = Data_survival %>%
        dplyr::filter(time_enroll_final > 0 & !is.na(time_enroll_final) & is.finite(time_enroll_final))
      Cancername = sort(unique(Data_survival$Cancers))
      Total_pts = as.vector(table((Data_survival %>%
                                     dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = T))$Cancers))
      Data_MAF_target = Data_MAF_target %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_survival$C.CAT調査結果.基本項目.ハッシュID)
      incProgress(1 / 13)
      
      output$figure_survival_CGP_1 = renderPlot({
        g = list()
        # Survival analysis for all patients
        survival_simple = survfit(Surv(time_enroll_final, censor)~1,
                                  data=Data_survival,conf.type = "log-log")
        g[[1]] = surv_curv_entry(survival_simple, Data_survival, paste(survival_simple[[1]], "patients"), "All enrolled patients", NULL, NULL)
        kk=2
        # Survival analysis for EP recommendation
        survival_simple = survfit(Surv(time_enroll_final, censor)~EP_option,
                                  data=Data_survival)
        if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~EP_option, data=Data_survival, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~EP_option, data=Data_survival, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste("EP option existed for", 
                                                                     (survival_simple)[[1]][[2]], "patients"), paste("Expert panel recommended option existed:",
                                                                                                                     c("No", "Yes"), sep=""), diff_0, diff_1)
          kk = kk + 1
        }
        
        # Survival analysis for EP recommended treatment
        survival_simple = survfit(Surv(time_enroll_final, censor)~EP_treat,
                                  data=Data_survival)
        if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~EP_treat,
                            data=Data_survival, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~EP_treat,
                            data=Data_survival, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste("Recommended treatment done for", 
                                                                     (survival_simple)[[1]][[2]], "patients"),
                               paste("Recommended treatment done: ",
                                     c("No", "Yes"), sep=""), diff_0, diff_1)
          kk = kk + 1
        }
        
        # Survival analysis for EP recommended treatment only patients with treatment option
        Data_survival_option = Data_survival %>%
          dplyr::filter(EP_option == 1)
        survival_simple = survfit(Surv(time_enroll_final, censor)~EP_treat,
                                  data=Data_survival_option)
        if(length(Data_survival_option[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~EP_treat,
                            data=Data_survival_option, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~EP_treat,
                            data=Data_survival_option, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival_option,  paste("Recommended treatment done for", 
                                                                             (survival_simple)[[1]][[2]], "patients with treatment option"), c("EP option exists but recommended treatment not done",
                                                                                                                                               "EP option exists and recommended treatment done"), diff_0, diff_1)
          kk = kk + 1
        }
        
        # Survival analysis for EP recommended treatment
        survival_simple = survfit(Surv(time_enroll_final, censor)~treat_group,
                                  data=Data_survival)
        if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~treat_group,
                            data=Data_survival, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~treat_group,
                            data=Data_survival, rho=1)
          if(length(unique(Data_survival$treat_group))==5){
            g[[kk]] = surv_curv_entry(survival_simple, Data_survival,  paste("EP option and treatment"),
                                     c("Targetable mutation (+) and recommended treatment done",
                                       "Targetable mutation (+) and other treatment done",
                                       "Targetable mutation (-) and treatment done",
                                       "Targetable mutation (+) and no treatment done",
                                       "Targetable mutation (-) and no treatment done"),
                                     diff_0, diff_1)
          } else {
            g[[kk]] = surv_curv_entry(survival_simple, Data_survival,  paste("EP option and treatment"),
                                      NULL,
                                      diff_0, diff_1)
          }
          kk = kk + 1
        }

        # Survival analysis for EP recommended treatment
        survival_simple = survfit(Surv(time_enroll_final, censor)~treat_group_2,
                                  data=Data_survival)
        if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~treat_group_2,
                            data=Data_survival, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~treat_group_2,
                            data=Data_survival, rho=1)
          if(length(unique(Data_survival$treat_group))==3){
            g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste("EP option and treatment"),
                                   c("Recommended treatment done",
                                     "No treatment done",
                                     "Not-recommended treatment done"),
                                   diff_0, diff_1)
          } else {
            g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste("EP option and treatment"),
                                      NULL,
                                      diff_0, diff_1)
            
          }
          kk = kk + 1
        }
        if(kk != 7){
          for(kkk in kk:6){
            g[[kkk]] = ggsurvplot_empty()
          }
        }
        arrange_ggsurvplots(g,print=TRUE,ncol=2,nrow=3)
      })
      incProgress(1 / 13)
       
      Data_survival_PS_matched = Data_survival %>%
        dplyr::filter(症例.背景情報.ECOG.PS.名称. != "不明" &
                        症例.基本情報.性別.名称. != "未入力・不明" &
                        !is.na(YoungOld) &
                        treat_group_2 != "UnrecomTreat(+)") %>%
        dplyr::mutate(
          PS_modified = case_when(
            症例.背景情報.ECOG.PS.名称. == "0" ~ "0",
            症例.背景情報.ECOG.PS.名称. == "1" ~ "1",
            TRUE ~ "2_4"
          ),
          treatment = case_when(
            treat_group_2 == "RecomTreat(+)" ~ 1,
            TRUE ~ 0
          ),
          Lines = case_when(
            CTx_lines_before_CGP %in% c("2", "3", "4")  ~ "2 or later",
            TRUE ~ CTx_lines_before_CGP
          ),
          Panel = case_when(
            症例.検体情報.パネル.名称. %in% c("NCC OncoPanel", "FoundationOne CDx", "GenMineTOP") ~ "Solid",
            TRUE ~ "Liquid"
          )
        )
      
      # propensity score matching considering
      # sex, age, performance status, histology, lines, metastasis
      Factor_PS = NULL
      if(length(unique(Data_survival_PS_matched$Cancers)) > 1){
        Factor_PS = c(Factor_PS, "Cancers")
      }
      if(length(unique(Data_survival_PS_matched$症例.基本情報.性別.名称.)) > 1){
        Factor_PS = c(Factor_PS, "症例.基本情報.性別.名称.")
      }
      if(length(unique(Data_survival_PS_matched$YoungOld)) > 1){
        Factor_PS = c(Factor_PS, "YoungOld")
      }
      if(length(unique(Data_survival_PS_matched$Panel)) > 1){
        Factor_PS = c(Factor_PS, "Panel")
      }
      if(length(unique(Data_survival_PS_matched$PS_modified)) > 1){
        Factor_PS = c(Factor_PS, "PS_modified")
      }
      if(length(unique(Data_survival_PS_matched$Lines)) > 1){
        Factor_PS = c(Factor_PS, "Lines")
      }
      if(length(unique(Data_survival_PS_matched$Lymph_met)) > 1){
        Factor_PS = c(Factor_PS, "Lymph_met")
      }
      if(length(unique(Data_survival_PS_matched$Brain_met)) > 1){
        Factor_PS = c(Factor_PS, "Brain_met")
      }
      if(length(unique(Data_survival_PS_matched$Lung_met)) > 1){
        Factor_PS = c(Factor_PS, "Lung_met")
      }
      if(length(unique(Data_survival_PS_matched$Bone_met)) > 1){
        Factor_PS = c(Factor_PS, "Bone_met")
      }
      if(length(unique(Data_survival_PS_matched$Liver_met)) > 1){
        Factor_PS = c(Factor_PS, "Liver_met")
      }
      formula_PS = formula(
        paste0("treatment ~", paste(Factor_PS, collapse = "+"))
      )
      matching = NA
      if(length(Factor_PS)>0 & !all(Data_survival_PS_matched$treatment == Data_survival_PS_matched$treatment[1])){
        propensityScore = glm(formula_PS,
                              family  = binomial(link = "logit"),
                              data    = Data_survival_PS_matched)
        
        Data_survival_PS_matched$PScore = propensityScore$fitted.values
        matching = Match(Y = Data_survival_PS_matched$time_enroll_final,
                         Tr = Data_survival_PS_matched$treatment,
                         X = Data_survival_PS_matched$PScore,
                         caliper=0.25,
                         ties=F,
                         replace=F)
      }
      
      output$figure_survival_CGP_CTx = renderPlot({
        g = list()
        kk = 1
        # Survival analysis for treatment effect before CGP
        Data_survival_treated = Data_survival %>%
          dplyr::filter(RECIST != "NE")
        survival_simple = survfit(Surv(time_enroll_final, censor)~RECIST,
                                  data=Data_survival_treated)
        if(length(Data_survival_treated[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~RECIST,
                            data=Data_survival_treated, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~RECIST,
                            data=Data_survival_treated, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival_treated, "Best CTx effect before CGP",
                                   NULL, diff_0, diff_1)
          kk = kk + 1
        }
        Data_survival_treated = Data_survival
        survival_simple = survfit(Surv(time_enroll_final, censor)~CTx_lines_before_CGP,
                                  data=Data_survival_treated)
        if(length(Data_survival_treated[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~CTx_lines_before_CGP,
                            data=Data_survival_treated, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~CTx_lines_before_CGP,
                            data=Data_survival_treated, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival_treated, "CTx lines before CGP",
                                   NULL, diff_0, diff_1)
          kk = kk + 1
        }
        
        if(!is.na(matching)[[1]]){
          matched_data = Data_survival_PS_matched[c(matching$index.treated, matching$index.control),]
          matched_fit = survfit(Surv(event = censor,
                                     time = time_enroll_final) ~ treatment, 
                                data = matched_data)
          if(sum(matched_fit$n.event) > 0){
            if(summary(matched_fit)$table[7] > 2 & summary(matched_fit)$table[8] > 2){
              tau0 = (max((matched_data %>% dplyr::filter(treatment == 0))$time_enroll_final)/365.25)
              tau1 = (max((matched_data %>% dplyr::filter(treatment == 1))$time_enroll_final)/365.25)
              tau = floor(min(tau0, tau1, input$RMST_CGP) * 10) / 10
              verify <- survRM2::rmst2(
                time = matched_data$time_enroll_final,
                status = matched_data$censor,
                arm = matched_data$treatment,
                tau = tau * 365.25,
                alpha = 0.05
              )
              
              surv_diff_est = round(verify$unadjusted.result[1], digits = 1)
              surv_diff_CI_LL = round(verify$unadjusted.result[4], digits = 1)
              surv_diff_CI_UL = round(verify$unadjusted.result[7], digits = 1)
              
              diff_0 = survdiff(Surv(time_enroll_final, censor)~treatment, data=matched_data, rho=0)
              diff_1 = survdiff(Surv(time_enroll_final, censor)~treatment, data=matched_data, rho=1)
              g[[kk]] = surv_curv_entry(matched_fit, matched_data,
                                  paste0("PS matched: age/sex/PS/metastasis/diagnosis/CTx-line/panel, ", tau, "-year RMST diff.: ",
                                         surv_diff_est, " (", surv_diff_CI_LL, "-", surv_diff_CI_UL, ")"),
                                  c("No-treatment, PS matched",
                                    "Recommended treatment, PS matched"),
                                  diff_0, diff_1)
              kk = kk + 1
            }
          }
        }
        if(input$HER2 != "No"){
          Data_survival_treated = Data_survival %>%
            dplyr::filter(!is.na(HER2_IHC))
          survival_simple = survfit(Surv(time_enroll_final, censor)~HER2_IHC,
                                    data=Data_survival_treated)
          if(length(Data_survival_treated[,1]) != survival_simple[[1]][[1]]){
            diff_0 = survdiff(Surv(time_enroll_final, censor)~HER2_IHC,
                              data=Data_survival_treated, rho=0)
            diff_1 = survdiff(Surv(time_enroll_final, censor)~HER2_IHC,
                              data=Data_survival_treated, rho=1)
            g[[kk]] = surv_curv_entry(survival_simple, Data_survival_treated, "HER2 IHC",
                                      NULL, diff_0, diff_1)
            kk = kk + 1
          }
        }
        if(input$MSI != "No"){
          Data_survival_treated = Data_survival %>%
            dplyr::filter(!is.na(MSI_PCR))
          survival_simple = survfit(Surv(time_enroll_final, censor)~MSI_PCR,
                                    data=Data_survival_treated)
          if(length(Data_survival_treated[,1]) != survival_simple[[1]][[1]]){
            diff_0 = survdiff(Surv(time_enroll_final, censor)~MSI_PCR,
                              data=Data_survival_treated, rho=0)
            diff_1 = survdiff(Surv(time_enroll_final, censor)~MSI_PCR,
                              data=Data_survival_treated, rho=1)
            g[[kk]] = surv_curv_entry(survival_simple, Data_survival_treated, "MSI PCR",
                                      NULL, diff_0, diff_1)
            kk = kk + 1
          }
        }
        if(input$MMR != "No"){
          Data_survival_treated = Data_survival %>%
            dplyr::filter(!is.na(MMR_IHC))
          survival_simple = survfit(Surv(time_enroll_final, censor)~MMR_IHC,
                                    data=Data_survival_treated)
          if(length(Data_survival_treated[,1]) != survival_simple[[1]][[1]]){
            diff_0 = survdiff(Surv(time_enroll_final, censor)~MMR_IHC,
                              data=Data_survival_treated, rho=0)
            diff_1 = survdiff(Surv(time_enroll_final, censor)~MMR_IHC,
                              data=Data_survival_treated, rho=1)
            g[[kk]] = surv_curv_entry(survival_simple, Data_survival_treated, "MMR IHC",
                                      NULL, diff_0, diff_1)
            kk = kk + 1
          }
        }
        if(kk != 7){
          for(kkk in kk:6){
            g[[kkk]] = ggsurvplot_empty()
          }
        }
        arrange_ggsurvplots(g,print=TRUE,ncol=2,nrow=3)
      })
          
      output$figure_survival_CGP_2 = renderPlot({
        g = list()
        kk = 1
        # Survival analysis for EP recommended treatment
        Data_survival_treated = Data_survival %>%
          dplyr::filter(treat_group_2 != "Treat(-)")
        survival_simple = survfit(Surv(time_enroll_final, censor)~treat_group_2,
                                  data=Data_survival_treated)
        if(length(Data_survival_treated[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~treat_group_2,
                            data=Data_survival_treated, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~treat_group_2,
                            data=Data_survival_treated, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival_treated, paste("EP option and treatment"),
                                   c("Recommended treatment done",
                                     "Not-recommended treatment done"),
                                   diff_0, diff_1)
          kk = kk + 1
        }
        
        # Survival analysis for EP recommended treatment
        survival_simple = survfit(Surv(time_enroll_final, censor)~treat_group_3,
                                  data=Data_survival)
        if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~treat_group_3,
                            data=Data_survival, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~treat_group_3,
                            data=Data_survival, rho=1)
          #summary(survival_simple)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste("EP option and treatment"),
                                   c("Treatment done",
                                     "No treatment done"),
                                   diff_0, diff_1)
          kk = kk + 1
        }
        
        # Survival analysis for ECOG performance status
        Data_survival_Performance = Data_survival %>%
          dplyr::mutate(症例.背景情報.ECOG.PS.名称. = case_when(
            症例.背景情報.ECOG.PS.名称. == "不明" ~ "Unknown",
            TRUE ~ 症例.背景情報.ECOG.PS.名称.
          ))
        survival_simple = survfit(Surv(time_enroll_final, censor)~症例.背景情報.ECOG.PS.名称.,
                                  data=Data_survival_Performance)
        if(length(Data_survival_Performance[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~症例.背景情報.ECOG.PS.名称.,
                            data=Data_survival_Performance, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~症例.背景情報.ECOG.PS.名称.,
                            data=Data_survival_Performance, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival_Performance, "ECOG PS",
                                   paste0("Performance status:",
                                         sort(unique(Data_survival_Performance$症例.背景情報.ECOG.PS.名称.))), diff_0, diff_1)
          kk = kk + 1
        }
        
        # Survival analysis for ECOG performance status, PS 0 vs 1 vs 2/3/4
        Data_survival_PS = Data_survival %>%
          dplyr::filter(症例.背景情報.ECOG.PS.名称. != "不明") %>%
          dplyr::mutate(PS_modified = case_when(
            症例.背景情報.ECOG.PS.名称. == "0" ~ "0",
            症例.背景情報.ECOG.PS.名称. == "1" ~ "1",
            TRUE ~ "2_4"
          ))
        survival_simple = survfit(Surv(time_enroll_final, censor)~PS_modified,
                                  data=Data_survival_PS)
        if(length(Data_survival_PS[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~PS_modified,
                            data=Data_survival_PS, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~PS_modified,
                            data=Data_survival_PS, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival_PS,
                                   paste0("ECOG PS (PS unknown patients excluded)"), paste("Performance status:",
                                          sort(unique(Data_survival_PS$PS_modified))), diff_0, diff_1)
          kk = kk + 1
        }
        
        
        # Survival analysis for diagnosis
        Data_survival_tmp = Data_survival %>% dplyr::filter(
          Cancers %in% sort(names(table(Data_survival$Cancers)))[1:min(8,length(unique(Data_survival$Cancers)))])
        if(length(unique(Data_survival_tmp$Cancers))>1){
          survival_simple = survfit(Surv(time_enroll_final, censor)~Cancers,
                                    data=Data_survival_tmp)
          if(length(Data_survival_tmp[,1]) != survival_simple[[1]][[1]]){
            diff_0 = survdiff(Surv(time_enroll_final, censor)~Cancers,
                              data=Data_survival_tmp, rho=0)
            diff_1 = survdiff(Surv(time_enroll_final, censor)~Cancers,
                              data=Data_survival_tmp, rho=1)
            g[[kk]] = surv_curv_entry(survival_simple, Data_survival_tmp, paste("diagnosis"), sort(unique(Data_survival_tmp$Cancers)), diff_0, diff_1)
            kk = kk + 1
          }
        } else{
          survival_simple = survfit(Surv(time_enroll_final, censor)~1,
                                    data=Data_survival_tmp)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival_PS, paste("Only 1 diagnosis"), unique(Data_survival_tmp$Cancers)[[1]], diff_0, diff_1)
          kk = kk + 1
        }
        
        # Survival analysis for mutation, any
        mut_gene = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
        if(length(mut_gene)==0){
          mut_gene = "TP53"
        }
        ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode
        Data_survival = Data_survival %>% dplyr::mutate(
          mutation = case_when(
            C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ 0,
            TRUE ~ 1
          )
        )
        survival_simple = survfit(Surv(time_enroll_final, censor)~mutation,
                                  data=Data_survival)
        if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~mutation,
                            data=Data_survival, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~mutation,
                            data=Data_survival, rho=1)
          g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste(paste(mut_gene, collapse = "/")),
                                c(paste0(paste(mut_gene, collapse = "/"), " mut in any"), "Not mut"), diff_0, diff_1)
          kk = kk + 1
        }
        # Survival analysis for mutation, all
        mut_gene = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
        if(length(mut_gene)==0){
          mut_gene = "TP53"
        }
        ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode
        for(jj in 1:length(mut_gene)){
          ID_mutation = ID_mutation[ID_mutation %in% (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene[jj]))$Tumor_Sample_Barcode]
        }
        if(length(ID_mutation) > 0){
          Data_survival = Data_survival %>% dplyr::mutate(
            mutation = case_when(
              C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ 1,
              C.CAT調査結果.基本項目.ハッシュID %in% (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode ~ 2,
              TRUE ~ 4
            )
          )
          survival_simple = survfit(Surv(time_enroll_final, censor)~mutation,
                                    data=Data_survival)
          if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
            if(sum(unique(Data_survival$mutation)) == 7){
              diff_0 = survdiff(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival, rho=0)
              diff_1 = survdiff(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival, rho=1)
              g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste(paste(mut_gene, collapse = "/")),
                                        c(paste0(paste(mut_gene, collapse = "/"), " mut in all"),
                                          paste0(paste(mut_gene, collapse = "/"), " mut in some"),
                                          "Not mut"), diff_0, diff_1)
              kk = kk + 1
            } else if(sum(unique(Data_survival$mutation)) == 6){
              diff_0 = survdiff(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival, rho=0)
              diff_1 = survdiff(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival, rho=1)
              g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste(paste(mut_gene, collapse = "/")),
                                        c(paste0(paste(mut_gene, collapse = "/"), " mut in some"), "Not mut"), diff_0, diff_1)
              kk = kk + 1
            } else if(sum(unique(Data_survival$mutation)) == 5){
              diff_0 = survdiff(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival, rho=0)
              diff_1 = survdiff(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival, rho=1)
              g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste(paste(mut_gene, collapse = "/")),
                                        c(paste0(paste(mut_gene, collapse = "/"), " mut in all"), "Not mut"), diff_0, diff_1)
              kk = kk + 1
            } else {
              diff_0 = survdiff(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival, rho=0)
              diff_1 = survdiff(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival, rho=1)
              g[[kk]] = surv_curv_entry(survival_simple, Data_survival, paste(paste(mut_gene, collapse = "/")),
                                        c(paste0(paste(mut_gene, collapse = "/"), " mut in all"), paste0(paste(mut_gene, collapse = "/"), " mut in some")), diff_0, diff_1)
              kk = kk + 1
            }
          }
        }
        if(kk != 9){
          for(kkk in kk:8){
            g[[kkk]] = ggsurvplot_empty()
          }
        }
        arrange_ggsurvplots(g,print=TRUE,ncol=2,nrow=4)
      })
      incProgress(1 / 13)
      # analysis for common oncogenic mutations
      h = list()
      hs = list()
      oncogenic_genes = Data_MAF_target %>%
        dplyr::select(Tumor_Sample_Barcode, Hugo_Symbol) %>%
        dplyr::distinct() %>%
        dplyr::count(Hugo_Symbol) %>%
        dplyr::arrange(-n)
      colnames(oncogenic_genes) = c("gene_mutation", "all_patients")
      oncogenic_genes = oncogenic_genes[1:min(length(oncogenic_genes$all_patients), input$gene_no),]
      
      gene_table = data.frame(oncogenic_genes$gene_mutation)
      colnames(gene_table) = c("Gene")
      gene_table$positive_patients = oncogenic_genes$all_patients
      gene_table$positive_freq = round(1000 * gene_table$positive_patients / length(Data_survival$C.CAT調査結果.基本項目.ハッシュID)) / 10
      gene_table$positive_median = 0
      gene_table$positive_LL = 0
      gene_table$positive_UL = 0
      gene_table$negative_median = 0
      gene_table$negative_LL = 0
      gene_table$negative_UL = 0
      gene_table$diff_median = 0
      gene_table$diff_LL = 0
      gene_table$diff_UL = 0
      
      k = 1
      for(i in 1:length(oncogenic_genes$all_patients)){
        ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% oncogenic_genes$gene_mutation[i]))$Tumor_Sample_Barcode
        Data_survival = Data_survival %>% dplyr::mutate(
          gene_select = case_when(
            C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ 0,
            TRUE ~ 1
          )
        )
        traditional_fit = survfit(Surv(event = censor,
                                       time = time_enroll_final) ~ gene_select, 
                                  data = Data_survival)
        if(length(Data_survival[,1]) != traditional_fit[[1]][[1]]){
          tau0 = ((max((Data_survival %>% dplyr::filter(gene_select == 0))$time_enroll_final) - 1)/365.25)
          tau1 = ((max((Data_survival %>% dplyr::filter(gene_select == 1))$time_enroll_final) - 1)/365.25)
          tau = floor(min(tau0, tau1, input$RMST_CGP) * 10) / 10
          verify <- survRM2::rmst2(
            time = Data_survival$time_enroll_final,
            status = Data_survival$censor,
            arm = Data_survival$gene_select,
            tau = tau * 365.25,
            alpha = 0.05
          )

          diff_0 = survdiff(Surv(time_enroll_final, censor)~gene_select,
                            data=Data_survival, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~gene_select,
                            data=Data_survival, rho=1)
          mut_gene = paste(oncogenic_genes$gene_mutation[i],
                           ", top ", i, " gene with oncogenic mutations", sep="")
          tmp = data.frame(summary(traditional_fit)$table)
          gene_table$positive_median[i] = tmp$median[1]
          gene_table$positive_LL[i] = tmp$X0.95LCL[1]
          gene_table$positive_UL[i] = tmp$X0.95UCL[1]
          gene_table$negative_median[i] = tmp$median[2]
          gene_table$negative_LL[i] = tmp$X0.95LCL[2]
          gene_table$negative_UL[i] = tmp$X0.95UCL[2]
          gene_table$diff_median[i] = -round(verify$unadjusted.result[1], digits = 1)
          gene_table$diff_LL[i] = -round(verify$unadjusted.result[7], digits = 1)
          gene_table$diff_UL[i] = -round(verify$unadjusted.result[4], digits = 1)
          hs[[k]] = surv_curv_entry(traditional_fit, Data_survival,
                                    paste0(tau, "-year RMST diff.: ",
                                           gene_table$diff_median[i],
                                           " (", gene_table$diff_LL[i], "-", gene_table$diff_UL[i], ")"),
                                   c(paste0(oncogenic_genes$gene_mutation[i], " mut"), "Not mut"), diff_0, diff_1)
          k = k + 1
        } else{
          tmp = summary(traditional_fit)$table
          legends = paste0(tmp[[7]], " (", tmp[[8]], "-", tmp[[9]],")")
          gene_table$negative_median[i] = tmp[[7]]
          gene_table$negative_LL[i] = tmp[[8]]
          gene_table$negative_UL[i] = tmp[[9]]
        }
      }
      incProgress(1 / 13)
      Gene_arrange = gene_table$Gene
      Gene_data = gene_table
      gene_table = gene_table %>% dplyr::mutate(
        Gene = factor(gene_table$Gene, levels = Gene_arrange))
      p <- 
        gene_table |>
        ggplot(aes(y = fct_rev(Gene))) + 
        theme_classic()
      p <- p +
        geom_point(aes(x=diff_median), shape=15, size=3) +
        geom_linerange(aes(xmin=diff_LL, xmax=diff_UL))
      p <- p +
        geom_vline(xintercept = 0, linetype="dashed") +
        labs(x="Median OS and difference in restricted mean survival time (days) in 2 years", y="Genes with oncogenic alteration")
      p <- p +
        coord_cartesian(ylim=c(1,length(Gene_arrange) + 1),
                        xlim=c( - max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) - 15,
                                max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) + 15))
      p <- p +
        annotate("text",
                 x = (-max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) - 15)/2,
                 y = length(Gene_arrange) + 1,
                 label = "mut=short survival") +
        annotate("text",
                 x = (max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) + 15)/2,
                 y = length(Gene_arrange) + 1,
                 label = "mut=long survival")
      p_mid <- p + 
        theme(legend.position = "none",
              axis.line.y = element_blank(),
              axis.ticks.y= element_blank(),
              axis.text.y= element_blank(),
              axis.title.y= element_blank())
      gene_table <- gene_table %>%
        dplyr::mutate(
          estimate_lab_1 = paste0(positive_median, " (", positive_LL, "-", positive_UL, ")")) %>%
        dplyr::mutate(
          estimate_lab_2 = paste0(negative_median, " (", negative_LL, "-", negative_UL, ")")) %>%
        dplyr::mutate(
          estimate_lab_3 = paste0(diff_median, " (", diff_LL, "-", diff_UL, ")")) %>%
        dplyr::mutate(
          patients = paste0(positive_patients, " (", positive_freq, "%)"))
      gene_table = 
        dplyr::bind_rows(
          data.frame(
            Gene = "Gene",
            estimate_lab_1 = "Survival, mut (+)",
            estimate_lab_2 = "Survival, mut (-)",
            estimate_lab_3 = "RMST difference",
            patients = "Patients"
          ), gene_table)
      Gene_arrange = gene_table$Gene
      gene_table = gene_table %>% dplyr::mutate(
        Gene = factor(gene_table$Gene, levels = Gene_arrange))
      
      p_left <- gene_table  %>% ggplot(aes(y = fct_rev(Gene)))
      p_left <- p_left + geom_text(aes(x = 0, label = Gene), hjust = 0,
                                   fontface = ifelse(gene_table$Gene == "Gene", "bold", "bold.italic"))
      p_left <- p_left + geom_text(aes(x = 1.4, label = estimate_lab_1), hjust = 0,
                                   fontface = ifelse(gene_table$estimate_lab_1 == "Survival, mut (+)", "bold", "plain"))
      p_left <- p_left + geom_text(aes(x = 2.6, label = estimate_lab_2), hjust = 0,
                                   fontface = ifelse(gene_table$estimate_lab_2 == "Survival, mut (-)", "bold", "plain"))
      p_left <- p_left + geom_text(aes(x = 3.8, label = estimate_lab_3), hjust = 0,
                                   fontface = ifelse(gene_table$estimate_lab_3 == "RMST difference", "bold", "plain"))
      p_left <- p_left + theme_void() + coord_cartesian(xlim = c(0, 6.5))
      
      # right side of plot - pvalues
      p_right <- gene_table  |> ggplot() +
        geom_text(aes(x = 0, y = fct_rev(Gene), label = patients), hjust = 0,
                  fontface = ifelse(gene_table$patients == "Patients", "bold", "plain")) +
        theme_void()
      
      for(kk in k:32){
        hs[[kk]] = ggsurvplot_empty()
      }
      
      # final plot arrangement
      layout <- c(patchwork::area(t = 0, l = 0, b = 30, r = 6.5),
                  patchwork::area(t = 1, l = 6.5, b = 30, r = 10.5),
                  patchwork::area(t = 0, l = 10.5, b = 30, r = 12))
      h[[1]] = p_left + p_mid + p_right + plot_layout(design = layout)

      incProgress(1 / 13)
      
      output$figure_survival_CGP_3 = renderPlot({
        h[[1]]
      })
      output$figure_survival_CGP_4 = renderPlot({
        arrange_ggsurvplots(hs,print=TRUE,ncol=4,nrow=8,surv.plot.height = 0.8,risk.table.height = 0.2)
      })
      incProgress(1 / 13)
      
      Data_forest = Data_case_target %>%
          dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                        YoungOld,
                        Lymph_met,
                        Brain_met,
                        Lung_met,
                        Bone_met,
                        Liver_met,
                        #Other_met,
                        EP_option,
                        EP_treat,
                        症例.基本情報.性別.名称.,
                        症例.基本情報.がん種.OncoTree.,
                        症例.基本情報.がん種.OncoTree.LEVEL1.,
                        症例.背景情報.ECOG.PS.名称.,
                        #症例.背景情報.喫煙歴有無.名称.,
                        #症例.背景情報.アルコール多飲有無.名称.,
                        time_enroll_final,
                        censor,
                        CTx_lines_before_CGP,
                        症例.検体情報.パネル.名称.,
                        症例.基本情報.年齢)
      colnames(Data_forest) = 
          c('ID', 'Age',
            'Lymph_met',
            'Brain_met',
            'Lung_met',
            'Bone_met',
            'Liver_met',
            #'Other_met',
            'EP_option',
            'EP_treat',
            'Sex', 'Histology', 'Histology_dummy', 'PS',
            #'Smoking_history', 'Alcoholic_history',
            'time_enroll_final', 'censor', "Lines", "Panel","Age_raw")
      #Data_forest$Histology_dummy = paste0(Data_forest$Histology_dummy,"_NOS")
      col_added = 0
      if(input$HER2 != "No"){
        Data_forest$HER2_IHC = Data_case_target$HER2_IHC
        Data_forest = Data_forest %>%
          dplyr::filter(
            HER2_IHC != "Unknown"
          )
        col_added = col_added + 1
      }
      if(input$MSI != "No"){
        Data_forest$MSI_PCR = Data_case_target$MSI_PCR
        Data_forest = Data_forest %>%
          dplyr::filter(
            MSI_PCR != "Unknown"
          )
        col_added = col_added + 1
      }
      if(input$MMR != "No"){
        Data_forest$MMR_IHC = Data_case_target$MMR_IHC
        Data_forest = Data_forest %>%
          dplyr::filter(
            MMR_IHC != "Unknown"
          )
        col_added = col_added + 1
      }
      
      Data_forest = Data_forest %>%
        dplyr::filter(PS != "不明" & Sex != "未入力・不明") %>%
        dplyr::mutate(
          PS = case_when(
            PS == 0 ~ "0",
            PS == 1 ~ "1",
            TRUE ~ "2_4"
          ),
          Lines = case_when(
            Lines == "0" ~ "0",
            Lines == "1" ~ "1",
            TRUE ~ "2~"
          ),
          Panel = case_when(
            Panel %in% c("NCC OncoPanel", "FoundationOne CDx", "GenMineTOP") ~ "Solid",
            TRUE ~ "Liquid"
          )
        )
      Data_forest$Panel = factor(Data_forest$Panel)
      if(length(unique(Data_forest$Panel))>1){
        Data_forest$Panel =  relevel(Data_forest$Panel, ref="Solid") 
      }
      frequent_organs = sort(table(Data_forest$Histology),decreasing = T)
      frequent_organs_names = names(frequent_organs[frequent_organs>=50])
      Data_forest = Data_forest %>% dplyr::mutate(
        Histology = case_when(
          Histology %in% frequent_organs_names ~ Histology,
          TRUE ~ Histology_dummy
        )
      )
      Data_ML =  Data_forest %>%
        dplyr::select(-Age, -time_enroll_final, -censor, -EP_option, -ID, -Histology_dummy)
      Data_forest =  Data_forest %>%
        dplyr::select(-Age_raw)
      gene_names = unique(c(input$gene,
                          as.character(Gene_data$Gene)))
      gene_names = gene_names[gene_names %in% unique(Data_MAF_target$Hugo_Symbol)]
      
      gene_names = gene_names[1:min(10, length(gene_names))]
      for(i in 1:length(gene_names)){
        ID_mutation = unique((Data_MAF_target %>% dplyr::filter(Hugo_Symbol == gene_names[i]))$Tumor_Sample_Barcode)
        Data_forest_tmp = Data_forest %>% 
          dplyr::select(ID) %>%
          dplyr::distinct() %>%
          dplyr::mutate(
            XXX = case_when(
              ID %in% ID_mutation ~ "mut(+)",
              TRUE ~ "mut(-)"
          )
        )
        colnames(Data_forest_tmp) = c("ID", gene_names[i])
        Data_forest = left_join(Data_forest, Data_forest_tmp, by=c("ID"))
      }
      Factor_names = colnames(Data_forest)
      Factor_names = Factor_names[!Factor_names %in% c('ID', 'time_enroll_final', 'censor', 'EP_treat')]
      
      Data_forest_tmp = Data_forest
      Disease_tmp = unique(sort(Data_forest_tmp$Histology))
      for(i in length(gene_names):1){
        if(sum(Data_forest_tmp[,17+col_added+i] == "mut(+)" & Data_forest_tmp$censor == 1) < 3){
          Factor_names = Factor_names[-(13+col_added+i)]
        } else if(sum(Data_forest_tmp[,17+col_added+i] != "mut(+)" & Data_forest_tmp$censor == 1) < 3){
          Factor_names = Factor_names[-(13+col_added+i)]
        }
      }
      for(i in 1:length(Disease_tmp)){
        Data_forest_tmp2 = Data_forest_tmp %>% dplyr::filter(Histology == Disease_tmp[i])
        if(sum(Data_forest_tmp2$censor == 1) < 3){
          Data_forest_tmp = Data_forest_tmp %>%
            dplyr::mutate(Histology = case_when(
              Histology == Disease_tmp[i] ~ Histology_dummy,
              TRUE ~ Histology
            )
          )
        }
      }
      if(length(unique(Data_forest_tmp$Histology))<2){
        Factor_names = Factor_names[!Factor_names %in% c('Histology')]
      }
      if(sum(Data_forest_tmp$EP_option == 0 & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('EP_option')]
      } else if(sum(Data_forest_tmp$EP_option == 1 & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('EP_option')]
      }
      if(sum(Data_forest_tmp$Age == "Younger" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Age')]
      } else if(sum(Data_forest_tmp$Age == "Older" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Age')]
      }
      if(sum(Data_forest_tmp$Sex == "男" & Data_forest_tmp$censor == 1,na.rm = T) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Sex')]
        } else if(sum(Data_forest_tmp$Sex != "男" & Data_forest_tmp$censor == 1,na.rm = T) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Sex')]
      }
      if(sum(Data_forest_tmp$Panel == "Solid" & Data_forest_tmp$censor == 1,na.rm = T) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Panel')]
      } else if(sum(Data_forest_tmp$Panel != "Solid" & Data_forest_tmp$censor == 1,na.rm = T) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Panel')]
      }
      if(sum(Data_forest_tmp$PS == "0" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('PS')]
      } else if(sum(Data_forest_tmp$PS != "0" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('PS')]
      } else if(sum(Data_forest_tmp$PS == "2_4" & Data_forest_tmp$censor == 1) < 3){
        Data_forest_tmp$Lines[Data_forest_tmp$PS == "1"] = "1_4"
        Data_forest_tmp$Lines[Data_forest_tmp$PS == "2_4"] = "1_4"
      }
      if(sum(Data_forest_tmp$Lines == "1" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lines')]
      } else if(sum(Data_forest_tmp$Lines != "1" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lines')]
      } else if(sum(Data_forest_tmp$Lines == "0" & Data_forest_tmp$censor == 1) < 3){
        Data_forest_tmp$Lines[Data_forest_tmp$Lines == "0"] = "0~1"
        Data_forest_tmp$Lines[Data_forest_tmp$Lines == "1"] = "0~1"
      } else if(sum(Data_forest_tmp$Lines == "2~" & Data_forest_tmp$censor == 1) < 3){
        Data_forest_tmp$Lines[Data_forest_tmp$Lines == "2~"] = "1~"
        Data_forest_tmp$Lines[Data_forest_tmp$Lines == "1"] = "1~"
      }
      if(sum(Data_forest_tmp$Lymph_met == "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lymph_met')]
      } else if(sum(Data_forest_tmp$Lymph_met != "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lymph_met')]
      }
      if(sum(Data_forest_tmp$Lung_met == "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lung_met')]
      } else if(sum(Data_forest_tmp$Lung_met != "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lung_met')]
      }
      if(sum(Data_forest_tmp$Brain_met == "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Brain_met')]
      } else if(sum(Data_forest_tmp$Brain_met != "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Brain_met')]
      }
      if(sum(Data_forest_tmp$Bone_met == "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Bone_met')]
      } else if(sum(Data_forest_tmp$Bone_met != "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Bone_met')]
      }
      if(sum(Data_forest_tmp$Liver_met == "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Liver_met')]
      } else if(sum(Data_forest_tmp$Liver_met != "Yes" & Data_forest_tmp$censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Liver_met')]
      }
      if(input$HER2 != "No"){
        if(sum(Data_forest_tmp$HER2_IHC == "Positive" & Data_forest_tmp$censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('HER2_IHC')]
        } else if(sum(Data_forest_tmp$HER2_IHC != "Positive" & Data_forest_tmp$censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('HER2_IHC')]
        }
      }
      if(input$MSI != "No"){
        if(sum(Data_forest_tmp$MSI_PCR == "Positive" & Data_forest_tmp$censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('MSI_PCR')]
        } else if(sum(Data_forest_tmp$MSI_PCR != "Positive" & Data_forest_tmp$censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('MSI_PCR')]
        }
      }
      if(input$MMR != "No"){
        if(sum(Data_forest_tmp$MMR_IHC == "Positive" & Data_forest_tmp$censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('MMR_IHC')]
        } else if(sum(Data_forest_tmp$MMR_IHC != "Positive" & Data_forest_tmp$censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('MMR_IHC')]
        }
      }
      
      if(length(Factor_names) > 1){
        for(i in length(Factor_names):1){
          if(all(Data_forest_tmp[,colnames(Data_forest_tmp) == Factor_names[i]] ==
                 Data_forest_tmp[1,colnames(Data_forest_tmp) == Factor_names[i]])){
            Factor_names = Factor_names[Factor_names != Factor_names[i]]
          }
        }
      }
      Factor_names = Factor_names[!Factor_names %in% c('Histology_dummy')]
      Factor_names_univariant = Factor_names
      if(length(Factor_names) > 1){
        Factor_names_tmp = Factor_names
        for(i in 1:(length(Factor_names_tmp) - 1)){
          for(j in (i+1):length(Factor_names_tmp)){
            if(Factor_names_tmp[i] %in% colnames(Data_forest_tmp) &
               Factor_names_tmp[j] %in% colnames(Data_forest_tmp)){
              if(mean(Data_forest_tmp[,colnames(Data_forest_tmp) == Factor_names_tmp[i]] ==
                      Data_forest_tmp[,colnames(Data_forest_tmp) == Factor_names_tmp[j]]) > 0.95){
                Factor_names = Factor_names[Factor_names != Factor_names_tmp[j]]
              }
            }
          }
        }
      }
          
      incProgress(1 / 13)
      output$figure_survival_CGP_5 = render_gt({
        if(length(Factor_names) > 0){
          if("Sex" %in% colnames(Data_forest_tmp)){
            Data_forest_tmp = Data_forest_tmp %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          Data_forest_tmp_table = Data_forest_tmp %>%
            dplyr::mutate(EP_option=case_when(
              EP_option == 1 ~ "Yes",
              TRUE ~ "No"
            ))
          colnames_tmp = colnames(Data_forest_tmp_table)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "EP_option"] = "Treatment recommended"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines before CGP"
          Factor_names[Factor_names == "Lymph_met"] = "Lymphatic metastasis"
          Factor_names[Factor_names == "Liver_met"] = "Liver metastasis"
          Factor_names[Factor_names == "Lung_met"] = "Lung metastasis"
          Factor_names[Factor_names == "Bone_met"] = "Bone metastasis"
          Factor_names[Factor_names == "Brain_met"] = "Brain metastasis"
          Factor_names[Factor_names == "EP_option"] = "Treatment recommended"
          Factor_names[Factor_names == "PS"] = "Performance status"
          Factor_names[Factor_names == "Lines"] = "CTx lines before CGP"
          Factor_names_univariant[Factor_names_univariant == "Lymph_met"] = "Lymphatic metastasis"
          Factor_names_univariant[Factor_names_univariant == "Liver_met"] = "Liver metastasis"
          Factor_names_univariant[Factor_names_univariant == "Lung_met"] = "Lung metastasis"
          Factor_names_univariant[Factor_names_univariant == "Bone_met"] = "Bone metastasis"
          Factor_names_univariant[Factor_names_univariant == "Brain_met"] = "Brain metastasis"
          Factor_names_univariant[Factor_names_univariant == "EP_option"] = "Treatment recommended"
          Factor_names_univariant[Factor_names_univariant == "PS"] = "Performance status"
          Factor_names_univariant[Factor_names_univariant == "Lines"] = "CTx lines before CGP"
          
          colnames(Data_forest_tmp_table) = colnames_tmp
          Formula = as.formula(paste0("Surv(time_enroll_final, censor) ~ ",
                                        paste( paste0("`",Factor_names,"`"), collapse = " + ")))
          linelistsurv_cox <-  coxph(formula = Formula,
                                     data = Data_forest_tmp_table,
                                     control = coxph.control(iter.max = 50))

          univ_tab <- Data_forest_tmp_table %>% 
            tbl_uvregression(                         ## 単変量解析の表を生成
              method = coxph,                           ## 実行したい回帰（一般化線形モデル）を定義
              y = Surv(time = time_enroll_final, event = censor),
              include = Factor_names_univariant,                            ## アウトカム変数を定義
              exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
            ) |>
            add_global_p() |> # add global p-value
            add_n(location = "level") |>
            add_nevent(location = "level") |> # add number of events of the outcome
            add_q() |> # adjusts global p-values for multiple testing
            bold_p() |> # bold p-values under a given threshold (default 0.05)
            modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            bold_labels()

          final_mv_reg <- linelistsurv_cox %>%
            stats::step(direction = "backward", trace = FALSE)
          if(!is.null(final_mv_reg$xlevels)){
            mv_tab = final_mv_reg |>
              tbl_regression(                         ## 多変量解析の表を生成
                exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
              ) |>
              add_global_p() |> # add global p-value
              add_q() |> # adjusts global p-values for multiple testing
              bold_p() |> # bold p-values under a given threshold (default 0.05)
              modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              bold_labels()
            tbl_merge(
              tbls = list(univ_tab, mv_tab),
              tab_spanner = c("**Univariate**", "**Multivariable**")) |>
              modify_caption("Hazard ratio for death after CGP (Only factors with >2 events observed)") |> as_gt()
          } else {
            univ_tab |>
              modify_caption("Hazard ratio for death after CGP, no significant factor in multivariable analysis (Only factors with >2 events observed)") |> as_gt()
          }
        }
      })
     
      Data_forest_tmp__ = Data_forest %>%
        dplyr::select(-time_enroll_final, -censor, -EP_option, -ID)
      Disease_tmp = unique(sort(Data_forest_tmp__$Histology))
      for(i in 1:length(Disease_tmp)){
        Data_forest_tmp_2_ = Data_forest_tmp__ %>% dplyr::filter(Histology == Disease_tmp[i])
        if(sum(Data_forest_tmp_2_$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::mutate(Histology = case_when(
              Histology == Disease_tmp[i] ~ Histology_dummy,
              TRUE ~ Histology
            )
            )
        }
      }
      for(i in length(gene_names):1){
        if(sum(Data_forest_tmp__[,13+col_added+i] == "mut(+)" & Data_forest_tmp__$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__[,-(13+col_added+i)]
        } else if(sum(Data_forest_tmp__[,13+col_added+i] != "mut(+)" & Data_forest_tmp__$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__[,-(13+col_added+i)]
        }
      }
      if(sum(Data_forest_tmp__$PS == "0" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-PS)
      } else if(sum(Data_forest_tmp__$PS != "0" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-PS)
      } else if(sum(Data_forest_tmp__$PS == "2_4" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__$PS[Data_forest_tmp__$PS == "1"] = "1_4"
        Data_forest_tmp__$PS[Data_forest_tmp__$PS == "2_4"] = "1_4"
      }
      if(sum(Data_forest_tmp__$Panel == "Solid" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Panel)
      } else if(sum(Data_forest_tmp__$Panel != "Solid" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Panel)
      }
      if(sum(Data_forest_tmp__$Lines == "1" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Lines)
      } else if(sum(Data_forest_tmp__$Lines != "1" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Lines)
      } else if(sum(Data_forest_tmp__$Lines == "0" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__$Lines[Data_forest_tmp__$Lines == "0"] = "0~1"
        Data_forest_tmp__$Lines[Data_forest_tmp__$Lines == "1"] = "0~1"
      } else if(sum(Data_forest_tmp__$Lines == "2~" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__$Lines[Data_forest_tmp__$Lines == "2~"] = "1~"
        Data_forest_tmp__$Lines[Data_forest_tmp__$Lines == "1"] = "1~"
      } 
      if(sum(Data_forest_tmp__$Age == "Younger" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Age)
      } else if(sum(Data_forest_tmp__$Age == "Older" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Age)
      }
      if(sum(Data_forest_tmp__$Sex == "男" & Data_forest_tmp__$EP_treat == 1,na.rm = T) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Sex)
      } else if(sum(Data_forest_tmp__$Sex != "男" & Data_forest_tmp__$EP_treat == 1,na.rm = T) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Sex)
      }
      if(sum(Data_forest_tmp__$Lymph_met == "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Lymph_met)
      } else if(sum(Data_forest_tmp__$Lymph_met != "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Lymph_met)
      }
      if(sum(Data_forest_tmp__$Lung_met == "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Lung_met)
      } else if(sum(Data_forest_tmp__$Lung_met != "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Lung_met)
      }
      if(sum(Data_forest_tmp__$Brain_met == "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Brain_met)
      } else if(sum(Data_forest_tmp__$Brain_met != "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Brain_met)
      }
      if(sum(Data_forest_tmp__$Bone_met == "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Bone_met)
      } else if(sum(Data_forest_tmp__$Bone_met != "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Bone_met)
      }
      if(sum(Data_forest_tmp__$Liver_met == "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Liver_met)
      } else if(sum(Data_forest_tmp__$Liver_met != "Yes" & Data_forest_tmp__$EP_treat == 1) < 3){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Liver_met)
      }
      if(input$HER2 != "No"){
        if(sum(Data_forest_tmp__$HER2_IHC == "Positive" & Data_forest_tmp__$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::select(-HER2_IHC)
        } else if(sum(Data_forest_tmp__$HER2_IHC != "Positive" & Data_forest_tmp__$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::select(-HER2_IHC)
        }
      }
      if(input$MSI != "No"){
        if(sum(Data_forest_tmp__$MSI_PCR == "Positive" & Data_forest_tmp__$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::select(-MSI_PCR)
        } else if(sum(Data_forest_tmp__$MSI_PCR != "Positive" & Data_forest_tmp__$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::select(-MSI_PCR)
        }
      }
      if(input$MMR != "No"){
        if(sum(Data_forest_tmp__$MMR_IHC == "dMMR" & Data_forest_tmp__$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::select(-MMR_IHC)
        } else if(sum(Data_forest_tmp__$MMR_IHC != "dMMR" & Data_forest_tmp__$EP_treat == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::select(-MMR_IHC)
        }
      }
      if(length(unique(Data_forest_tmp__$Histology))<2){
        Data_forest_tmp__ = Data_forest_tmp__ %>%
          dplyr::select(-Histology)
      }
      Data_forest_tmp__ = Data_forest_tmp__ %>%
        dplyr::select(-Histology_dummy)
      
      if(length(colnames(Data_forest_tmp__)) > 1){
        Factor_names_tmp__ = colnames(Data_forest_tmp__)
        Factor_names_tmp__ = Factor_names_tmp__[Factor_names_tmp__ != "EP_treat"]
        for(i in length(Factor_names_tmp__):1){
          if(all(Data_forest_tmp__[,colnames(Data_forest_tmp__) == Factor_names_tmp__[i]] ==
                 Data_forest_tmp__[1,colnames(Data_forest_tmp__) == Factor_names_tmp__[i]])){
            Data_forest_tmp__ = Data_forest_tmp__ %>%
              dplyr::select(-Factor_names_tmp__[i])
          }
        }
      }
      Data_forest_tmp__univariant = Data_forest_tmp__
      if(length(colnames(Data_forest_tmp__)) > 1){
        Factor_names_tmp__ = colnames(Data_forest_tmp__)
        Factor_names_tmp__ = Factor_names_tmp__[Factor_names_tmp__ != "EP_treat"]
        for(i in 1:(length(Factor_names_tmp__) - 1)){
          for(j in (i+1):length(Factor_names_tmp__)){
            if(Factor_names_tmp__[i] %in% colnames(Data_forest_tmp__) &
               Factor_names_tmp__[j] %in% colnames(Data_forest_tmp__)){
              if(mean(Data_forest_tmp__[,colnames(Data_forest_tmp__) == Factor_names_tmp__[i]] ==
                      Data_forest_tmp__[,colnames(Data_forest_tmp__) == Factor_names_tmp__[j]]) > 0.95){
                Data_forest_tmp__ = Data_forest_tmp__ %>%
                  dplyr::select(-Factor_names_tmp__[j])
              }
            }
          }
        }
      }

      # Data_forest_tmp_7 = Data_forest_tmp__
      Data_forest_tmp_7 = Data_forest_tmp__[,colnames(Data_forest_tmp__) %in% 
                                              c("Age","Lymph_met","Brain_met","Lung_met","Bone_met","Liver_met","Sex","Histology","PS","Lines","EP_treat","Panel",
                                                "HER2_IHC", "MSI_PCR", "MMR_IHC")]
      Data_forest_tmp_7__univariant = Data_forest_tmp__univariant[,colnames(Data_forest_tmp__univariant) %in% 
                                              c("Age","Lymph_met","Brain_met","Lung_met","Bone_met","Liver_met","Sex","Histology","PS","Lines","EP_treat","Panel",
                                                "HER2_IHC", "MSI_PCR", "MMR_IHC")]
      output$figure_survival_CGP_7 = render_gt({
        if(length(colnames(Data_forest_tmp_7)) > 1){
          Data_forest_tmp_7 = data.frame( lapply(Data_forest_tmp_7, as.factor) )
          Data_forest_tmp_7__univariant = data.frame( lapply(Data_forest_tmp_7__univariant, as.factor) )
          if("Histology" %in% colnames(Data_forest_tmp_7)){
            Data_forest_tmp_7$Histology <- relevel(Data_forest_tmp_7$Histology, ref=names(sort(table(Data_forest_tmp_7$Histology),decreasing = T))[[1]]) 
          }
          if("Histology" %in% colnames(Data_forest_tmp_7__univariant)){
            Data_forest_tmp_7__univariant$Histology <- relevel(Data_forest_tmp_7__univariant$Histology, ref=names(sort(table(Data_forest_tmp_7__univariant$Histology),decreasing = T))[[1]]) 
          }
          if("Sex" %in% colnames(Data_forest_tmp_7)){
            Data_forest_tmp_7 = Data_forest_tmp_7 %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          if("Sex" %in% colnames(Data_forest_tmp_7__univariant)){
            Data_forest_tmp_7__univariant = Data_forest_tmp_7__univariant %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          colnames_tmp = colnames(Data_forest_tmp_7)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines before CGP"
          colnames(Data_forest_tmp_7) = colnames_tmp
          colnames_tmp = colnames(Data_forest_tmp_7__univariant)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines before CGP"
          colnames(Data_forest_tmp_7__univariant) = colnames_tmp
          univ_tab <- Data_forest_tmp_7__univariant %>% 
            tbl_uvregression(                         ## 単変量解析の表を生成
              method = glm,                           ## 実行したい回帰（一般化線形モデル）を定義
              y = EP_treat,
              method.args = list(family = binomial),  ## 実行したい glm のタイプを定義（ここではロジスティック）
              exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
            ) |>
            add_global_p() |> # add global p-value
            add_n(location = "level") |>
            add_nevent(location = "level") |> # add number of events of the outcome
            add_q() |> # adjusts global p-values for multiple testing
            bold_p() |> # bold p-values under a given threshold (default 0.05)
            modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            bold_labels() 
          m1 <- glm(EP_treat ~., data = Data_forest_tmp_7, family = binomial(link = "logit"))
          final_mv_reg <- m1 %>%
            stats::step(direction = "backward", trace = FALSE)
          if(!is.null(final_mv_reg$xlevels)){
            mv_tab = final_mv_reg |>
              tbl_regression(                         ## 多変量解析の表を生成
                exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
              ) |>
              add_global_p() |> # add global p-value
              add_q() |> # adjusts global p-values for multiple testing
              bold_p() |> # bold p-values under a given threshold (default 0.05)
              modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              bold_labels()
            tbl_merge(
              tbls = list(univ_tab, mv_tab),
              tab_spanner = c("**Univariate**", "**Multivariable**")) |>
              modify_caption("Factors that led patients to receive the recommended treatment (Only factors with >2 events observed)") |> as_gt()
          } else {
            univ_tab |>
              modify_caption("Factors that led patients to receive the recommended treatment, no significant factor in multivariable analysis (Only factors with >2 events observed)") |> as_gt()
          }
        }
      })
   
      Data_forest_tmp_ = Data_forest  %>%
        dplyr::filter(EP_option == 1) %>%
        dplyr::select(-time_enroll_final, -censor, -EP_option, -ID)
      Disease_tmp = unique(sort(Data_forest_tmp_$Histology))
      for(i in 1:length(Disease_tmp)){
        Data_forest_tmp_2 = Data_forest_tmp_ %>% dplyr::filter(Histology == Disease_tmp[i])
        if(sum(Data_forest_tmp_2$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_ %>%
            dplyr::mutate(Histology = case_when(
              Histology == Disease_tmp[i] ~ Histology_dummy,
              TRUE ~ Histology
            )
          )
        }
      }
      for(i in length(gene_names):1){
       if(sum(Data_forest_tmp_[,13+col_added+i] == "mut(+)" & Data_forest_tmp_$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_[,-(13+col_added+i)]
        } else if(sum(Data_forest_tmp_[,13+col_added+i] != "mut(+)" & Data_forest_tmp_$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_[,-(13+col_added+i)]
        }
      }
      if(sum(Data_forest_tmp_$PS == "0" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-PS)
      } else if(sum(Data_forest_tmp_$PS != "0" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-PS)
      } else if(sum(Data_forest_tmp_$PS == "2_4" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_$PS[Data_forest_tmp_$PS == "1"] = "1_4"
        Data_forest_tmp_$PS[Data_forest_tmp_$PS == "2_4"] = "1_4"
      }
      if(sum(Data_forest_tmp_$Panel == "Solid" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Panel)
      } else if(sum(Data_forest_tmp_$Panel != "Solid" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Panel)
      }
      if(sum(Data_forest_tmp_$Age == "Younger" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Age)
      } else if(sum(Data_forest_tmp_$Age == "Older" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Age)
      }
      if(sum(Data_forest_tmp_$Sex == "男" & Data_forest_tmp_$EP_treat == 1,na.rm = T) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Sex)
      } else if(sum(Data_forest_tmp_$Sex != "男" & Data_forest_tmp_$EP_treat == 1,na.rm = T) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Sex)
      }
      if(sum(Data_forest_tmp_$Lines == "1" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Lines)
      } else if(sum(Data_forest_tmp_$Lines != "1" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Lines)
      } else if(sum(Data_forest_tmp_$Lines == "0" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_$Lines[Data_forest_tmp_$Lines == "0"] = "0~1"
        Data_forest_tmp_$Lines[Data_forest_tmp_$Lines == "1"] = "0~1"
      } else if(sum(Data_forest_tmp_$Lines == "2~" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_$Lines[Data_forest_tmp_$Lines == "2~"] = "1~"
        Data_forest_tmp_$Lines[Data_forest_tmp_$Lines == "1"] = "1~"
      } 
      if(sum(Data_forest_tmp_$Lymph_met == "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Lymph_met)
      } else if(sum(Data_forest_tmp_$Lymph_met != "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Lymph_met)
      }
      if(sum(Data_forest_tmp_$Lung_met == "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Lung_met)
      } else if(sum(Data_forest_tmp_$Lung_met != "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Lung_met)
      }
      if(sum(Data_forest_tmp_$Brain_met == "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Brain_met)
      } else if(sum(Data_forest_tmp_$Brain_met != "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Brain_met)
      }
      if(sum(Data_forest_tmp_$Bone_met == "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Bone_met)
      } else if(sum(Data_forest_tmp_$Bone_met != "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Bone_met)
      }
      if(sum(Data_forest_tmp_$Liver_met == "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Liver_met)
      } else if(sum(Data_forest_tmp_$Liver_met != "Yes" & Data_forest_tmp_$EP_treat == 1) < 3){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Liver_met)
      }
      if(input$HER2 != "No"){
        if(sum(Data_forest_tmp_$HER2_IHC == "Positive" & Data_forest_tmp_$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_ %>%
            dplyr::select(-HER2_IHC)
        } else if(sum(Data_forest_tmp_$HER2_IHC != "Positive" & Data_forest_tmp_$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_ %>%
            dplyr::select(-HER2_IHC)
        }
      }
      if(input$MSI != "No"){
        if(sum(Data_forest_tmp_$MSI_PCR == "Positive" & Data_forest_tmp_$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_ %>%
            dplyr::select(-MSI_PCR)
        } else if(sum(Data_forest_tmp_$MSI_PCR != "Positive" & Data_forest_tmp_$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_ %>%
            dplyr::select(-MSI_PCR)
        }
      }
      if(input$MMR != "No"){
        if(sum(Data_forest_tmp_$MMR_IHC == "dMMR" & Data_forest_tmp_$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_ %>%
            dplyr::select(-MMR_IHC)
        } else if(sum(Data_forest_tmp_$MMR_IHC != "dMMR" & Data_forest_tmp_$EP_treat == 1) < 3){
          Data_forest_tmp_ = Data_forest_tmp_ %>%
            dplyr::select(-MMR_IHC)
        }
      }
      if(length(unique(Data_forest_tmp_$Histology))<2){
        Data_forest_tmp_ = Data_forest_tmp_ %>%
          dplyr::select(-Histology)
      }
      Data_forest_tmp_ = Data_forest_tmp_ %>%
        dplyr::select(-Histology_dummy)
      if(length(colnames(Data_forest_tmp_)) > 1){
        Factor_names_tmp_ = colnames(Data_forest_tmp_)
        Factor_names_tmp_ = Factor_names_tmp_[Factor_names_tmp_ != "EP_treat"]
        for(i in length(Factor_names_tmp_):1){
          if(all(Data_forest_tmp_[,colnames(Data_forest_tmp_) == Factor_names_tmp_[i]] ==
                 Data_forest_tmp_[1,colnames(Data_forest_tmp_) == Factor_names_tmp_[i]])){
            Data_forest_tmp_ = Data_forest_tmp_ %>%
              dplyr::select(-Factor_names_tmp_[i])
          }
        }
      }
      
      Data_forest_tmp_univariant = Data_forest_tmp_
  
      if(length(colnames(Data_forest_tmp_)) > 1){
        Factor_names_tmp_ = colnames(Data_forest_tmp_)
        Factor_names_tmp_ = Factor_names_tmp_[Factor_names_tmp_ != "EP_treat"]
        for(i in 1:(length(Factor_names_tmp_) - 1)){
          for(j in (i+1):length(Factor_names_tmp_)){
            if(Factor_names_tmp_[i] %in% colnames(Data_forest_tmp_) &
               Factor_names_tmp_[j] %in% colnames(Data_forest_tmp_)){
              if(mean(Data_forest_tmp_[,colnames(Data_forest_tmp_) == Factor_names_tmp_[i]] ==
                      Data_forest_tmp_[,colnames(Data_forest_tmp_) == Factor_names_tmp_[j]]) > 0.95){
                Data_forest_tmp_ = Data_forest_tmp_ %>%
                  dplyr::select(-Factor_names_tmp_[j])
              }
            }
          }
        }
      }
      incProgress(1 / 13)
      
      Data_forest_tmp_6 = Data_forest_tmp_
      Data_forest_tmp_6_univariant = Data_forest_tmp_univariant
      output$figure_survival_CGP_6 = render_gt({
        if(length(colnames(Data_forest_tmp_6)) > 1){
          Data_forest_tmp_6 = data.frame( lapply(Data_forest_tmp_6, as.factor) )
          Data_forest_tmp_6_univariant = data.frame( lapply(Data_forest_tmp_6_univariant, as.factor) )
          if("Histology" %in% colnames(Data_forest_tmp_6)){
            Data_forest_tmp_6$Histology <- relevel(Data_forest_tmp_6$Histology, ref=names(sort(table(Data_forest_tmp_6$Histology),decreasing = T))[[1]]) 
          }
          if("Histology" %in% colnames(Data_forest_tmp_6_univariant)){
            Data_forest_tmp_6_univariant$Histology <- relevel(Data_forest_tmp_6_univariant$Histology, ref=names(sort(table(Data_forest_tmp_6_univariant$Histology),decreasing = T))[[1]]) 
          }
          if("Sex" %in% colnames(Data_forest_tmp_6)){
            Data_forest_tmp_6 = Data_forest_tmp_6 %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          if("Sex" %in% colnames(Data_forest_tmp_6_univariant)){
            Data_forest_tmp_6_univariant = Data_forest_tmp_6_univariant %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          colnames_tmp = colnames(Data_forest_tmp_6)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines before CGP"
          colnames(Data_forest_tmp_6) = colnames_tmp
          colnames_tmp = colnames(Data_forest_tmp_6_univariant)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines before CGP"
          colnames(Data_forest_tmp_6_univariant) = colnames_tmp
          
          univ_tab <- Data_forest_tmp_6_univariant %>% 
            tbl_uvregression(                         ## 単変量解析の表を生成
              method = glm,                           ## 実行したい回帰（一般化線形モデル）を定義
              y = EP_treat,
              method.args = list(family = binomial),  ## 実行したい glm のタイプを定義（ここではロジスティック）
              exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
            ) |>
            add_global_p() |> # add global p-value
            add_n(location = "level") |>
            add_nevent(location = "level") |> # add number of events of the outcome
            add_q() |> # adjusts global p-values for multiple testing
            bold_p() |> # bold p-values under a given threshold (default 0.05)
            modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            bold_labels() 
          m1 <- glm(EP_treat ~., data = Data_forest_tmp_6, family = binomial(link = "logit"))
          final_mv_reg <- m1 %>%
            stats::step(direction = "backward", trace = FALSE)
          if(!is.null(final_mv_reg$xlevels)){
            mv_tab = final_mv_reg |>
              tbl_regression(                         ## 多変量解析の表を生成
                exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
              ) |>
              add_global_p() |> # add global p-value
              add_q() |> # adjusts global p-values for multiple testing
              bold_p() |> # bold p-values under a given threshold (default 0.05)
              modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              bold_labels()
            tbl_merge(
              tbls = list(univ_tab, mv_tab),
              tab_spanner = c("**Univariate**", "**Multivariable**")) |>
              modify_caption("Factors that led patients with recommended treatment to receive the recommended treatment (Only factors with >2 events observed)") |> as_gt()
          } else {
            univ_tab |>
              modify_caption("Factors that led patients with recommended treatment to receive the recommended treatment, no significant factor in multivariable analysis (Only factors with >2 events observed)") |> as_gt()
          }
        }
      })
      

      output$figure_nomogram_treat_post_CGP = renderPlot({
        if(length(colnames(Data_forest_tmp_6)) > 1){
          Data_forest_tmp_6 = data.frame( lapply(Data_forest_tmp_6, as.factor) )
          if("Histology" %in% colnames(Data_forest_tmp_6)){
            Data_forest_tmp_6$Histology <- relevel(Data_forest_tmp_6$Histology, ref=names(sort(table(Data_forest_tmp_6$Histology),decreasing = T))[[1]]) 
          }
          m1 <- glm(EP_treat ~., data = Data_forest_tmp_6, family = binomial(link = "logit"))
          final_mv_reg <- m1 %>%
            stats::step(direction = "backward", trace = FALSE)
          if(!is.null(final_mv_reg$xlevels)){
            Data_forest_tmp_treat = Data_forest_tmp_6 %>% dplyr::select(c("EP_treat", names(final_mv_reg$xlevels)))
            dd <- datadist(Data_forest_tmp_treat) 
            options(datadist=dd) 
            m2 <- lrm(formula(paste0("EP_treat ~ ",paste(colnames(Data_forest_tmp_treat)[colnames(Data_forest_tmp_treat)!="EP_treat"], collapse="+"))),
                      data = Data_forest_tmp_treat,x=TRUE,y=TRUE,penalty = 0.1)
            log_nomogram <- nomogram(m2, fun = plogis, lp=F, funlabel="Matched therapy")
            options(datadist=NULL) 
            m3 <- glm(formula(paste0("EP_treat ~ ",paste(colnames(Data_forest_tmp_treat)[colnames(Data_forest_tmp_treat)!="EP_treat"], collapse="+"))),
                      data = Data_forest_tmp_treat, family = binomial(link = 'logit'))
            val = rms::validate(m2, B=500)
            par(mfcol = c(2, 1))
            cal = rms::calibrate(m2, B=500)
            plot(cal, lwd=2, lty=1, 
                 cex.lab=1.2, cex.axis=1, cex.main=1.2, cex.sub=0.6, 
                 xlim=c(0, 1), ylim= c(0, 1), 
                 xlab="Nomogram-Predicted Probability of recommended treatment receive", 
                 ylab="Actual recommended treatment receive (proportion)", 

                 legend=FALSE)
            
            lines(cal[, c(1:3)], type ="o", lwd=1, pch=16, col=c("#00468BFF"))
            
            abline(0, 1, lty=3, lwd=2,  col=c("#224444")) 
            text(x=.6, y=.1, paste0("Intercept = ",round(val[3,5], digits=3),"\n",
                                    "Slope = ", round(val[4,5], digits=3)))
            text(x=.4, y=.9, paste0("Matched therapy receiving ratio, only patients with CTx recommendation, post CGP information","\n",
                                    "Nagelkerke R2 = ", round(val[2,5], digits=3),'\n',
                                    "500-time-bootstrapped-concordance index = ", round(((val[1,5] + 1) / 2), digits=3)))
            legend(x=.6, y=.3, legend=c("Apparent", "Bias-corrected", "Ideal"), 
                   lty=c(3, 1, 2), bty="n")
            plot(log_nomogram)
          } else {
            gg_empty()
          }
        }
      })
      Data_forest_tmp_8 = Data_forest_tmp_7
      Data_forest_tmp_8 = Data_forest_tmp_8 %>%
        dplyr::mutate(Sex=case_when(
          Sex == "女" ~ "Female",
          TRUE ~ "Male"
        ))
      Data_ML = Data_ML %>%
        dplyr::mutate(Sex=case_when(
          Sex == "女" ~ "Female",
          TRUE ~ "Male"
        ))
      Organ_data = data.frame(sort(unique(Data_ML$Histology)))
      colnames(Organ_data) = c("Organ_type")
      save(file = "source/Organ_data.rda", Organ_data)
      if(length(colnames(Data_forest_tmp_8)) > 1){
        Data_forest_tmp_8 = data.frame( lapply(Data_forest_tmp_8, as.factor) )
        if("Histology" %in% colnames(Data_forest_tmp_8)){
          Data_forest_tmp_8$Histology <- relevel(Data_forest_tmp_8$Histology, ref=names(sort(table(Data_forest_tmp_8$Histology),decreasing = T))[[1]]) 
        }
        m1 <- glm(EP_treat ~., data = Data_forest_tmp_8, family = binomial(link = "logit"))
        final_mv_reg <- m1 %>%
          stats::step(direction = "backward", trace = FALSE)
        if(!is.null(final_mv_reg$xlevels)){
          Data_forest_tmp_treat = Data_forest_tmp_8 %>% dplyr::select(c("EP_treat", names(final_mv_reg$xlevels)))
          if(length(colnames(Data_forest_tmp_treat)) > 1){
            dd <- datadist(Data_forest_tmp_treat) 
            options(datadist=dd)
            formula_treat = formula(paste0("EP_treat ~ ",paste(colnames(Data_forest_tmp_treat)[colnames(Data_forest_tmp_treat)!="EP_treat"], collapse="+")))
            m2 <- lrm(formula_treat,
                      data = Data_forest_tmp_treat,x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)
            save(m2, file = "source/m2.rda")
            # error in rms package
            val <- try(rms::validate(m2, B=500), silent = FALSE)
            if (class(val) == "try-error") {
              val = rms::validate(m2, B=500)
            }
            # do not delete
            cal = rms::calibrate(m2, B=500)
            options(datadist=NULL)
            log_nomogram <- nomogram(m2, fun = plogis, lp=F, funlabel="Matched therapy")
          }
        }
      }
      output$figure_nomogram_treat_pre_CGP = renderPlot({
        if(length(colnames(Data_forest_tmp_8)) > 1){
          if(!is.null(final_mv_reg$xlevels)){
            if(length(colnames(Data_forest_tmp_treat)) > 1){
              par(mfcol = c(2, 1))
              plot(cal, lwd=2, lty=1, 
                   cex.lab=1.2, cex.axis=1, cex.main=1.2, cex.sub=0.6, 
                   xlim=c(0, 1), ylim= c(0, 1), 
                   xlab="Nomogram-Predicted Probability of recommended treatment receive", 
                   ylab="Actual recommended treatment receive (proportion)", 
                   legend=FALSE)
              
              lines(cal[, c(1:3)], type ="o", lwd=1, pch=16, col=c("#00468BFF"))
              
              abline(0, 1, lty=3, lwd=2,  col=c("#224444")) 
              text(x=.6, y=.1, paste0("Intercept = ",round(val[3,5], digits=3),"\n",
                                      "Slope = ", round(val[4,5], digits=3)))
              text(x=.4, y=.9, paste0("Matched therapy receiving ratio, pre CGP information (other than mutation)","\n",
                                      "Nagelkerke R2 = ", round(val[2,5], digits=3),'\n',
                                      "500-time-bootstrapped-concordance index = ", round(((val[1,5] + 1) / 2), digits=3)))
              legend(x=.6, y=.3, legend=c("Apparent", "Bias-corrected", "Ideal"), 
                     lty=c(3, 1, 2), bty="n")
              plot(log_nomogram)
            } else {
              gg_empty()
            }
          } else {
            gg_empty()
          }
        } else {
          gg_empty()
        }
      })
      
      if(length(colnames(Data_forest_tmp_8)) > 1){
        if(!is.null(final_mv_reg$xlevels)){
          if(length(colnames(Data_forest_tmp_treat)) > 1){
            Data_forest_tmp_8$patientid = 1:length(Data_forest_tmp_8$EP_treat)
            Data_forest_tmp_treat$patientid = 1:length(Data_forest_tmp_treat$EP_treat)
            dca_thresholds = seq(0, 0.20, 0.01)
            set.seed(1212)            
            # create a 10-fold cross validation set, 1 repeat which is the base case, change to suit your use case
            cross_validation_samples <- rsample::vfold_cv(Data_forest_tmp_treat, strata = "EP_treat", v = 10, repeats = 1)
  
            df_crossval_predictions <- 
              cross_validation_samples %>% 
              dplyr::mutate(
                glm_analysis = c(list(lrm(formula = formula_treat, data = rsample::analysis(splits[[1]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[2]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[3]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[4]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[5]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[6]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[7]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[8]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[9]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[10]]),x=TRUE,y=TRUE,penalty = 0.1, tol=1e-14)))
              )
            df_prediction_id = c(rsample::assessment(df_crossval_predictions$splits[[1]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[2]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[3]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[4]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[5]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[6]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[7]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[8]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[9]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[10]])$patientid
            )
            df_prediction_score = c(predict(df_crossval_predictions$glm_analysis[[1]], rsample::assessment(df_crossval_predictions$splits[[1]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[2]], rsample::assessment(df_crossval_predictions$splits[[2]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[3]], rsample::assessment(df_crossval_predictions$splits[[3]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[4]], rsample::assessment(df_crossval_predictions$splits[[4]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[5]], rsample::assessment(df_crossval_predictions$splits[[5]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[6]], rsample::assessment(df_crossval_predictions$splits[[6]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[7]], rsample::assessment(df_crossval_predictions$splits[[7]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[8]], rsample::assessment(df_crossval_predictions$splits[[8]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[9]], rsample::assessment(df_crossval_predictions$splits[[9]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[10]], rsample::assessment(df_crossval_predictions$splits[[10]]),type = "fitted")
            )
            df_prediction = data.frame(df_prediction_id, df_prediction_score)
            colnames(df_prediction) = c("patientid", ".fitted")
            
            df_cv_pred <-
              Data_forest_tmp_treat %>%
              dplyr::left_join(
                df_prediction,
                by = 'patientid'
              )
            if("PS" %in% colnames(Data_forest_tmp_treat)){
              PS_data = data.frame(sort(unique(Data_forest_tmp_treat$PS)))
              colnames(PS_data) = c("PS_type")
              save(file = "source/PS_data.rda", PS_data)
            }
            if("Lines" %in% colnames(Data_forest_tmp_treat)){
              Lines_data = data.frame(sort(unique(Data_forest_tmp_treat$Lines)))
              colnames(Lines_data) = c("Lines_type")
              save(file = "source/Lines_data.rda", Lines_data)
            }
            
            set.seed(1212)
            Data_ML$EP_treat = factor(Data_ML$EP_treat)
            cls_met <- metric_set(brier_class)
            Data_cv <- vfold_cv(v=10, Data_ML, strata = EP_treat)
            Data_parameter_train = rsample::analysis(Data_cv$splits[[1]])
            Data_parameter_test = rsample::assessment(Data_cv$splits[[1]])
            Data_parameter_cv = Data_parameter_train |> 
              rsample::vfold_cv(v = 10, strata = EP_treat)
            Data_recipe <- Data_ML |>
              recipe(EP_treat ~ .) |>
              step_nzv(all_predictors())# |>
              #step_dummy(all_nominal_predictors())
            cv_fit_pred <- function(recipe, spec, df_train, df_test, df_cv = NULL, grid = 10) {
              if(is.null(df_cv)) {
                params_grid = NULL
                wf <- 
                  workflow() |> 
                  workflows::add_recipe(recipe = recipe) |> 
                  workflows::add_model(spec = spec)
              } else {
                cv_wf <- 
                  workflow() |> 
                  workflows::add_recipe(recipe = recipe) |> 
                  workflows::add_model(spec = spec)
                params_grid <- 
                  cv_wf |> 
                  tune::tune_grid(
                    resamples = df_cv,
                    grid = grid,
                    control = tune::control_grid(save_pred = TRUE)
                  )
                wf <- 
                  cv_wf |> 
                  tune::finalize_workflow(
                    parameters = params_grid |> tune::select_best()
                  )
              }
              wf_fit <- 
                wf |> 
                parsnip::fit(data = df_train)
              pred <- 
                wf_fit |> 
                tune::augment(new_data = df_test)
              return(
                list(
                  params_grid = params_grid, 
                  wf_fit = wf_fit, 
                  pred = pred
                )
              )
            }
            rf_spec <-
              parsnip::rand_forest() |> 
              parsnip::set_args(mtry = tune(), min_n = tune(), trees = 500) |> 
              parsnip::set_engine(
                'ranger',
                num.threads = max(1, parallel::detectCores() - 1, na.rm = TRUE)
              ) |> 
              parsnip::set_mode('classification')            
            lgb_spec <-
              parsnip::boost_tree(mode = "classification") %>%
              parsnip::set_args(
                tree_depth = tune(), min_n = tune(), mtry = tune(), trees = 500, learn_rate = 0.01, lambda_l1 = 0.9) |> 
              set_engine("lightgbm")
            rf_result <- 
              Data_recipe |> 
              cv_fit_pred(rf_spec, Data_parameter_train, Data_parameter_test, Data_parameter_cv)
            lgb_result <- 
              Data_recipe |> 
              cv_fit_pred(lgb_spec, Data_parameter_train, Data_parameter_test, Data_parameter_cv)
            rf_parameter = (rf_result$params_grid %>% show_best(metric = "brier_class"))[1,]
            lgb_parameter = (lgb_result$params_grid %>% show_best(metric = "brier_class"))[1,]
            rf_model <-
              parsnip::rand_forest() |>
              parsnip::set_args(trees = 10000, min_n = rf_parameter$min_n, mtry = rf_parameter$mtry) |>
              parsnip::set_engine(
                'ranger',
                num.threads = max(1, parallel::detectCores() - 1, na.rm = TRUE)
              ) |>
              parsnip::set_mode('classification')
            lgb_model <-
              parsnip::boost_tree(mode = "classification") %>%
              set_engine("lightgbm",
                         lambda_l1 = .9,
                         min_n = lgb_parameter$min_n,
                         tree_depth = lgb_parameter$tree_depth,
                         learn_rate = 0.01,
                         trees = 10000,
                         mtry = lgb_parameter$mtry)
            rf_wflow <- 
              workflow() %>% 
              add_model(rf_model) %>% 
              add_recipe(Data_recipe)
            lgb_wflow <- 
              workflow() %>% 
              add_model(lgb_model) %>% 
              add_recipe(Data_recipe)
            set.seed(1212)
            lgb_m2 = lgb_wflow %>% fit(Data_ML) 
            rf_m2 = rf_wflow %>% fit(Data_ML) 
            save(lgb_m2, file = "source/lgb_m2.rda")
            save(rf_m2, file = "source/rf_m2.rda")
            keep_pred <- control_resamples(save_pred = TRUE, save_workflow = TRUE)

          set.seed(1212)
          rf_res <- rf_wflow %>% fit_resamples(resamples = Data_cv, metrics = cls_met, control = keep_pred)
          rf_res_all = rf_res %>%
            pull(.predictions) %>%
            bind_rows() %>%
            dplyr::arrange(.row)
          # df_cv_pred$rf  = rf_res_all$.pred_1
          ROC_rf <- roc(EP_treat ~ .pred_1, data = rf_res_all, ci = TRUE)
          gROC_rf = ggroc(ROC_rf, 
                        size = 1, #サイズ
                        legacy.axes = TRUE) + 
            geom_abline(color = "dark grey", size = 0.5) +
            theme_classic() +
            labs(
              title = 
                paste0("Random forest, AUC: ", round(ROC_rf$auc[1],3), " (95%CI:",round(ROC_rf$ci[1],3), "-", round(ROC_rf$ci[3],3), ")",
                       ", mtry/min_n=",rf_parameter$mtry,"/",rf_parameter$min_n)
            )

          set.seed(1212)
          lgb_res <- lgb_wflow %>% fit_resamples(resamples = Data_cv, metrics = cls_met, control = keep_pred)
          lgb_res_all = lgb_res %>%
            pull(.predictions) %>%
            bind_rows() %>%
            dplyr::arrange(.row)
          # df_cv_pred$lgb  = lgb_res_all$.pred_1
          ROC_lgb <- roc(EP_treat ~ .pred_1, data = lgb_res_all, ci = TRUE)
          gROC_lgb = ggroc(ROC_lgb, 
                          size = 1, #サイズ
                          legacy.axes = TRUE) + 
            geom_abline(color = "dark grey", size = 0.5) +
            theme_classic() +
            labs(
              title = 
                paste0("LightGBM, AUC: ", round(ROC_lgb$auc[1],3), " (95%CI:",round(ROC_lgb$ci[1],3), "-", round(ROC_lgb$ci[3],3), ")",
                       ", mtry/min_n/tree_depth=",lgb_parameter$mtry,"/",lgb_parameter$min_n,"/",lgb_parameter$tree_depth)
            )

          g1 = collect_predictions(lgb_res) %>%
               ggplot(aes(.pred_1)) +
               geom_histogram(col = "white", bins = 40) +
               facet_wrap(~ EP_treat, ncol = 1) +
               geom_rug(col = "blue", alpha = 1 / 2) + 
               labs(x = "LightGBM: Probability Estimate of Treatment reach")
          g2 = lgb_res %>% cal_plot_windowed(truth = EP_treat, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
            ggtitle("LightGBM: Calibration curve")
          set.seed(1212)
          iso_val <- cal_validate_logistic(lgb_res, metrics = cls_met,
                                                save_pred = TRUE, times = 25)
          # collect_metrics(iso_val)
          g3= collect_predictions(iso_val) %>%
            filter(.type == "calibrated") %>%
            cal_plot_windowed(truth = EP_treat, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
            ggtitle("LightGBM: Logistic calibration via GAM")

          df_cv_pred$lgb  = (iso_val %>%
                               pull(.predictions_cal) %>%
                               bind_rows() %>%
                               dplyr::arrange(.row))$.pred_1
          # beta_val <- lgb_res %>% cal_validate_beta(metrics = cls_met, save_pred = TRUE)
          # # collect_metrics(beta_val)
          # g3= collect_predictions(beta_val) %>%
          #   filter(.type == "calibrated") %>%
          #   cal_plot_windowed(truth = EP_treat, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
          #   ggtitle("LightGBM: Beta calibration")
          # df_cv_pred$lgb  = (beta_val %>%
          #                      pull(.predictions_cal) %>%
          #                      bind_rows() %>%
          #                      dplyr::arrange(.row))$.pred_1
          g4 = collect_predictions(rf_res) %>%
            ggplot(aes(.pred_1)) +
            geom_histogram(col = "white", bins = 40) +
            facet_wrap(~ EP_treat, ncol = 1) +
            geom_rug(col = "blue", alpha = 1 / 2) + 
            labs(x = "Random forest: Probability Estimate of Treatment reach")
          g5 = rf_res %>% cal_plot_windowed(truth = EP_treat, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
            ggtitle("Random forest: Calibration curve")

          iso_val <- cal_validate_logistic(rf_res, metrics = cls_met,
                                                save_pred = TRUE, times = 25)
          collect_metrics(iso_val)
          g6= collect_predictions(iso_val) %>%
            filter(.type == "calibrated") %>%
            cal_plot_windowed(truth = EP_treat, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
            ggtitle("Random forest: Logistic calibration via GAM")
          df_cv_pred$rf  = (iso_val %>%
                               pull(.predictions_cal) %>%
                               bind_rows() %>%
                               dplyr::arrange(.row))$.pred_1
          # beta_val <- rf_res %>% cal_validate_beta(metrics = cls_met, save_pred = TRUE)
          # collect_metrics(beta_val)
          # g6= collect_predictions(beta_val) %>%
          #   filter(.type == "calibrated") %>%
          #   cal_plot_windowed(truth = EP_treat, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
          #   ggtitle("Random forest: Beta calibration")
          # df_cv_pred$rf  = (beta_val %>%
          #                      pull(.predictions_cal) %>%
          #                      bind_rows() %>%
          #                      dplyr::arrange(.row))$.pred_1
          
          output$figure_DCA_pre_CGP_1 = renderPlot({
              dcurves::dca( # calculate net benefit scores on mean cross validation predictions
                data = df_cv_pred,
                formula = EP_treat ~ .fitted + rf + lgb,
                thresholds = dca_thresholds,
                label = list(
                  .fitted = "10-fold cross-validated logistic regression model",
                  rf = "10-fold cross-validated random forest model",
                  lgb = "10-fold cross-validated lightGBM model"
                ))$dca |> 
                # plot cross validated net benefit values
                ggplot(aes(x = threshold, y = net_benefit, color = label)) +
                stat_smooth(method = "loess", se = FALSE, formula = "y ~ x", span = 0.2, fullrange = TRUE) +
                scale_x_continuous(labels = scales::percent_format(accuracy = 1)) +
                scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
                labs(x = "Threshold probability", y = "Net Benefit", color = "") +
                coord_cartesian(xlim = c(0, 0.2), ylim = c(-0.01, NA)) + 
                theme_bw()
            })
  
          output$figure_DCA_pre_CGP_ROC = renderPlot({
            gNomogram = df_cv_pred %>%
              ggplot(aes(.fitted)) +
              theme_classic() +
              geom_histogram(col = "white", bins = 40) +
              facet_wrap(~ EP_treat, ncol = 1) +
              geom_rug(col = "blue", alpha = 1 / 2) + 
              labs(x = "Nomogram: Probability Estimate of treatment reach")
            ROC <- roc(EP_treat ~ .fitted, data = df_cv_pred, ci = TRUE)
            gROC2 = ggroc(ROC, 
                          size = 1, #サイズ
                          legacy.axes = TRUE) + 
              geom_abline(color = "dark grey", size = 0.5) +
              theme_classic() +
              labs(
                title = 
                  paste0("Nomogram, AUC: ", round(ROC$auc[1],3), " (95%CI:",round(ROC$ci[1],3), "-", round(ROC$ci[3],3), ")")
              )
            ROC3 <- roc(EP_treat ~ .fitted + lgb + rf, data = df_cv_pred, ci = TRUE)
            gROC3 = ggroc(ROC3, 
                          size = 1, #サイズ
                          legacy.axes = TRUE) + 
              geom_abline(color = "dark grey", size = 0.5) +
              theme_classic() +
              scale_color_hue(name = "Prediction methods",
                              labels = c(.fitted = "Nomogram",
                                         lgb = "Light GBM",
                                         rf  = "Random forest")) +
              labs(
                title = 
                  paste0("ROC curves for treatment reach")
              )
            grid.arrange(gNomogram,gROC2,gROC3, nrow = 3)
          })

          output$figure_DCA_pre_CGP_Machine_learning = renderPlot({
            grid.arrange(g1,g2,g3,gROC_lgb,g4,g5,g6,gROC_rf, nrow = 4, ncol=2)
          })          
          output$table_DCA_pre_CGP_2 = render_gt({
              (dcurves::dca( # calculate net benefit scores on mean cross validation predictions
                data = df_cv_pred,
                formula = EP_treat ~ .fitted + rf + lgb,
                thresholds = dca_thresholds,
                label = list(
                  .fitted = "10-fold cross-validated Nomogram model",
                  rf = "10-fold cross-validated random forest model",
                  lgb = "10-fold cross-validated lightGBM model"
                ))) %>%
                net_intervention_avoided() %>%
                as_tibble() %>%
                gt::gt() %>%
                gt::fmt_percent(columns = threshold, decimals = 0) %>%
                gt::fmt(columns = net_benefit, fns = function(x) style_sigfig(x, digits = 3)) %>%
                gt::cols_label(
                  label = "Strategy",
                  threshold = "Decision Threshold",
                  net_benefit = "Net Benefit"
                ) %>%
                gt::cols_align("left", columns = label)
            })
          
          output$table_prediction = DT::renderDataTable(df_cv_pred,
                                                        server = FALSE,
                                                        filter = 'top', 
                                                        extensions = c('Buttons'), 
                                                        options = list(pageLength = 100, 
                                                                       scrollX = TRUE,
                                                                       scrollY = "1000px",
                                                                       scrollCollapse = TRUE,
                                                                       dom="Blfrtip",
                                                                       buttons = c('csv', 'copy')))
          }
        }
      }
      incProgress(1 / 13)
    })
  })
  tmp <- reactiveValues()
  observeEvent(input$predict_nomogram_setting, {
    withProgress(message = sample(nietzsche)[1], {
      incProgress(1 / 13)
      load("source/m2.rda")
      load("source/lgb_m2.rda")
      load("source/rf_m2.rda")
      tmp$m2 = m2
      tmp$lgb_m2 = lgb_m2
      tmp$rf_m2 = rf_m2
      load("source/Organ_data.rda")
      output$input_age = renderUI({ 
        numericInput("predict_age", "Age",
                     value = 60,
                     min = 1,
                     max = 120,
                     step = 1)
      })
      output$input_sex = renderUI({ 
        radioButtons(
          "predict_Sex", "Sex",
          choices = c("Male", "Female"),
          selected = "Male")
      })
      output$input_Lymph_met = renderUI({ 
        radioButtons(
          "predict_Lymph_met", "Lymph node metastasis",
          choices = c("Yes", "No"),
          selected = "No")
      })
      output$input_Brain_met = renderUI({ 
        radioButtons(
          "predict_Brain_met", "Brain metastasis",
          choices = c("Yes", "No"),
          selected = "No")
      })
      output$input_Lung_met = renderUI({ 
        radioButtons(
          "predict_Lung_met", "Lung metastasis",
          choices = c("Yes", "No"),
          selected = "No")
      })
      output$input_Bone_met = renderUI({ 
        radioButtons(
          "predict_Bone_met", "Bone metastasis",
          choices = c("Yes", "No"),
          selected = "No")
      })
      output$input_Liver_met = renderUI({ 
        radioButtons(
          "predict_Liver_met", "Liver metastasis",
          choices = c("Yes", "No"),
          selected = "No")
      })
      output$input_PS = renderUI({ 
        radioButtons(
          "predict_PS", "Performance status",
          choices = c("0", "1", "2_4"),
          selected = "0")
      })
      output$input_Lines = renderUI({ 
        radioButtons(
          "predict_Lines", "CTx lines before CGP",
          choices = c("0", "1", "2~"),
          selected = "1")
      })
      output$input_organ = renderUI({
        pickerInput("predict_organ", "Organ",
                    choices = c("", Organ_data$Organ_type),
                    selected = "", multiple = FALSE)
      })
      output$input_Panel = renderUI({ 
        radioButtons(
          "predict_Panel", "Panel",
          choices = c("Solid", "Liquid"),
          selected = "Solid")
      })
    })
  })
  observeEvent(input$start_prediction, {
    withProgress(message = sample(nietzsche)[1], {
      incProgress(1 / 13)
      predict_age = ifelse(input$predict_age <= input$mid_age, "Younger", "Older")
      predict_PS = input$predict_PS
      predict_Lines = input$predict_Lines
      if(file.exists("source/PS_data.rda")){
        load("source/PS_data.rda")
        PS_choice = PS_data$PS_type
      } else {
        PS_choice = c("0", "1", "2_4")
      }
      if(file.exists("source/Lines_data.rda")){
        load("source/Lines_data.rda")
        Lines_choice = Lines_data$Lines_type
      } else {
        Lines_choice = c("0", "1", "2~")
      }
      if(length(PS_choice) == 2){
        predict_PS = ifelse(predict_PS == "0", "0", "1_4")
      }
      if(length(Lines_choice) == 2){
        if(Lines_choice == c("0~1", "2~")){
          predict_Lines = ifelse(predict_PS == "2~", "2~", "0~1")
        } else {
          predict_Lines = ifelse(predict_Lines == "0", "0", "1~")
        }
      }
      input_data = data.frame(
          Age = predict_age,
          Lymph_met = input$predict_Lymph_met,
          Brain_met = input$predict_Brain_met,
          Lung_met = input$predict_Lung_met,
          Bone_met = input$predict_Bone_met,
          Liver_met = input$predict_Liver_met,
          Sex = input$predict_Sex,
          Histology = input$predict_organ,
          PS = predict_PS,
          Lines = predict_Lines,
          Panel = input$predict_Panel
      )
      input_data_ML = data.frame(
        Age_raw = input$predict_age,
        Lymph_met = input$predict_Lymph_met,
        Brain_met = input$predict_Brain_met,
        Lung_met = input$predict_Lung_met,
        Bone_met = input$predict_Bone_met,
        Liver_met = input$predict_Liver_met,
        Sex = input$predict_Sex,
        Histology = input$predict_organ,
        PS = input$predict_PS,
        Lines = input$predict_Lines,
        Panel = input$predict_Panel
      )
      predicted_score = predict(tmp$m2, input_data, type = "fitted")
      predicted_score_lgb = predict(tmp$lgb_m2, input_data_ML, type = "prob")
      predicted_score_rf = predict(tmp$rf_m2, input_data_ML, type = "prob")
      output$prediction_nomogram = renderText({
        paste0("Predicted treatment reach rate\n",
               "Nomogram: ", round(predicted_score, digits=2)*100, "%\n",
               "LightGBM: ", round(predicted_score_lgb[2], digits=2)*100, "%\n",
               "Random forest: ", round(predicted_score_rf[2], digits=2)*100, "%"
        )
      })
      incProgress(1 / 13)
    })
  })
  
  observeEvent(input$survival_CTx_analysis, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
        Data_case_target = Data_case_target %>%
          dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                          Data_report()$Tumor_Sample_Barcode)
      }
      Data_case_target = Data_case_target %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                      症例.基本情報.年齢,
                      Lymph_met,
                      Brain_met,
                      Lung_met,
                      Bone_met,
                      Liver_met,
                      Other_met,
                      EP_option,
                      EP_treat,
                      YoungOld,
                      症例.EP前レジメン情報.化学療法レジメン名称,
                      症例.EP前レジメン情報.治療ライン.名称.,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.投与終了日,
                      症例.EP前レジメン情報.レジメン継続区分.名称.,
                      症例.EP前レジメン情報.実施目的.名称.,
                      症例.EP前レジメン情報.終了理由.名称.,
                      症例.EP前レジメン情報.最良総合効果.名称.,
                      症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                      症例.EP後レジメン情報.治療ライン,
                      症例.EP後レジメン情報.治療ライン.名称.,
                      症例.EP後レジメン情報.化学療法レジメン名称,
                      症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP後レジメン情報.投与開始日,
                      症例.EP後レジメン情報.投与終了日,
                      症例.EP後レジメン情報.レジメン継続区分.名称.,
                      症例.EP後レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.最良総合効果.名称.,
                      症例.基本情報.性別.名称.,
                      症例.基本情報.がん種.OncoTree.,
                      症例.基本情報.がん種.OncoTree..名称.,
                      症例.基本情報.がん種.OncoTree.LEVEL1.,
                      症例.検体情報.パネル.名称.,
                      症例.背景情報.ECOG.PS.名称.,
                      症例.背景情報.喫煙歴有無.名称.,
                      症例.背景情報.アルコール多飲有無.名称.,
                      症例.背景情報.重複がん有無.異なる臓器..名称.,
                      症例.背景情報.多発がん有無.同一臓器..名称.,
                      症例.がん種情報.登録時転移部位.名称.,
                      症例.検体情報.腫瘍細胞含有割合,
                      症例.検体情報.検体採取部位.名称.,
                      症例.転帰情報.転帰.名称.,
                      症例.背景情報.診断日,
                      症例.管理情報.登録日,
                      症例.転帰情報.最終生存確認日,
                      症例.転帰情報.死亡日
        )
      incProgress(1 / 13)

      Data_case_target$Cancers = Data_case_target$症例.基本情報.がん種.OncoTree.
      Data_survival = Data_case_target %>%
        dplyr::mutate(final_observe = case_when(
          症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
          症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
          症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
          TRUE ~ 症例.管理情報.登録日))
      Data_survival = Data_survival %>%
        dplyr::arrange(desc(final_observe)) %>%
        dplyr::mutate(censor = case_when(
          症例.転帰情報.死亡日 != "" ~ 1,
          TRUE ~ 0)) %>%
        dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
      
      Data_survival = Data_survival %>%
        dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
        dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
      
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, censor) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      
      Data_survival = Data_survival %>%
        dplyr::mutate(final_observe = as.Date(Data_survival$final_observe)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(Data_survival$症例.管理情報.登録日)) %>%
        dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                        as.Date(症例.EP前レジメン情報.投与開始日))
      
      Data_survival = Data_survival %>%
        dplyr::mutate(time_enroll_final =
                        as.integer(difftime(Data_survival$final_observe,
                                            Data_survival$症例.管理情報.登録日,
                                            units = "days")))
      Data_survival = Data_survival %>%
        dplyr::mutate(time_palliative_final =
                        as.integer(difftime(Data_survival$final_observe,
                                            Data_survival$症例.EP前レジメン情報.投与開始日,
                                            units = "days")))
      Data_survival = Data_survival %>%
        dplyr::mutate(time_palliative_enroll =
                        Data_survival$time_palliative_final -
                        Data_survival$time_enroll_final)
      
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, final_observe) %>%
        dplyr::arrange(desc(final_observe)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_enroll_final) %>%
        dplyr::arrange(desc(time_enroll_final)) %>%
        dplyr::filter(time_enroll_final > 0 & !is.na(time_enroll_final) & is.finite(time_enroll_final)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      incProgress(1 / 13)
      
      Data_survival_tmp = Data_survival %>%
        dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                        c("その他", "緩和")) %>%
        dplyr::arrange(症例.EP前レジメン情報.投与開始日) %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_palliative_enroll, time_palliative_final) %>%
        dplyr::filter(time_palliative_enroll > 0 & time_palliative_enroll < 10000 & !is.na(time_palliative_enroll) & is.finite(time_palliative_enroll)) %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
      Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
      
      Data_case_target = Data_case_target %>%
        dplyr::distinct(.keep_all = TRUE, C.CAT調査結果.基本項目.ハッシュID)
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
       if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }

      Data_report_TMB = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
        dplyr::select(Tumor_Sample_Barcode, TMB) %>%
        dplyr::distinct(Tumor_Sample_Barcode, .keep_all=T)
      colnames(Data_report_TMB) = c("C.CAT調査結果.基本項目.ハッシュID", "TMB")
      Data_case_target = left_join(Data_case_target, Data_report_TMB,
                                   by = "C.CAT調査結果.基本項目.ハッシュID")
      
      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      }
      Data_MAF_target = Data_MAF_target %>%
        dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, .keep_all = T)
      incProgress(1 / 13)
      Gene_list = unique(names(sort(table(Data_MAF_target$Hugo_Symbol),
                                    decreasing = T)))

      if(length(Data_case_target$censor[is.na(Data_case_target$censor)])> 0){
        Data_case_target$censor[is.na(Data_case_target$censor)] = 0
      }
      Data_survival = Data_case_target %>% dplyr::filter(
        !is.na(time_palliative_enroll) &
        !is.na(time_enroll_final) &
        is.finite(time_palliative_enroll) &
        is.finite(time_enroll_final) & 
        time_palliative_enroll > 0 &
        time_enroll_final > 0 &
        !is.na(censor) &
        is.finite(censor)
      )  
      Median_entry = median(Data_survival_tmp$time_palliative_enroll)
      Data_MAF_target = Data_MAF_target %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_survival$C.CAT調査結果.基本項目.ハッシュID)
      
      Data_survival = Data_survival %>%
        dplyr::mutate(delay_1 = case_when(
          Data_survival$time_palliative_enroll <= Median_entry ~ "SPT to entry early",
          TRUE ~ "SPT to entry later"))
      Cancername = sort(unique(Data_survival$Cancers))
      Total_pts = as.vector(table((Data_survival %>%
                                     dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = T))$Cancers))
      
      incProgress(1 / 13)
      stan_weibull_survival_model_data <-
        list(
          Median = as.integer(Median_entry),
          Nobs = sum(Data_survival$censor == 1),
          Ncen = sum(Data_survival$censor == 0),
          Ntot = length(Data_survival$censor),
          M_bg = 1,
          Nexp = length(Data_survival_tmp$time_palliative_enroll),
          ybef_exp = Data_survival_tmp$time_palliative_enroll,
          yobs = Data_survival$time_enroll_final[Data_survival$censor == 1],
          ycen = Data_survival$time_enroll_final[Data_survival$censor == 0],
          Xobs_bg = matrix(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 1], ncol = 1),
          Xcen_bg = matrix(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 0], ncol = 1)
        )
      
      stan_weibull_survival_model_fit <-
        rstan::stan(file = "source/Stan_code_loglog_weibull.stan",
                    data = stan_weibull_survival_model_data,
                    control=list(adapt_delta=0.99, max_treedepth = 10),
                    seed=1234, chains=4, iter=3000, warmup=1000, thin=1, refresh=500, verbose = FALSE)
      incProgress(1 / 13)
      
      stan_weibull_survival_model_draws <- tidybayes::tidy_draws(stan_weibull_survival_model_fit)
      stan_weibull_survival_model_draws_total_exp <-
        stan_weibull_survival_model_draws %>%
        dplyr::select(.chain, .iteration, .draw, starts_with("yhat_exp_total")) %>%
        tidyr::gather(key = key, value = yhat_total_exp, starts_with("yhat_exp_total")) %>%
        dplyr::select(-key) 
      stan_weibull_survival_model_draws_bef_exp <-
        stan_weibull_survival_model_draws %>%
        dplyr::select(.chain, .iteration, .draw, starts_with("y_exptmp")) %>%
        tidyr::gather(key = key, value = yhat_bef_exp, starts_with("y_exptmp")) %>%
        dplyr::select(-key) 
      stan_weibull_survival_model_draws_aft_exp <-
        stan_weibull_survival_model_draws %>%
        dplyr::select(.chain, .iteration, .draw, starts_with("yhat_exp_uncens")) %>%
        tidyr::gather(key = key, value = yhat_aft_exp, starts_with("yhat_exp_uncens")) %>%
        dplyr::select(-key) 
      stan_weibull_survival_model_draws_ear <-
        stan_weibull_survival_model_draws %>%
        dplyr::select(.chain, .iteration, .draw, starts_with("yhat_early")) %>%
        tidyr::gather(key = key, value = yhat_ear, starts_with("yhat_early")) %>%
        dplyr::select(-key) 
      stan_weibull_survival_model_draws_lat <-
        stan_weibull_survival_model_draws %>%
        dplyr::select(.chain, .iteration, .draw, starts_with("yhat_late")) %>%
        tidyr::gather(key = key, value = yhat_lat, starts_with("yhat_late")) %>%
        dplyr::select(-key) 
      
      median_os_list_weibull_total_exp = matrix(stan_weibull_survival_model_draws_total_exp$yhat_total_exp, ncol=8000)
      median_os_list_weibull_total_exp = colMedians(median_os_list_weibull_total_exp,na.rm = T)
  
      median_os_summary_weibull_total_exp = quantile(median_os_list_weibull_total_exp, probs = c(0.025, 0.5, 0.975))
      yhat_weibull_sort_total_exp = sort(stan_weibull_survival_model_draws_total_exp$yhat_total_exp)
      yhat_weibull_sort_average_total_exp = yhat_weibull_sort_total_exp[1:length(Data_survival$censor) * 8000]
  
      Data_survival$left_adj = yhat_weibull_sort_average_total_exp
      Data_survival$left_adj[Data_survival$left_adj > 10000] = 10000
  
      
      independence_check = with(Data_survival, cKendall(
        trun = time_palliative_enroll,
        obs = time_palliative_final,
        delta = censor,
        trans = "linear"))
      
      
      traditional_fit = survfit(Surv(event = censor,
                                     time = time_palliative_final) ~ 1, 
                                data = Data_survival)
      delayed_entry_fit = survfit(Surv(event = censor,
                                       time = time_palliative_enroll,
                                       time2 = time_palliative_final) ~ 1,
                                  data = Data_survival)
      simulation_fit_2 = survfit(Surv(event = rep(1,length(Data_survival$left_adj)),
                                      time = left_adj) ~ 1, 
                                 data = Data_survival)
      g = list()
      g[[1]] = ggsurvplot(
        fit = list(traditional_fit = traditional_fit,
                   delayed_entry_fit = delayed_entry_fit,
                   simulation_fit_2 = simulation_fit_2
        ),
        combine = TRUE,
        data = Data_survival,
        xlab = "Time from SPT to final observation (days)",
        ylab = "Survival Probability",
        censor = TRUE,
        conf.int = FALSE,
        font.title = 8,
        font.subtitle = 8,
        font.main = 8,
        font.submain = 8,
        font.caption = 8,
        font.legend = 8,
        pval = FALSE,
        surv.median.line = "hv",
        risk.table = TRUE,
        risk.table.y.text = FALSE,
        tables.theme = clean_theme(), 
        legend = c(0.8,0.90),
        xlim = c(0, max(Data_survival$time_palliative_final) * 1.05),
        break.x.by = ceiling(max(Data_survival$time_palliative_final) / 500) * 100,
        legend.labs = c("All patients, Unadjusted",
                        "All patients, Number at risk adjusted",
                        "All patients, Adj. right cens. & left trunc.")
      ) + 
        labs(title = paste(traditional_fit[[1]], " patients; Median OS ",
                           as.integer(summary(traditional_fit)$table[[7]])," (",
                           as.integer(summary(traditional_fit)$table[[8]]),"-",
                           as.integer(summary(traditional_fit)$table[[9]]),") (unadj.)/",
                           as.integer(summary(delayed_entry_fit)$table[[7]]), " (",
                           as.integer(summary(delayed_entry_fit)$table[[8]]),"-",
                           as.integer(summary(delayed_entry_fit)$table[[9]]),") (risk adj.)/\n",
                           as.integer(median_os_summary_weibull_total_exp[[2]]), " (",
                           as.integer(median_os_summary_weibull_total_exp[[1]]), "-",
                           as.integer(median_os_summary_weibull_total_exp[[3]]),
                           ") (adj. right & left) days",
                           sep=""),
             subtitle = paste(2, "-year rate ",
                              format(summary(traditional_fit, time = 2 * 365)$surv * 100,digits=3),
                              "% (unadj.)/",
                               format(summary(delayed_entry_fit, time = 2 * 365)$surv * 100,digits=3),
                               "% (risk adj.)/",
                              format(summary(simulation_fit_2, time = 2 * 365)$surv * 100,digits=3),
                              "% (adj. right & left), ",
                              "cKendall tau= ", format(independence_check$PE,digits=2),
                              ", SE= ", format(independence_check$SE,digits=2),
                              ", p= ", format(independence_check$p.value,digits=2), sep=""))
      g[[1]]$table <- g[[1]]$table + theme(plot.title = element_blank(),
                                 plot.subtitle = element_blank())
      
      incProgress(1 / 13)
      # Survival analysis for mutation
      mut_gene = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
      if(length(mut_gene)==0){
        mut_gene = "TP53"
      }
      ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode
      Data_survival = Data_survival %>% dplyr::mutate(
        mutation = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ paste(mut_gene, collapse = ";"),
          TRUE ~ "no-mut"
        )
      )
      traditional_fit = survfit(Surv(event = censor,
                                     time = time_palliative_final) ~ mutation, 
                                data = Data_survival)
      if(length(Data_survival[,1]) != traditional_fit[[1]][[1]]){
        name_1 = paste("mutation", sort(unique(Data_survival$mutation))[[1]])
        name_2 = paste("mutation", sort(unique(Data_survival$mutation))[[2]])
        name_1_short = sort(unique(Data_survival$mutation))[[1]]
        name_2_short = sort(unique(Data_survival$mutation))[[2]]
        
        Data_survival$gene_select = Data_survival$mutation == sort(unique(Data_survival$mutation))[[2]]
        Data_survival_tmp_pos = Data_survival %>%
          dplyr::filter(gene_select == TRUE)
        
        Data_survival_tmp = Data_survival_tmp_pos
        Median_entry_pos = median(Data_survival_tmp$time_palliative_enroll)
              Data_survival_tmp_neg = Data_survival %>%
          dplyr::filter(gene_select == FALSE)
        
        Data_survival_tmp3 = Data_survival_tmp_neg
        Median_entry_neg = median(Data_survival_tmp3$time_palliative_enroll)
        Data_survival_tmp = rbind(Data_survival_tmp, Data_survival_tmp3)  
        
        Data_survival = Data_survival %>%
          dplyr::mutate(delay_1 = case_when(
            Data_survival$time_palliative_enroll <= Median_entry_pos &
              gene_select == TRUE ~ "SPT to entry early",
            Data_survival$time_palliative_enroll > Median_entry_pos &
              gene_select == TRUE ~ "SPT to entry later",
            Data_survival$time_palliative_enroll <= Median_entry_neg &
              gene_select == FALSE ~ "SPT to entry early",
            Data_survival$time_palliative_enroll > Median_entry_neg &
              gene_select == FALSE ~ "SPT to entry later"))
        
        if(sum((Data_survival %>% dplyr::filter(gene_select == TRUE & delay_1 == "SPT to entry later"))$censor) >= 1 &
           sum((Data_survival %>% dplyr::filter(gene_select == FALSE & delay_1 == "SPT to entry later"))$censor) >= 1 &
           sum((Data_survival %>% dplyr::filter(gene_select == TRUE & delay_1 != "SPT to entry later"))$censor) >= 1 &
           sum((Data_survival %>% dplyr::filter(gene_select == FALSE & delay_1 != "SPT to entry later"))$censor) >= 1){
          
          stan_weibull_survival_model_data <-
            list(
              Median_pos = as.integer(Median_entry_pos),
              Median_neg = as.integer(Median_entry_neg),
              Nobs = sum(Data_survival$censor == 1),
              Ncen = sum(Data_survival$censor == 0),
              Ntot = length(Data_survival$censor),
              M_bg = 2,
              Nexp = length(Data_survival_tmp$time_palliative_enroll),
              ybef_exp = Data_survival_tmp$time_palliative_enroll,
              xfactor = as.numeric(Data_survival_tmp$gene_select),
              yobs = Data_survival$time_enroll_final[Data_survival$censor == 1],
              ycen = Data_survival$time_enroll_final[Data_survival$censor == 0],
              Xobs_bg = matrix(c(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 1],
                                 as.numeric(Data_survival$gene_select)[Data_survival$censor == 1]),ncol = 2),
              Xcen_bg = matrix(c(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 0],
                                 as.numeric(Data_survival$gene_select)[Data_survival$censor == 0]),ncol = 2)
            )
          
          stan_weibull_survival_model_fit <-
            rstan::stan(file = "source/Stan_code_loglog_weibull_factor.stan",
                        data = stan_weibull_survival_model_data,
                        control=list(adapt_delta=0.99, max_treedepth = 10),
                        seed=1234, chains=4, iter=3000, warmup=1000, thin=1, refresh=500, verbose = FALSE,
                        pars = c("alpha","mu", "shape_exp", "scale_exp", "factor",
                                 "yhat_total", "yhat_factor_total"))
          
         stan_weibull_survival_model_draws <- tidybayes::tidy_draws(stan_weibull_survival_model_fit)
          stan_weibull_survival_model_draws_total <-
            stan_weibull_survival_model_draws %>%
            dplyr::select(.chain, .iteration, .draw, starts_with("yhat_total")) %>%
            tidyr::gather(key = key, value = yhat_total, starts_with("yhat_total")) %>%
            dplyr::select(-key) 
          stan_weibull_survival_model_draws_total_exp <-
            stan_weibull_survival_model_draws %>%
            dplyr::select(.chain, .iteration, .draw, starts_with("yhat_factor_total")) %>%
            tidyr::gather(key = key, value = yhat_total_exp, starts_with("yhat_factor_total")) %>%
            dplyr::select(-key) 
          
          median_os_list_weibull_total_exp = matrix(stan_weibull_survival_model_draws_total_exp$yhat_total_exp, ncol=8000)
          median_os_list_weibull_total_exp = colMedians(median_os_list_weibull_total_exp,na.rm = T)
          
          median_os_list_weibull_total = matrix(stan_weibull_survival_model_draws_total$yhat_total, ncol=8000)
          median_os_list_weibull_total = colMedians(median_os_list_weibull_total,na.rm = T)
          
          median_os_list_weibull_bias = median_os_list_weibull_total - median_os_list_weibull_total_exp
  
          median_os_summary_weibull_total = quantile(median_os_list_weibull_total, probs = c(0.025, 0.5, 0.975))
          median_os_summary_weibull_total_exp = quantile(median_os_list_weibull_total_exp, probs = c(0.025, 0.5, 0.975))
          median_os_summary_weibull_bias = quantile(median_os_list_weibull_bias, probs = c(0.025, 0.5, 0.975))
          yhat_weibull_sort_total = sort(stan_weibull_survival_model_draws_total$yhat_total)
          yhat_weibull_sort_total_exp = sort(stan_weibull_survival_model_draws_total_exp$yhat_total_exp)
          yhat_weibull_sort_average_total = yhat_weibull_sort_total[1:length(Data_survival$censor) * 8000]
          yhat_weibull_sort_average_total_exp = yhat_weibull_sort_total_exp[1:length(Data_survival$censor) * 8000]
          
          Data_survival$factor_neg = yhat_weibull_sort_average_total
          Data_survival$factor_pos = yhat_weibull_sort_average_total_exp
          Data_survival$factor_neg[Data_survival$factor_neg > 10000] = 10000
          Data_survival$factor_pos[Data_survival$factor_pos > 10000] = 10000
  
          traditional_fit = survfit(Surv(event = censor,
                                         time = time_palliative_final) ~ gene_select,
                                    data = Data_survival)
          simulation_fit_neg = survfit(Surv(event = rep(1,length(Data_survival$factor_neg)),
                                            time = factor_neg) ~ 1, 
                                       data = Data_survival)
          simulation_fit_pos = survfit(Surv(event = rep(1,length(Data_survival$factor_pos)),
                                            time = factor_pos) ~ 1, 
                                       data = Data_survival)
          
          g[[2]] = ggsurvplot(
            fit = list(traditional_fit = traditional_fit,
                       simulation_fit_neg = simulation_fit_neg,
                       simulation_fit_pos = simulation_fit_pos),
            combine = TRUE,
            data = Data_survival,
            xlab = "Time from SPT to final observation (days)",
            ylab = "Survival Probability",
            censor = TRUE,
            font.title = 8,
            font.subtitle = 8,
            font.main = 8,
            font.submain = 8,
            font.caption = 8,
            font.legend = 8,
            surv.median.line = "hv",
            conf.int = FALSE,
            pval = FALSE,
            risk.table = TRUE,
            risk.table.y.text = FALSE,
            tables.theme = clean_theme(), 
            legend = c(0.8,0.8),
            xlim = c(0, max(Data_survival$time_palliative_final) * 1.05),
            break.x.by = ceiling(max(Data_survival$time_palliative_final) / 500) * 100,
            legend.labs = c(paste(name_1, ", Unadjusted"),
                            paste(name_2, ", Unadjusted"),
                            paste(name_1, ", Adjusted for Delayed Entry"),
                            paste(name_2, ", Adjusted for Delayed Entry"))
          ) +   
            labs(title = paste(sum(traditional_fit[[1]]), " patients ",
                               "Median OS ",
                               as.integer(summary(traditional_fit)$table[[13]])," (",
                               as.integer(summary(traditional_fit)$table[[15]]),"-",
                               as.integer(summary(traditional_fit)$table[[17]]),") (",
                               name_1_short,", unadj.)/",
                               as.integer(summary(traditional_fit)$table[[14]]), " (",
                               as.integer(summary(traditional_fit)$table[[16]]),"-",
                               as.integer(summary(traditional_fit)$table[[18]]),") (",
                               name_2_short,", unadj.)/",
                               as.integer(median_os_summary_weibull_total[[2]]), 
                               " (", as.integer(median_os_summary_weibull_total[[1]]), "-",
                               as.integer(median_os_summary_weibull_total[[3]]), ") (",
                               name_1_short,", adj.)/",
                               as.integer(median_os_summary_weibull_total_exp[[2]]), " (",
                               as.integer(median_os_summary_weibull_total_exp[[1]]), "-",
                               as.integer(median_os_summary_weibull_total_exp[[3]]),
                               ") (", name_2_short,", adj.) days",
                               sep=""),
                 subtitle = paste("Survival difference, ",name_1_short, "-", name_2_short, ": ",
                                  as.integer(median_os_summary_weibull_bias[[2]]), " (",
                                  as.integer(median_os_summary_weibull_bias[[1]]), "-", 
                                  as.integer(median_os_summary_weibull_bias[[3]]), 
                                  ") days, median (95% CI)",
                                  sep=""))
          g[[2]]$table <- g[[2]]$table + theme(plot.title = element_blank(),
                                               plot.subtitle = element_blank())
        }
      }
      incProgress(1 / 13)
      
      # analysis for common oncogenic mutations
      h = list()
      hs=list()
      k = 1
      oncogenic_genes = Data_MAF_target %>%
        dplyr::select(Tumor_Sample_Barcode, Hugo_Symbol) %>%
        dplyr::distinct() %>%
        dplyr::count(Hugo_Symbol) %>%
        dplyr::arrange(-n)
      colnames(oncogenic_genes) = c("gene_mutation", "all_patients")
      oncogenic_genes = oncogenic_genes[1:min(length(oncogenic_genes$all_patients), input$gene_no),]
      
      gene_table = data.frame(oncogenic_genes$gene_mutation)
      colnames(gene_table) = c("Gene")
      gene_table$positive_patients = oncogenic_genes$all_patients
      gene_table$positive_freq = round(1000 * gene_table$positive_patients / length(Data_survival$C.CAT調査結果.基本項目.ハッシュID)) / 10
      gene_table$positive_median = 0
      gene_table$positive_LL = 0
      gene_table$positive_UL = 0
      gene_table$negative_median = 0
      gene_table$negative_LL = 0
      gene_table$negative_UL = 0
      gene_table$diff_median = 0
      gene_table$diff_LL = 0
      gene_table$diff_UL = 0
      gene_table$positive_mortal_event = 0
      gene_table$negative_mortal_event = 0
      withProgress(message = sample(nietzsche)[1], {
        for(i in 1:length(oncogenic_genes$all_patients)){
          ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% oncogenic_genes$gene_mutation[i]))$Tumor_Sample_Barcode
          Data_survival = Data_survival %>% dplyr::mutate(
            gene_select = case_when(
              C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ TRUE,
              TRUE ~ FALSE
            )
          )
          
          mut_gene = paste(oncogenic_genes$gene_mutation[i],
                           ", top ", i, " gene with oncogenic mut", sep="")
          traditional_fit = survfit(Surv(event = censor,
                                         time = time_palliative_final) ~ gene_select, 
                                    data = Data_survival)
          if(length(Data_survival[,1]) != traditional_fit[[1]][[1]]){
            gene_table$negative_mortal_event[i] = summary(traditional_fit)$table[7]
            gene_table$positive_mortal_event[i] = summary(traditional_fit)$table[8]
            Data_survival_tmp_pos = Data_survival %>%
              dplyr::filter(gene_select == TRUE)
            
            Data_survival_tmp = Data_survival_tmp_pos
            Median_entry_pos = median(Data_survival_tmp$time_palliative_enroll)
            
            Data_survival_tmp_neg = Data_survival %>%
              dplyr::filter(gene_select == FALSE)
            
            Data_survival_tmp3 = Data_survival_tmp_neg
    
            Median_entry_neg = median(Data_survival_tmp3$time_palliative_enroll)
            Data_survival_tmp = rbind(Data_survival_tmp, Data_survival_tmp3)  
            
            Data_survival = Data_survival %>%
              dplyr::mutate(delay_1 = case_when(
                Data_survival$time_palliative_enroll <= Median_entry_pos &
                  gene_select == TRUE ~ "SPT to entry early",
                Data_survival$time_palliative_enroll > Median_entry_pos &
                  gene_select == TRUE ~ "SPT to entry later",
                Data_survival$time_palliative_enroll <= Median_entry_neg &
                  gene_select == FALSE ~ "SPT to entry early",
                Data_survival$time_palliative_enroll > Median_entry_neg &
                  gene_select == FALSE ~ "SPT to entry later"))
            
            if(sum((Data_survival %>% dplyr::filter(gene_select == TRUE & delay_1 == "SPT to entry later"))$censor) >= 1 &
               sum((Data_survival %>% dplyr::filter(gene_select == FALSE & delay_1 == "SPT to entry later"))$censor) >= 1 &
               sum((Data_survival %>% dplyr::filter(gene_select == TRUE & delay_1 != "SPT to entry later"))$censor) >= 1 &
               sum((Data_survival %>% dplyr::filter(gene_select == FALSE & delay_1 != "SPT to entry later"))$censor) >= 1){
              
              stan_weibull_survival_model_data <-
                list(
                  Median_pos = as.integer(Median_entry_pos),
                  Median_neg = as.integer(Median_entry_neg),
                  Nobs = sum(Data_survival$censor == 1),
                  Ncen = sum(Data_survival$censor == 0),
                  Ntot = length(Data_survival$censor),
                  M_bg = 2,
                  Nexp = length(Data_survival_tmp$time_palliative_enroll),
                  ybef_exp = Data_survival_tmp$time_palliative_enroll,
                  xfactor = as.numeric(Data_survival_tmp$gene_select),
                  yobs = Data_survival$time_enroll_final[Data_survival$censor == 1],
                  ycen = Data_survival$time_enroll_final[Data_survival$censor == 0],
                  Xobs_bg = matrix(c(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 1],
                                     as.numeric(Data_survival$gene_select)[Data_survival$censor == 1]),ncol = 2),
                  Xcen_bg = matrix(c(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 0],
                                     as.numeric(Data_survival$gene_select)[Data_survival$censor == 0]),ncol = 2)
                )
              
              stan_weibull_survival_model_fit <-
                rstan::stan(file = "source/Stan_code_loglog_weibull_factor.stan",
                            data = stan_weibull_survival_model_data,
                            control=list(adapt_delta=0.99, max_treedepth = 10),
                            seed=1234, chains=4, iter=3000, warmup=1000, thin=1, refresh=500, verbose = FALSE,
                            pars = c("alpha","mu", "shape_exp", "scale_exp", "factor",
                                     "yhat_total", "yhat_factor_total"))
              stan_weibull_survival_model_draws <- tidybayes::tidy_draws(stan_weibull_survival_model_fit)
              stan_weibull_survival_model_draws_total <-
                stan_weibull_survival_model_draws %>%
                dplyr::select(.chain, .iteration, .draw, starts_with("yhat_total")) %>%
                tidyr::gather(key = key, value = yhat_total, starts_with("yhat_total")) %>%
                dplyr::select(-key) 
              stan_weibull_survival_model_draws_total_exp <-
                stan_weibull_survival_model_draws %>%
                dplyr::select(.chain, .iteration, .draw, starts_with("yhat_factor_total")) %>%
                tidyr::gather(key = key, value = yhat_total_exp, starts_with("yhat_factor_total")) %>%
                dplyr::select(-key) 
              
              median_os_list_weibull_total_exp = matrix(stan_weibull_survival_model_draws_total_exp$yhat_total_exp, ncol=8000)
              median_os_list_weibull_total_exp = colMedians(median_os_list_weibull_total_exp,na.rm = T)
              
              median_os_list_weibull_total = matrix(stan_weibull_survival_model_draws_total$yhat_total, ncol=8000)
              median_os_list_weibull_total = colMedians(median_os_list_weibull_total,na.rm = T)
              
              median_os_list_weibull_bias = median_os_list_weibull_total - median_os_list_weibull_total_exp
              
              
              median_os_summary_weibull_total = quantile(median_os_list_weibull_total, probs = c(0.025, 0.5, 0.975))
              median_os_summary_weibull_total_exp = quantile(median_os_list_weibull_total_exp, probs = c(0.025, 0.5, 0.975))
              median_os_summary_weibull_bias = quantile(median_os_list_weibull_bias, probs = c(0.025, 0.5, 0.975))
              yhat_weibull_sort_total = sort(stan_weibull_survival_model_draws_total$yhat_total)
              yhat_weibull_sort_total_exp = sort(stan_weibull_survival_model_draws_total_exp$yhat_total_exp)
              yhat_weibull_sort_average_total = yhat_weibull_sort_total[1:length(Data_survival$censor) * 8000]
              yhat_weibull_sort_average_total_exp = yhat_weibull_sort_total_exp[1:length(Data_survival$censor) * 8000]
              
              Data_survival$factor_neg = yhat_weibull_sort_average_total
              Data_survival$factor_pos = yhat_weibull_sort_average_total_exp
              Data_survival$factor_neg[Data_survival$factor_neg > 10000] = 10000
              Data_survival$factor_pos[Data_survival$factor_pos > 10000] = 10000
              
              traditional_fit = survfit(Surv(event = censor,
                                             time = time_palliative_final) ~ gene_select,
                                        data = Data_survival)
              simulation_fit_neg = survfit(Surv(event = rep(1,length(Data_survival$factor_neg)),
                                                time = factor_neg) ~ 1, 
                                           data = Data_survival)
              simulation_fit_pos = survfit(Surv(event = rep(1,length(Data_survival$factor_pos)),
                                                time = factor_pos) ~ 1, 
                                           data = Data_survival)
              hs[[k]] = ggsurvplot(
                fit = list(traditional_fit = traditional_fit,
                           simulation_fit_neg = simulation_fit_neg,
                           simulation_fit_pos = simulation_fit_pos),
                combine = TRUE,
                data = Data_survival,
                xlab = "Time from SPT to final observation (days)",
                ylab = "Survival Probability",
                censor = TRUE,
                surv.scale = "percent",
                font.title = 8,
                font.subtitle = 8,
                font.main = 8,
                font.submain = 8,
                font.caption = 8,
                font.legend = 8,
                surv.median.line = "v",
                palette = "Dark2",
                conf.int = FALSE,
                pval = FALSE,
                risk.table = TRUE,
                risk.table.y.text = FALSE,
                tables.theme = clean_theme(), 
                legend = c(0.8,0.8),
                xlim = c(0, max(Data_survival$time_palliative_final) * 1.05),
                break.x.by = ceiling(max(Data_survival$time_palliative_final) / 500) * 100,
                legend.labs = c(paste(mut_gene, "(-), Unadjusted"),
                                paste(mut_gene, "(+), Unadjusted"),
                                paste(mut_gene, "(-), Adjusted for Delayed Entry"),
                                paste(mut_gene, "(+), Adjusted for Delayed Entry"))
              ) +   
                labs(title = paste(sum(traditional_fit[[1]]), " patients ",
                                   "Median OS ",
                                   as.integer(summary(traditional_fit)$table[[13]])," (",
                                   as.integer(summary(traditional_fit)$table[[15]]),"-",
                                   as.integer(summary(traditional_fit)$table[[17]]),") (mut(-), unadj.)/",
                                   as.integer(summary(traditional_fit)$table[[14]]), " (",
                                   as.integer(summary(traditional_fit)$table[[16]]),"-",
                                   as.integer(summary(traditional_fit)$table[[18]]),") (mut(+), unadj.)/\n",
                                   as.integer(median_os_summary_weibull_total[[2]]), 
                                   " (", as.integer(median_os_summary_weibull_total[[1]]), "-",
                                   as.integer(median_os_summary_weibull_total[[3]]), ") (mut(-), adj.)/",
                                   as.integer(median_os_summary_weibull_total_exp[[2]]), " (",
                                   as.integer(median_os_summary_weibull_total_exp[[1]]), "-",
                                   as.integer(median_os_summary_weibull_total_exp[[3]]),
                                   ") (mut(+), adj.) days",
                                   sep=""),
                     subtitle = paste("Survival difference with gene mutation: ",
                                      as.integer(median_os_summary_weibull_bias[[2]]), " (",
                                      as.integer(median_os_summary_weibull_bias[[1]]), "-", 
                                      as.integer(median_os_summary_weibull_bias[[3]]), 
                                      ") days, median (95% CI)",
                                      sep=""))
              hs[[k]]$table <- hs[[k]]$table + theme(plot.title = element_blank(),
                                                   plot.subtitle = element_blank())
              k = k + 1
              gene_table$positive_median[i] = as.integer(median_os_summary_weibull_total_exp[[2]])
              gene_table$positive_LL[i] = as.integer(median_os_summary_weibull_total_exp[[1]])
              gene_table$positive_UL[i] = as.integer(median_os_summary_weibull_total_exp[[3]])
              gene_table$negative_median[i] = as.integer(median_os_summary_weibull_total[[2]])
              gene_table$negative_LL[i] = as.integer(median_os_summary_weibull_total[[1]])
              gene_table$negative_UL[i] = as.integer(median_os_summary_weibull_total[[3]])
              gene_table$diff_median[i] = -as.integer(median_os_summary_weibull_bias[[2]])
              gene_table$diff_LL[i] = -as.integer(median_os_summary_weibull_bias[[3]])
              gene_table$diff_UL[i] = -as.integer(median_os_summary_weibull_bias[[1]])
            }
          }
          incProgress(1 / length(oncogenic_genes$all_patients))
        }
        for(kk in k:32){
          hs[[kk]] = ggsurvplot_empty()
        }
      })
      incProgress(1 / 13)
      
      Gene_arrange = gene_table$Gene
      gene_table = gene_table %>% dplyr::mutate(
        Gene = factor(gene_table$Gene, levels = Gene_arrange))
      p <- 
        gene_table |>
        ggplot(aes(y = fct_rev(Gene))) + 
        theme_classic()
      p <- p +
        geom_point(aes(x=diff_median), shape=15, size=3) +
        geom_linerange(aes(xmin=diff_LL, xmax=diff_UL)) 
      p <- p +
        geom_vline(xintercept = 0, linetype="dashed") +
        labs(x="Survival difference by mutation", y="Genes with oncogenic alteration")
      p <- p +
        coord_cartesian(ylim=c(1,length(Gene_arrange) + 1),
                        xlim=c(-max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) - 15,
                                max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) + 15))
      p <- p +
        annotate("text",
                 x = (-max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) - 15)/2,
                 y = length(Gene_arrange) + 1,
                 label = "mut=short survival") +
        annotate("text",
                 x = (max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) + 15)/2,
                 y = length(Gene_arrange) + 1,
                 label = "mut=long survival")
      p_mid <- p + 
        theme(axis.line.y = element_blank(),
              axis.ticks.y= element_blank(),
              axis.text.y= element_blank(),
              axis.title.y= element_blank())
      
      gene_table <- gene_table %>%
        dplyr::mutate(
          estimate_lab = paste0(diff_median, " (", diff_LL, "-", diff_UL, ")")) %>%
        dplyr::mutate(
          patients = paste0(positive_patients, " (", positive_freq, "%)"))
      gene_table = 
        dplyr::bind_rows(
          data.frame(
            Gene = "Gene",
            estimate_lab = "Survival difference",
            patients = "Patients"
          ), gene_table  )
      Gene_arrange = gene_table$Gene
      gene_table = gene_table %>% dplyr::mutate(
        Gene = factor(gene_table$Gene, levels = Gene_arrange))
      
      p_left <- gene_table  %>% ggplot(aes(y = fct_rev(Gene)))
      p_left <- p_left + geom_text(aes(x = 0, label = Gene), hjust = 0,
                                   fontface = ifelse(gene_table$Gene == "Gene", "bold", "bold.italic"))
      p_left <- p_left + geom_text(aes(x = 1.4, label = estimate_lab), hjust = 0,
                                   fontface = ifelse(gene_table$estimate_lab == "Survival difference", "bold", "plain"))
      p_left <- p_left + theme_void() + coord_cartesian(xlim = c(0, 4))
      
      # right side of plot - pvalues
      p_right <- gene_table  |> ggplot() +
        geom_text(aes(x = 0, y = fct_rev(Gene), label = patients), hjust = 0,
                  fontface = ifelse(gene_table$patients == "Patients", "bold", "plain")) +
        theme_void()
      
      
      # final plot arrangement
      layout <- c(patchwork::area(t = 0, l = 0, b = 30, r = 4),
                  patchwork::area(t = 1, l = 4, b = 30, r = 9),
                  patchwork::area(t = 0, l = 9, b = 30, r = 11))
      h[[1]] = p_left + p_mid + p_right + plot_layout(design = layout)
      incProgress(1 / 13)
      
      output$figure_survival_CTx_1 = renderPlot({
        arrange_ggsurvplots(g,print=TRUE,ncol=1,nrow=2)
      })
      incProgress(1 / 13)
      
      output$figure_survival_CTx_2 = renderPlot({
        h[[1]]
      })
      incProgress(1 / 13)
      output$figure_survival_CTx_3 = renderPlot({
        arrange_ggsurvplots(hs,print=TRUE,ncol=4,nrow=8,surv.plot.height = 0.75,risk.table.height = 0.25)
      })
      incProgress(1 / 13)
    })
  })

  observeEvent(input$drug_table, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
        Data_case_target = Data_case_target %>%
          dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                          Data_report()$Tumor_Sample_Barcode)
      }
      Data_case_target = Data_case_target %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                      症例.基本情報.年齢,
                      Lymph_met,
                      Brain_met,
                      Lung_met,
                      Bone_met,
                      Liver_met,
                      Other_met,
                      EP_option,
                      EP_treat,
                      症例.EP前レジメン情報.化学療法レジメン名称,
                      症例.EP前レジメン情報.治療ライン.名称.,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.投与終了日,
                      症例.EP前レジメン情報.レジメン継続区分.名称.,
                      症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP前レジメン情報.実施目的.名称.,
                      症例.EP前レジメン情報.終了理由.名称.,
                      症例.EP前レジメン情報.最良総合効果.名称.,
                      症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                      症例.EP後レジメン情報.治療ライン,
                      症例.EP後レジメン情報.治療ライン.名称.,
                      症例.EP後レジメン情報.化学療法レジメン名称,
                      症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP後レジメン情報.投与開始日,
                      症例.EP後レジメン情報.投与終了日,
                      症例.EP後レジメン情報.レジメン継続区分.名称.,
                      症例.EP後レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.最良総合効果.名称.,
                      症例.基本情報.性別.名称.,
                      症例.基本情報.がん種.OncoTree.,
                      症例.基本情報.がん種.OncoTree..名称.,
                      症例.基本情報.がん種.OncoTree.LEVEL1.,
                      症例.検体情報.パネル.名称.,
                      症例.背景情報.ECOG.PS.名称.,
                      症例.背景情報.喫煙歴有無.名称.,
                      症例.背景情報.アルコール多飲有無.名称.,
                      症例.背景情報.重複がん有無.異なる臓器..名称.,
                      症例.背景情報.多発がん有無.同一臓器..名称.,
                      症例.がん種情報.登録時転移部位.名称.,
                      症例.検体情報.腫瘍細胞含有割合,
                      症例.検体情報.検体採取部位.名称.,
                      症例.転帰情報.転帰.名称.,
                      症例.背景情報.診断日,
                      症例.管理情報.登録日,
                      症例.転帰情報.最終生存確認日,
                      症例.転帰情報.死亡日
        )
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
       if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }

      
      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      } else {
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
        
      }
      Data_MAF_target_tmp = Data_MAF_target  %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        amino.acid.change,
                        .keep_all = TRUE)
      Data_MAF_target = Data_MAF_target  %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        .keep_all = TRUE)

      if(length(Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.化学療法レジメン名称),]$症例.EP前レジメン情報.化学療法レジメン名称) != 0){
        Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.化学療法レジメン名称),]$症例.EP前レジメン情報.化学療法レジメン名称 = ""
      }
      if(length(Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.化学療法レジメン名称),]$症例.EP後レジメン情報.化学療法レジメン名称) != 0){
        Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.化学療法レジメン名称),]$症例.EP後レジメン情報.化学療法レジメン名称 = ""
      }
      if(length(Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.最良総合効果.名称.),]$症例.EP前レジメン情報.最良総合効果.名称.) != 0){
        Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.最良総合効果.名称.),]$症例.EP前レジメン情報.最良総合効果.名称. = "NE"
      }
      if(length(Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.最良総合効果.名称.),]$症例.EP後レジメン情報.最良総合効果.名称.) != 0){
        Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.最良総合効果.名称.),]$症例.EP後レジメン情報.最良総合効果.名称. = "NE"
      }
      
      Data_survival = Data_case_target %>%
        dplyr::mutate(final_observe = case_when(
          症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
          症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
          症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
          TRUE ~ 症例.管理情報.登録日))
      Data_survival = Data_survival %>%
        dplyr::arrange(desc(final_observe)) %>%
        dplyr::mutate(censor = case_when(
          症例.転帰情報.死亡日 != "" ~ 1,
          TRUE ~ 0)) %>%
        dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
      
      Data_survival = Data_survival %>%
        dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
        dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
      tmp1 = Data_survival %>%
        dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                        c("その他", "緩和")) %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                      症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP前レジメン情報.化学療法レジメン名称,
                      症例.EP前レジメン情報.治療ライン.名称.,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.投与終了日,
                      症例.EP前レジメン情報.レジメン継続区分.名称.,
                      症例.管理情報.登録日,
                      症例.EP前レジメン情報.実施目的.名称.,
                      final_observe,
                      censor,
                      症例.EP前レジメン情報.終了理由.名称.,
                      症例.EP前レジメン情報.最良総合効果.名称.) %>%
        dplyr::distinct()
      tmp1 = tmp1 %>%
        dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                        as.Date(tmp1$症例.EP前レジメン情報.投与開始日)) %>%
        dplyr::mutate(症例.EP前レジメン情報.投与終了日 =
                        as.Date(tmp1$症例.EP前レジメン情報.投与終了日)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(tmp1$症例.管理情報.登録日))
      tmp1 = tmp1 %>%
        dplyr::mutate(Drug_length =
                        as.integer(difftime(tmp1$症例.EP前レジメン情報.投与終了日,
                                            tmp1$症例.EP前レジメン情報.投与開始日,
                                            units = "days")))
      colnames(tmp1) = c("ID",
                         "Drug",
                         "レジメン",
                         "治療ライン",
                         "投与開始日",
                         "投与終了日",
                         "Ongoing",
                         "登録日",
                         "実施目的",
                         "final_observe",
                         "censor",
                         "終了理由",
                         "最良総合効果",
                         "Drug_length")
      tmp1$TxCGP = "Pre"
      tmp2 = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP後レジメン情報.化学療法レジメン名称,
                      症例.EP後レジメン情報.治療ライン.名称.,
                      症例.EP後レジメン情報.投与開始日,
                      症例.EP後レジメン情報.投与終了日,
                      症例.EP後レジメン情報.レジメン継続区分.名称.,
                      症例.管理情報.登録日,
                      症例.EP前レジメン情報.実施目的.名称.,
                      final_observe,
                      censor,
                      症例.EP後レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.最良総合効果.名称.) %>%
        dplyr::distinct()
      tmp2$症例.EP前レジメン情報.実施目的.名称. = "緩和"
      tmp2 = tmp2 %>%
        dplyr::mutate(症例.EP後レジメン情報.投与開始日 =
                        as.Date(tmp2$症例.EP後レジメン情報.投与開始日)) %>%
        dplyr::mutate(症例.EP後レジメン情報.投与終了日 =
                        as.Date(tmp2$症例.EP後レジメン情報.投与終了日)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(tmp2$症例.管理情報.登録日))
      
      tmp2 = tmp2 %>%
        dplyr::mutate(Drug_length =
                        as.integer(difftime(tmp2$症例.EP後レジメン情報.投与終了日,
                                            tmp2$症例.EP後レジメン情報.投与開始日,
                                            units = "days")))
      colnames(tmp2) = c("ID",
                         "Drug",
                         "レジメン",
                         "治療ライン",
                         "投与開始日",
                         "投与終了日",
                         "Ongoing",
                         "登録日",
                         "実施目的",
                         "final_observe",
                         "censor",
                         "終了理由",
                         "最良総合効果",
                         "Drug_length")
      tmp2$TxCGP = "Post"
      Data_drug = rbind(tmp1, tmp2)
      
      if(!is.null(input$ID_drug)){
        Data_drug = data.frame(NULL)
        for(i in 1:length(input$ID_drug[,1])){
          tmp = read.csv(header = TRUE, file(input$ID_drug[[i, 'datapath']],
                                   encoding='UTF-8-BOM'))
          if("症例.EP前レジメン情報.投与開始日" %in% colnames(tmp)){
            colnames(tmp) = c("ID",
                               "登録日",
                               "治療ライン",
                               "実施目的",
                               "レジメン",
                               "Drug",
                               "投与開始日",
                               "投与終了日",
                               "Ongoing",
                               "終了理由",
                               "最良総合効果",
                               "最終生存確認日",
                               "死亡日")
            tmp = tmp %>%
              dplyr::mutate(
                Drug_length = as.integer(difftime(tmp$投与終了日,
                                                  tmp$投与開始日,
                                                  units = "days")),
                censor = case_when(
                  死亡日 != "" ~ 1,
                  TRUE ~ 0
                ),
                final_observe = case_when(
                  最終生存確認日 == "           " ~ 死亡日,
                  最終生存確認日 != "" ~ 最終生存確認日,
                  死亡日 != "" ~ 死亡日,
                  TRUE ~ 登録日)
              )
            tmp = tmp %>%
              dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
              dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
            tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
            tmp$TxCGP = "Pre"
          } else{
            colnames(tmp) = c("ID",
                              "登録日",
                              "治療ライン",
                              "レジメン",
                              "Drug",
                              "投与開始日",
                              "投与終了日",
                              "Ongoing",
                              "終了理由",
                              "最良総合効果",
                              "最終生存確認日",
                              "死亡日")
            tmp = tmp %>%
              dplyr::mutate(
                Drug_length = as.integer(difftime(tmp$投与終了日,
                                                  tmp$投与開始日,
                                                  units = "days")),
                censor = case_when(
                  死亡日 != "" ~ 1,
                  TRUE ~ 0
                ),
                final_observe = case_when(
                  最終生存確認日 == "           " ~ 死亡日,
                  最終生存確認日 != "" ~ 最終生存確認日,
                  死亡日 != "" ~ 死亡日,
                  TRUE ~ 登録日)
              )
            tmp = tmp %>%
              dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
              dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
            tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
            tmp$実施目的 = "緩和"
            tmp$TxCGP = "Post"
          }
          Data_drug = rbind(Data_drug, tmp)
        }
      }
      
      
      incProgress(1 / 3)
      Data_drug = Data_drug %>%
        dplyr::mutate(final_observe =
                        as.Date(Data_drug$final_observe))
      Data_drug = Data_drug %>%
        dplyr::arrange(投与開始日) %>%
        dplyr::arrange(治療ライン) %>%
        dplyr::arrange(ID)
      
      Data_drug = Data_drug %>% dplyr::mutate(RECIST = case_when(
        最良総合効果 == "CR" ~ "5",
        最良総合効果 == "PR" ~ "4",
        最良総合効果 == "SD" ~ "3",
        最良総合効果 == "PD" ~ "2",
        最良総合効果 == "NE" ~ "1",
        最良総合効果 == "NoData" ~ "0",
        TRUE ~ "0"
      ))
      Data_drug = Data_drug %>%
        dplyr::filter(治療ライン %in% c("１次治療","２次治療","３次治療","４次治療"))
    
      Data_drug_Start = (Data_drug %>%
                           dplyr::arrange(投与開始日,ID,desc(レジメン),治療ライン) %>%
                           dplyr::distinct(ID,治療ライン, .keep_all = T)) %>%
                           dplyr::select(ID,治療ライン,投与開始日)
      Data_drug_End = (Data_drug %>%
                           dplyr::arrange(desc(投与終了日),ID,desc(レジメン),治療ライン) %>%
                           dplyr::distinct(ID,治療ライン, .keep_all = T)) %>%
                           dplyr::select(ID,治療ライン,投与終了日)
      Data_drug_RECIST = (Data_drug %>%
                         dplyr::arrange(desc(RECIST),ID,desc(レジメン),治療ライン) %>%
                         dplyr::distinct(ID,治療ライン,.keep_all = T)) %>%
                         dplyr::select(ID,治療ライン,RECIST)
      Data_drug_Ongoing = (Data_drug %>%
                            dplyr::arrange(desc(Ongoing),ID,desc(レジメン),治療ライン) %>%
                            dplyr::distinct(ID,治療ライン,.keep_all = T)) %>%
                            dplyr::select(ID,治療ライン,Ongoing)
      Data_drug_Ongoing$Drug = ""
      for(samples in 1:length(Data_drug_Ongoing$ID)){
        tmp = sort(unique(str_split(Data_drug[Data_drug$ID == Data_drug_Ongoing$ID[samples] &
                                              Data_drug$治療ライン == Data_drug_Ongoing$治療ライン[samples],]$Drug, ",", simplify = T)[,1]))
        if("" %in% tmp){
          tmp = tmp[tmp != ""]
        }
        Data_drug_Ongoing$Drug[samples] = paste0(tmp, collapse = ",")
      }
      if(length(Data_drug_Ongoing[Data_drug_Ongoing$Drug == "",]$Drug)>0){
        Data_drug_Ongoing$Drug[Data_drug_Ongoing$Drug == ""] = "NoData"
      }
    
      if(length(Data_drug_Start[is.na(Data_drug_Start$投与開始日),]$投与開始日)>0){
        Data_drug_Start[is.na(Data_drug_Start$投与開始日),]$投与開始日 <- -Inf
      }
      if(length(Data_drug_End[is.na(Data_drug_End$投与終了日),]$投与終了日)>0){
        Data_drug_End[is.na(Data_drug_End$投与終了日),]$投与終了日 <- -Inf
      }
    
      Data_drug = Data_drug %>% dplyr::select(-投与開始日, -投与終了日, -RECIST, -Ongoing, -Drug)
      Data_drug = left_join(Data_drug, Data_drug_Start, by = c('ID','治療ライン'))
      Data_drug = left_join(Data_drug, Data_drug_End, by = c('ID','治療ライン'))
      Data_drug = left_join(Data_drug, Data_drug_RECIST, by = c('ID','治療ライン'))
      Data_drug = left_join(Data_drug, Data_drug_Ongoing, by = c('ID','治療ライン'))
      Data_drug = Data_drug %>%
        dplyr::arrange(ID) %>%
        dplyr::distinct(ID,治療ライン, .keep_all = T)
      
      Data_drug <- data.frame(Data_drug %>% 
                                dplyr::arrange(ID) %>%
                                dplyr::group_by(ID) %>%
                                dplyr::mutate(治療ライン = row_number()))
      Data_drug$治療ライン = as.character(Data_drug$治療ライン)    
      
      Data_drug = Data_drug %>% dplyr::mutate(TTF_censor = case_when(
        投与終了日 < 0 & Ongoing == "継続中" & TxCGP =="Pre" ~ 0,
        TRUE ~ 1
      ))
      Data_drug = Data_drug %>% dplyr::mutate(投与終了日 = case_when(
        投与終了日 < 0 & Ongoing == "継続中" & TxCGP =="Pre" ~ 登録日,
        TRUE ~ 投与終了日
      ))
      Data_drug$投与開始日 = as.Date(Data_drug$投与開始日)
      Data_drug$投与終了日 = as.Date(Data_drug$投与終了日)
      Drug_length_tmp = difftime(Data_drug$投与終了日, Data_drug$投与開始日, units = "days")
      Drug_length_tmp[Drug_length_tmp == -Inf] = NA
      Drug_length_tmp[Drug_length_tmp == Inf] = NA
      Data_drug$Drug_length = as.integer(Drug_length_tmp)
      #Data_drug = Data_drug %>% dplyr::filter(投与開始日 >=0 & 投与終了日 >= 0)
      Data_drug = Data_drug %>%
        dplyr::mutate(
          Drug_length = case_when(
            投与開始日 <0 | 投与終了日 < 0 ~ NA_integer_,
            投与開始日 >投与終了日 ~ NA_integer_,
            is.infinite(Drug_length) ~ NA_integer_,
            TRUE ~ Drug_length
        )
      )
      Data_drug = Data_drug %>%
        dplyr::mutate(
          TTF_censor = case_when(
            is.na(Drug_length) ~ NA_integer_,
            TRUE ~ TTF_censor
          )
        )
      #Data_drug = Data_drug %>% dplyr::filter(Drug_length>0 & !is.na(Drug_length) & is.finite(Drug_length))
      Data_drug = Data_drug %>%
        dplyr::arrange(ID, 治療ライン)
  
      Data_drug = Data_drug %>% dplyr::mutate(最良総合効果 = case_when(
        RECIST == "5" ~ "CR",
        RECIST == "4" ~ "PR",
        RECIST == "3" ~ "SD",
        RECIST == "2" ~ "PD",
        RECIST == "1" ~ "NE",
        RECIST == "0" ~ "NE",
        TRUE ~ "NE"
      ))
  
      Data_drug$治療ライン = as.character(Data_drug$治療ライン)
      Drug_summary =  Data_drug %>%
        dplyr::select(
          ID,
          Drug,
          治療ライン,
          最良総合効果,
          終了理由,
          Drug_length,
          TTF_censor,
      )
      colnames(Drug_summary)=
        c("ID", "Drugs", "CTx line", "RECIST", "Reason to finish treatment", "Time on treatment", "Treatment finished or censored")
      Drug_summary$`Reason to finish treatment`[is.na(Drug_summary$`Reason to finish treatment`)] = "Unknown"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "その他理由で中止"] = "Other reason"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "不明"] = "Unknown"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "副作用等で中止"] = "Side effect"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "本人希望により中止"] = "Patient will"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "無効中止"] = "Not effective"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "計画通り終了"] = "As planned"
      Drug_summary$`Treatment finished or censored` = as.character(Drug_summary$`Treatment finished or censored`)
      Drug_summary$`Treatment finished or censored`[is.na(Drug_summary$`Treatment finished or censored`)] = "Unknown"
      Drug_summary$`Treatment finished or censored`[Drug_summary$`Treatment finished or censored` == "1"] = "Finished"
      Drug_summary$`Treatment finished or censored`[Drug_summary$`Treatment finished or censored` == "0"] = "Censored"
      Drug_summary_renamed = Drug_summary
      output$table_drug_all_1 <- render_gt({
        Drug_summary %>%
          dplyr::select(-ID) %>%
          tbl_summary(
            by = "CTx line",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                                "{mean} ({sd})",
                                                                "{median} ({p25}, {p75})", 
                                                                "{min}, {max}"),
                                           all_categorical() ~ "{n} / {N} ({p}%)"),
                          type = list(all_continuous() ~ "continuous2",
                                      all_dichotomous() ~ "categorical"),
                          digits = all_continuous() ~ 2,
                          missing = "ifany") %>%
          modify_caption("**Palliative CTx with treatment duration information, 1st-4th lines**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      output$table_drug_all_2 <- render_gt({
        Drug_summary %>%
          dplyr::select(-ID) %>%
          tbl_summary(
            by = "RECIST",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx with treatment duration information, 1st-4th lines**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      if(!input$special_gene == ""){
        Data_MAF_target_tmp = Data_MAF_target_tmp %>%
          dplyr::filter(Tumor_Sample_Barcode %in%
                          Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
          dplyr::arrange(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change)
        
        ID_special_gene = (Data_MAF_target_tmp %>%
                             dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_"))))$Tumor_Sample_Barcode
        ID_special_gene_mutation_1 = (Data_MAF_target_tmp %>%
                                        dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                        amino.acid.change %in% input$special_gene_mutation_1))$Tumor_Sample_Barcode
        ID_special_gene_mutation_2 = (Data_MAF_target_tmp %>%
                                        dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                        amino.acid.change %in% input$special_gene_mutation_2))$Tumor_Sample_Barcode
        Drug_summary_line_renamed = Drug_summary_renamed %>% dplyr::mutate(
          separation_value = case_when(
            ID %in% ID_special_gene_mutation_1 ~ paste0(input$special_gene_mutation_1_name, " in ", input$special_gene),
            ID %in% ID_special_gene_mutation_2 ~ paste0(input$special_gene_mutation_2_name, " in ", input$special_gene),
            ID %in% ID_special_gene ~ paste0("Other mut in ", input$special_gene),
            TRUE ~ paste0("No mut in ", input$special_gene)
          )
        )
      } else{
        Drug_summary_line_renamed = Drug_summary_renamed %>% dplyr::mutate(
          separation_value = "No mutation pattern")
      }
      
      Drug_summary_line_renamed = Drug_summary_line_renamed %>% dplyr::filter(`CTx line` %in% input$target_line)

      output$table_drug_line_1 <- render_gt({
        Drug_summary_line_renamed %>%
          dplyr::select(-ID) %>%
          tbl_summary(
            by = "separation_value",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx, selected lines, by mutation pattern**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      incProgress(1 / 3)
      
      Drug_summary_diagnosis_renamed = Drug_summary_line_renamed
      ID_diagnosis_list = Data_case_target %>% dplyr::select(C.CAT調査結果.基本項目.ハッシュID,症例.基本情報.がん種.OncoTree.) %>% dplyr::distinct()
      Drug_summary_diagnosis_renamed$diagnosis = unlist(lapply(list(Drug_summary_diagnosis_renamed$ID), function(x) {
          as.vector(ID_diagnosis_list$症例.基本情報.がん種.OncoTree.[match(x, ID_diagnosis_list$C.CAT調査結果.基本項目.ハッシュID)])}))
      output$table_drug_line_2 <- render_gt({
        Drug_summary_diagnosis_renamed %>%
          dplyr::select(-ID, -separation_value) %>%
          tbl_summary(
            by = "diagnosis",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx, selected lines, by diagnosis**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      mut_gene_ = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
      if(length(mut_gene_)==0){
        mut_gene_ = "TP53"
        ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
        Drug_summary_mutation = Drug_summary_diagnosis_renamed %>% dplyr::mutate(
          mutation = case_when(
            ID %in% ID_mutation_ ~ "TP53 mut(+)",
            TRUE ~ "TP53 mut(-)"
          )
        )
      } else{
        if(is.null(input$gene_group_2)){
          ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
          Drug_summary_mutation = Drug_summary_diagnosis_renamed %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_ ~ paste0(paste(mut_gene_, collapse = "/"), " mut(+)"),
              TRUE ~ paste0(paste(mut_gene_, collapse = "/"), " mut(-)")
            )
          )
        } else{
          ID_mutation_1 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_1))$Tumor_Sample_Barcode
          ID_mutation_2 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_2))$Tumor_Sample_Barcode
          Drug_summary_mutation = Drug_summary_diagnosis_renamed %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
              ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
              !ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
              !ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
            )
          )
        }
      }
      
      output$table_drug_line_3 <- render_gt({
        Drug_summary_mutation %>%
          dplyr::select(-ID, -separation_value, -diagnosis) %>%
          tbl_summary(
            by = "mutation",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx, selected lines, by mutation**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
  
      output$select_drug = renderUI({ 
        pickerInput("drug", "Choose drugs for treatment effect analysis",
                    choices = sort(unique(Drug_summary$Drug)), 
                    options = list(`actions-box` = TRUE),
                    selected = names(sort(table(Drug_summary$Drug), decreasing = TRUE))[[1]], multiple = TRUE)
      })
      output$select_drug_group_1 = renderUI({ 
        pickerInput("drug_group_1", "Drug set 1 to be analyzed (if any)",
                    options = list(`actions-box` = TRUE),
                    input$drug, multiple = TRUE)
      })
      output$select_drug_group_1_name = renderUI({ 
        textInput(inputId = "drug_group_1_name", label = "Name for Drug set 1",
                  value = input$drug_group_1[[1]])
      })
      output$select_drug_group_2 = renderUI({ 
        pickerInput("drug_group_2", "Drug set 2 to be analyzed (if any)",
                    options = list(`actions-box` = TRUE),
                    input$drug[-which(input$drug %in% input$drug_group_1)], multiple = TRUE)
      })
      output$select_drug_group_2_name = renderUI({ 
        textInput(inputId = "drug_group_2_name", label = "Name for Drug set 2",
                  value = input$drug_group_2[[1]])
      })
      output$select_drug_group_3 = renderUI({ 
        pickerInput("drug_group_3", "Drug set 3 to be analyzed (if any)",
                    options = list(`actions-box` = TRUE),
                    input$drug[-which(input$drug %in% 
                                        c(input$drug_group_1, input$drug_group_2))], multiple = TRUE)
      })
      output$select_drug_group_3_name = renderUI({ 
        textInput(inputId = "drug_group_3_name", label = "Name for Drug set 3",
                  value = input$drug_group_3[[1]])
      })
      output$select_drug_group_4 = renderUI({ 
        pickerInput("drug_group_4", "Drug set 4 to be analyzed (if any)",
                    options = list(`actions-box` = TRUE),
                    input$drug[-which(input$drug %in% 
                                        c(input$drug_group_1, input$drug_group_2, input$drug_group_3))], multiple = TRUE)
      })
      output$select_drug_group_4_name = renderUI({ 
        textInput(inputId = "drug_group_4_name", label = "Name for Drug set 4",
                  value = input$drug_group_4[[1]])
      })
      incProgress(1 / 3)
    })
  })
    
  observeEvent(input$drug_analysis, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      if(input$gene_group_analysis %in% c("Only cases with mutations in the gene set are analyzed", "Only cases without mutations in the gene set are analyzed")){
        Data_case_target = Data_case_target %>%
          dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in%
                          Data_report()$Tumor_Sample_Barcode)
      }
      Data_case_target = Data_case_target %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                      症例.基本情報.年齢,
                      Lymph_met,
                      Brain_met,
                      Lung_met,
                      Bone_met,
                      Liver_met,
                      Other_met,
                      EP_option,
                      EP_treat,
                      YoungOld,
                      症例.EP前レジメン情報.化学療法レジメン名称,
                      症例.EP前レジメン情報.治療ライン.名称.,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.投与終了日,
                      症例.EP前レジメン情報.レジメン継続区分.名称.,
                      症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP前レジメン情報.実施目的.名称.,
                      症例.EP前レジメン情報.終了理由.名称.,
                      症例.EP前レジメン情報.最良総合効果.名称.,
                      症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                      症例.EP後レジメン情報.治療ライン,
                      症例.EP後レジメン情報.治療ライン.名称.,
                      症例.EP後レジメン情報.化学療法レジメン名称,
                      症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP後レジメン情報.投与開始日,
                      症例.EP後レジメン情報.投与終了日,
                      症例.EP後レジメン情報.レジメン継続区分.名称.,
                      症例.EP後レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.最良総合効果.名称.,
                      症例.基本情報.性別.名称.,
                      症例.基本情報.がん種.OncoTree.,
                      症例.基本情報.がん種.OncoTree..名称.,
                      症例.基本情報.がん種.OncoTree.LEVEL1.,
                      症例.検体情報.パネル.名称.,
                      症例.背景情報.ECOG.PS.名称.,
                      症例.背景情報.喫煙歴有無.名称.,
                      症例.背景情報.アルコール多飲有無.名称.,
                      症例.背景情報.重複がん有無.異なる臓器..名称.,
                      症例.背景情報.多発がん有無.同一臓器..名称.,
                      症例.がん種情報.登録時転移部位.名称.,
                      症例.検体情報.腫瘍細胞含有割合,
                      症例.検体情報.検体採取部位.名称.,
                      症例.転帰情報.転帰.名称.,
                      症例.背景情報.診断日,
                      症例.管理情報.登録日,
                      症例.転帰情報.最終生存確認日,
                      症例.転帰情報.死亡日,
                      HER2_IHC,
                      MSI_PCR,
                      MMR_IHC
        )
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
        if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }
      
      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      } else {
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
      }
      Data_MAF_target_tmp = Data_MAF_target  %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        amino.acid.change,
                        .keep_all = TRUE)
      Data_MAF_target = Data_MAF_target  %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        .keep_all = TRUE)

      Data_cluster_ID_list = Data_cluster_ID() %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, cluster, driver_mutations)
      Data_case_target = left_join(Data_case_target,
                                   Data_cluster_ID_list,
                                   by = "C.CAT調査結果.基本項目.ハッシュID")
      
      if(length(Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.化学療法レジメン名称),]$症例.EP前レジメン情報.化学療法レジメン名称) != 0){
        Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.化学療法レジメン名称),]$症例.EP前レジメン情報.化学療法レジメン名称 = ""
      }
      if(length(Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.化学療法レジメン名称),]$症例.EP後レジメン情報.化学療法レジメン名称) != 0){
        Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.化学療法レジメン名称),]$症例.EP後レジメン情報.化学療法レジメン名称 = ""
      }
      if(length(Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.最良総合効果.名称.),]$症例.EP前レジメン情報.最良総合効果.名称.) != 0){
        Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.最良総合効果.名称.),]$症例.EP前レジメン情報.最良総合効果.名称. = "NE"}
      if(length(Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.最良総合効果.名称.),]$症例.EP後レジメン情報.最良総合効果.名称.) != 0){
        Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.最良総合効果.名称.),]$症例.EP後レジメン情報.最良総合効果.名称. = "NE"}
      
      Data_survival = Data_case_target %>%
        dplyr::mutate(final_observe = case_when(
          症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
          症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
          症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
          TRUE ~ 症例.管理情報.登録日))
      Data_survival = Data_survival %>%
        dplyr::arrange(desc(final_observe)) %>%
        dplyr::mutate(censor = case_when(
          症例.転帰情報.死亡日 != "" ~ 1,
          TRUE ~ 0)) %>%
        dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
      incProgress(1 / 13)
      Data_survival = Data_survival %>%
        dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
        dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
      tmp1 = Data_survival %>%
        dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                        c("その他", "緩和")) %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                      症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP前レジメン情報.化学療法レジメン名称,
                      症例.EP前レジメン情報.治療ライン.名称.,
                      症例.EP前レジメン情報.投与開始日,
                      症例.EP前レジメン情報.投与終了日,
                      症例.EP前レジメン情報.レジメン継続区分.名称.,
                      症例.管理情報.登録日,
                      症例.EP前レジメン情報.実施目的.名称.,
                      final_observe,
                      censor,
                      症例.EP前レジメン情報.終了理由.名称.,
                      症例.EP前レジメン情報.最良総合効果.名称.) %>%
        dplyr::distinct()
      tmp1 = tmp1 %>%
        dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                        as.Date(tmp1$症例.EP前レジメン情報.投与開始日)) %>%
        dplyr::mutate(症例.EP前レジメン情報.投与終了日 =
                        as.Date(tmp1$症例.EP前レジメン情報.投与終了日)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(tmp1$症例.管理情報.登録日))
      tmp1 = tmp1 %>%
        dplyr::mutate(Drug_length =
                        as.integer(difftime(tmp1$症例.EP前レジメン情報.投与終了日,
                                            tmp1$症例.EP前レジメン情報.投与開始日,
                                            units = "days")))
      colnames(tmp1) = c("ID",
                         "Drug",
                         "レジメン",
                         "治療ライン",
                         "投与開始日",
                         "投与終了日",
                         "Ongoing",
                         "登録日",
                         "実施目的",
                         "final_observe",
                         "censor",
                         "終了理由",
                         "最良総合効果",
                         "Drug_length")
      tmp1$TxCGP = "Pre"
      tmp2 = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                      症例.EP後レジメン情報.化学療法レジメン名称,
                      症例.EP後レジメン情報.治療ライン.名称.,
                      症例.EP後レジメン情報.投与開始日,
                      症例.EP後レジメン情報.投与終了日,
                      症例.EP後レジメン情報.レジメン継続区分.名称.,
                      症例.管理情報.登録日,
                      症例.EP前レジメン情報.実施目的.名称.,
                      final_observe,
                      censor,
                      症例.EP後レジメン情報.終了理由.名称.,
                      症例.EP後レジメン情報.最良総合効果.名称.) %>%
        dplyr::distinct()
      tmp2$症例.EP前レジメン情報.実施目的.名称. = "緩和"
      tmp2 = tmp2 %>%
        dplyr::mutate(症例.EP後レジメン情報.投与開始日 =
                        as.Date(tmp2$症例.EP後レジメン情報.投与開始日)) %>%
        dplyr::mutate(症例.EP後レジメン情報.投与終了日 =
                        as.Date(tmp2$症例.EP後レジメン情報.投与終了日)) %>%
        dplyr::mutate(症例.管理情報.登録日 =
                        as.Date(tmp2$症例.管理情報.登録日))
      
      tmp2 = tmp2 %>%
        dplyr::mutate(Drug_length =
                        as.integer(difftime(tmp2$症例.EP後レジメン情報.投与終了日,
                                            tmp2$症例.EP後レジメン情報.投与開始日,
                                            units = "days")))
      colnames(tmp2) = c("ID",
                         "Drug",
                         "レジメン",
                         "治療ライン",
                         "投与開始日",
                         "投与終了日",
                         "Ongoing",
                         "登録日",
                         "実施目的",
                         "final_observe",
                         "censor",
                         "終了理由",
                         "最良総合効果",
                         "Drug_length")
      tmp2$TxCGP = "Post"
      Data_drug = rbind(tmp1, tmp2)
      if(!is.null(input$ID_drug)){
        Data_drug = data.frame(NULL)
        for(i in 1:length(input$ID_drug[,1])){
          tmp = read.csv(header = TRUE, file(input$ID_drug[[i, 'datapath']],
                                             encoding='UTF-8-BOM'))
          if("症例.EP前レジメン情報.投与開始日" %in% colnames(tmp)){
            colnames(tmp) = c("ID",
                              "登録日",
                              "治療ライン",
                              "実施目的",
                              "レジメン",
                              "Drug",
                              "投与開始日",
                              "投与終了日",
                              "Ongoing",
                              "終了理由",
                              "最良総合効果",
                              "最終生存確認日",
                              "死亡日")
            tmp = tmp %>%
              dplyr::mutate(
                Drug_length = as.integer(difftime(tmp$投与終了日,
                                                  tmp$投与開始日,
                                                  units = "days")),
                censor = case_when(
                  死亡日 != "" ~ 1,
                  TRUE ~ 0
                ),
                final_observe = case_when(
                  最終生存確認日 == "           " ~ 死亡日,
                  最終生存確認日 != "" ~ 最終生存確認日,
                  死亡日 != "" ~ 死亡日,
                  TRUE ~ 登録日)
              )
            tmp = tmp %>%
              dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
              dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
            tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
            tmp$TxCGP = "Pre"
          } else{
            colnames(tmp) = c("ID",
                              "登録日",
                              "治療ライン",
                              "レジメン",
                              "Drug",
                              "投与開始日",
                              "投与終了日",
                              "Ongoing",
                              "終了理由",
                              "最良総合効果",
                              "最終生存確認日",
                              "死亡日")
            tmp = tmp %>%
              dplyr::mutate(
                Drug_length = as.integer(difftime(tmp$投与終了日,
                                                  tmp$投与開始日,
                                                  units = "days")),
                censor = case_when(
                  死亡日 != "" ~ 1,
                  TRUE ~ 0
                ),
                final_observe = case_when(
                  最終生存確認日 == "           " ~ 死亡日,
                  最終生存確認日 != "" ~ 最終生存確認日,
                  死亡日 != "" ~ 死亡日,
                  TRUE ~ 登録日)
              )
            tmp = tmp %>%
              dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
              dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
            tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
            tmp$実施目的 = "緩和"
            tmp$TxCGP = "Post"
          }
          Data_drug = rbind(Data_drug, tmp)
        }
      }
      incProgress(1 / 13)
      
      Data_drug = Data_drug %>%
        dplyr::mutate(final_observe =
                        as.Date(Data_drug$final_observe))
      Data_drug = Data_drug %>%
        dplyr::arrange(ID,治療ライン,投与開始日)
      
      Data_drug = Data_drug %>% dplyr::mutate(RECIST = case_when(
        最良総合効果 == "CR" ~ "5",
        最良総合効果 == "PR" ~ "4",
        最良総合効果 == "SD" ~ "3",
        最良総合効果 == "PD" ~ "2",
        最良総合効果 == "NE" ~ "1",
        最良総合効果 == "NoData" ~ "0",
        TRUE ~ "0"
      ))
      Data_drug = Data_drug %>%
        dplyr::filter(治療ライン %in% c("１次治療","２次治療","３次治療","４次治療"))
      
      Data_drug_Start = Data_drug %>%
                           dplyr::arrange(投与開始日,ID,desc(レジメン),治療ライン) %>%
                           dplyr::distinct(ID,治療ライン, .keep_all = T) %>%
                           dplyr::select(ID,治療ライン, 投与開始日)
      Data_drug_End = Data_drug %>%
                         dplyr::arrange(desc(投与終了日),ID,desc(レジメン),治療ライン) %>%
                         dplyr::distinct(ID,治療ライン, .keep_all = T) %>%
                         dplyr::select(ID,治療ライン,投与終了日)
      Data_drug_RECIST = Data_drug %>%
                            dplyr::arrange(desc(RECIST),ID,desc(レジメン),治療ライン) %>%
                            dplyr::distinct(ID,治療ライン,.keep_all = T) %>%
                            dplyr::select(ID,治療ライン, RECIST)
      Data_drug_Ongoing = Data_drug %>%
                             dplyr::arrange(desc(Ongoing),ID,desc(レジメン),治療ライン) %>%
                             dplyr::distinct(ID,治療ライン, .keep_all = T) %>%
                             dplyr::select(ID,治療ライン,Ongoing)
      Data_drug_Ongoing$Drug = ""
      for(samples in 1:length(Data_drug_Ongoing$ID)){
        tmp = sort(unique(str_split(Data_drug[Data_drug$ID == Data_drug_Ongoing$ID[samples] &
                                                Data_drug$治療ライン == Data_drug_Ongoing$治療ライン[samples],]$Drug, ",", simplify = T)[,1]))
        if("" %in% tmp){
          tmp = tmp[tmp != ""]
        }
        Data_drug_Ongoing$Drug[samples] = paste0(tmp, collapse = ",")
      }
      if(length(Data_drug_Ongoing[Data_drug_Ongoing$Drug == "",]$Drug)>0){
        Data_drug_Ongoing$Drug[Data_drug_Ongoing$Drug == ""] = "NoData"
      }
      
      if(length(Data_drug_Start[is.na(Data_drug_Start$投与開始日),]$投与開始日)>0){
        Data_drug_Start[is.na(Data_drug_Start$投与開始日),]$投与開始日 <- -Inf
      }
      if(length(Data_drug_End[is.na(Data_drug_End$投与終了日),]$投与終了日)>0){
        Data_drug_End[is.na(Data_drug_End$投与終了日),]$投与終了日 <- -Inf
      }
      
      Data_drug = Data_drug %>% dplyr::select(-投与開始日, -投与終了日, -RECIST, -Ongoing, -Drug)
      Data_drug = left_join(Data_drug, Data_drug_Start, by = c('ID','治療ライン'))
      Data_drug = left_join(Data_drug, Data_drug_End, by = c('ID','治療ライン'))
      Data_drug = left_join(Data_drug, Data_drug_RECIST, by = c('ID','治療ライン'))
      Data_drug = left_join(Data_drug, Data_drug_Ongoing, by = c('ID','治療ライン'))
      Data_drug = Data_drug %>%
        dplyr::arrange(ID) %>%
        dplyr::distinct(ID, 治療ライン, .keep_all = T)
      Data_drug = Data_drug %>% dplyr::mutate(最良総合効果 = case_when(
        RECIST == "5" ~ "CR",
        RECIST == "4" ~ "PR",
        RECIST == "3" ~ "SD",
        RECIST == "2" ~ "PD",
        RECIST == "1" ~ "NE",
        RECIST == "0" ~ "NoData",
        TRUE ~ RECIST
      ))
      
      Data_drug <- data.frame(Data_drug %>% 
                                    dplyr::arrange(ID) %>%
                                    dplyr::group_by(ID) %>%
                                    dplyr::mutate(治療ライン = row_number()))
      Data_drug$治療ライン = as.character(Data_drug$治療ライン)
      
      Data_drug = Data_drug %>% dplyr::mutate(TTF_censor = case_when(
        投与終了日 < 0  & Ongoing == "継続中" & TxCGP =="Pre" ~ 0,
        TRUE ~ 1
      ))
      Data_drug = Data_drug %>% dplyr::mutate(投与終了日 = case_when(
        投与終了日 < 0  & Ongoing == "継続中" & TxCGP =="Pre" ~ 登録日,
        TRUE ~ 投与終了日
      ))
  
      Data_drug = Data_drug %>% dplyr::mutate(TTF_censor = case_when(
        is.na(Drug_length) ~ 0,
        TRUE ~ TTF_censor
      ))
      
      Data_drug$投与開始日 = as.Date(Data_drug$投与開始日)
      Data_drug$投与終了日 = as.Date(Data_drug$投与終了日)
      Drug_length_tmp = difftime(Data_drug$投与終了日, Data_drug$投与開始日, units = "days")
      Drug_length_tmp[Drug_length_tmp == -Inf] = NA
      Drug_length_tmp[Drug_length_tmp == Inf] = NA
      Data_drug$Drug_length = as.integer(Drug_length_tmp)
      Data_drug = Data_drug %>%
        dplyr::mutate(
          Drug_length = case_when(
            投与開始日 <0 | 投与終了日 < 0 ~ NA_integer_,
            投与開始日 > 投与終了日 ~ NA_integer_,
            is.infinite(Drug_length) ~ NA_integer_,
            TRUE ~ Drug_length
          )
        )
      Data_drug = Data_drug %>%
        dplyr::mutate(
          TTF_censor = case_when(
            is.na(Drug_length) ~ NA_integer_,
            TRUE ~ TTF_censor
          )
        )
      incProgress(1 / 13)
      
      Data_drug_RECIST = Data_drug
      Data_drug = Data_drug %>% dplyr::filter(投与開始日 >=0 & 投与終了日 >= 0 & is.finite(投与開始日) & is.finite(投与終了日))
      Data_drug = Data_drug %>% dplyr::filter(Drug_length>0 & !is.na(Drug_length) & is.finite(Drug_length))
      Data_drug = Data_drug %>%
        dplyr::arrange(ID, 治療ライン)
      
      Data_drug$TTF_pre_censor = -1
      Data_drug$TTF_pre = -1
      for(tx in 2:(length(Data_drug$ID))){
        if(Data_drug[tx,]$ID == Data_drug[tx-1,]$ID){
          Data_drug[tx,]$TTF_pre = Data_drug[tx-1,]$Drug_length
          Data_drug[tx,]$TTF_pre_censor = Data_drug[tx-1,]$TTF_censor
        }
      }
  
      Data_drug = Data_drug %>%
        dplyr::filter(治療ライン %in% input$target_line)
      
      Drug_summary =  Data_drug%>%
        dplyr::filter(Drug %in% input$drug) %>%
        dplyr::select(
          ID,
          Drug,
          治療ライン,
          最良総合効果,
          終了理由,
          Drug_length,
          TTF_censor,
        )

      colnames(Drug_summary)=
        c("ID", "Drugs", "CTx line", "RECIST", "Reason to finish treatment", "Time on treatment", "Treatment finished or censored")
      Drug_summary$`Reason to finish treatment`[is.na(Drug_summary$`Reason to finish treatment`)] = "Unknown"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "その他理由で中止"] = "Other reason"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "不明"] = "Unknown"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "副作用等で中止"] = "Side effect"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "本人希望により中止"] = "Patient will"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "無効中止"] = "Not effective"
      Drug_summary$`Reason to finish treatment`[Drug_summary$`Reason to finish treatment` == "計画通り終了"] = "As planned"
      Drug_summary$`Treatment finished or censored` = as.character(Drug_summary$`Treatment finished or censored`)
      Drug_summary$`Treatment finished or censored`[is.na(Drug_summary$`Treatment finished or censored`)] = "Unknown"
      Drug_summary$`Treatment finished or censored`[Drug_summary$`Treatment finished or censored` == "1"] = "Finished"
      Drug_summary$`Treatment finished or censored`[Drug_summary$`Treatment finished or censored` == "0"] = "Censored"
      
      if(!input$special_gene == ""){
        Data_MAF_target_tmp = Data_MAF_target_tmp %>%
          dplyr::filter(Tumor_Sample_Barcode %in%
                          Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
          dplyr::arrange(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change)
        
        ID_special_gene = (Data_MAF_target_tmp %>%
                             dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_"))))$Tumor_Sample_Barcode
        ID_special_gene_mutation_1 = (Data_MAF_target_tmp %>%
                                        dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                        amino.acid.change %in% input$special_gene_mutation_1))$Tumor_Sample_Barcode
        ID_special_gene_mutation_2 = (Data_MAF_target_tmp %>%
                                        dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                        amino.acid.change %in% input$special_gene_mutation_2))$Tumor_Sample_Barcode
        Drug_summary_line = Drug_summary %>% dplyr::mutate(
          separation_value = case_when(
            ID %in% ID_special_gene_mutation_1 ~ paste0(input$special_gene_mutation_1_name, " in ", input$special_gene),
            ID %in% ID_special_gene_mutation_2 ~ paste0(input$special_gene_mutation_2_name, " in ", input$special_gene),
            ID %in% ID_special_gene ~ paste0("Other mut in ", input$special_gene),
            TRUE ~ paste0("No mut in ", input$special_gene)
          )
        )
      } else{
        Drug_summary_line = Drug_summary %>% dplyr::mutate(
          separation_value = "No mutation pattern")
      }
      output$table_drug_ToT_1 <- render_gt({
        Drug_summary_line %>%
          dplyr::select(-ID) %>%
          tbl_summary(
            by = "separation_value",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx with treatment duration information, selected lines, by mutation pattern**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      
      Drug_summary_diagnosis = Drug_summary_line
      ID_diagnosis_list = Data_case_target %>% dplyr::select(C.CAT調査結果.基本項目.ハッシュID,症例.基本情報.がん種.OncoTree.) %>% dplyr::distinct()
      Drug_summary_diagnosis$diagnosis = unlist(lapply(list(Drug_summary_diagnosis$ID), function(x) {
        as.vector(ID_diagnosis_list$症例.基本情報.がん種.OncoTree.[match(x, ID_diagnosis_list$C.CAT調査結果.基本項目.ハッシュID)])}))
      output$table_drug_ToT_2 <- render_gt({
        Drug_summary_diagnosis %>%
          dplyr::select(-ID, -separation_value) %>%
          tbl_summary(
            by = "diagnosis",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx with treatment duration information, selected lines, by diagnosis**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      mut_gene_ = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
      if(length(mut_gene_)==0){
        mut_gene_ = "TP53"
        ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
        Drug_summary_mutation = Drug_summary_diagnosis %>% dplyr::mutate(
          mutation = case_when(
            ID %in% ID_mutation_ ~ "TP53 mut(+)",
            TRUE ~ "TP53 mut(-)"
          )
        )
      } else{
        if(is.null(input$gene_group_2)){
          ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
          Drug_summary_mutation = Drug_summary_diagnosis %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_ ~ paste0(paste(mut_gene_, collapse = "/"), " mut(+)"),
              TRUE ~ paste0(paste(mut_gene_, collapse = "/"), " mut(-)")
            )
          )
        } else{
          ID_mutation_1 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_1))$Tumor_Sample_Barcode
          ID_mutation_2 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_2))$Tumor_Sample_Barcode
          Drug_summary_mutation = Drug_summary_diagnosis %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
              ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
              !ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
              !ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
            )
          )
        }
      }
      incProgress(1 / 13)
      
      output$table_drug_ToT_3 <- render_gt({
        Drug_summary_mutation %>%
          dplyr::select(-ID, -separation_value, -diagnosis) %>%
          tbl_summary(
            by = "mutation",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx with treatment duration information, selected lines, by mutation**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      
      Data_drug$serial = 1:length(Data_drug$ID)
  
      Data_drug_TTF = Data_drug %>% dplyr::distinct(ID, Drug, .keep_all = T)
      ga = list()
      gb = list()
      gc = list()
      kk = 1
      Data_TTF_compare = Data_drug %>%
        dplyr::filter(TTF_pre>0) %>%
        dplyr::distinct(ID, Drug, .keep_all = T)
      if(length(Data_TTF_compare$TTF_pre)>0){
        Data_TTF_compare$Drug_length = as.numeric(Data_TTF_compare$Drug_length)
        Data_TTF_compare$TTF_pre = as.numeric(Data_TTF_compare$TTF_pre)
        Data_TTF_compare$TTF_censor_shape = as.character(4 + 16 * Data_TTF_compare$TTF_censor)
        Data_TTF_compare$TTF_pre_censor_shape = as.character(4 + 16 * Data_TTF_compare$TTF_pre_censor)
        Data_TTF_compare = Data_TTF_compare %>% dplyr::mutate(
          TTF_censor_color = case_when(
            TTF_censor == 0 ~ "censored",
            TTF_censor == 1 ~ "finished",
            TRUE ~ "NoData"
          )
        )
        Data_TTF_compare = Data_TTF_compare %>% dplyr::mutate(
          TTF_pre_censor_color = case_when(
            TTF_pre_censor == 0 ~ "censored",
            TTF_pre_censor == 1 ~ "finished",
            TRUE ~ "NoData"
          )
        )
        Data_TTF_compare = Data_TTF_compare %>% dplyr::mutate(
          TTF_censor_double_color = case_when(
            TTF_censor == 0  & TTF_pre_censor == 0 ~ "target:censored, previous:censored",
            TTF_censor == 1  & TTF_pre_censor == 0 ~ "target:finished, previous:censored",
            TTF_censor == 0  & TTF_pre_censor == 1 ~ "target:censored, previous:finished",
            TTF_censor == 1  & TTF_pre_censor == 1 ~ "target:finished, previous:finished",
            TRUE ~ as.character(TTF_censor)
          )
        )
        Data_TTF_compare_tmp = Data_TTF_compare %>% dplyr::filter(Drug %in% input$drug) %>%
          dplyr::arrange(Drug_length)
        Data_TTF_compare_tmp$ind <- factor(seq(1:length(Data_TTF_compare_tmp$ID)))
        Data_TTF_compare_tmp = Data_TTF_compare_tmp %>%
          dplyr::arrange(TTF_pre)
        Data_TTF_compare_tmp$ind2 <- factor(seq(1:length(Data_TTF_compare_tmp$ID)))
        g.mid<-ggplot(Data_TTF_compare_tmp,aes(x=1,y=ind))+
          geom_segment(aes(x=0.94,xend=0.96,yend=ind))+
          geom_segment(aes(x=1.04,xend=1.065,yend=ind))+
          ggtitle("")+
          ylab(NULL)+
          scale_x_continuous(expand=c(0,0),limits=c(0.94,1.065))+
          theme(axis.title=element_blank(),
                legend.position = 'none',
                panel.grid=element_blank(),
                axis.text.y=element_blank(),
                axis.ticks.y=element_blank(),
                panel.background=element_blank(),
                axis.text.x=element_text(color=NA),
                axis.ticks.x=element_line(color=NA),
                plot.margin = unit(c(1,-1,1,-1), "mm"))
        g1 <- ggplot(data = Data_TTF_compare_tmp, aes(x = ind, y = TTF_pre)) +
          geom_bar(stat = "identity") + ggtitle("Previous line, red:finished, blue:censored") +
          geom_point(aes(x = ind, y = TTF_pre,shape = TTF_pre_censor_shape,colour = TTF_pre_censor_color),size=2)+
          theme(axis.title.x = element_blank(),
                legend.position = 'none',
                axis.title.y = element_blank(),
                axis.text.y = element_blank(),
                axis.ticks.y = element_blank(),
                plot.margin = unit(c(1,-1,1,0), "mm")) +
          scale_y_reverse() + coord_flip() +
          scale_colour_brewer(palette = "Dark2")
        g2 <- ggplot(data = Data_TTF_compare_tmp, aes(x = ind, y = Drug_length)) +xlab(NULL)+
          geom_bar(stat = "identity") + ggtitle(paste0("Time on treatment: ", paste(input$drug, collapse = ";"))) +
          geom_point(aes(x = ind, y = Drug_length,shape = TTF_censor_shape,colour = TTF_censor_color),size=2)+
          theme(axis.title.x = element_blank(), axis.title.y = element_blank(),
                legend.position = 'none',
                axis.text.y = element_blank(), axis.ticks.y = element_blank(),
                plot.margin = unit(c(1,0,1,-1), "mm")) +
          coord_flip() +
          scale_colour_brewer(palette = "Dark2")
        gg1 <- ggplot_gtable(ggplot_build(g1))
        gg2 <- ggplot_gtable(ggplot_build(g2))
        gg.mid <- ggplot_gtable(ggplot_build(g.mid))
        ga[[1]] = grid.arrange(gg1,gg.mid,gg2,ncol=3,widths=c(9/19,1/19,9/19))
    
        Data_tmp_1 = Data_TTF_compare_tmp %>% dplyr::select(
          Drug_length, TTF_censor)
        Data_tmp_2 = Data_TTF_compare_tmp %>% dplyr::select(
          TTF_pre, TTF_pre_censor)
        colnames(Data_tmp_2) = colnames(Data_tmp_1)
        Data_tmp_1$line = "Time on treatment"
        Data_tmp_2$line = "Time on treatment, previous-line"
        Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
        survfit_t <- survfit(Surv(Drug_length, TTF_censor)~line, data=Data_tmp,type = "kaplan-meier", conf.type = "log-log")
        diff_0 = survdiff(Surv(Drug_length, TTF_censor)~line,
                          data=Data_tmp, rho=0)
        diff_1 = survdiff(Surv(Drug_length, TTF_censor)~line,
                          data=Data_tmp, rho=1)
        gb[[1]] = surv_curv_drug(survfit_t, Data_tmp, paste0("Time on treatment, ", paste(input$drug, collapse = ";")), diff_0, diff_1)
    
        Data_TTF_compare_tmp = Data_TTF_compare_tmp %>% dplyr::filter(TTF_pre_censor == 1 & TTF_censor == 1)
        
        if(length(Data_TTF_compare_tmp$TTF_pre)>2){
          RegModel.1 <- lm(TTF_pre~Drug_length, data=Data_TTF_compare_tmp)
          equation <- sprintf("Y = %.3g + %.3g * X", coef(RegModel.1)[1], coef(RegModel.1)[2])
          res <- cor.test(Data_TTF_compare_tmp$TTF_pre, Data_TTF_compare_tmp$Drug_length, alternative="two.sided", method="pearson")
          res_1 = round(res$estimate,3)
          res_2 = round(res$conf.int[1],3)
          res_3 = round(res$conf.int[2],3)
          equation = paste0("r=", res_1, " (", res_2, "-", res_3, "), ", equation)
          ga[[2]] = Data_TTF_compare_tmp %>%
            ggplot(aes(x = Drug_length, y = TTF_pre, colour = TTF_censor_double_color)) +
            geom_point()+
            geom_smooth(method=lm, se=FALSE, color="black", show.legend=FALSE)+
            theme_classic()+
            annotate("text", x = max(Data_TTF_compare_tmp$Drug_length)/2, y=0, label=equation, parse=F) +
            labs(x = "Time on treatment, only pts without censoring", y = "Previous line, only pts without censoring", title = paste0("ToT of target-line/previous-line:",paste(input$drug, collapse = ";"))) +
            scale_colour_brewer(palette = "Dark2")
        } else {
          ga[[2]] = Data_TTF_compare_tmp %>%
            ggplot(aes(x = Drug_length, y = TTF_pre, colour = TTF_censor_double_color)) +
            geom_point()+
            theme_classic()+
            labs(x = "Time on treatment, only pts without censoring", y = "Previous line, only pts without censoring", title = paste0("ToT of target-line/previous-line:",paste(input$drug, collapse = ";"))) +
            scale_colour_brewer(palette = "Dark2")
        }
        kk=2
      }
      incProgress(1 / 13)
      
      survfit_t <- survfit(Surv(Drug_length, TTF_censor)~1, data=Data_drug_TTF,type = "kaplan-meier", conf.type = "log-log")
      gb[[kk]] = surv_curv_drug(survfit_t, Data_drug_TTF, paste0("Time on treatment, all drugs"), NULL, NULL)
      kk = kk + 1
  
      mut_gene = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
      if(is.null(input$gene)){
        mut_gene = "TP53"
      }
  
      Data_drug_TTF = Data_drug_TTF %>% dplyr::mutate(mut = case_when(
        ID %in% unique((Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode) ~ "+",
        TRUE ~ "-"))
      survfit_t <- survfit(Surv(Drug_length, TTF_censor)~mut, data=Data_drug_TTF,type = "kaplan-meier", conf.type = "log-log")
      if(length(Data_drug_TTF[,1]) != survfit_t[[1]][[1]]){
          
        diff_0 = survdiff(Surv(Drug_length, TTF_censor)~mut,
                          data=Data_drug_TTF, rho=0)
        diff_1 = survdiff(Surv(Drug_length, TTF_censor)~mut,
                          data=Data_drug_TTF, rho=1)
        gb[[kk]] = surv_curv_drug(survfit_t, Data_drug_TTF, paste("Time on treatment, all drugs,", paste0(collapse = ";", mut_gene) , "mut"), diff_0, diff_1)
        kk = kk + 1
      }
      
      Data_drug_TTF = Data_drug_TTF %>% dplyr::mutate(Regimen_type = case_when(
        Drug %in% input$drug ~ paste(input$drug, collapse = ";"),
        TRUE ~ "Other drugs"))
      survfit_t <- survfit(Surv(Drug_length, TTF_censor)~Regimen_type, data=Data_drug_TTF,type = "kaplan-meier", conf.type = "log-log")
      if(length(Data_drug_TTF[,1]) != survfit_t[[1]][[1]]){
        diff_0 = survdiff(Surv(Drug_length, TTF_censor)~Regimen_type,
                          data=Data_drug_TTF, rho=0)
        diff_1 = survdiff(Surv(Drug_length, TTF_censor)~Regimen_type,
                          data=Data_drug_TTF, rho=1)
        gb[[kk]] = surv_curv_drug(survfit_t, Data_drug_TTF, paste0("Time on treatment, ", paste(input$drug, collapse = ";")), diff_0, diff_1)
        kk = kk + 1
      }
      
      Data_drug_TTF = Data_drug_TTF %>% dplyr::mutate(Regimen = case_when(
        Drug %in% input$drug_group_1 ~ input$drug_group_1_name,
        Drug %in% input$drug_group_2 ~ input$drug_group_2_name,
        Drug %in% input$drug_group_3 ~ input$drug_group_3_name,
        Drug %in% input$drug_group_4 ~ input$drug_group_4_name,
        TRUE ~ "Other drugs"))
      Data_drug_TTF_drug_select = Data_drug_TTF %>% dplyr::filter(Drug != "Other drugs")
      if(length(Data_drug_TTF_drug_select$Drug) > 0){
        survfit_t <- survfit(Surv(Drug_length, TTF_censor)~Regimen, data=Data_drug_TTF_drug_select,type = "kaplan-meier", conf.type = "log-log")
        if(length(Data_drug_TTF_drug_select[,1]) != survfit_t[[1]][[1]]){
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~Regimen,
                            data=Data_drug_TTF_drug_select, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~Regimen,
                            data=Data_drug_TTF_drug_select, rho=1)
          gb[[kk]] = surv_curv_drug(survfit_t, Data_drug_TTF_drug_select, "Time on treatment, selected drugs", diff_0, diff_1)
          kk = kk + 1
        }
      }
      
      survfit_t <- survfit(Surv(Drug_length, TTF_censor)~mut+Regimen_type, data=Data_drug_TTF,type = "kaplan-meier", conf.type = "log-log")
      if(length(Data_drug_TTF[,1]) != survfit_t[[1]][[1]]){
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~mut+Regimen_type,
                          data=Data_drug_TTF, rho=0)
        diff_1 = survdiff(Surv(Drug_length, TTF_censor)~mut+Regimen_type,
                          data=Data_drug_TTF, rho=1)
        gb[[kk]] = surv_curv_drug(survfit_t, Data_drug_TTF, paste("Time on treatment,", paste0(collapse = ";", mut_gene), "and", paste(input$drug, collapse = ";")), diff_0, diff_1)
        kk = kk + 1
      }
      
      # Survival analysis for mutation, all
      ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode
      for(jj in 1:length(mut_gene)){
        ID_mutation = ID_mutation[ID_mutation %in% (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene[jj]))$Tumor_Sample_Barcode]
      }
      if(length(ID_mutation) > 0){
        Data_drug_TTF = Data_drug_TTF %>% dplyr::mutate(
          mut = case_when(
            ID %in% ID_mutation ~ "All genes",
            ID %in% (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode ~ "Any genes",
            TRUE ~ "No genes"
          )
        )
        Data_drug_TTF_mut = Data_drug_TTF %>% dplyr::filter(Regimen_type == paste(input$drug, collapse = ";"))
        if(dim(Data_drug_TTF_mut)[1] > 0){
          survfit_t <- survfit(Surv(Drug_length, TTF_censor)~mut, data=Data_drug_TTF_mut,type = "kaplan-meier", conf.type = "log-log")
          if(length(Data_drug_TTF_mut[,1]) != survfit_t[[1]][[1]]){
            diff_0 = survdiff(Surv(Drug_length, TTF_censor)~mut,
                              data=Data_drug_TTF_mut, rho=0)
            diff_1 = survdiff(Surv(Drug_length, TTF_censor)~mut,
                              data=Data_drug_TTF_mut, rho=1)
            gb[[kk]] = surv_curv_drug(survfit_t, Data_drug_TTF_mut, paste("Time on treatment,", paste0(collapse = ";", mut_gene), "and", paste(input$drug, collapse = ";")), diff_0, diff_1)
            kk = kk + 1
          }
        }
      }
      if(kk != 9){
        for(kkk in kk:8){
          gb[[kkk]] = ggsurvplot_empty()
        }
      }
      
      Data_drug_TTF$diagnosis = ""
      for(target_diseases in unique(Data_case_target$症例.基本情報.がん種.OncoTree.)){
        Data_drug_TTF = Data_drug_TTF %>% dplyr::mutate(diagnosis = case_when(
          ID %in% unique((Data_case_target %>% dplyr::filter(症例.基本情報.がん種.OncoTree. == target_diseases))$C.CAT調査結果.基本項目.ハッシュID) ~ target_diseases,
          TRUE ~ diagnosis))
      }
      
  
      output$figure_drug_1 = renderPlot({
        if(length(Data_TTF_compare$TTF_pre)>0){
          grid.arrange(ga[[1]], ga[[2]], nrow=2,  ncol = 1)
        }
      })
      incProgress(1 / 13)
      
      output$figure_drug_2 = renderPlot({
        arrange_ggsurvplots(gb,print=TRUE,ncol=2,nrow=4)
      })
      output$figure_drug_3 = renderPlot({
        if(length(unique(Data_drug_TTF$diagnosis)) > 1){
          Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::filter(
            diagnosis %in% sort(names(table(Data_drug_TTF$diagnosis)))[1:min(8,length(unique(diagnosis)))])
          survfit_t <- survfit(Surv(Drug_length, TTF_censor)~diagnosis, data=Data_drug_TTF_tmp,type = "kaplan-meier", conf.type = "log-log")
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~diagnosis,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~diagnosis,
                            data=Data_drug_TTF_tmp, rho=1)
          gc[[1]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp, paste0("Time on treatment, diagnosis, all drugs"), diff_0, diff_1)
          
          Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::filter(Drug %in% input$drug)
          Data_drug_TTF_tmp = Data_drug_TTF_tmp %>% dplyr::filter(
            diagnosis %in% sort(names(table(Data_drug_TTF_tmp$diagnosis)))[1:min(8,length(unique(diagnosis)))])
          if(length(unique(Data_drug_TTF_tmp$diagnosis)) > 1){
              survfit_t <- survfit(Surv(Drug_length, TTF_censor)~diagnosis, data=Data_drug_TTF_tmp,type = "kaplan-meier", conf.type = "log-log")
            diff_0 = survdiff(Surv(Drug_length, TTF_censor)~diagnosis,
                              data=Data_drug_TTF_tmp, rho=0)
            diff_1 = survdiff(Surv(Drug_length, TTF_censor)~diagnosis,
                              data=Data_drug_TTF_tmp, rho=1)
            gc[[2]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp, paste0("Time on treatment, diagnosis, treated with ", paste(input$drug, collapse = ";")), diff_0, diff_1)
          }
          arrange_ggsurvplots(gc,print=TRUE,ncol=1,nrow=2)
        } else {
          g = gg_empty()
          plot(g)
        }
      })
      
      incProgress(1 / 13)
      
      # analysis for common oncogenic mutations
        
      Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::filter(Drug %in% input$drug)
      h = list()
      hs = list()
      hsc = list()
      
      oncogenic_genes = Data_MAF_target %>%
        dplyr::select(Tumor_Sample_Barcode, Hugo_Symbol) %>%
        dplyr::filter(Tumor_Sample_Barcode %in% Data_drug_TTF_tmp$ID) %>%
        dplyr::distinct() %>%
        dplyr::count(Hugo_Symbol) %>%
        dplyr::arrange(-n)
      colnames(oncogenic_genes) = c("gene_mutation", "all_patients")
      oncogenic_genes = oncogenic_genes[1:min(length(oncogenic_genes$all_patients), input$gene_no),]
      
      gene_table = data.frame(oncogenic_genes$gene_mutation)
      colnames(gene_table) = c("Gene")
      gene_table$positive_patients = oncogenic_genes$all_patients
      gene_table$positive_freq = round(1000 * gene_table$positive_patients / length(unique(Data_drug_TTF_tmp$ID))) / 10
      gene_table$positive_median = 0
      gene_table$positive_LL = 0
      gene_table$positive_UL = 0
      gene_table$negative_median = 0
      gene_table$negative_LL = 0
      gene_table$negative_UL = 0
      gene_table$diff_median = 0
      gene_table$diff_LL = 0
      gene_table$diff_UL = 0
      k = 1
      for(i in 1:length(oncogenic_genes$all_patients)){
        ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% oncogenic_genes$gene_mutation[i]))$Tumor_Sample_Barcode
        Data_drug_TTF_tmp = Data_drug_TTF_tmp %>% dplyr::mutate(
          gene_select = case_when(
            ID %in% ID_mutation ~ 1,
            TRUE ~ 0
          )
        )
        traditional_fit = survfit(Surv(event = TTF_censor,
                                       time = Drug_length) ~ gene_select, 
                                  data = Data_drug_TTF_tmp)
        if(length(Data_drug_TTF_tmp[,1]) != traditional_fit[[1]][[1]]){
          tau0 = ((max((Data_drug_TTF_tmp %>% dplyr::filter(gene_select == 0))$Drug_length) - 1)/365.25*12)
          tau1 = ((max((Data_drug_TTF_tmp %>% dplyr::filter(gene_select == 1))$Drug_length) - 1)/365.25*12)
          tau = floor(min(tau0, tau1, input$RMST_drug) * 10) / 10
          verify <- survRM2::rmst2(
            time = Data_drug_TTF_tmp$Drug_length,
            status = Data_drug_TTF_tmp$TTF_censor,
            arm = Data_drug_TTF_tmp$gene_select,
            tau = tau * 365.25 / 12,
            alpha = 0.05
          )
          
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~gene_select,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~gene_select,
                            data=Data_drug_TTF_tmp, rho=1)
          mut_gene = paste(oncogenic_genes$gene_mutation[i],
                           ", top ", i, " gene with oncogenic muts", sep="")
          tmp = data.frame(summary(traditional_fit)$table)
          gene_table$positive_median[i] = tmp$median[1]
          gene_table$positive_LL[i] = tmp$X0.95LCL[1]
          gene_table$positive_UL[i] = tmp$X0.95UCL[1]
          gene_table$negative_median[i] = tmp$median[2]
          gene_table$negative_LL[i] = tmp$X0.95LCL[2]
          gene_table$negative_UL[i] = tmp$X0.95UCL[2]
          gene_table$diff_median[i] = -round(verify$unadjusted.result[1], digits = 1)
          gene_table$diff_LL[i] = -round(verify$unadjusted.result[7], digits = 1)
          gene_table$diff_UL[i] = -round(verify$unadjusted.result[4], digits = 1)
          hs[[k]] = surv_curv_drug(traditional_fit, Data_drug_TTF_tmp, paste(oncogenic_genes$gene_mutation[i], "Oncogenic mut, treated with ", paste(input$drug, collapse = ";")),
                                    diff_0, diff_1)
          k = k + 1
        } else{
          tmp = summary(traditional_fit)$table
          legends = paste0(tmp[[7]], " (", tmp[[8]], "-", tmp[[9]],")")
          gene_table$negative_median[i] = tmp[[7]]
          gene_table$negative_LL[i] = tmp[[8]]
          gene_table$negative_UL[i] = tmp[[9]]
        }
      }
      Gene_arrange = gene_table$Gene
      Gene_data = gene_table
      gene_table = gene_table %>% dplyr::mutate(
        Gene = factor(gene_table$Gene, levels = Gene_arrange))

      p <- 
        gene_table |>
        ggplot(aes(y = fct_rev(Gene))) + 
        theme_classic()
      p <- p +
        geom_point(aes(x=diff_median), shape=15, size=3) +
        geom_linerange(aes(xmin=diff_LL, xmax=diff_UL))
      p <- p +
        geom_vline(xintercept = 0, linetype="dashed") +
        labs(x=paste("Median time on treatment and difference in restricted mean survival time in 6 months with ", paste(input$drug, collapse = ";"), " (days), red:mut (+), blue:mut (-)"), y="Genes with oncogenic alteration")
      p <- p +
        coord_cartesian(ylim=c(1,length(Gene_arrange) + 1),
                        xlim=c( - max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) - 15,
                                max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) + 15))
      p <- p +
        annotate("text",
                 x = (-max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) - 15)/2,
                 y = length(Gene_arrange) + 1,
                 label = "mut=short survival") +
        annotate("text",
                 x = (max(abs(gene_table$diff_LL), abs(gene_table$diff_UL)) + 15)/2,
                 y = length(Gene_arrange) + 1,
                 label = "mut=long survival")
      p_mid <- p + 
        theme(legend.position = "none",
              axis.line.y = element_blank(),
              axis.ticks.y= element_blank(),
              axis.text.y= element_blank(),
              axis.title.y= element_blank())
      gene_table <- gene_table %>%
        dplyr::mutate(
          estimate_lab_1 = paste0(positive_median, " (", positive_LL, "-", positive_UL, ")")) %>%
        dplyr::mutate(
          estimate_lab_2 = paste0(negative_median, " (", negative_LL, "-", negative_UL, ")")) %>%
        dplyr::mutate(
          estimate_lab_3 = paste0(diff_median, " (", diff_LL, "-", diff_UL, ")")) %>%
        dplyr::mutate(
          patients = paste0(positive_patients, " (", positive_freq, "%)"))
      gene_table = 
        dplyr::bind_rows(
          data.frame(
            Gene = "Gene",
            estimate_lab_1 = "ToT, mut (+)",
            estimate_lab_2 = "ToT, mut (-)",
            estimate_lab_3 = "RMST difference",
            patients = "Patients"
          ), gene_table)
      Gene_arrange = gene_table$Gene
      gene_table = gene_table %>% dplyr::mutate(
        Gene = factor(gene_table$Gene, levels = Gene_arrange))
      
      p_left <- gene_table  %>% ggplot(aes(y = fct_rev(Gene)))
      p_left <- p_left + geom_text(aes(x = 0, label = Gene), hjust = 0,
                                   fontface = ifelse(gene_table$Gene == "Gene", "bold", "bold.italic"))
      p_left <- p_left + geom_text(aes(x = 1.4, label = estimate_lab_1), hjust = 0,
                                   fontface = ifelse(gene_table$estimate_lab_1 == "ToT, mut (+)", "bold", "plain"))
      p_left <- p_left + geom_text(aes(x = 2.6, label = estimate_lab_2), hjust = 0,
                                   fontface = ifelse(gene_table$estimate_lab_2 == "ToT, mut (-)", "bold", "plain"))
      p_left <- p_left + geom_text(aes(x = 3.8, label = estimate_lab_3), hjust = 0,
                                   fontface = ifelse(gene_table$estimate_lab_3 == "RMST difference", "bold", "plain"))
      p_left <- p_left + theme_void() + coord_cartesian(xlim = c(0, 6.5))
      
      # right side of plot - pvalues
      p_right <- gene_table  |> ggplot() +
        geom_text(aes(x = 0, y = fct_rev(Gene), label = patients), hjust = 0,
                  fontface = ifelse(gene_table$patients == "Patients", "bold", "plain")) +
        theme_void()

      for(kk in k:32){
        hs[[kk]] = ggsurvplot_empty()
      }
      
      k = 1
      for(i in unique(Data_case_target$cluster)){
        ID_mutation = (Data_case_target %>% dplyr::filter(cluster == i))$C.CAT調査結果.基本項目.ハッシュID
        Data_drug_TTF_tmp = Data_drug_TTF_tmp %>% dplyr::mutate(
          Cluster = case_when(
            ID %in% ID_mutation ~ as.character(i),
            TRUE ~ "Others"
          )
        )
        traditional_fit = survfit(Surv(event = TTF_censor,
                                       time = Drug_length) ~ Cluster, 
                                  data = Data_drug_TTF_tmp)
        if(length(Data_drug_TTF_tmp[,1]) != traditional_fit[[1]][[1]]){
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~Cluster,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~Cluster,
                            data=Data_drug_TTF_tmp, rho=1)
          mut_gene = paste0("Cluster ", i)
          hsc[[k]] = surv_curv_drug(traditional_fit, Data_drug_TTF_tmp, paste0(mut_gene, ", treated with ", paste(input$drug, collapse = ";")),
                                   diff_0, diff_1)
          k = k + 1
        }
      }
      for(kk in k:32){
        hsc[[kk]] = ggsurvplot_empty()
      }
      
      # final plot arrangement
      layout <- c(patchwork::area(t = 0, l = 0, b = 30, r = 5.5),
                  patchwork::area(t = 1, l = 5.5, b = 30, r = 10.5),
                  patchwork::area(t = 0, l = 10.5, b = 30, r = 12))
      h[[1]] = p_left + p_mid + p_right + plot_layout(design = layout)
      
      output$figure_drug_cluster = renderPlot({
        arrange_ggsurvplots(hsc,print=TRUE,ncol=4,nrow=8,surv.plot.height = 0.8,risk.table.height = 0.2)
      })
      output$figure_drug_4 = renderPlot({
        h[[1]]
      })
      output$figure_drug_5 = renderPlot({
        arrange_ggsurvplots(hs,print=TRUE,ncol=4,nrow=8,surv.plot.height = 0.8,risk.table.height = 0.2)
      })
      incProgress(1 / 13)
      
      output$figure_drug_pattern = renderPlot({
        hsa = list()
        mut_gene_ = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
        if(length(mut_gene_)==0){
          mut_gene_ = "TP53"
          ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
          Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_ ~ "TP53 mut(+)",
              TRUE ~ "TP53 mut(-)"
            )
          )
        } else{
          if(is.null(input$gene_group_2)){
            ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
            Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::mutate(
              mutation = case_when(
                ID %in% ID_mutation_ ~ paste0(paste(mut_gene_, collapse = "/"), " mut(+)"),
                TRUE ~ paste0(paste(mut_gene_, collapse = "/"), " mut(-)")
              )
            )
          } else{
            ID_mutation_1 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_1))$Tumor_Sample_Barcode
            ID_mutation_2 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_2))$Tumor_Sample_Barcode
            Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::mutate(
              mutation = case_when(
                ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
                ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
                !ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
                !ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
              )
            )
          }
        }
        if(!input$special_gene == ""){
          ID_special_gene = (Data_MAF_target %>%
                               dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_"))))$Tumor_Sample_Barcode
          ID_special_gene_mutation_1 = (Data_MAF_target %>%
                                          dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                          amino.acid.change %in% input$special_gene_mutation_1))$Tumor_Sample_Barcode
          ID_special_gene_mutation_2 = (Data_MAF_target %>%
                                          dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                          amino.acid.change %in% input$special_gene_mutation_2))$Tumor_Sample_Barcode
          Data_drug_TTF_tmp = Data_drug_TTF_tmp %>% dplyr::mutate(
            separation_value = case_when(
              ID %in% ID_special_gene_mutation_1 ~ paste0(input$special_gene_mutation_1_name, " in ", input$special_gene),
              ID %in% ID_special_gene_mutation_2 ~ paste0(input$special_gene_mutation_2_name, " in ", input$special_gene),
              ID %in% ID_special_gene ~ paste0("Other mut in ", input$special_gene),
              TRUE ~ paste0("No mut in ", input$special_gene)
            )
          )
        } else{
          Data_drug_TTF_tmp = Data_drug_TTF_tmp %>% dplyr::mutate(
            separation_value = "No mutation pattern")
        }
        kkk = 1
        if(length(unique(Data_drug_TTF_tmp$mutation)) > 1){
          survfit_t <- survfit(Surv(Drug_length, TTF_censor)~mutation, data=Data_drug_TTF_tmp,type = "kaplan-meier", conf.type = "log-log")
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~mutation,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~mutation,
                            data=Data_drug_TTF_tmp, rho=1)
          hsa[[kkk]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp, paste0("Time on treatment, mutation, all drugs"), diff_0, diff_1)
          kkk = kkk + 1
        }
        if(length(unique(Data_drug_TTF_tmp$separation_value)) > 1){
          survfit_t <- survfit(Surv(Drug_length, TTF_censor)~separation_value, data=Data_drug_TTF_tmp,type = "kaplan-meier", conf.type = "log-log")
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~separation_value,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~separation_value,
                            data=Data_drug_TTF_tmp, rho=1)
          hsa[[kkk]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp, paste0("Time on treatment, mutation pattern, all drugs"), diff_0, diff_1)
          kkk = kkk + 1
        }
        Data_drug_TTF_tmp = Data_drug_TTF_tmp %>% dplyr::filter(Drug %in% input$drug)
        if(length(unique(Data_drug_TTF_tmp$mutation)) > 1){
          survfit_t <- survfit(Surv(Drug_length, TTF_censor)~mutation, data=Data_drug_TTF_tmp,type = "kaplan-meier", conf.type = "log-log")
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~mutation,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~mutation,
                            data=Data_drug_TTF_tmp, rho=1)
          hsa[[kkk]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp, paste0("Time on treatment, mutation, treated with ", paste(input$drug, collapse = ";")), diff_0, diff_1)
          kkk = kkk + 1
        }
        if(length(unique(Data_drug_TTF_tmp$separation_value)) > 1){
          survfit_t <- survfit(Surv(Drug_length, TTF_censor)~separation_value, data=Data_drug_TTF_tmp,type = "kaplan-meier", conf.type = "log-log")
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~separation_value,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~separation_value,
                            data=Data_drug_TTF_tmp, rho=1)
          hsa[[kkk]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp, paste0("Time on treatment, mutation pattern, treated with ", paste(input$drug, collapse = ";")), diff_0, diff_1)
          kkk = kkk + 1
        }
        if(input$HER2 != "No"){
          ID_mutation_P = (Data_case_target %>% dplyr::filter(HER2_IHC == "Positive"))$C.CAT調査結果.基本項目.ハッシュID
          ID_mutation_N = (Data_case_target %>% dplyr::filter(HER2_IHC == "Negative"))$C.CAT調査結果.基本項目.ハッシュID
          Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::mutate(
            HER2 = case_when(
              ID %in% ID_mutation_P ~ "HER2 IHC (+)",
              ID %in% ID_mutation_N ~ "HER2 IHC (-)",
              TRUE ~ "Unknown"
            )
          )
          Data_drug_TTF_tmp_ = Data_drug_TTF_tmp %>%
            dplyr::filter(HER2 != "Unknown")
          if(length(unique(Data_drug_TTF_tmp_$HER2)) > 1){
            survfit_t <- survfit(Surv(Drug_length, TTF_censor)~HER2, data=Data_drug_TTF_tmp_,type = "kaplan-meier", conf.type = "log-log")
            diff_0 = survdiff(Surv(Drug_length, TTF_censor)~HER2,
                              data=Data_drug_TTF_tmp_, rho=0)
            diff_1 = survdiff(Surv(Drug_length, TTF_censor)~HER2,
                              data=Data_drug_TTF_tmp_, rho=1)
            hsa[[kkk]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp_, paste0("Time on treatment, mutation pattern, treated with ", paste(input$drug, collapse = ";")), diff_0, diff_1)
            kkk = kkk + 1
          }
        }
        if(input$MSI != "No"){
          ID_mutation_P = (Data_case_target %>% dplyr::filter(MSI_PCR == "dMMR"))$C.CAT調査結果.基本項目.ハッシュID
          ID_mutation_N = (Data_case_target %>% dplyr::filter(MSI_PCR == "pMMR"))$C.CAT調査結果.基本項目.ハッシュID
          Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::mutate(
            MSI = case_when(
              ID %in% ID_mutation_P ~ "MSI PCR dMMR",
              ID %in% ID_mutation_N ~ "MSI PCR pMMR",
              TRUE ~ "Unknown"
            )
          )
          Data_drug_TTF_tmp_ = Data_drug_TTF_tmp %>%
            dplyr::filter(MSI != "Unknown")
          if(length(unique(Data_drug_TTF_tmp_$MSI)) > 1){
            survfit_t <- survfit(Surv(Drug_length, TTF_censor)~HER2, data=Data_drug_TTF_tmp_,type = "kaplan-meier", conf.type = "log-log")
            diff_0 = survdiff(Surv(Drug_length, TTF_censor)~MSI,
                              data=Data_drug_TTF_tmp_, rho=0)
            diff_1 = survdiff(Surv(Drug_length, TTF_censor)~MSI,
                              data=Data_drug_TTF_tmp_, rho=1)
            hsa[[kkk]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp_, paste0("Time on treatment, mutation pattern, treated with ", paste(input$drug, collapse = ";")), diff_0, diff_1)
            kkk = kkk + 1
          }
        }
        if(input$MMR != "No"){
          ID_mutation_P = (Data_case_target %>% dplyr::filter(MMR_IHC == "Positive"))$C.CAT調査結果.基本項目.ハッシュID
          ID_mutation_N = (Data_case_target %>% dplyr::filter(MMR_IHC == "Negative"))$C.CAT調査結果.基本項目.ハッシュID
          Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::mutate(
            MMR = case_when(
              ID %in% ID_mutation_P ~ "MMR IHC (+)",
              ID %in% ID_mutation_N ~ "MMR IHC (-)",
              TRUE ~ "Unknown"
            )
          )
          Data_drug_TTF_tmp_ = Data_drug_TTF_tmp %>%
            dplyr::filter(MMR != "Unknown")
          if(length(unique(Data_drug_TTF_tmp_$MMR)) > 1){
            survfit_t <- survfit(Surv(Drug_length, TTF_censor)~HER2, data=Data_drug_TTF_tmp_,type = "kaplan-meier", conf.type = "log-log")
            diff_0 = survdiff(Surv(Drug_length, TTF_censor)~MMR,
                              data=Data_drug_TTF_tmp_, rho=0)
            diff_1 = survdiff(Surv(Drug_length, TTF_censor)~MMR,
                              data=Data_drug_TTF_tmp_, rho=1)
            hsa[[kkk]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp_, paste0("Time on treatment, mutation pattern, treated with ", paste(input$drug, collapse = ";")), diff_0, diff_1)
            kkk = kkk + 1
          }
        }
        if(kkk<=18){
          for(kkkk in kkk:18){
            hsa[[kkkk]] = ggsurvplot_empty()
          }
        }
        arrange_ggsurvplots(hsa,print=TRUE,ncol=min(3, length(hsa)), nrow=ceiling(length(hsa)/3),surv.plot.height = 0.8,risk.table.height = 0.2)
      })
      incProgress(1 / 13)
      
      Data_drug_RECIST = Data_drug_RECIST %>%
        dplyr::filter(Drug %in% input$drug) %>%
        dplyr::filter(治療ライン %in% input$target_line) %>%
        dplyr::arrange(ID, 治療ライン) %>%
        dplyr::distinct(ID, Drug, .keep_all = T)
  
      Drug_summary_RECIST =  Data_drug_RECIST %>%
        dplyr::filter(最良総合効果 != "NE") %>%
        dplyr::select(
          ID,
          Drug,
          治療ライン,
          最良総合効果,
          終了理由,
          Drug_length,
          TTF_censor,
        )
      colnames(Drug_summary_RECIST)=
        c("ID", "治療薬", "治療ライン", "RECIST", "終了理由", "Time on treatment", "打ち切り0,終了1")
      Drug_summary_RECIST$終了理由[Drug_summary_RECIST$終了理由 == ""] = "入力なし"
      if(!input$special_gene == ""){
        Data_MAF_target_tmp = Data_MAF_target_tmp %>%
          dplyr::filter(Tumor_Sample_Barcode %in%
                          Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
          dplyr::arrange(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change)
        
        ID_special_gene = (Data_MAF_target_tmp %>%
                             dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_"))))$Tumor_Sample_Barcode
        ID_special_gene_mutation_1 = (Data_MAF_target_tmp %>%
                                        dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                        amino.acid.change %in% input$special_gene_mutation_1))$Tumor_Sample_Barcode
        ID_special_gene_mutation_2 = (Data_MAF_target_tmp %>%
                                        dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                        amino.acid.change %in% input$special_gene_mutation_2))$Tumor_Sample_Barcode
        Drug_summary_RECIST_line = Drug_summary_RECIST %>% dplyr::mutate(
          separation_value = case_when(
            ID %in% ID_special_gene_mutation_1 ~ paste0(input$special_gene_mutation_1_name, " in ", input$special_gene),
            ID %in% ID_special_gene_mutation_2 ~ paste0(input$special_gene_mutation_2_name, " in ", input$special_gene),
            ID %in% ID_special_gene ~ paste0("Other mut in ", input$special_gene),
            TRUE ~ paste0("No mut in ", input$special_gene)
          )
        )
      } else{
        Drug_summary_RECIST_line = Drug_summary_RECIST %>% dplyr::mutate(
          separation_value = "No mutation pattern")
      }
      colnames(Drug_summary_RECIST_line)=
        c("ID", "Drugs", "CTx line", "RECIST", "Reason to finish treatment", "Time on treatment", "Treatment finished or censored", "separation_value")
      Drug_summary_RECIST_line$`Reason to finish treatment`[is.na(Drug_summary_RECIST_line$`Reason to finish treatment`)] = "Unknown"
      Drug_summary_RECIST_line$`Reason to finish treatment`[Drug_summary_RECIST_line$`Reason to finish treatment` == "その他理由で中止"] = "Other reason"
      Drug_summary_RECIST_line$`Reason to finish treatment`[Drug_summary_RECIST_line$`Reason to finish treatment` == "不明"] = "Unknown"
      Drug_summary_RECIST_line$`Reason to finish treatment`[Drug_summary_RECIST_line$`Reason to finish treatment` == "副作用等で中止"] = "Side effect"
      Drug_summary_RECIST_line$`Reason to finish treatment`[Drug_summary_RECIST_line$`Reason to finish treatment` == "本人希望により中止"] = "Patient will"
      Drug_summary_RECIST_line$`Reason to finish treatment`[Drug_summary_RECIST_line$`Reason to finish treatment` == "無効中止"] = "Not effective"
      Drug_summary_RECIST_line$`Reason to finish treatment`[Drug_summary_RECIST_line$`Reason to finish treatment` == "計画通り終了"] = "As planned"
      Drug_summary_RECIST_line$`Treatment finished or censored` = as.character(Drug_summary_RECIST_line$`Treatment finished or censored`)
      Drug_summary_RECIST_line$`Treatment finished or censored`[is.na(Drug_summary_RECIST_line$`Treatment finished or censored`)] = "Unknown"
      Drug_summary_RECIST_line$`Treatment finished or censored`[Drug_summary_RECIST_line$`Treatment finished or censored` == "1"] = "Finished"
      Drug_summary_RECIST_line$`Treatment finished or censored`[Drug_summary_RECIST_line$`Treatment finished or censored` == "0"] = "Censored"
      
      output$table_drug_RECIST_1 <- render_gt({
        Drug_summary_RECIST_line %>%
          dplyr::select(-ID) %>%
          tbl_summary(
            by = "separation_value",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx with RECIST evaluation, selected lines, by mutation pattern**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      
      Drug_summary_RECIST_diagnosis = Drug_summary_RECIST_line
      ID_diagnosis_list = Data_case_target %>% dplyr::select(C.CAT調査結果.基本項目.ハッシュID,症例.基本情報.がん種.OncoTree.)
      Drug_summary_RECIST_diagnosis$diagnosis = unlist(lapply(list(Drug_summary_RECIST_diagnosis$ID), function(x) {
        as.vector(ID_diagnosis_list$症例.基本情報.がん種.OncoTree.[match(x, ID_diagnosis_list$C.CAT調査結果.基本項目.ハッシュID)])}))
      output$table_drug_RECIST_2 <- render_gt({
        Drug_summary_RECIST_diagnosis %>%
          dplyr::select(-ID, -separation_value) %>%
          tbl_summary(
            by = "diagnosis",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx with RECIST evaluation, selected lines, by diagnosis**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      
      mut_gene_ = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
      if(length(mut_gene_)==0){
        mut_gene_ = "TP53"
        ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
        Drug_summary_RECIST_mutation = Drug_summary_RECIST_diagnosis %>% dplyr::mutate(
          mutation = case_when(
            ID %in% ID_mutation_ ~ "TP53 mut(+)",
            TRUE ~ "TP53 mut(-)"
          )
        )
      } else{
        if(is.null(input$gene_group_2)){
          ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
          Drug_summary_RECIST_mutation = Drug_summary_RECIST_diagnosis %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_ ~ paste0(paste(mut_gene_, collapse = "/"), " mut(+)"),
              TRUE ~ paste0(paste(mut_gene_, collapse = "/"), " mut(-)")
            )
          )
        } else{
          mut_gene_ = input$gene
          ID_mutation_1 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_1))$Tumor_Sample_Barcode
          ID_mutation_2 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_2))$Tumor_Sample_Barcode
          Drug_summary_RECIST_mutation = Drug_summary_RECIST_diagnosis %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
              ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
              !ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
              !ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
            )
          )
        }
      }
      
      output$table_drug_RECIST_3 <- render_gt({
        Drug_summary_RECIST_mutation %>%
          dplyr::select(-ID, -separation_value, -diagnosis) %>%
          tbl_summary(
            by = "mutation",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Palliative CTx with RECIST evaluation, selected lines, by mutation**") %>%
          add_n() %>% bold_labels() %>% as_gt()
      })
      
      Data_forest = Data_drug_RECIST %>%
        dplyr::select(ID, Drug, Drug_length, TTF_censor, 最良総合効果, 治療ライン)
      colnames(Data_forest) = c("ID", "Drug", "Drug_length", "TTF_censor", "最良総合効果", "Lines")
      Data_survival_tmp = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                      YoungOld,
                      Lymph_met,
                      Brain_met,
                      Lung_met,
                      Bone_met,
                      Liver_met,
                      症例.基本情報.性別.名称.,
                      症例.基本情報.がん種.OncoTree.,
                      症例.基本情報.がん種.OncoTree.LEVEL1.,
                      HER2_IHC,
                      MSI_PCR,
                      MMR_IHC#,
                      #症例.背景情報.喫煙歴有無.名称.,
                      #症例.背景情報.アルコール多飲有無.名称.
                      )
      col_added = 0
      if(input$HER2 != "No"){
        col_added = col_added + 1
      } else {
        Data_survival_tmp = Data_survival_tmp %>%
          dplyr::select(-HER2_IHC)
      }
      if(input$MSI != "No"){
        col_added = col_added + 1
      } else {
        Data_survival_tmp = Data_survival_tmp %>%
          dplyr::select(-MSI_PCR)
      }
      if(input$MMR != "No"){
        col_added = col_added + 1
      } else {
        Data_survival_tmp = Data_survival_tmp %>%
          dplyr::select(-MMR_IHC)
      }
 
      Data_survival_tmp = Data_survival_tmp %>%
        dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE) %>%
        dplyr::filter(C.CAT調査結果.基本項目.ハッシュID %in% Data_forest$ID) #%>%
        # dplyr::mutate(
        #   症例.背景情報.喫煙歴有無.名称. = case_when(
        #     症例.背景情報.喫煙歴有無.名称. == "あり" ~ "Yes",
        #     症例.背景情報.喫煙歴有無.名称. == "なし" ~ "No",
        #     TRUE ~ "Unknown"
        #   ),
        #   症例.背景情報.アルコール多飲有無.名称. = case_when(
        #     症例.背景情報.アルコール多飲有無.名称. == "あり" ~ "Yes",
        #     症例.背景情報.アルコール多飲有無.名称. == "なし" ~ "No",
        #     TRUE ~ "Unknown"
        #   )
        # )
      colnames_tmp = colnames(Data_survival_tmp)
      colnames_tmp[colnames_tmp == "C.CAT調査結果.基本項目.ハッシュID"] = "ID"
      colnames_tmp[colnames_tmp == "YoungOld"] = "Age"
      colnames_tmp[colnames_tmp == "症例.基本情報.性別.名称."] = "Sex"
      colnames_tmp[colnames_tmp == "症例.基本情報.がん種.OncoTree."] = "Histology"
      colnames_tmp[colnames_tmp == "症例.基本情報.がん種.OncoTree.LEVEL1."] = "Histology_dummy"
      colnames(Data_survival_tmp) = colnames_tmp
      
      #Data_survival_tmp$Histology_dummy = paste0(Data_survival_tmp$Histology_dummy,"_NOS")
      Data_survival_tmp$Age[is.na(Data_survival_tmp$Age)] <- "不明"
      Data_forest = left_join(Data_forest, Data_survival_tmp, by="ID")
      Data_forest = Data_forest %>% dplyr::mutate(
        Lines = case_when(
          Lines == "0" ~ "0",
          Lines == "1" ~ "1",
          TRUE ~ "2~"
        ),
        ORR_data = case_when(
          最良総合効果 %in% c("CR", "PR") ~ 1,
          最良総合効果 %in% c("LongSD", "SD", "PD") ~ 0,
          最良総合効果 %in% c("NE") ~ -1,
          TRUE ~ -1
        ),
        DCR_data = case_when(
          最良総合効果 %in% c("CR", "PR", "LongSD", "SD") ~ 1,
          最良総合効果 %in% c("PD") ~ 0,
          最良総合効果 %in% c("NE") ~ -1,
          TRUE ~ -1
        )
      )
      gene_names = unique(c(input$gene,
                            as.character((Gene_data %>% dplyr::arrange(positive_UL))$Gene)))
      gene_names = gene_names[gene_names %in% unique(Data_MAF_target$Hugo_Symbol)]
      gene_names = gene_names[1:min(8, length(gene_names))]
      for(i in 1:length(gene_names)){
        ID_mutation = unique((Data_MAF_target %>% dplyr::filter(Hugo_Symbol == gene_names[i]))$Tumor_Sample_Barcode)
        Data_forest_tmp = Data_forest %>%
          dplyr::select(ID) %>%
          dplyr::distinct() %>%
          dplyr::mutate(
            XXX = case_when(
              ID %in% ID_mutation ~ "mut(+)",
              TRUE ~ "mut(-)"
            )
          )
        colnames(Data_forest_tmp) = c("ID", gene_names[i])
        Data_forest = left_join(Data_forest, Data_forest_tmp, by="ID")
      }
  
  
      Factor_names = colnames(Data_forest)
      Factor_names = Factor_names[!Factor_names %in% c('ID', 'Drug',
                                                       "TTF_censor", "Drug_length",
                                                       "最良総合効果", "ORR_data", "DCR_data")]
      Data_forest = Data_forest %>%
        dplyr::filter(Sex != "未入力・不明") %>%
        dplyr::filter(Age != "不明") #%>%
        #dplyr::filter(Smoking_history != "Unknown" & Alcoholic_history != "Unknown")
      if(input$HER2 != "No"){
        Data_forest = Data_forest %>%
          dplyr::filter(HER2_IHC != "Unknown")
      }
      if(input$MSI != "No"){
        Data_forest = Data_forest %>%
          dplyr::filter(MSI_PCR != "Unknown")
      }
      if(input$MMR != "No"){
        Data_forest = Data_forest %>%
          dplyr::filter(MMR_IHC != "Unknown")
      }
      
      Data_forest_tmp = Data_forest %>% dplyr::filter(!is.na(TTF_censor))
      Disease_tmp = unique(sort(Data_forest_tmp$Histology))
      Disease_tmp2 = unique(sort(Data_forest_tmp$Histology_dummy))
      Disease_tmp = c(Disease_tmp[!Disease_tmp %in% Disease_tmp2], Disease_tmp2)
      for(i in length(gene_names):1){
        if(sum(Data_forest_tmp[,17+col_added+i] == "mut(+)" & Data_forest_tmp$TTF_censor == 1) < 3){
          Factor_names = Factor_names[-(10+col_added+i)]
        } else if(sum(Data_forest_tmp[,17+col_added+i] == "mut(-)" & Data_forest_tmp$TTF_censor == 1) < 3){
          Factor_names = Factor_names[-(10+col_added+i)]
        }
      }
      for(i in 1:length(Disease_tmp)){
        Data_forest_tmp2 = Data_forest_tmp %>% dplyr::filter(Histology == Disease_tmp[i])
        if(sum(Data_forest_tmp2$TTF_censor == 1,na.rm = T) < 3){
          Data_forest_tmp = Data_forest_tmp %>%
            dplyr::mutate(Histology = case_when(
              Histology == Disease_tmp[i] ~ Histology_dummy,
              TRUE ~ Histology
            )
          )
        } else {
          Data_forest_tmp2 = Data_forest_tmp %>% dplyr::filter(Histology != Disease_tmp[i])
          if(sum(Data_forest_tmp2$TTF_censor == 1,na.rm = T) < 3){
            Data_forest_tmp = Data_forest_tmp %>%
              dplyr::mutate(Histology = case_when(
                Histology == Disease_tmp[i] ~ Histology_dummy,
                TRUE ~ Histology
              )
              )
          }
        }
      }
      if(length(unique(Data_forest_tmp$Histology))<2){
        Factor_names = Factor_names[!Factor_names %in% c('Histology')]
      }
      if(sum(Data_forest_tmp$Age == "Younger" & Data_forest_tmp$TTF_censor == 1,na.rm = T) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Age')]
      } else if(sum(Data_forest_tmp$Age == "Older" & Data_forest_tmp$TTF_censor == 1,na.rm = T) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Age')]
      }
      if(sum(Data_forest_tmp$Sex == "男" & Data_forest_tmp$TTF_censor == 1,na.rm = T) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Sex')]
      } else if(sum(Data_forest_tmp$Sex != "男" & Data_forest_tmp$TTF_censor == 1,na.rm = T) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Sex')]
      }
      # if(sum(Data_forest_tmp$Smoking_history == "Yes" & Data_forest_tmp$TTF_censor == 1,na.rm = T) < 3){
      #   Factor_names = Factor_names[!Factor_names %in% c('Smoking_history')]
      # } else if(sum(Data_forest_tmp$Smoking_history != "Yes" & Data_forest_tmp$TTF_censor == 1,na.rm = T) < 3){
      #   Factor_names = Factor_names[!Factor_names %in% c('Smoking_history')]
      # }
      # if(sum(Data_forest_tmp$Alcoholic_history == "Yes" & Data_forest_tmp$TTF_censor == 1,na.rm = T) < 3){
      #   Factor_names = Factor_names[!Factor_names %in% c('Alcoholic_history')]
      # } else if(sum(Data_forest_tmp$Alcoholic_history != "Yes" & Data_forest_tmp$TTF_censor == 1,na.rm = T) < 3){
      #   Factor_names = Factor_names[!Factor_names %in% c('Alcoholic_history')]
      # }
      if(sum(Data_forest_tmp$Lines == "1" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lines')]
      } else if(sum(Data_forest_tmp$Lines != "1" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lines')]
      } else if(sum(Data_forest_tmp$Lines == "0" & Data_forest_tmp$TTF_censor == 1) < 3){
        Data_forest_tmp$Lines[Data_forest_tmp$Lines == "0"] = "0~1"
        Data_forest_tmp$Lines[Data_forest_tmp$Lines == "1"] = "0~1"
      } else if(sum(Data_forest_tmp$Lines == "2~" & Data_forest_tmp$TTF_censor == 1) < 3){
        Data_forest_tmp$Lines[Data_forest_tmp$Lines == "2~"] = "1~"
        Data_forest_tmp$Lines[Data_forest_tmp$Lines == "1"] = "1~"
      }
      if(sum(Data_forest_tmp$Lymph_met == "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lymph_met')]
      } else if(sum(Data_forest_tmp$Lymph_met != "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lymph_met')]
      }
      if(sum(Data_forest_tmp$Lung_met == "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lung_met')]
      } else if(sum(Data_forest_tmp$Lung_met != "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Lung_met')]
      }
      if(sum(Data_forest_tmp$Brain_met == "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Brain_met')]
      } else if(sum(Data_forest_tmp$Brain_met != "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Brain_met')]
      }
      if(sum(Data_forest_tmp$Bone_met == "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Bone_met')]
      } else if(sum(Data_forest_tmp$Bone_met != "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Bone_met')]
      }
      if(sum(Data_forest_tmp$Liver_met == "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Liver_met')]
      } else if(sum(Data_forest_tmp$Liver_met != "Yes" & Data_forest_tmp$TTF_censor == 1) < 3){
        Factor_names = Factor_names[!Factor_names %in% c('Liver_met')]
      }
      if(input$HER2 != "No"){
        if(sum(Data_forest_tmp$HER2_IHC == "Positive" & Data_forest_tmp$TTF_censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('HER2_IHC')]
        } else if(sum(Data_forest_tmp$HER2_IHC != "Positive" & Data_forest_tmp$TTF_censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('HER2_IHC')]
        }
      }
      if(input$MSI != "No"){
        if(sum(Data_forest_tmp$MSI_PCR == "Positive" & Data_forest_tmp$TTF_censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('MSI_PCR')]
        } else if(sum(Data_forest_tmp$MSI_PCR != "Positive" & Data_forest_tmp$TTF_censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('MSI_PCR')]
        }
      }
      if(input$MMR != "No"){
        if(sum(Data_forest_tmp$MMR_IHC == "dMMR" & Data_forest_tmp$TTF_censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('MMR_IHC')]
        } else if(sum(Data_forest_tmp$MMR_IHC != "dMMR" & Data_forest_tmp$TTF_censor == 1) < 3){
          Factor_names = Factor_names[!Factor_names %in% c('MMR_IHC')]
        }
      }
      if(length(Factor_names) > 1){
        for(i in length(Factor_names):1){
          if(all(Data_forest_tmp[,colnames(Data_forest_tmp) == Factor_names[i]] ==
                 Data_forest_tmp[1,colnames(Data_forest_tmp) == Factor_names[i]])){
            Factor_names = Factor_names[Factor_names != Factor_names[i]]
          }
        }
      }
      Factor_names = Factor_names[!Factor_names %in% c('Histology_dummy')]
      Factor_names_univariant = Factor_names
      if(length(Factor_names) > 1){
        Factor_names_tmp = Factor_names
        for(i in 1:(length(Factor_names_tmp) - 1)){
          for(j in (i+1):length(Factor_names_tmp)){
            if(Factor_names_tmp[i] %in% colnames(Data_forest_tmp) &
               Factor_names_tmp[j] %in% colnames(Data_forest_tmp)){
              if(mean(Data_forest_tmp[,colnames(Data_forest_tmp) == Factor_names_tmp[i]] ==
                      Data_forest_tmp[,colnames(Data_forest_tmp) == Factor_names_tmp[j]]) > 0.95){
                Factor_names = Factor_names[Factor_names != Factor_names_tmp[j]]
              }
            }
          }
        }
      }
      Data_forest_tmp_x = Data_forest_tmp
      Factor_names_x = Factor_names
      Factor_names_x_univariant = Factor_names_univariant
      output$figure_drug_6 = render_gt({
        if(length(Factor_names_x) > 0){
          if("Sex" %in% colnames(Data_forest_tmp_x)){
            Data_forest_tmp_x = Data_forest_tmp_x %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          colnames_tmp = colnames(Data_forest_tmp_x)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "EP_option"] = "Treatment recommended"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines"
          Factor_names_x[Factor_names_x == "Lymph_met"] = "Lymphatic metastasis"
          Factor_names_x[Factor_names_x == "Liver_met"] = "Liver metastasis"
          Factor_names_x[Factor_names_x == "Lung_met"] = "Lung metastasis"
          Factor_names_x[Factor_names_x == "Bone_met"] = "Bone metastasis"
          Factor_names_x[Factor_names_x == "Brain_met"] = "Brain metastasis"
          Factor_names_x[Factor_names_x == "EP_option"] = "Treatment recommended"
          Factor_names_x[Factor_names_x == "PS"] = "Performance status"
          Factor_names_x[Factor_names_x == "Lines"] = "CTx lines"
          Factor_names_x_univariant[Factor_names_x_univariant == "Lymph_met"] = "Lymphatic metastasis"
          Factor_names_x_univariant[Factor_names_x_univariant == "Liver_met"] = "Liver metastasis"
          Factor_names_x_univariant[Factor_names_x_univariant == "Lung_met"] = "Lung metastasis"
          Factor_names_x_univariant[Factor_names_x_univariant == "Bone_met"] = "Bone metastasis"
          Factor_names_x_univariant[Factor_names_x_univariant == "Brain_met"] = "Brain metastasis"
          Factor_names_x_univariant[Factor_names_x_univariant == "EP_option"] = "Treatment recommended"
          Factor_names_x_univariant[Factor_names_x_univariant == "PS"] = "Performance status"
          Factor_names_x_univariant[Factor_names_x_univariant == "Lines"] = "CTx lines"
          colnames(Data_forest_tmp_x) = colnames_tmp
          Formula = as.formula(paste0("Surv(Drug_length, TTF_censor) ~ ",
                                      paste( paste0("`",Factor_names_x,"`"), collapse = "+")))
          linelistsurv_cox <-  coxph(formula = Formula,
                                     data = Data_forest_tmp_x,
                                     control = coxph.control(iter.max = 50))
          univ_tab <- Data_forest_tmp_x %>% 
            tbl_uvregression(
              method = coxph,
              y = Surv(time = Drug_length, event = TTF_censor),
              include = Factor_names_x_univariant,
              exponentiate = TRUE
            ) |>
            add_global_p() |> # add global p-value
            add_n(location = "level") |>
            add_nevent(location = "level") |> # add number of events of the outcome
            add_q() |> # adjusts global p-values for multiple testing
            bold_p() |> # bold p-values under a given threshold (default 0.05)
            modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            bold_labels()
           final_mv_reg <- linelistsurv_cox %>%
            stats::step(direction = "backward", trace = FALSE)
          if(!is.null(final_mv_reg$xlevels)){
            mv_tab = final_mv_reg |>
              tbl_regression(
                exponentiate = TRUE
              ) |>
              add_global_p() |> # add global p-value
              add_q() |> # adjusts global p-values for multiple testing
              bold_p() |> # bold p-values under a given threshold (default 0.05)
              modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              bold_labels()
            tbl_merge(
              tbls = list(univ_tab, mv_tab),
              tab_spanner = c("**Univariate**", "**Multivariable**")) |>
              modify_caption(paste0("Hazard ratio for Treatment discontinuation with ", paste(input$drug, collapse = ";"), " (Only factors with >2 events observed)")) |> as_gt()
          } else {
            univ_tab |>
              modify_caption(paste0("Hazard ratio for Treatment discontinuation with ", paste(input$drug, collapse = ";"), ", no significant factor in multivariable analysis (Only factors with >2 events observed)")) |> as_gt()
          }
        }
      })

      incProgress(1 / 13)
      
      Data_forest_tmp_1 = Data_forest  %>%
        dplyr::filter(ORR_data != -1) %>%
        dplyr::select(-ID, -Drug,
                      -TTF_censor, -Drug_length,
                      -最良総合効果, -DCR_data)
      Disease_tmp_1 = unique(sort(Data_forest_tmp_1$Histology))
      Disease_tmp_12 = unique(sort(Data_forest_tmp_1$Histology_dummy))
      Disease_tmp_1 = c(Disease_tmp_1[!Disease_tmp_1 %in% Disease_tmp_12], Disease_tmp_12)
      for(i in 1:length(Disease_tmp_1)){
        Data_forest_tmp_12 = Data_forest_tmp_1 %>% dplyr::filter(Histology == Disease_tmp_1[i])
        if(sum(Data_forest_tmp_12$ORR_data == 1,na.rm = T) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1 %>%
            dplyr::mutate(Histology = case_when(
              Histology == Disease_tmp_1[i] ~ Histology_dummy,
              TRUE ~ Histology
            )
            )
        } else {
          Data_forest_tmp_12 = Data_forest_tmp_1 %>% dplyr::filter(Histology == Disease_tmp_1[i])
          if(sum(Data_forest_tmp_12$ORR_data == 1,na.rm = T) < 3){
            Data_forest_tmp_1 = Data_forest_tmp_1 %>%
              dplyr::mutate(Histology = case_when(
                Histology == Disease_tmp_1[i] ~ Histology_dummy,
                TRUE ~ Histology
              )
              )
          }
        }
      }
      for(i in length(gene_names):1){
        if(sum(Data_forest_tmp_1[,11+col_added+i] == "mut(+)" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1[,-(11+col_added+i)]
        } else if(sum(Data_forest_tmp_1[,11+col_added+i] == "mut(-)" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1[,-(11+col_added+i)]
        }
      }
      if(sum(Data_forest_tmp_1$Age == "Younger" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Age)
      } else if(sum(Data_forest_tmp_1$Age == "Older" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Age)
      }
      if(sum(Data_forest_tmp_1$Sex == "男" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Sex)
      } else if(sum(Data_forest_tmp_1$Sex != "男" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Sex)
      }
      # if(sum(Data_forest_tmp_1$Smoking_history == "Yes" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
      #   Data_forest_tmp_1 = Data_forest_tmp_1 %>%
      #     dplyr::select(-Smoking_history)
      # } else if(sum(Data_forest_tmp_1$Smoking_history != "Yes" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
      #   Data_forest_tmp_1 = Data_forest_tmp_1 %>%
      #     dplyr::select(-Smoking_history)
      # }
      # if(sum(Data_forest_tmp_1$Alcoholic_history == "Yes" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
      #   Data_forest_tmp_1 = Data_forest_tmp_1 %>%
      #     dplyr::select(-Alcoholic_history)
      # } else if(sum(Data_forest_tmp_1$Alcoholic_history != "Yes" & Data_forest_tmp_1$ORR_data == 1,na.rm = T) < 3){
      #   Data_forest_tmp_1 = Data_forest_tmp_1 %>%
      #     dplyr::select(-Alcoholic_history)
      # }
      if(sum(Data_forest_tmp_1$Lines == "1" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Lines)
      } else if(sum(Data_forest_tmp_1$Lines != "1" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Lines)
      } else if(sum(Data_forest_tmp_1$Lines == "0" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1$Lines[Data_forest_tmp_1$Lines == "0"] = "0~1"
        Data_forest_tmp_1$Lines[Data_forest_tmp_1$Lines == "1"] = "0~1"
      } else if(sum(Data_forest_tmp_1$Lines == "2~" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1$Lines[Data_forest_tmp_1$Lines == "2~"] = "1~"
        Data_forest_tmp_1$Lines[Data_forest_tmp_1$Lines == "1"] = "1~"
      }
      if(sum(Data_forest_tmp_1$Lymph_met == "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Lymph_met)
      } else if(sum(Data_forest_tmp_1$Lymph_met != "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Lymph_met)
      }
      if(sum(Data_forest_tmp_1$Lung_met == "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Lung_met)
      } else if(sum(Data_forest_tmp_1$Lung_met != "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Lung_met)
      }
      if(sum(Data_forest_tmp_1$Brain_met == "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Brain_met)
      } else if(sum(Data_forest_tmp_1$Brain_met != "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Brain_met)
      }
      if(sum(Data_forest_tmp_1$Bone_met == "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Bone_met)
      } else if(sum(Data_forest_tmp_1$Bone_met != "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Bone_met)
      }
      if(sum(Data_forest_tmp_1$Liver_met == "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Liver_met)
      } else if(sum(Data_forest_tmp_1$Liver_met != "Yes" & Data_forest_tmp_1$ORR_data == 1) < 3){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Liver_met)
      }
      if(input$HER2 != "No"){
        if(sum(Data_forest_tmp_1$HER2_IHC == "Positive" & Data_forest_tmp_1$ORR_data == 1) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1 %>%
            dplyr::select(-HER2_IHC)
        } else if(sum(Data_forest_tmp_1$HER2_IHC != "Positive" & Data_forest_tmp_1$ORR_data == 1) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1 %>%
            dplyr::select(-HER2_IHC)
        }
      }
      if(input$MSI != "No"){
        if(sum(Data_forest_tmp_1$MSI_PCR == "Positive" & Data_forest_tmp_1$ORR_data == 1) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1 %>%
            dplyr::select(-MSI_PCR)
        } else if(sum(Data_forest_tmp_1$MSI_PCR != "Positive" & Data_forest_tmp_1$ORR_data == 1) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1 %>%
            dplyr::select(-MSI_PCR)
        }
      }
      if(input$MMR != "No"){
        if(sum(Data_forest_tmp_1$MMR_IHC == "dMMR" & Data_forest_tmp_1$ORR_data == 1) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1 %>%
            dplyr::select(-MMR_IHC)
        } else if(sum(Data_forest_tmp_1$MMR_IHC != "dMMR" & Data_forest_tmp_1$ORR_data == 1) < 3){
          Data_forest_tmp_1 = Data_forest_tmp_1 %>%
            dplyr::select(-MMR_IHC)
        }
      }
      if(length(unique(Data_forest_tmp_1$Histology))<2){
        Data_forest_tmp_1 = Data_forest_tmp_1 %>%
          dplyr::select(-Histology)
      }
      Data_forest_tmp_1 = Data_forest_tmp_1 %>%
        dplyr::select(-Histology_dummy)
      if(length(colnames(Data_forest_tmp_1)) > 1){
        Factor_names_tmp_1 = colnames(Data_forest_tmp_1)
        for(i in length(Factor_names_tmp_1):1){
          if(all(Data_forest_tmp_1[,colnames(Data_forest_tmp_1) == Factor_names_tmp_1[i]] ==
                 Data_forest_tmp_1[1,colnames(Data_forest_tmp_1) == Factor_names_tmp_1[i]])){
            Data_forest_tmp_1 = Data_forest_tmp_1 %>%
              dplyr::select(-Factor_names_tmp_1[i])
          }
        }
      }
      

      Data_forest_tmp_1_univariant = Data_forest_tmp_1
      if(length(colnames(Data_forest_tmp_1)) > 1){
        Factor_names_tmp_1 = colnames(Data_forest_tmp_1)
        for(i in 1:(length(Factor_names_tmp_1) - 1)){
          for(j in (i+1):length(Factor_names_tmp_1)){
            if(Factor_names_tmp_1[i] %in% colnames(Data_forest_tmp_1) &
               Factor_names_tmp_1[j] %in% colnames(Data_forest_tmp_1)){
              if(mean(Data_forest_tmp_1[,colnames(Data_forest_tmp_1) == Factor_names_tmp_1[i]] ==
                      Data_forest_tmp_1[,colnames(Data_forest_tmp_1) == Factor_names_tmp_1[j]]) > 0.95){
                Data_forest_tmp_1 = Data_forest_tmp_1 %>%
                  dplyr::select(-Factor_names_tmp_1[j])
              }
            }
          }
        }
      }
      Data_forest_tmp_7 = Data_forest_tmp_1
      Data_forest_tmp_7_univariant = Data_forest_tmp_1_univariant
      output$figure_drug_7 = render_gt({
        if(length(colnames(Data_forest_tmp_7)) > 1){
          Data_forest_tmp_7 = data.frame( lapply(Data_forest_tmp_7, as.factor) )
          Data_forest_tmp_7_univariant = data.frame( lapply(Data_forest_tmp_7_univariant, as.factor) )
          
          if("Histology" %in% colnames(Data_forest_tmp_7)){
            Data_forest_tmp_7$Histology <- relevel(Data_forest_tmp_7$Histology, ref=names(sort(table(Data_forest_tmp_7$Histology),decreasing = T))[[1]]) 
          }
          if("Histology" %in% colnames(Data_forest_tmp_7_univariant)){
            Data_forest_tmp_7_univariant$Histology <- relevel(Data_forest_tmp_7_univariant$Histology, ref=names(sort(table(Data_forest_tmp_7_univariant$Histology),decreasing = T))[[1]]) 
          }
          if("Sex" %in% colnames(Data_forest_tmp_7)){
            Data_forest_tmp_7 = Data_forest_tmp_7 %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          if("Sex" %in% colnames(Data_forest_tmp_7_univariant)){
            Data_forest_tmp_7_univariant = Data_forest_tmp_7_univariant %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          colnames_tmp = colnames(Data_forest_tmp_7)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines"
          colnames(Data_forest_tmp_7) = colnames_tmp
          colnames_tmp = colnames(Data_forest_tmp_7_univariant)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines"
          colnames(Data_forest_tmp_7_univariant) = colnames_tmp
          univ_tab <- Data_forest_tmp_7_univariant %>% 
            tbl_uvregression(                         ## 単変量解析の表を生成
              method = glm,                           ## 実行したい回帰（一般化線形モデル）を定義
              y = ORR_data,
              method.args = list(family = binomial),  ## 実行したい glm のタイプを定義（ここではロジスティック）
              exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
            ) |>
            add_global_p() |> # add global p-value
            add_n(location = "level") |>
            add_nevent(location = "level") |> # add number of events of the outcome
            add_q() |> # adjusts global p-values for multiple testing
            bold_p() |> # bold p-values under a given threshold (default 0.05)
            modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            bold_labels() 
          m1 <- glm(ORR_data ~., data = Data_forest_tmp_7, family = binomial(link = "logit"))
          final_mv_reg <- m1 %>%
            stats::step(direction = "backward", trace = FALSE)
          if(!is.null(final_mv_reg$xlevels)){
            mv_tab = final_mv_reg |>
              tbl_regression(                         ## 多変量解析の表を生成
                exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
              ) |>
              add_global_p() |> # add global p-value
              add_q() |> # adjusts global p-values for multiple testing
              bold_p() |> # bold p-values under a given threshold (default 0.05)
               modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              bold_labels()
            tbl_merge(
              tbls = list(univ_tab, mv_tab),
              tab_spanner = c("**Univariate**", "**Multivariable**")) |>
              modify_caption(paste("Factors for objective response rate, ", paste(input$drug, collapse = ";"), "multivariable regression (Only patients with >2 events observed)")) |> as_gt()
          } else {
            univ_tab |>
              modify_caption(paste("Factors for objective response rate,", paste(input$drug, collapse = ";"), "(Only patients with >2 events observed), no significant factor in multivariable analysis")) |> as_gt()
          }
        }
      })
      incProgress(1 / 13)

      Data_forest_tmp_2 = Data_forest  %>%
        dplyr::filter(DCR_data != -1) %>%
        dplyr::select(-ID, -Drug,
                      -TTF_censor, -Drug_length,
                      -最良総合効果, -ORR_data)
      Disease_tmp_2 = unique(sort(Data_forest_tmp_2$Histology))
      Disease_tmp_22 = unique(sort(Data_forest_tmp_2$Histology_dummy))
      Disease_tmp_2 = c(Disease_tmp_2[!Disease_tmp_2 %in% Disease_tmp_22], Disease_tmp_22)
      for(i in 1:length(Disease_tmp_2)){
        Data_forest_tmp_22 = Data_forest_tmp_2 %>% dplyr::filter(Histology == Disease_tmp_2[i])
        if(sum(Data_forest_tmp_22$DCR_data == 1,na.rm = T) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2 %>%
            dplyr::mutate(Histology = case_when(
              Histology == Disease_tmp_2[i] ~ Histology_dummy,
              TRUE ~ Histology
            )
            )
        } else{
          Data_forest_tmp_22 = Data_forest_tmp_2 %>% dplyr::filter(Histology != Disease_tmp_2[i])
          if(sum(Data_forest_tmp_22$DCR_data == 1,na.rm = T) < 3){
            Data_forest_tmp_2 = Data_forest_tmp_2 %>%
              dplyr::mutate(Histology = case_when(
                Histology == Disease_tmp_2[i] ~ Histology_dummy,
                TRUE ~ Histology
              )
              )
          }
        }
      }
      for(i in length(gene_names):1){
        if(sum(Data_forest_tmp_2[,11+col_added+i] == "mut(+)" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2[,-(11+col_added+i)]
        } else if(sum(Data_forest_tmp_2[,11+col_added+i] == "mut(-)" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2[,-(11+col_added+i)]
        }
      }
      if(sum(Data_forest_tmp_2$Age == "Younger" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Age)
      } else if(sum(Data_forest_tmp_2$Age == "Older" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Age)
      }
      if(sum(Data_forest_tmp_2$Sex == "男" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Sex)
      } else if(sum(Data_forest_tmp_2$Sex != "男" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Sex)
      }
      # if(sum(Data_forest_tmp_2$Smoking_history == "Yes" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
      #   Data_forest_tmp_2 = Data_forest_tmp_2 %>%
      #     dplyr::select(-Smoking_history)
      # } else if(sum(Data_forest_tmp_2$Smoking_history != "Yes" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
      #   Data_forest_tmp_2 = Data_forest_tmp_2 %>%
      #     dplyr::select(-Smoking_history)
      # }
      # if(sum(Data_forest_tmp_2$Alcoholic_history == "Yes" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
      #   Data_forest_tmp_2 = Data_forest_tmp_2 %>%
      #     dplyr::select(-Alcoholic_history)
      # } else if(sum(Data_forest_tmp_2$Alcoholic_history != "Yes" & Data_forest_tmp_2$DCR_data == 1,na.rm = T) < 3){
      #   Data_forest_tmp_2 = Data_forest_tmp_2 %>%
      #     dplyr::select(-Alcoholic_history)
      # }
      if(sum(Data_forest_tmp_2$Lines == "1" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Lines)
      } else if(sum(Data_forest_tmp_2$Lines != "1" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Lines)
      } else if(sum(Data_forest_tmp_2$Lines == "0" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2$Lines[Data_forest_tmp_2$Lines == "0"] = "0~1"
        Data_forest_tmp_2$Lines[Data_forest_tmp_2$Lines == "1"] = "0~1"
      } else if(sum(Data_forest_tmp_2$Lines == "2~" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2$Lines[Data_forest_tmp_2$Lines == "2~"] = "1~"
        Data_forest_tmp_2$Lines[Data_forest_tmp_2$Lines == "1"] = "1~"
      }
      if(sum(Data_forest_tmp_2$Lymph_met == "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Lymph_met)
      } else if(sum(Data_forest_tmp_2$Lymph_met != "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Lymph_met)
      }
      if(sum(Data_forest_tmp_2$Lung_met == "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Lung_met)
      } else if(sum(Data_forest_tmp_2$Lung_met != "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Lung_met)
      }
      if(sum(Data_forest_tmp_2$Brain_met == "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Brain_met)
      } else if(sum(Data_forest_tmp_2$Brain_met != "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Brain_met)
      }
      if(sum(Data_forest_tmp_2$Bone_met == "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Bone_met)
      } else if(sum(Data_forest_tmp_2$Bone_met != "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Bone_met)
      }
      if(sum(Data_forest_tmp_2$Liver_met == "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Liver_met)
      } else if(sum(Data_forest_tmp_2$Liver_met != "Yes" & Data_forest_tmp_2$DCR_data == 1) < 3){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Liver_met)
      }
      if(input$HER2 != "No"){
        if(sum(Data_forest_tmp_2$HER2_IHC == "Positive" & Data_forest_tmp_2$DCR_data == 1) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2 %>%
            dplyr::select(-HER2_IHC)
        } else if(sum(Data_forest_tmp_2$HER2_IHC != "Positive" & Data_forest_tmp_2$DCR_data == 1) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2 %>%
            dplyr::select(-HER2_IHC)
        }
      }
      if(input$MSI != "No"){
        if(sum(Data_forest_tmp_2$MSI_PCR == "Positive" & Data_forest_tmp_2$DCR_data == 1) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2 %>%
            dplyr::select(-MSI_PCR)
        } else if(sum(Data_forest_tmp_2$MSI_PCR != "Positive" & Data_forest_tmp_2$DCR_data == 1) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2 %>%
            dplyr::select(-MSI_PCR)
        }
      }
      if(input$MMR != "No"){
        if(sum(Data_forest_tmp_2$MMR_IHC == "dMMR" & Data_forest_tmp_2$DCR_data == 1) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2 %>%
            dplyr::select(-MMR_IHC)
        } else if(sum(Data_forest_tmp_2$MMR_IHC != "dMMR" & Data_forest_tmp_2$DCR_data == 1) < 3){
          Data_forest_tmp_2 = Data_forest_tmp_2 %>%
            dplyr::select(-MMR_IHC)
        }
      }
      if(length(unique(Data_forest_tmp_2$Histology))<2){
        Data_forest_tmp_2 = Data_forest_tmp_2 %>%
          dplyr::select(-Histology)
      }
      Data_forest_tmp_2 = Data_forest_tmp_2 %>%
        dplyr::select(-Histology_dummy)
      if(length(colnames(Data_forest_tmp_2)) > 1){
        Factor_names_tmp_2 = colnames(Data_forest_tmp_2)
        for(i in length(Factor_names_tmp_2):1){
          if(all(Data_forest_tmp_2[,colnames(Data_forest_tmp_2) == Factor_names_tmp_2[i]] ==
                 Data_forest_tmp_2[1,colnames(Data_forest_tmp_2) == Factor_names_tmp_2[i]])){
            Data_forest_tmp_2 = Data_forest_tmp_2 %>%
              dplyr::select(-Factor_names_tmp_2[i])
          }
        }
      }
      Data_forest_tmp_2_univariant = Data_forest_tmp_2
      if(length(colnames(Data_forest_tmp_2)) > 1){
        Factor_names_tmp_2 = colnames(Data_forest_tmp_2)
        for(i in 1:(length(Factor_names_tmp_2) - 1)){
          for(j in (i+1):length(Factor_names_tmp_2)){
            if(Factor_names_tmp_2[i] %in% colnames(Data_forest_tmp_2) &
               Factor_names_tmp_2[j] %in% colnames(Data_forest_tmp_2)){
              if(mean(Data_forest_tmp_2[,colnames(Data_forest_tmp_2) == Factor_names_tmp_2[i]] ==
                      Data_forest_tmp_2[,colnames(Data_forest_tmp_2) == Factor_names_tmp_2[j]]) > 0.95){
                Data_forest_tmp_2 = Data_forest_tmp_2 %>%
                  dplyr::select(-Factor_names_tmp_2[j])
              }
            }
          }
        }
      }

      Data_forest_tmp_8 = Data_forest_tmp_2
      Data_forest_tmp_8_univariant = Data_forest_tmp_2_univariant
      output$figure_drug_8 = render_gt({
        if(length(colnames(Data_forest_tmp_8)) > 1){
          Data_forest_tmp_8 = data.frame( lapply(Data_forest_tmp_8, as.factor) )
          Data_forest_tmp_8_univariant = data.frame( lapply(Data_forest_tmp_8_univariant, as.factor) )
          if("Histology" %in% colnames(Data_forest_tmp_8)){
            Data_forest_tmp_8$Histology <- relevel(Data_forest_tmp_8$Histology, ref=names(sort(table(Data_forest_tmp_8$Histology),decreasing = T))[[1]]) 
          }
          if("Histology" %in% colnames(Data_forest_tmp_8_univariant)){
            Data_forest_tmp_8_univariant$Histology <- relevel(Data_forest_tmp_8_univariant$Histology, ref=names(sort(table(Data_forest_tmp_8_univariant$Histology),decreasing = T))[[1]]) 
          }
          if("Sex" %in% colnames(Data_forest_tmp_8)){
            Data_forest_tmp_8 = Data_forest_tmp_8 %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          if("Sex" %in% colnames(Data_forest_tmp_8_univariant)){
            Data_forest_tmp_8_univariant = Data_forest_tmp_8_univariant %>%
              dplyr::mutate(Sex=case_when(
                Sex == "女" ~ "Female",
                TRUE ~ "Male"
              ))
          }
          colnames_tmp = colnames(Data_forest_tmp_8)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines"
          colnames(Data_forest_tmp_8) = colnames_tmp
          colnames_tmp = colnames(Data_forest_tmp_8_univariant)
          colnames_tmp[colnames_tmp == "Lymph_met"] = "Lymphatic metastasis"
          colnames_tmp[colnames_tmp == "Liver_met"] = "Liver metastasis"
          colnames_tmp[colnames_tmp == "Lung_met"] = "Lung metastasis"
          colnames_tmp[colnames_tmp == "Bone_met"] = "Bone metastasis"
          colnames_tmp[colnames_tmp == "Brain_met"] = "Brain metastasis"
          colnames_tmp[colnames_tmp == "PS"] = "Performance status"
          colnames_tmp[colnames_tmp == "Lines"] = "CTx lines"
          colnames(Data_forest_tmp_8_univariant) = colnames_tmp
          univ_tab <- Data_forest_tmp_8_univariant %>% 
            tbl_uvregression(                         ## 単変量解析の表を生成
              method = glm,                           ## 実行したい回帰（一般化線形モデル）を定義
              y = DCR_data,
              method.args = list(family = binomial),  ## 実行したい glm のタイプを定義（ここではロジスティック）
              exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
            ) |>
            add_global_p() |> # add global p-value
            add_n(location = "level") |>
            add_nevent(location = "level") |> # add number of events of the outcome
            add_q() |> # adjusts global p-values for multiple testing
            bold_p() |> # bold p-values under a given threshold (default 0.05)
             modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            bold_labels() 
          m1 <- glm(DCR_data ~., data = Data_forest_tmp_8, family = binomial(link = "logit"))
          final_mv_reg <- m1 %>%
            stats::step(direction = "backward", trace = FALSE)
          if(!is.null(final_mv_reg$xlevels)){
            mv_tab = final_mv_reg |>
              tbl_regression(                         ## 多変量解析の表を生成
                exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
              ) |>
              add_global_p() |> # add global p-value
              add_q() |> # adjusts global p-values for multiple testing
              bold_p() |> # bold p-values under a given threshold (default 0.05)
              modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              bold_labels()
            tbl_merge(
              tbls = list(univ_tab, mv_tab),
              tab_spanner = c("**Univariate**", "**Multivariable**")) |>
              modify_caption(paste("Factors for disease control rate, ", paste(input$drug, collapse = ";"), "multivariable regression (Only patients with >2 events observed)")) |> as_gt()
          } else {
            univ_tab |>
              modify_caption(paste("Factors for disease control rate,", paste(input$drug, collapse = ";"), "(Only patients with >2 events observed), no significant factor in multivariable analysis")) |> as_gt()
          }
        }
      })
      incProgress(1 / 13)
      
      if(!input$special_gene == ""){
        Data_MAF_target_tmp = Data_MAF_target_tmp %>%
          dplyr::filter(Tumor_Sample_Barcode %in%
                          Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
          dplyr::arrange(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change)
        
        ID_special_gene_ = (Data_MAF_target_tmp %>%
                             dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_"))))$Tumor_Sample_Barcode
        ID_special_gene_mutation_1_ = (Data_MAF_target_tmp %>%
                                        dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                        amino.acid.change %in% input$special_gene_mutation_1))$Tumor_Sample_Barcode
        ID_special_gene_mutation_2_ = (Data_MAF_target_tmp %>%
                                        dplyr::filter(Hugo_Symbol == input$special_gene | str_detect(Hugo_Symbol, paste0(input$special_gene, "_")) &
                                                        amino.acid.change %in% input$special_gene_mutation_2))$Tumor_Sample_Barcode
        Data_forest = Data_forest %>% dplyr::mutate(
          separation_value = case_when(
            ID %in% ID_special_gene_mutation_1_ ~ paste0(input$special_gene_mutation_1_name, " in ", input$special_gene),
            ID %in% ID_special_gene_mutation_2_ ~ paste0(input$special_gene_mutation_2_name, " in ", input$special_gene),
            ID %in% ID_special_gene_ ~ paste0("Other mut in ", input$special_gene),
            TRUE ~ paste0("No mut in ", input$special_gene)
          )
        )
      } else{
        Data_forest = Data_forest %>% dplyr::mutate(
          separation_value = "No mutation pattern")
      }
      Table_outcome_pattern_total = NULL
      drug_list = list(input$drug, input$drug_group_1, input$drug_group_2, input$drug_group_3, input$drug_group_4)
      for(drug_count in 1:5){
        drug_name_2 = case_when(
          drug_count == 1 ~ paste(input$drug, collapse = ";"),
          drug_count == 2 ~ input$drug_group_1_name,
          drug_count == 3 ~ input$drug_group_2_name,
          drug_count == 4 ~ input$drug_group_3_name,
          drug_count == 5 ~ input$drug_group_4_name
        )
        Data_summary_pattern = Data_forest %>% dplyr::filter(最良総合効果 != "NE") %>% dplyr::filter(Drug %in% drug_list[[drug_count]])
        if(length(Data_summary_pattern$Drug)>0){
          Table_outcome_pattern = data.frame(c("Total", as.character((Data_summary_pattern %>% group_by(separation_value) %>% tally())$separation_value)))
          colnames(Table_outcome_pattern) = "Pattern"
          Table_outcome_pattern$Drug = drug_name_2
          Table_outcome_pattern$N = 0
          Table_outcome_pattern$OR = 0
          Table_outcome_pattern$ORR = 0
          Table_outcome_pattern$ORR_95CI_LL = 0
          Table_outcome_pattern$ORR_95CI_UL = 0
          Table_outcome_pattern$DC = 0
          Table_outcome_pattern$DCR = 0
          Table_outcome_pattern$DCR_95CI_LL = 0
          Table_outcome_pattern$DCR_95CI_UL = 0
          
          tmp2 = Data_summary_pattern %>% group_by(separation_value) %>% tally()
          Table_outcome_pattern$N[1] = sum(tmp2$n)
          if(length(Table_outcome_pattern$Pattern)>1){
            for(i in 1:(length(Table_outcome_pattern$Pattern)-1)){
              Table_outcome_pattern$N[i+1] = tmp2$n[i]
            }
            
            tmp2 = Data_summary_pattern %>% group_by(separation_value, ORR_data) %>% tally()
            Table_outcome_pattern$OR[1] = sum((tmp2 %>% dplyr::filter(ORR_data == 1))$n)
            for(i in 1:(length(Table_outcome_pattern$Pattern)-1)){
              if(length((tmp2 %>% dplyr::filter(ORR_data == 1 & separation_value == Table_outcome_pattern$Pattern[i+1]))$n)>0){
                Table_outcome_pattern$OR[i+1] = (tmp2 %>% dplyr::filter(ORR_data == 1 & separation_value == Table_outcome_pattern$Pattern[i+1]))$n
              }
            }
            tmp2 = Data_summary_pattern %>% group_by(separation_value, DCR_data) %>% tally()
            Table_outcome_pattern$DC[1] = sum((tmp2 %>% dplyr::filter(DCR_data == 1))$n)
            for(i in 1:(length(Table_outcome_pattern$Pattern)-1)){
              if(length((tmp2 %>% dplyr::filter(DCR_data == 1 & separation_value == Table_outcome_pattern$Pattern[i+1]))$n)>0){
                Table_outcome_pattern$DC[i+1] = (tmp2 %>% dplyr::filter(DCR_data == 1 & separation_value == Table_outcome_pattern$Pattern[i+1]))$n
              }
            }
            
            for(i in 1:length(Table_outcome_pattern$Pattern)){
              Table_outcome_pattern$ORR[i] = Table_outcome_pattern$OR[i] / Table_outcome_pattern$N[i]
              Table_outcome_pattern$DCR[i] = Table_outcome_pattern$DC[i] / Table_outcome_pattern$N[i]
              Table_outcome_pattern$ORR_95CI_LL[i] = exactci(Table_outcome_pattern$OR[i], Table_outcome_pattern$N[i], conf.level=0.95)$conf.int[1]
              Table_outcome_pattern$ORR_95CI_UL[i] = exactci(Table_outcome_pattern$OR[i], Table_outcome_pattern$N[i], conf.level=0.95)$conf.int[2]
              Table_outcome_pattern$DCR_95CI_LL[i] = exactci(Table_outcome_pattern$DC[i], Table_outcome_pattern$N[i], conf.level=0.95)$conf.int[1]
              Table_outcome_pattern$DCR_95CI_UL[i] = exactci(Table_outcome_pattern$DC[i], Table_outcome_pattern$N[i], conf.level=0.95)$conf.int[2]
            }
            Table_outcome_pattern_total = rbind(Table_outcome_pattern_total, Table_outcome_pattern)
          }
        }
      }
      output$table_outcome_1 = DT::renderDataTable(Table_outcome_pattern_total,
                                                   server = FALSE,
                                                   filter = 'top', 
                                                   extensions = c('Buttons'), 
                                                   options = list(pageLength = 100, 
                                                                  scrollX = TRUE,
                                                                  scrollY = "1000px",
                                                                  scrollCollapse = TRUE,
                                                                  dom="Blfrtip",
                                                                  buttons = c('csv', 'copy')))  
      
      Data_forest$Cluster = ""
      for(i in unique(Data_case_target$cluster)){
        ID_mutation = (Data_case_target %>% dplyr::filter(cluster == i))$C.CAT調査結果.基本項目.ハッシュID
        if(length(Data_forest[Data_forest$ID %in% ID_mutation,]$Cluster)>0){
          Data_forest[Data_forest$ID %in% ID_mutation,]$Cluster = paste0("Cluster ", i)
        }
      }
      Table_outcome_cluster_total = NULL
      drug_list = list(input$drug, input$drug_group_1, input$drug_group_2, input$drug_group_3, input$drug_group_4)
      for(drug_count in 1:5){
        drug_name_1 = case_when(
          drug_count == 1 ~ paste(input$drug, collapse = ";"),
          drug_count == 2 ~ input$drug_group_1_name,
          drug_count == 3 ~ input$drug_group_2_name,
          drug_count == 4 ~ input$drug_group_3_name,
          drug_count == 5 ~ input$drug_group_4_name
        )
        Data_summary_cluster = Data_forest %>% dplyr::filter(最良総合効果 != "NE") %>% dplyr::filter(Drug %in% drug_list[[drug_count]])
        if(length(Data_summary_cluster$Drug)>0){
          Table_outcome_cluster = data.frame(c("Total", as.character((Data_summary_cluster %>% group_by(Cluster) %>% tally())$Cluster)))
          colnames(Table_outcome_cluster) = "Cluster"
          Table_outcome_cluster$Drug = drug_name_1
          Table_outcome_cluster$N = 0
          Table_outcome_cluster$OR = 0
          Table_outcome_cluster$ORR = 0
          Table_outcome_cluster$ORR_95CI_LL = 0
          Table_outcome_cluster$ORR_95CI_UL = 0
          Table_outcome_cluster$DC = 0
          Table_outcome_cluster$DCR = 0
          Table_outcome_cluster$DCR_95CI_LL = 0
          Table_outcome_cluster$DCR_95CI_UL = 0
          tmp = Data_summary_cluster %>% group_by(Cluster) %>% tally()
          Table_outcome_cluster$N[1] = sum(tmp$n)
          if(sum(tmp$n)>0){
            for(i in 1:(length(Table_outcome_cluster$Cluster)-1)){
              Table_outcome_cluster$N[i+1] = tmp$n[i]
            }
            
            tmp = Data_summary_cluster %>% group_by(Cluster, ORR_data) %>% tally()
            Table_outcome_cluster$OR[1] = sum((tmp %>% dplyr::filter(ORR_data == 1))$n)
            for(i in 1:(length(Table_outcome_cluster$Cluster)-1)){
              if(length((tmp %>% dplyr::filter(ORR_data == 1 & Cluster == Table_outcome_cluster$Cluster[i+1]))$n)>0){
                Table_outcome_cluster$OR[i+1] = (tmp %>% dplyr::filter(ORR_data == 1 & Cluster == Table_outcome_cluster$Cluster[i+1]))$n
              }
            }
            tmp = Data_summary_cluster %>% group_by(Cluster, DCR_data) %>% tally()
            Table_outcome_cluster$DC[1] = sum((tmp %>% dplyr::filter(DCR_data == 1))$n)
            for(i in 1:(length(Table_outcome_cluster$Cluster)-1)){
              if(length((tmp %>% dplyr::filter(DCR_data == 1 & Cluster == Table_outcome_cluster$Cluster[i+1]))$n)>0){
                Table_outcome_cluster$DC[i+1] = (tmp %>% dplyr::filter(DCR_data == 1 & Cluster == Table_outcome_cluster$Cluster[i+1]))$n
              }
            }
            
            for(i in 1:length(Table_outcome_cluster$Cluster)){
              Table_outcome_cluster$ORR[i] = Table_outcome_cluster$OR[i] / Table_outcome_cluster$N[i]
              Table_outcome_cluster$DCR[i] = Table_outcome_cluster$DC[i] / Table_outcome_cluster$N[i]
              Table_outcome_cluster$ORR_95CI_LL[i] = exactci(Table_outcome_cluster$OR[i], Table_outcome_cluster$N[i], conf.level=0.95)$conf.int[1]
              Table_outcome_cluster$ORR_95CI_UL[i] = exactci(Table_outcome_cluster$OR[i], Table_outcome_cluster$N[i], conf.level=0.95)$conf.int[2]
              Table_outcome_cluster$DCR_95CI_LL[i] = exactci(Table_outcome_cluster$DC[i], Table_outcome_cluster$N[i], conf.level=0.95)$conf.int[1]
              Table_outcome_cluster$DCR_95CI_UL[i] = exactci(Table_outcome_cluster$DC[i], Table_outcome_cluster$N[i], conf.level=0.95)$conf.int[2]
            }
          }
          Table_outcome_cluster_total = rbind(Table_outcome_cluster_total, Table_outcome_cluster)
        }
      }
      
      
      output$table_outcome_cluster = DT::renderDataTable(Table_outcome_cluster_total,
                                                   server = FALSE,
                                                   filter = 'top', 
                                                   extensions = c('Buttons'), 
                                                   options = list(pageLength = 100, 
                                                                  scrollX = TRUE,
                                                                  scrollY = "1000px",
                                                                  scrollCollapse = TRUE,
                                                                  dom="Blfrtip",
                                                                  buttons = c('csv', 'copy')))
      
    
      Table_outcome_mutation_histology_total = NULL
      drug_list = list(input$drug, input$drug_group_1, input$drug_group_2, input$drug_group_3, input$drug_group_4)
      for(drug_count in 1:5){
        drug_name_1 = case_when(
          drug_count == 1 ~ paste(input$drug, collapse = ";"),
          drug_count == 2 ~ input$drug_group_1_name,
          drug_count == 3 ~ input$drug_group_2_name,
          drug_count == 4 ~ input$drug_group_3_name,
          drug_count == 5 ~ input$drug_group_4_name
        )
        Data_summary_histology = Data_forest %>% dplyr::filter(最良総合効果 != "NE") %>% dplyr::filter(Drug %in% drug_list[[drug_count]])
        if(length(Data_summary_histology$Drug)>0){
          Table_outcome_mutation_histology = data.frame(c("Total", as.character((Data_summary_histology %>% group_by(Histology) %>% tally())$Histology)))
          colnames(Table_outcome_mutation_histology) = "Histology"
          Table_outcome_mutation_histology$Drug = drug_name_1
          Table_outcome_mutation_histology$N = 0
          Table_outcome_mutation_histology$OR = 0
          Table_outcome_mutation_histology$ORR = 0
          Table_outcome_mutation_histology$ORR_95CI_LL = 0
          Table_outcome_mutation_histology$ORR_95CI_UL = 0
          Table_outcome_mutation_histology$DC = 0
          Table_outcome_mutation_histology$DCR = 0
          Table_outcome_mutation_histology$DCR_95CI_LL = 0
          Table_outcome_mutation_histology$DCR_95CI_UL = 0
          tmp = Data_summary_histology %>% group_by(Histology) %>% tally()
          Table_outcome_mutation_histology$N[1] = sum(tmp$n)
          if(sum(tmp$n)>0){
            for(i in 1:(length(Table_outcome_mutation_histology$Histology)-1)){
              Table_outcome_mutation_histology$N[i+1] = tmp$n[i]
            }
            
            tmp = Data_summary_histology %>% group_by(Histology, ORR_data) %>% tally()
            Table_outcome_mutation_histology$OR[1] = sum((tmp %>% dplyr::filter(ORR_data == 1))$n)
            for(i in 1:(length(Table_outcome_mutation_histology$Histology)-1)){
              if(length((tmp %>% dplyr::filter(ORR_data == 1 & Histology == Table_outcome_mutation_histology$Histology[i+1]))$n)>0){
                Table_outcome_mutation_histology$OR[i+1] = (tmp %>% dplyr::filter(ORR_data == 1 & Histology == Table_outcome_mutation_histology$Histology[i+1]))$n
              }
            }
            tmp = Data_summary_histology %>% group_by(Histology, DCR_data) %>% tally()
            Table_outcome_mutation_histology$DC[1] = sum((tmp %>% dplyr::filter(DCR_data == 1))$n)
            for(i in 1:(length(Table_outcome_mutation_histology$Histology)-1)){
              if(length((tmp %>% dplyr::filter(DCR_data == 1 & Histology == Table_outcome_mutation_histology$Histology[i+1]))$n)>0){
                Table_outcome_mutation_histology$DC[i+1] = (tmp %>% dplyr::filter(DCR_data == 1 & Histology == Table_outcome_mutation_histology$Histology[i+1]))$n
              }
            }
            
            for(i in 1:length(Table_outcome_mutation_histology$Histology)){
              Table_outcome_mutation_histology$ORR[i] = Table_outcome_mutation_histology$OR[i] / Table_outcome_mutation_histology$N[i]
              Table_outcome_mutation_histology$DCR[i] = Table_outcome_mutation_histology$DC[i] / Table_outcome_mutation_histology$N[i]
              Table_outcome_mutation_histology$ORR_95CI_LL[i] = exactci(Table_outcome_mutation_histology$OR[i], Table_outcome_mutation_histology$N[i], conf.level=0.95)$conf.int[1]
              Table_outcome_mutation_histology$ORR_95CI_UL[i] = exactci(Table_outcome_mutation_histology$OR[i], Table_outcome_mutation_histology$N[i], conf.level=0.95)$conf.int[2]
              Table_outcome_mutation_histology$DCR_95CI_LL[i] = exactci(Table_outcome_mutation_histology$DC[i], Table_outcome_mutation_histology$N[i], conf.level=0.95)$conf.int[1]
              Table_outcome_mutation_histology$DCR_95CI_UL[i] = exactci(Table_outcome_mutation_histology$DC[i], Table_outcome_mutation_histology$N[i], conf.level=0.95)$conf.int[2]
            }
          }
          Table_outcome_mutation_histology_total = rbind(Table_outcome_mutation_histology_total, Table_outcome_mutation_histology)
        }
      }
  
  
      output$table_outcome_2 = DT::renderDataTable(Table_outcome_mutation_histology_total,
                                                  server = FALSE,
                                                  filter = 'top', 
                                                  extensions = c('Buttons'), 
                                                  options = list(pageLength = 100, 
                                                                 scrollX = TRUE,
                                                                 scrollY = "1000px",
                                                                 scrollCollapse = TRUE,
                                                                 dom="Blfrtip",
                                                                 buttons = c('csv', 'copy')))
      
      mut_gene_ = input$gene[input$gene %in% unique(Data_MAF_target$Hugo_Symbol)]
      if(length(mut_gene_)==0){
        mut_gene_ = "TP53"
        ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
        Data_forest = Data_forest %>% dplyr::mutate(
          mutation = case_when(
            ID %in% ID_mutation_ ~ "TP53 mut(+)",
            TRUE ~ "TP53 mut(-)"
          )
        )
      } else{
        if(is.null(input$gene_group_2)){
          ID_mutation_ = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene_))$Tumor_Sample_Barcode
          Data_forest = Data_forest %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_ ~ paste0(paste(mut_gene_, collapse = "/"), " mut(+)"),
              TRUE ~ paste0(paste(mut_gene_, collapse = "/"), " mut(-)")
            )
          )
        } else{
          ID_mutation_1 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_1))$Tumor_Sample_Barcode
          ID_mutation_2 = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% input$gene_group_2))$Tumor_Sample_Barcode
          Data_forest = Data_forest %>% dplyr::mutate(
            mutation = case_when(
              ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
              ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(+) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
              !ID %in% ID_mutation_1 & ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(+)"),
              !ID %in% ID_mutation_1 & !ID %in% ID_mutation_2 ~ paste0(paste(input$gene_group_1, collapse = "/"), " mut(-) & ", paste(input$gene_group_2, collapse = "/"), " mut(-)"),
            )
          )
        }
      }
      
      Table_outcome_mutation_total = NULL
      drug_list = list(input$drug, input$drug_group_1, input$drug_group_2, input$drug_group_3, input$drug_group_4)
      for(drug_count in 1:5){
        drug_name_2 = case_when(
          drug_count == 1 ~ paste(input$drug, collapse = ";"),
          drug_count == 2 ~ input$drug_group_1_name,
          drug_count == 3 ~ input$drug_group_2_name,
          drug_count == 4 ~ input$drug_group_3_name,
          drug_count == 5 ~ input$drug_group_4_name
        )
        Data_summary_mutation = Data_forest %>% dplyr::filter(最良総合効果 != "NE") %>% dplyr::filter(Drug %in% drug_list[[drug_count]])
        if(length(Data_summary_mutation$Drug)>0){
          Table_outcome_mutation = data.frame(c("Total", as.character((Data_summary_mutation %>% group_by(mutation) %>% tally())$mutation)))
          colnames(Table_outcome_mutation) = "Mutation"
          Table_outcome_mutation$Drug = drug_name_2
          Table_outcome_mutation$N = 0
          Table_outcome_mutation$OR = 0
          Table_outcome_mutation$ORR = 0
          Table_outcome_mutation$ORR_95CI_LL = 0
          Table_outcome_mutation$ORR_95CI_UL = 0
          Table_outcome_mutation$DC = 0
          Table_outcome_mutation$DCR = 0
          Table_outcome_mutation$DCR_95CI_LL = 0
          Table_outcome_mutation$DCR_95CI_UL = 0
          
          tmp2 = Data_summary_mutation %>% group_by(mutation) %>% tally()
          Table_outcome_mutation$N[1] = sum(tmp2$n)
          if(length(Table_outcome_mutation$Mutation)>1){
            for(i in 1:(length(Table_outcome_mutation$Mutation)-1)){
              Table_outcome_mutation$N[i+1] = tmp2$n[i]
            }
            
            tmp2 = Data_summary_mutation %>% group_by(mutation, ORR_data) %>% tally()
            Table_outcome_mutation$OR[1] = sum((tmp2 %>% dplyr::filter(ORR_data == 1))$n)
            for(i in 1:(length(Table_outcome_mutation$Mutation)-1)){
              if(length((tmp2 %>% dplyr::filter(ORR_data == 1 & mutation == Table_outcome_mutation$Mutation[i+1]))$n)>0){
                Table_outcome_mutation$OR[i+1] = (tmp2 %>% dplyr::filter(ORR_data == 1 & mutation == Table_outcome_mutation$Mutation[i+1]))$n
              }
            }
            tmp2 = Data_summary_mutation %>% group_by(mutation, DCR_data) %>% tally()
            Table_outcome_mutation$DC[1] = sum((tmp2 %>% dplyr::filter(DCR_data == 1))$n)
            for(i in 1:(length(Table_outcome_mutation$Mutation)-1)){
              if(length((tmp2 %>% dplyr::filter(DCR_data == 1 & mutation == Table_outcome_mutation$Mutation[i+1]))$n)>0){
                Table_outcome_mutation$DC[i+1] = (tmp2 %>% dplyr::filter(DCR_data == 1 & mutation == Table_outcome_mutation$Mutation[i+1]))$n
              }
            }
            
            for(i in 1:length(Table_outcome_mutation$Mutation)){
              Table_outcome_mutation$ORR[i] = Table_outcome_mutation$OR[i] / Table_outcome_mutation$N[i]
              Table_outcome_mutation$DCR[i] = Table_outcome_mutation$DC[i] / Table_outcome_mutation$N[i]
              Table_outcome_mutation$ORR_95CI_LL[i] = exactci(Table_outcome_mutation$OR[i], Table_outcome_mutation$N[i], conf.level=0.95)$conf.int[1]
              Table_outcome_mutation$ORR_95CI_UL[i] = exactci(Table_outcome_mutation$OR[i], Table_outcome_mutation$N[i], conf.level=0.95)$conf.int[2]
              Table_outcome_mutation$DCR_95CI_LL[i] = exactci(Table_outcome_mutation$DC[i], Table_outcome_mutation$N[i], conf.level=0.95)$conf.int[1]
              Table_outcome_mutation$DCR_95CI_UL[i] = exactci(Table_outcome_mutation$DC[i], Table_outcome_mutation$N[i], conf.level=0.95)$conf.int[2]
            }
            Table_outcome_mutation_total = rbind(Table_outcome_mutation_total, Table_outcome_mutation)
          }
        }
      }
      output$table_outcome_3 = DT::renderDataTable(Table_outcome_mutation_total,
                                                          server = FALSE,
                                                          filter = 'top', 
                                                          extensions = c('Buttons'), 
                                                          options = list(pageLength = 100, 
                                                                         scrollX = TRUE,
                                                                         scrollY = "1000px",
                                                                         scrollCollapse = TRUE,
                                                                         dom="Blfrtip",
                                                                         buttons = c('csv', 'copy')))  
  
      incProgress(1 / 13)
    })
  })
}
# Run the application 
shinyApp(ui = ui, server = server)
