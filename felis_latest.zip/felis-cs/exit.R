observeEvent(input$logout_button, {
  # JavaScript confirm を使ってYes/No確認
  shinyjs::runjs("
      if (confirm('Want to log out?')) {
        Shiny.setInputValue('confirm_logout', true, {priority: 'event'});
      }
    ")
})
observeEvent(input$confirm_logout, {
  # 明示的ログアウト処理
  do_logout(session)
})

observeEvent(input$browser_closed, {
  # ブラウザ閉じ時のみ処理
  do_logout(session)
})

do_logout <- function(session) {
  URL <- session$userData$url
  if (!is.null(URL)) {
    res <- tryCatch(httr::GET(URL), error = function(e) NULL)
    if (!is.null(res) && httr::status_code(res) == 200) {
      cat("Log out.\n", URL, "\n")
      shinyjs::runjs("
        alert('Session finished. Window closing...');
      ")
    } else {
      cat("Log-out error.\n", URL, "\n")
      shinyjs::runjs("
        alert('Log-out error occurred.');
      ")
    }
  }
  session$close()
}

observeEvent(input$URL, {
  session$userData$url <- input$URL
})

# セッション終了時の処理
session$onSessionEnded(function() {
  Data_case_raw <- NULL
  Data_case <- NULL
  Data_drug_raw <- NULL
  Data_drug_raw_rename <- NULL
  Data_report_raw <- NULL
  Data_report <- NULL
  OUTPUT_DATA <- NULL
  Data_cluster_ID <- NULL
  tmp_post <- NULL
  output <- NULL
  input <- NULL
  analysis_env <- NULL
  all_objects <- ls(envir = .GlobalEnv)
  for(obj_name in all_objects) {
    tryCatch({
      obj <- get(obj_name, envir = .GlobalEnv)
      size_mb <- as.numeric(object.size(obj)) / (1024^2)
      if(size_mb > 10) {  # 10MB以上
        cat("Removing large object:", obj_name, "-", round(size_mb, 1), "MB\n")
        rm(list = obj_name, envir = .GlobalEnv)
      }
    }, error = function(e) {})
  }
  session$reactlog(FALSE)
  if(exists("session_data", envir = .GlobalEnv)) {
    rm(session_data, envir = .GlobalEnv)
  }
  rm(analysis_env)
  gc()
})

