observeEvent(input$logout_button, {
  # JavaScript confirm を使ってYes/No確認
  shinyjs::runjs("
      if (confirm('Want to log out?')) {
        Shiny.setInputValue('confirm_logout', true, {priority: 'event'});
      }
    ")
})
observeEvent(input$confirm_logout, {
  URL <- session$userData$url
  if (!is.null(URL)) {
    res <- tryCatch({
      httr::GET(URL)
    }, error = function(e) NULL)
    
    if (!is.null(res) && httr::status_code(res) == 200) {
      cat("Log out.\n")
      cat(URL, "\n")
      
      # ログアウト成功時のポップアップ表示
      shinyjs::runjs("
        alert('Session finished. Close the window');
      ")
      
    } else {
      cat("Log-out error.\n")
      cat(URL, "\n")
      
      # エラー時のポップアップ（オプション）
      shinyjs::runjs("
        alert('Log-out error occurred.');
      ")
    }
  } else {
    cat("No URL recorded.\n")
    
    # URL未記録時のポップアップ（オプション）
    shinyjs::runjs("
      alert('No URL recorded for logout.');
    ")
  }
  
  # stopApp()
})
observeEvent(input$URL, {
  session$userData$url <- input$URL
})
# セッション終了時の処理
session$onSessionEnded(function() {
  URL <- session$userData$url
  
  if (!is.null(URL)) {
    res <- tryCatch({
      httr::GET(URL)
    }, error = function(e) NULL)
    
    if (!is.null(res) && httr::status_code(res) == 200) {
      cat("Log out.\n")
      cat(URL, "\n")
    } else {
      cat("Log-out error.\n")
      cat(URL, "\n")
    }
  } else {
    cat("No URL recorded.\n")
  }
  
  # stopApp()
})
