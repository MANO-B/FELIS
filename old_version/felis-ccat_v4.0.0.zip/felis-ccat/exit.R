observeEvent(input$logout_button, {
  # JavaScript confirm を使ってYes/No確認
  shinyjs::runjs("
      if (confirm('Want to log out?')) {
        Shiny.setInputValue('confirm_logout', true, {priority: 'event'});
      }
    ")
})
observeEvent(input$confirm_logout, {
  URL <- session$userData$url
  if (!is.null(URL)) {
    res <- tryCatch({
      httr::GET(URL)
    }, error = function(e) NULL)
    
    if (!is.null(res) && httr::status_code(res) == 200) {
      cat("Log out.\n")
      cat(URL, "\n")
      
      # ログアウト成功時のポップアップ表示
      shinyjs::runjs("
        alert('Session finished. Window closing...');
      ")
      
    } else {
      cat("Log-out error.\n")
      cat(URL, "\n")
      
      # エラー時のポップアップ（オプション）
      shinyjs::runjs("
        alert('Log-out error occurred.');
      ")
    }
  } else {
    cat("No URL recorded.\n")
    
    # URL未記録時のポップアップ（オプション）
    shinyjs::runjs("
      alert('No URL recorded for logout.');
    ")
  }
  shinyjs::runjs("window.close();")
  session$close()
  # stopApp()
})
observeEvent(input$URL, {
  session$userData$url <- input$URL
})

onStop(function() {
  reactive_vars <- c("Data_case_raw", "Data_case", "Data_drug_raw", "Data_drug_raw_rename", "Data_report_raw", "Data_report")
  for(var in reactive_vars) {
    if(exists(var, envir = .GlobalEnv)) {
      rm(list = var, envir = .GlobalEnv)
    }
  }
  if(exists("OUTPUT_DATA")) {
    tryCatch({
      clear_reactive_data(OUTPUT_DATA)
    }, error = function(e) {
      rm(OUTPUT_DATA, envir = .GlobalEnv)
    })
  }
  all_objects <- ls(envir = .GlobalEnv)
  for(obj_name in all_objects) {
    tryCatch({
      obj <- get(obj_name, envir = .GlobalEnv)
      size_mb <- as.numeric(object.size(obj)) / (1024^2)
      if(size_mb > 10) {  # 10MB以上
        cat("Removing large object:", obj_name, "-", round(size_mb, 1), "MB\n")
        rm(list = obj_name, envir = .GlobalEnv)
      }
    }, error = function(e) {})
  }
  gc()
})

# セッション終了時の処理
session$onSessionEnded(function() {
  Data_case_raw <- NULL
  Data_case <- NULL
  Data_drug_raw <- NULL
  Data_drug_raw_rename <- NULL
  Data_report_raw <- NULL
  Data_report <- NULL
  OUTPUT_DATA <- NULL
  Data_cluster_ID <- NULL
  tmp_post <- NULL
  output <- NULL
  input <- NULL
  analysis_env <- NULL
  all_objects <- ls(envir = .GlobalEnv)
  for(obj_name in all_objects) {
    tryCatch({
      obj <- get(obj_name, envir = .GlobalEnv)
      size_mb <- as.numeric(object.size(obj)) / (1024^2)
      if(size_mb > 10) {  # 10MB以上
        cat("Removing large object:", obj_name, "-", round(size_mb, 1), "MB\n")
        rm(list = obj_name, envir = .GlobalEnv)
      }
    }, error = function(e) {})
  }
  session$reactlog(FALSE)
  if(exists("session_data", envir = .GlobalEnv)) {
    rm(session_data, envir = .GlobalEnv)
  }
  rm(analysis_env)
  gc()
  URL <- session$userData$url
  
  if (!is.null(URL)) {
    res <- tryCatch({
      httr::GET(URL)
    }, error = function(e) NULL)
    
    if (!is.null(res) && httr::status_code(res) == 200) {
      cat("Log out.\n")
      cat(URL, "\n")
    } else {
      cat("Log-out error.\n")
      cat(URL, "\n")
    }
  } else {
    cat("No URL recorded.\n")
  }
  
})

