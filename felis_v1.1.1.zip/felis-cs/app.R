library(ggplot2)
library(umap)
library(tidyr)
library(dbscan)
library(shiny)
library(shinyWidgets)
library(readr)
library(dplyr)
library(stringr)
library(ComplexHeatmap)
library(RColorBrewer)
library(gt)
library(gtsummary)
library(flextable)
library(Rediscover)
library(survival)
library(gridExtra)
library(survminer)
library(tranSurv)
library(rstan)
library(DT)
library(ggsci)
library(scales)
library(patchwork)
library(sjPlot)
library(sjlabelled)
library(forcats)
library(markdown)

rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())

ht_opt$message = FALSE
options(shiny.maxRequestSize=16*1024^3)

fun_zero <- function(a, b)ifelse(b == 0, 0, a / b)

shannon.entropy = function(x, x_length){ 
  x = x[(!is.na(x))]
  x = x[(x != 0)]
  if(sum(x) <= 0) {
    return(log(x_length, base=2)) 
  } else {
    p = x/sum(x)
    score = -sum(p * log(p, base=2))
    return(score)
  }
} 

odds.ratio <- function(a, b, c, d, correct=FALSE){
  cl <- function(x){
    or*exp(c(1,-1)*qnorm(x)*sqrt(1/a+1/b+1/c+1/d))
  }
  if (correct || a*b*c*d==0) {
    a <- a+0.5
    b <- b+0.5
    c <- c+0.5
    d <- d+0.5
  }
  or <- a*d/(b*c)
  conf <- rbind(cl90=cl(0.05), cl95=cl(0.025), cl99=cl(0.005), cl999=cl(0.0005))
  conf <- data.frame(conf)
  colnames(conf) <- paste(c("lower","upper"), " limit" , sep="")
  rownames(conf) <- paste(c(90, 95, 99, 99.9), "%CI" , sep="")
  list(or=or, conf=conf)
}


fun_oncoprint = function(Data_MAF_target,
                         Data_case_target,
                         oncogenic_genes,
                         gene,
                         gene_no,
                         gene_group_1,
                         gene_group_2,
                         oncoprint_option,
                         mid_age){
  col = c("amplification" = "red",
          "loss" = "blue",
          "TMB_high" = "orange",
          "exon_skipping" = "red4",
          "small_scale_variant" = "green",
          "duplication" = "pink",
          "rearrangement" = "purple",
          "fusion" = "gray",
          "truncation" = "black",
          "deletion" = "yellow")
  alter_fun = list(
    background = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h-unit(2, "pt"), 
                gp = gpar(fill = "#CCCCCC", col = NA))
    },
    amplification = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h-unit(2, "pt"), 
                gp = gpar(fill = col["amplification"], col = NA))
    },
    loss = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*1.0, 
                gp = gpar(fill = col["loss"], col = NA))
    },
    TMB_high = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*0.8, 
                gp = gpar(fill = col["TMB_high"], col = NA))
    },
    exon_skipping = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*0.7, 
                gp = gpar(fill = col["exon_skipping"], col = NA))
    },
    small_scale_variant = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*0.6, 
                gp = gpar(fill = col["small_scale_variant"], col = NA))
    },
    duplication = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*0.5, 
                gp = gpar(fill = col["duplication"], col = NA))
    },
    rearrangement = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                gp = gpar(fill = col["rearrangement"], col = NA))
    },
    fusion = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*0.3, 
                gp = gpar(fill = col["fusion"], col = NA))
    },
    truncation = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*0.2, 
                gp = gpar(fill = col["truncation"], col = NA))
    },
    deletion = function(x, y, w, h) {
      grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                gp = gpar(fill = col["deletion"], col = NA))
    }
  )
  Data_oncoprint = Data_case_target %>%
    dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                  症例.基本情報.がん種.OncoTree.,
                  YoungOld) %>%
    dplyr::distinct() %>%
    dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
  if(!is.null(gene)){
    oncogenic_genes = unique(c(gene, oncogenic_genes))
  }
  gene_no = min(length(oncogenic_genes),
                gene_no)
  mat_oncoprint = matrix("",
                         nrow = length(Data_oncoprint$症例.基本情報.がん種.OncoTree.),
                         ncol = gene_no)
  rownames(mat_oncoprint) = Data_oncoprint$C.CAT調査結果.基本項目.ハッシュID
  colnames(mat_oncoprint) = oncogenic_genes[1:gene_no]
  Data_TMB = (Data_MAF_target %>%
                dplyr::distinct(Tumor_Sample_Barcode, TMB))
  colnames(Data_TMB) = c("C.CAT調査結果.基本項目.ハッシュID", "TMB")
  Data_oncoprint = left_join(Data_oncoprint,
                             Data_TMB,
                             by = "C.CAT調査結果.基本項目.ハッシュID")
  Data_TMB = Data_oncoprint$TMB
  Data_TMB[is.na(Data_TMB)] <- 0
  
  Data_major_gene = Data_MAF_target %>%
    dplyr::filter(Hugo_Symbol %in% colnames(mat_oncoprint)) %>%
    dplyr::arrange(Tumor_Sample_Barcode)
  
  for(i in 1:length(Data_major_gene$Tumor_Sample_Barcode)){
      mat_oncoprint[Data_major_gene[i,"Tumor_Sample_Barcode"],
                    Data_major_gene[i,"Hugo_Symbol"]] =
        paste(mat_oncoprint[Data_major_gene[i,"Tumor_Sample_Barcode"],
                            Data_major_gene[i,"Hugo_Symbol"]],
              Data_major_gene[i,"Variant_Classification"],
              sep=";")
  }

  rownames(mat_oncoprint) = Data_oncoprint$症例.基本情報.がん種.OncoTree.
  mat_oncoprint = t(mat_oncoprint)
  column_title = paste("OncoPrint for frequent gene mutations")
  tmp = mat_oncoprint
  tmp[tmp != ""] = 1
  tmp[tmp == ""] = 0
  tmp = matrix(as.numeric(tmp), ncol = ncol(tmp))
  tmp2 = order(apply(tmp, FUN=sum, MARGIN=1))
  if(!is.null(gene_group_1)){
    if(!is.null(gene_group_2)){
  tmp2 = c(tmp2[-which(tmp2 %in%
                 c(which(oncogenic_genes %in% c(gene_group_1, gene_group_2))))],
               tmp2[which(tmp2 %in% which(oncogenic_genes %in% gene_group_2))],
               tmp2[which(tmp2 %in% which(oncogenic_genes %in%  gene_group_1))])
    } else{
      tmp2 = c(tmp2[-which(tmp2 %in% which(oncogenic_genes %in% gene_group_1))],
               tmp2[which(tmp2 %in% which(oncogenic_genes %in% gene_group_1))])
    }
  }
  tmp = data.frame(tmp)
  colnames(tmp) = 1:ncol(tmp)
  sample_order = 1:ncol(tmp)
  colPal3 <- colorRampPalette(brewer.pal(11, "Spectral"))

  anno_diag = colnames(mat_oncoprint)
  anno_age = Data_oncoprint$YoungOld
  diag_list = unique(anno_diag)
  diag_col = colPal3(length(diag_list))
  age_list = unique(Data_oncoprint$YoungOld)
  age_col = colPal3(length(age_list))
  names(diag_col) = diag_list
  names(age_col) = age_list
  
  
  tmp3 = matrix(as.numeric(as.factor(mat_oncoprint)) - 1,
                ncol = ncol(mat_oncoprint))
  tmp3 = data.frame(tmp3)
  colnames(tmp3) = 1:ncol(tmp3)
  for(l in rev(tmp2)){
    if(max(tmp3[l,]) != min(tmp3[l,])){
      sample_order_tmp = sample_order
      sample_order = NULL
      tmp4 = tmp3
      tmp5 = tmp
      tmp3 = tmp4[,0]
      tmp = tmp5[,0]
      for(m in sort(unique(unlist(as.vector(tmp4[l,]))),decreasing = F)){
        sample_order = c(sample_order, sample_order_tmp[tmp4[l,] == m])
        tmp3 = cbind(tmp3, tmp4[,tmp4[l,] == m])
        tmp = cbind(tmp, tmp5[,tmp4[l,] == m])
      }
    }
  }
  
  for(l in tmp2){
    if(!all(tmp[l,] == 1) & !all(tmp[l,] == 0)){
      sample_order = c(sample_order[tmp[l,] == 1], sample_order[tmp[l,] == 0])
      tmp = cbind(tmp[,tmp[l,] == 1], tmp[,tmp[l,] == 0])
    }
  }
  sample_order_final = NULL
  for(l in diag_list){
    sample_order_final = c(sample_order_final,
                           sample_order[sample_order %in% (1:length(sample_order))[(anno_diag == l)]])
  }

  sample_order_simple = sample_order
  sample_order = sample_order_final
  sample_order_final_age = NULL
  for(l in age_list){
    sample_order_final_age = c(sample_order_final_age,
                           sample_order[sample_order %in% (1:length(sample_order))[(anno_age == l)]])
  }

  heatmap_legend_param = list(title = "Alternations", at = c("Oncogenic mut"), 
                              labels = c("Oncogenic mut"))
  ha = HeatmapAnnotation(Diagnosis = anno_diag,
                         Age = anno_age,
                         col = list(Diagnosis = diag_col, Age = age_col),
                         annotation_height = unit(c(15, 5, 15), "mm"),
                         annotation_legend_param = list(Diagnosis = list(title = "Diagnosis"),
                                                        Age = list(title = paste(mid_age, ">= Age, or older")))
)
  hb = HeatmapAnnotation(TMB = anno_points(Data_TMB, ylim = c(0, 30),
                                           axis_param = list(
                                             side = "right",
                                             at = c(0, 10, 20, 30), 
                                             labels = c("0", "10", "20", ">30")
                                           )),
                         annotation_height = unit(15, "mm"))
  if(oncoprint_option == "Sort by mutation frequency"){
    ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                   column_order = sample_order_simple, row_order = rev(tmp2),
                   alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                   column_title = column_title,
                   #heatmap_legend_param = heatmap_legend_param,
                   remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                   bottom_annotation = ha,
                   top_annotation = hb,
                   use_raster = FALSE,
                   #height = unit(200, "mm"),
                   alter_fun_is_vectorized = TRUE)
  } else if(oncoprint_option == "Sort by age"){
    ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                   column_order = sample_order_final_age, row_order = rev(tmp2),
                   alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                   column_title = column_title,
                   #heatmap_legend_param = heatmap_legend_param,
                   remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                   bottom_annotation = ha,
                   top_annotation = hb,
                   use_raster = FALSE,
                   #height = unit(200, "mm"),
                   alter_fun_is_vectorized = TRUE)
  } else{
    ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                   column_order = sample_order_final, row_order = rev(tmp2),
                   alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                   column_title = column_title,
                   remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                   bottom_annotation = ha,
                   top_annotation = hb,
                   use_raster = FALSE,
                   #height = unit(200, "mm"),
                   alter_fun_is_vectorized = TRUE)
  }
  draw(ht)
}

save_table_docx <- function(Data_summary, separate_var, title, filename){
  tmp = Data_summary %>%
    tbl_summary(
      by = separate_var,
      statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                            "{mean} ({sd})",
                                            "{median} ({p25}, {p75})", 
                                            "{min}, {max}"),
                       all_categorical() ~ "{n} / {N} ({p}%)"),
      type = all_continuous() ~ "continuous2",
      digits = all_continuous() ~ 2,
      missing = "ifany")
  if(!is.null(separate_var)){
    tmp = tmp %>%
      add_p(pvalue_fun = ~style_pvalue(.x, digits = 2)) %>%
      add_overall()
  }
  tmp %>%
    add_n() %>%
    modify_header(label ~ "**Variable**") %>%
    modify_caption(title) %>%
    bold_labels() %>% as_flex_table() %>% save_as_docx(path = filename)
}

surv_curv_entry <- function(fit, data, title, legend_, diff_0, diff_1){
  g = ggsurvplot(
    fit = fit,
    combine = TRUE,
    data = data,
    xlab = "Time from enrollment (days)",
    ylab = "Survival Probability",
    censor = TRUE,
    conf.int = FALSE,
    surv.scale = "percent",
    font.title = 8,
    font.subtitle = 8,
    font.main = 8,
    font.submain = 8,
    font.caption = 8,
    font.legend = 8,
    pval = FALSE,
    surv.median.line = "v",
    palette = "Dark2",
    risk.table = TRUE,
    risk.table.y.text = FALSE,
    tables.theme = clean_theme(), 
    legend = c(0.8,0.8),
    xlim = c(0, max(data$time_enroll_final) * 1.05),
    break.x.by = ceiling(max(data$time_enroll_final) / 500) * 100,
    legend.labs = legend_
  )
  if(is.null(diff_0)){
    tmp = summary(fit)$table
    legends = paste0(tmp[[7]], " (", tmp[[8]], "-", tmp[[9]],")")
    g = g +
      labs(title = title,
           subtitle = paste0("Median OS, ", legends, " days"))
  } else{
    tmp = data.frame(summary(fit)$table)
    legends = paste0(tmp$median[1], " (", tmp$X0.95LCL[1], "-", tmp$X0.95UCL[1],")")
    for(i in 2:length(tmp$median)){
      legends = paste(legends, paste0(tmp$median[i], " (", tmp$X0.95LCL[i], "-", tmp$X0.95UCL[i],")"), sep=", ")
    }
    g = g +
      labs(title = paste0(title, ": log-rank, p=", format(
        1 - pchisq(diff_0$chisq, length(diff_0$n)-1, lower.tail = TRUE),digits=3),
        "/Gehan-Wilcoxon, p=", format(
          1 - pchisq(diff_1$chisq, length(diff_1$n)-1, lower.tail = TRUE),digits=3)),
        subtitle = paste0("Median OS, ", legends, " days"))
  }
  return(g)
}

surv_curv_drug <- function(fit, data, title, diff_0, diff_1){
  g = ggsurvplot(
    fit = fit,
    combine = TRUE,
    data = data,
    xlab = "Time from drug initiation (days)",
    ylab = "Survival Probability",
    censor = TRUE,
    surv.scale = "percent",
    conf.int = FALSE,
    font.title = 8,
    font.subtitle = 8,
    font.main = 8,
    font.submain = 8,
    font.caption = 8,
    font.legend = 8,
    pval = FALSE,
    surv.median.line = "v",
    palette = "Dark2",
    risk.table = TRUE,
    risk.table.y.text = FALSE,
    tables.theme = clean_theme(), 
    legend = c(0.8,0.8),
    xlim = c(0, 1000),
    break.x.by = 200
  )
  if(is.null(diff_0)){
    tmp = summary(fit)$table
    legends = paste0(tmp[[7]], " (", tmp[[8]], "-", tmp[[9]],")")
    g = g +
      labs(title = title,
           subtitle = paste0("Median OS, ", legends, " days"))
  } else{
    tmp = data.frame(summary(fit)$table)
    legends = paste0(tmp$median[1], " (", tmp$X0.95LCL[1], "-", tmp$X0.95UCL[1],")")
    for(i in 2:length(tmp$median)){
      legends = paste(legends, paste0(tmp$median[i], " (", tmp$X0.95LCL[i], "-", tmp$X0.95UCL[i],")"), sep=", ")
    }
    g = g +
      labs(title = paste0(title, ": log-rank, p=", format(
        1 - pchisq(diff_0$chisq, length(diff_0$n)-1, lower.tail = TRUE),digits=3),
        "/Gehan-Wilcoxon, p=", format(
          1 - pchisq(diff_1$chisq, length(diff_1$n)-1, lower.tail = TRUE),digits=3)),
        subtitle = paste0("Median OS, ", legends," days"))
  }
  return(g)
}

# Define UI for application that draws a histogram
ui <- fluidPage(
  titlePanel(h6("FELIS; Functions Especially for LIquid and Solid tumor clinical sequencing. See https://github.com/MANO-B/FELIS")),
  navbarPage("Select tab",
    tabPanel("Input C-CAT raw file",
      fluidRow(
        column(4,
          "必須：C-CATデータファイル",
          fileInput(inputId = "clinical_files",
                   label = "Choose case CSV Files",
                   multiple = TRUE,
                   accept = c(
                     "text/csv",
                     "text/comma-separated-values,text/plain",
                     ".csv")
          ),
          fileInput(inputId = "report_files",
                   label = "Choose report CSV Files",
                   multiple = TRUE,
                   accept = c(
                     "text/csv",
                     "text/comma-separated-values,text/plain",
                     ".csv")
          )
        ),
        column(4,
          "オプションファイル",
          fileInput(inputId = "ID_histology",
                   label = "IDと組織型の対応表(CSV)",
                   multiple = TRUE,
                   accept = c(
                     "text/csv",
                     "text/comma-separated-values,text/plain",
                     ".csv")
          ),
          "組織診断を修正したい患者のIDと変更後の組織型を指定します",
          br(),
          downloadButton('download_ID_histology', 'CSVファイルのひな形をダウンロード'),
          br(),
          br(),
          hr(),
          fileInput(inputId = "ID_drug",
                   label = "IDと各薬剤のラインの対応表(CSV)",
                   multiple = TRUE,
                   accept = c(
                     "text/csv",
                     "text/comma-separated-values,text/plain",
                     ".csv")
          ),
          "キュレーション後の薬剤のみ解析する場合",
          br(),
          downloadButton('download_ID_drug_pre_CGP', 'CSVのひな形(CGP前)をダウンロード'),
          br(),
          downloadButton('download_ID_drug_post_CGP', 'CSVのひな形(CGP後)をダウンロード'),
          br(),
          br(),
          hr(),
          fileInput(inputId = "drug_rename",
                    label = "薬剤のリネームの対応表(CSV)",
                    multiple = TRUE,
                    accept = c(
                      "text/csv",
                      "text/comma-separated-values,text/plain",
                      ".csv")
          ),
          "薬剤をリネームして類似した薬剤をまとめて解析する場合",
          br(),
          "分子標的治療薬、免疫チェックポイント阻害薬などに再分類",
          br(),
          "薬剤はABC順にカンマ区切りで表記",
          br(),
          downloadButton('download_drug_rename', 'CSVのひな形をダウンロード')
        ),
        column(4, "オプションファイル",
          fileInput(inputId = "mutation_rename",
                   label = "変異のリネームの対応表(CSV)",
                   multiple = TRUE,
                   accept = c(
                     "text/csv",
                     "text/comma-separated-values,text/plain",
                     ".csv")
          ),
          "変異をリネームして類似した変異をまとめて解析する場合",
          br(),
          "Exon 19変異、Exon 20変異、遺伝子増幅などに再分類",
          br(),
          "指定遺伝子に指定されていない変異があった場合は'Other'",
          br(),
          downloadButton('download_mutation_rename', 'CSVのひな形をダウンロード'),
          br(),
          br(),
          hr(),
          fileInput(inputId = "histology_rename",
                    label = "組織型のリネームの対応表(CSV)",
                    multiple = TRUE,
                    accept = c(
                      "text/csv",
                      "text/comma-separated-values,text/plain",
                      ".csv")
          ),
          "組織型をリネームして類似した組織型をまとめて解析する場合",
          br(),
          "分化型胃がん、未分化型胃がんなどに再分類",
          br(),
          downloadButton('download_histology_rename', 'CSVのひな形をダウンロード'),
          br(),
          br(),
          hr(),
          fileInput(inputId = "regimen_rename",
                    label = "レジメンに基づく薬剤リネームの対応表(CSV)",
                    multiple = TRUE,
                    accept = c(
                      "text/csv",
                      "text/comma-separated-values,text/plain",
                      ".csv")
          ),
          "薬剤名が不明でレジメンが分かる場合に薬剤名を入力する",
          br(),
          "MAP療法->Cisplatin,Doxorubicin,Methotrexateと変換",
          br(),
          downloadButton('download_regimen_rename', 'CSVのひな形をダウンロード')
        ),
      ),
      hr(),
      p("使用法など: "),
      a(href="https://github.com/MANO-B/FELIS",img(src="FELIS.png", width = 85, height = 100)),
         a(href="https://github.com/MANO-B/FELIS",p("https://github.com/MANO-B/FELIS"))
    ),
    tabPanel("Select patients",
        actionButton("start_setting", "ファイル読み込み・解析設定開始"),
        br(),
        hr(),
        fluidRow(
        column(4,
          htmlOutput("select_histology"),
          htmlOutput("select_histology_group_1"),
          htmlOutput("select_histology_group_1_name"),
          htmlOutput("select_histology_group_2"),
          htmlOutput("select_histology_group_2_name"),
          htmlOutput("select_histology_group_3"),
          htmlOutput("select_histology_group_3_name"),
          htmlOutput("select_histology_group_4"),
          htmlOutput("select_histology_group_4_name")
        ),
        column(4,
          htmlOutput("select_sex"),
          htmlOutput("select_panel"),
          htmlOutput("select_minimum_pts"),
          htmlOutput("select_eps"),
          htmlOutput("select_age"),
          htmlOutput("select_mid_age"),
          htmlOutput("select_PS"),
          htmlOutput("select_smoking")
        ),
        column(4,
          htmlOutput("select_gene"),
          htmlOutput("select_gene_group_1"),
          htmlOutput("select_gene_group_2"),
          htmlOutput("select_gene_no"),
          htmlOutput("select_patho"),
          htmlOutput("select_oncoprint_option")
        )
      )
    ),
    tabPanel("Analysis",
      fluidRow(
        column(4,
          "標準的な解析",
          hr(),
          actionButton("summary_base", "症例のまとめを表示"),
          br(),
          br(),
          actionButton("oncoprint", "Oncoprintを表示"),
          br(),
          br(),
          actionButton("mutually_exclusive", "相互排他・共変異を表示"),
          br(),
          br(),
          actionButton("mut_subtype", "組織型ごとの各遺伝子の変異率を表示"),
          br(),
          br(),
          actionButton("custering_analysis", "遺伝子変異に基づくクラスタリング"),
          br(),
          br(),
          actionButton("survival_CGP_analysis", "CGP検査後の生存期間解析"),
          br(),
          br(),
          actionButton("survival_CTx_analysis", "化学療法導入の生存期間解析(時間がかかります)"),
          br(),
          br(),
          actionButton("drug_table", "Palliative CTxで使用した薬剤リスト(1st-4th line)"),
          htmlOutput("select_drug"),
          br(),
          actionButton("drug_analysis", "上記ボタンで選択した薬剤の奏効性解析")
        )
      )
    ),
    tabPanel("症例のまとめ",
      fluidRow(
        tabPanel("Patients summary",
                 gt_output("table_summary")
        )
      )
    ),
    navbarMenu("Oncoprint",
      tabPanel("Oncoprint",
                 plotOutput('figure_oncoprint', 
                            height = "1000px",
                            width = "1000px")
      ),
      tabPanel("Per_patient_table",
               DT::dataTableOutput("table_patient")
      )
    ),
    tabPanel("相互排他・共変異",
             fluidRow(
               tabPanel("Co-occurrence",
                 plotOutput('figure_mutually_exclusive', 
                            height = "1000px",
                            width = "1000px")
        )
      )
    ),
    tabPanel("組織型ごとの変異",
      fluidRow(
        tabPanel("Mutation in subtypes",
          plotOutput('figure_mut_subtype', 
                  height = "1000px",
                  width = "1000px")
        )
      )
    ),
    navbarMenu("クラスタリング",
        tabPanel("Basic data",
          plotOutput('figure_base', 
                    height = "1500px",
                    width = "1000px")
        ),
        tabPanel("Clustering",
                 plotOutput('figure_cluster', 
                            height = "1000px",
                            width = "1200px")
        ),
        tabPanel("Cluster-age",
                 plotOutput('figure_cluster_age', 
                            height = "1000px",
                            width = "1200px")
        ),
        tabPanel("Cluster-subtypes",
                 plotOutput('figure_cluster_subtype', 
                            height = "1000px",
                            width = "1200px")
        ),
        tabPanel("Cluster-entropy",
                 plotOutput('figure_entropy', 
                            height = "1000px",
                            width = "1500px")
        ),
        tabPanel("Cluster-disease_table",
                 DT::dataTableOutput("table_disease")
        ),
        tabPanel("Cluster-mutation_table",
                 DT::dataTableOutput("table_mutation")
        ),
        
        tabPanel("Histology-drug_evidence",
                 plotOutput('figure_drug_evidence', 
                            height = "1000px",
                            width = "1500px")
        ),
        tabPanel("Patient_Num-treatment",
                 plotOutput('figure_patient_treatment', 
                            height = "1000px",
                            width = "1500px")
        ),
        tabPanel("Pre_CGP-treatment",
                 plotOutput('figure_Pre_CGP_treatment', 
                            height = "1000px",
                            width = "1500px")
        ),
        tabPanel("Post_CGP-treatment",
                 plotOutput('figure_Post_CGP_treatment', 
                            height = "1000px",
                            width = "1500px")
        )
    ),
    navbarMenu("CGP後の生存期間",
        tabPanel("Survival from CGP 1",
                 plotOutput('figure_survival_CGP_1', 
                            height = "2500px",
                            width = "1500px")
        ),
        tabPanel("Survival from CGP 2",
                 plotOutput('figure_survival_CGP_2', 
                            height = "2500px",
                            width = "1500px")
        ),
        tabPanel("Survival from CGP 3",
                 plotOutput('figure_survival_CGP_3', 
                            height = "1000px",
                            width = "1200px")
        ),
        tabPanel("Survival from CGP 4",
                 plotOutput('figure_survival_CGP_4', 
                            height = "3000px",
                            width = "1500px")
        ),
        tabPanel("Survival from CGP 5",
                 plotOutput('figure_survival_CGP_5', 
                            height = "3000px",
                            width = "1500px")
        ),
        tabPanel("Survival from CGP 6",
                 plotOutput('figure_survival_CGP_6', 
                            height = "1500px",
                            width = "1500px")
        )
    ),
    navbarMenu("CTx後の生存期間",
        tabPanel("Survival from CTx 1",
                 plotOutput('figure_survival_CTx_1', 
                            height = "2500px",
                            width = "1500px")
        ),
        tabPanel("Survival from CTx 2",
                 plotOutput('figure_survival_CTx_2', 
                            height = "1000px",
                            width = "1000px")
        ),
        tabPanel("Survival from CTx 3",
                 plotOutput('figure_survival_CTx_3', 
                            height = "3000px",
                            width = "1500px")
        )
    ),
    navbarMenu("薬剤奏効性",
        tabPanel("Drug table",
                 gt_output("table_drug")
        ),
        tabPanel("Drug analysis 1",
                 plotOutput('figure_drug_1', 
                            height = "2500px",
                            width = "1500px")
        ),
        tabPanel("Drug analysis 2",
                 plotOutput('figure_drug_2', 
                            height = "2500px",
                            width = "1500px")
        ),
        tabPanel("Drug analysis 3",
                 plotOutput('figure_drug_3', 
                            height = "2500px",
                            width = "1500px")
        )
      ),
    tabPanel("説明",
      includeMarkdown("www/README.md")
    )
  )
)

  
# Define server logic required to draw a histogram
server <- function(input, output, session) {
  observeEvent(input$clinical_files, {
    Data_case =  reactive({
      clin_tmp = data.frame(NULL)
      for(i in 1:length(input$clinical_files[,1])){
        Encode = guess_encoding(input$clinical_files[[i, 'datapath']])[[1]][[1]]
        if(Encode == "Shift_JIS"){
          Encode = "CP932"
        }
        clin_tmp <- rbind(clin_tmp,
                          read.csv(header = TRUE,
                            file(input$clinical_files[[i, 'datapath']],
                                 encoding=Encode)))
      }
      clin_tmp$症例.基本情報.がん種.OncoTree..名称. = 
        str_split(str_replace(clin_tmp$症例.基本情報.がん種.OncoTree..名称.,
                              "\\)_", "\\)__"), "__", simplify = TRUE)[,1]
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.背景情報.ECOG.PS.名称. = case_when(
          症例.背景情報.ECOG.PS.名称. == "" ~ "不明",
          TRUE ~ 症例.背景情報.ECOG.PS.名称.
        )
      )
      if(!is.null(input$ID_histology)){
        ID_histology_list = data.frame(NULL)
        for(i in 1:length(input$ID_histology[,1])){
          ID_histology_list <- rbind(ID_histology_list,
                            read.csv(header = TRUE,
                              file(input$ID_histology[[i, 'datapath']],
                                   encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.基本情報.がん種.OncoTree..名称._tmp = unlist(lapply(list(clin_tmp$C.CAT調査結果.基本項目.ハッシュID), function(x) {
          as.vector(ID_histology_list$Histology[match(x, ID_histology_list$ID)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.基本情報.がん種.OncoTree..名称. = case_when(
            !is.na(症例.基本情報.がん種.OncoTree..名称._tmp) ~ 症例.基本情報.がん種.OncoTree..名称._tmp,
            TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
          )
        )
      }
      if(!is.null(input$regimen_rename)){
        RenList = data.frame(NULL)
        for(i in 1:length(input$regimen_rename[,1])){
          RenList <- rbind(RenList,
                           read.csv(header = TRUE,
                                    file(input$regimen_rename[[i, 'datapath']],
                                         encoding='UTF-8-BOM')))
        }
        for(i in 1:length(RenList$P1)){
          clin_tmp = clin_tmp %>% dplyr::mutate(
            症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = case_when(
              症例.EP前レジメン情報.薬剤名.YJ一般名.EN. == "" &
                症例.EP前レジメン情報.化学療法レジメン名称 == RenList$P1[i] ~ RenList$P2[i],
              TRUE ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN.
            ))
        }
      }
      if(!is.null(input$drug_rename)){
        drug_rename_list = data.frame(NULL)
        for(i in 1:length(input$drug_rename[,1])){
          drug_rename_list <- rbind(drug_rename_list,
                                     read.csv(header = TRUE,
                                       file(input$drug_rename[[i, 'datapath']],
                                            encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp = unlist(lapply(list(clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN.), function(x) {
          as.vector(drug_rename_list$Rename[match(x, drug_rename_list$Drug)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = case_when(
            !is.na(症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp) ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp,
            TRUE ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN.
          )
        )
      }
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. == "" ~ 症例.基本情報.がん種.OncoTree.LEVEL1.,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
      if(!is.null(input$histology_rename)){
        histology_rename_list = data.frame(NULL)
        for(i in 1:length(input$histology_rename[,1])){
          histology_rename_list <- rbind(histology_rename_list,
                                         read.csv(header = TRUE,
                                           file(input$histology_rename[[i, 'datapath']],
                                                encoding='UTF-8-BOM')))
        }
        clin_tmp$症例.基本情報.がん種.OncoTree..名称._tmp = unlist(lapply(list(clin_tmp$症例.基本情報.がん種.OncoTree..名称.), function(x) {
          as.vector(histology_rename_list$Rename[match(x, histology_rename_list$Histology)])}))
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.基本情報.がん種.OncoTree..名称. = case_when(
            !is.na(症例.基本情報.がん種.OncoTree..名称._tmp) ~ 症例.基本情報.がん種.OncoTree..名称._tmp,
            TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
          )
        )
      }
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.背景情報.喫煙歴有無.名称. = case_when(
          症例.背景情報.喫煙歴有無.名称. == "" ~ "不明",
          TRUE ~ 症例.背景情報.喫煙歴有無.名称.
        )
      )
      return(clin_tmp)}
    )
  })
  observeEvent(input$report_files, {
    Data_report =  reactive({
      clin_tmp = data.frame(NULL)
      for(i in 1:length(input$report_files[,1])){
        Encode = guess_encoding(input$report_files[[i, 'datapath']])[[1]][[1]]
        if(Encode == "Shift_JIS"){
          Encode = "CP932"
        }
        clin_tmp <- rbind(clin_tmp,
                          read.csv(header = TRUE,
                            file(input$report_files[[i, 'datapath']],
                                 encoding=Encode)))
      }
      clin_tmp = clin_tmp %>%
        dplyr::filter(
          !str_detect(C.CAT調査結果.変異情報.マーカー, ",") &
            C.CAT調査結果.変異情報.マーカー != "" &
            C.CAT調査結果.変異情報.変異種類 != "expression"
        )
      if(input$patho == "Only pathogenic muts"){
        clin_tmp = clin_tmp %>%
          dplyr::filter(C.CAT調査結果.エビデンス.エビデンスレベル %in% c("A","B","C","D","E","F"))
      }
      clin_tmp = clin_tmp %>%
        dplyr::mutate(
          C.CAT調査結果.変異情報.マーカー = str_replace(C.CAT調査結果.変異情報.マーカー, "-", "_")
        )
      if(!is.null(input$mutation_rename)){
        mutation_rename_list = data.frame(NULL)
        for(i in 1:length(input$mutation_rename[,1])){
          mutation_rename_list <- rbind(mutation_rename_list,
                                    read.csv(header = TRUE,
                                      file(input$mutation_rename[[i, 'datapath']],
                                           encoding='UTF-8-BOM')))
        }
        Gene_list = sort(unique(mutation_rename_list$Gene))
        clin = clin_tmp %>% dplyr::filter(!C.CAT調査結果.変異情報.マーカー %in% Gene_list)
        for(i in 1:length(Gene_list)){
          mutation_rename_list_tmp = mutation_rename_list[mutation_rename_list$Gene == Gene_list[i],]
          clin_tmp2 = clin_tmp %>% dplyr::filter(C.CAT調査結果.変異情報.マーカー == Gene_list[i])
          clin_tmp2$C.CAT調査結果.変異情報.変異内容_tmp = unlist(lapply(list(clin_tmp2$C.CAT調査結果.変異情報.変異内容), function(x) {
            as.vector(mutation_rename_list_tmp$Rename[match(x, mutation_rename_list_tmp$Mutation)])}))
          clin_tmp2 = clin_tmp2 %>% dplyr::mutate(
            C.CAT調査結果.変異情報.変異内容 = case_when(
              !is.na(C.CAT調査結果.変異情報.変異内容_tmp) ~ C.CAT調査結果.変異情報.変異内容_tmp,
              TRUE ~ C.CAT調査結果.変異情報.変異内容
            )
          )
          clin_tmp2 = clin_tmp2 %>% dplyr::select(-C.CAT調査結果.変異情報.変異内容_tmp)
          clin = rbind(clin, clin_tmp2)
        }
        clin_tmp = clin
      }
      return(clin_tmp)}
    )
  })
  
  Data_case =  reactive({
    clin_tmp = data.frame(NULL)
    for(i in 1:length(input$clinical_files[,1])){
      Encode = guess_encoding(input$clinical_files[[i, 'datapath']])[[1]][[1]]
      if(Encode == "Shift_JIS"){
        Encode = "CP932"
      }
      clin_tmp <- rbind(clin_tmp,
                        read.csv(header = TRUE,
                          file(input$clinical_files[[i, 'datapath']],
                               encoding=Encode)))
    }
    clin_tmp$症例.転帰情報.死亡日[is.na(clin_tmp$症例.転帰情報.死亡日)] = ""
    clin_tmp$症例.転帰情報.最終生存確認日[is.na(clin_tmp$症例.転帰情報.最終生存確認日)] = ""
    clin_tmp$症例.管理情報.登録日[is.na(clin_tmp$症例.管理情報.登録日)] = ""
    clin_tmp$症例.EP前レジメン情報.投与開始日[is.na(clin_tmp$症例.EP前レジメン情報.投与開始日)] = ""
    clin_tmp$症例.EP前レジメン情報.投与終了日[is.na(clin_tmp$症例.EP前レジメン情報.投与終了日)] = ""
    clin_tmp$症例.EP後レジメン情報.投与開始日[is.na(clin_tmp$症例.EP後レジメン情報.投与開始日)] = ""
    clin_tmp$症例.EP後レジメン情報.投与終了日[is.na(clin_tmp$症例.EP後レジメン情報.投与終了日)] = ""
    clin_tmp$症例.管理情報.登録日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.管理情報.登録日)
    clin_tmp$症例.転帰情報.最終生存確認日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.転帰情報.最終生存確認日)
    clin_tmp$症例.転帰情報.死亡日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.転帰情報.死亡日)
    clin_tmp$症例.検体情報.検体採取日.腫瘍組織. = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.検体情報.検体採取日.腫瘍組織.)
    clin_tmp$症例.EP前レジメン情報.投与開始日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP前レジメン情報.投与開始日)
    clin_tmp$症例.EP後レジメン情報.投与開始日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP後レジメン情報.投与開始日)
    clin_tmp$症例.EP前レジメン情報.投与終了日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP前レジメン情報.投与終了日)
    clin_tmp$症例.EP後レジメン情報.投与終了日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.EP後レジメン情報.投与終了日)
    clin_tmp$症例.背景情報.診断日 = str_replace_all(replacement = "-", pattern = "/", string = clin_tmp$症例.背景情報.診断日)
    clin_tmp$症例.基本情報.年齢 = as.integer(clin_tmp$症例.基本情報.年齢)

    clin_tmp$症例.基本情報.がん種.OncoTree..名称. = 
      str_split(str_replace(clin_tmp$症例.基本情報.がん種.OncoTree..名称.,
                            "\\)_", "\\)__"), "__", simplify = TRUE)[,1]
    if(!is.null(input$ID_histology)){
      ID_histology_list = data.frame(NULL)
      for(i in 1:length(input$ID_histology[,1])){
        ID_histology_list <- rbind(ID_histology_list,
                                   read.csv(header = TRUE,
                                     file(input$clinical_files[[i, 'datapath']],
                                          encoding='UTF-8-BOM')))
      }
      clin_tmp$症例.基本情報.がん種.OncoTree..名称._tmp = unlist(lapply(list(clin_tmp$症例.基本情報.がん種.OncoTree..名称.), function(x) {
        as.vector(ID_histology_list$Histology[match(x, ID_histology_list$ID)])}))
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          !is.na(症例.基本情報.がん種.OncoTree..名称._tmp) ~ 症例.基本情報.がん種.OncoTree..名称._tmp,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
    }
    clin_tmp = clin_tmp %>% dplyr::mutate(
      症例.基本情報.がん種.OncoTree..名称. = case_when(
        症例.基本情報.がん種.OncoTree..名称. == "" ~ 症例.基本情報.がん種.OncoTree.LEVEL1.,
        TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
      )
    )
    clin_tmp = clin_tmp %>% dplyr::mutate(
      症例.基本情報.がん種.OncoTree. = case_when(
        症例.基本情報.がん種.OncoTree. == "" ~ 症例.基本情報.がん種.OncoTree.LEVEL1.,
        TRUE ~ 症例.基本情報.がん種.OncoTree.
      )
    )
    if(!is.null(input$histology_rename)){
      histology_rename_list = data.frame(NULL)
      for(i in 1:length(input$histology_rename[,1])){
        histology_rename_list <- rbind(histology_rename_list,
                                       read.csv(header = TRUE,
                                         file(input$histology_rename[[i, 'datapath']],
                                              encoding='UTF-8-BOM')))
      }
      clin_tmp$症例.基本情報.がん種.OncoTree..名称._tmp = unlist(lapply(list(clin_tmp$症例.基本情報.がん種.OncoTree..名称.), function(x) {
        as.vector(histology_rename_list$Rename[match(x, histology_rename_list$Histology)])}))
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          !is.na(症例.基本情報.がん種.OncoTree..名称._tmp) ~ 症例.基本情報.がん種.OncoTree..名称._tmp,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
    }
    clin_tmp = clin_tmp %>% dplyr::mutate(
      症例.基本情報.がん種.OncoTree. = str_replace(str_replace(症例.基本情報.がん種.OncoTree..名称., "\\)", ""), ".*\\(","")
    )
    if(!is.null(input$histology_group_1)){
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_1 ~ str_replace(str_replace(input$histology_group_1_name, "\\)", ""), ".*\\(",""),
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        ),
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_1 ~ input$histology_group_1_name,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
        
      )
    }
    if(!is.null(input$histology_group_2)){
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_2 ~ str_replace(str_replace(input$histology_group_2_name, "\\)", ""), ".*\\(",""),
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        ),
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_2 ~ input$histology_group_2_name,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
    }
    if(!is.null(input$histology_group_3)){
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_3 ~ str_replace(str_replace(input$histology_group_3_name, "\\)", ""), ".*\\(",""),
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        ),
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_3 ~ input$histology_group_3_name,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
    }
    if(!is.null(input$histology_group_4)){
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.基本情報.がん種.OncoTree. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_4 ~ str_replace(str_replace(input$histology_group_4_name, "\\)", ""), ".*\\(",""),
          TRUE ~ 症例.基本情報.がん種.OncoTree.
        ),
        症例.基本情報.がん種.OncoTree..名称. = case_when(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology_group_4 ~ input$histology_group_4_name,
          TRUE ~ 症例.基本情報.がん種.OncoTree..名称.
        )
      )
    }
    clin_tmp = clin_tmp %>% dplyr::mutate(
      症例.背景情報.ECOG.PS.名称. = case_when(
        症例.背景情報.ECOG.PS.名称. == "" ~ "不明",
        TRUE ~ 症例.背景情報.ECOG.PS.名称.
      ),
      症例.背景情報.アルコール多飲有無.名称. = case_when(
        症例.背景情報.アルコール多飲有無.名称. == "" ~ "不明",
        TRUE ~ 症例.背景情報.アルコール多飲有無.名称.
      ),
      症例.背景情報.重複がん有無.異なる臓器..名称. = case_when(
        症例.背景情報.重複がん有無.異なる臓器..名称. == "" ~ "不明",
        TRUE ~ 症例.背景情報.重複がん有無.異なる臓器..名称.
      ),
      症例.背景情報.多発がん有無.同一臓器..名称. = case_when(
        症例.背景情報.多発がん有無.同一臓器..名称. == "" ~ "不明",
        TRUE ~ 症例.背景情報.多発がん有無.同一臓器..名称.
      ),
      症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. = case_when(
        症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. == "" ~ "不明",
        TRUE ~ 症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.
      ),
      症例.EP後レジメン情報.提示された治療薬を投与した.名称. = case_when(
        症例.EP後レジメン情報.提示された治療薬を投与した.名称. == "" ~ "不明",
        TRUE ~ 症例.EP後レジメン情報.提示された治療薬を投与した.名称.
      ),
      症例.背景情報.喫煙歴有無.名称. = case_when(
        症例.背景情報.喫煙歴有無.名称. == "" ~ "不明",
        TRUE ~ 症例.背景情報.喫煙歴有無.名称.
      )
    )
    clin_tmp = clin_tmp %>% 
      dplyr::mutate(症例.EP前レジメン情報.投与開始日 = case_when(
        症例.EP前レジメン情報.投与開始日 < "1924-02-19"  & 症例.EP前レジメン情報.投与開始日 > "1901-01-01"~ paste0("20", str_sub(症例.EP前レジメン情報.投与開始日, 3,10)),
        TRUE ~ 症例.EP前レジメン情報.投与開始日)) %>% 
      dplyr::mutate(症例.EP後レジメン情報.投与開始日 = case_when(
        症例.EP後レジメン情報.投与開始日 < "1924-02-19"  & 症例.EP後レジメン情報.投与開始日 > "1901-01-01"~ paste0("20", str_sub(症例.EP後レジメン情報.投与開始日, 3,10)),
        TRUE ~ 症例.EP後レジメン情報.投与開始日)) %>% 
      dplyr::mutate(症例.EP前レジメン情報.投与終了日 = case_when(
        症例.EP前レジメン情報.投与終了日 < "1924-02-19"  & 症例.EP前レジメン情報.投与終了日 > "1901-01-01"~ paste0("20", str_sub(症例.EP前レジメン情報.投与終了日, 3,10)),
        TRUE ~ 症例.EP前レジメン情報.投与終了日)) %>% 
      dplyr::mutate(症例.EP後レジメン情報.投与終了日 = case_when(
        症例.EP後レジメン情報.投与終了日 < "1924-02-19"  & 症例.EP後レジメン情報.投与終了日 > "1901-01-01"~ paste0("20", str_sub(症例.EP後レジメン情報.投与終了日, 3,10)),
        TRUE ~ 症例.EP後レジメン情報.投与終了日)) %>% 
      dplyr::mutate(症例.EP後レジメン情報.エキスパートパネル開催日 = case_when(
        症例.EP後レジメン情報.エキスパートパネル開催日 < "1924-02-19"  & 症例.EP後レジメン情報.エキスパートパネル開催日 > "1901-01-01"~ paste0("20", str_sub(症例.EP後レジメン情報.エキスパートパネル開催日, 3,10)),
        TRUE ~ 症例.EP後レジメン情報.エキスパートパネル開催日))
    Cancername = table((clin_tmp %>% dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, 症例.基本情報.がん種.OncoTree.)
                        )$症例.基本情報.がん種.OncoTree.)
    Cancername = names(Cancername[Cancername >= input$minimum_pts])
    clin_tmp = clin_tmp %>% dplyr::mutate(
      症例.基本情報.がん種.OncoTree. = case_when(
        症例.基本情報.がん種.OncoTree. %in% Cancername ~ 症例.基本情報.がん種.OncoTree.,
        TRUE ~ 症例.基本情報.がん種.OncoTree.LEVEL1.
    ))

    ID_lymph_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. %in% c("リンパ節", "リンパ節/リンパ管")))$C.CAT調査結果.基本項目.ハッシュID
    ID_brain_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. %in% c("脳", "中枢神経系")))$C.CAT調査結果.基本項目.ハッシュID
    ID_lung_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. == "肺"))$C.CAT調査結果.基本項目.ハッシュID
    ID_bone_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. %in% c("骨髄", "骨")))$C.CAT調査結果.基本項目.ハッシュID
    ID_liver_met = (clin_tmp %>% dplyr::filter(症例.がん種情報.登録時転移部位.名称. == "肝"))$C.CAT調査結果.基本項目.ハッシュID
    ID_other_met = (clin_tmp %>% dplyr::filter(!症例.がん種情報.登録時転移部位.名称. %in%
                                                  c("リンパ節", "リンパ節/リンパ管", "脳", "中枢神経系", "肺", "骨髄", "骨", "肝", "")))$C.CAT調査結果.基本項目.ハッシュID
    clin_tmp =  clin_tmp %>% dplyr::mutate(
      Lymph_met = case_when(
        C.CAT調査結果.基本項目.ハッシュID %in% ID_lymph_met ~ "Yes",
        TRUE ~ "No"
      ),
      Brain_met = case_when(
        C.CAT調査結果.基本項目.ハッシュID %in% ID_brain_met ~ "Yes",
        TRUE ~ "No"
      ),
      Lung_met = case_when(
        C.CAT調査結果.基本項目.ハッシュID %in% ID_lung_met ~ "Yes",
        TRUE ~ "No"
      ),
      Bone_met = case_when(
        C.CAT調査結果.基本項目.ハッシュID %in% ID_bone_met ~ "Yes",
        TRUE ~ "No"
      ),
      Liver_met = case_when(
        C.CAT調査結果.基本項目.ハッシュID %in% ID_liver_met ~ "Yes",
        TRUE ~ "No"
      ),
      Other_met = case_when(
        C.CAT調査結果.基本項目.ハッシュID %in% ID_other_met ~ "Yes",
        TRUE ~ "No"
      )
    )
    
    RenList = read.csv("source/drug_rename.csv", header = T)
    for(i in 1:length(RenList$P1)){
      clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = str_replace_all(clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN., RenList$P1[i], RenList$P2[i])
      clin_tmp$症例.EP後レジメン情報.薬剤名.YJ一般名.EN. = str_replace_all(clin_tmp$症例.EP後レジメン情報.薬剤名.YJ一般名.EN., RenList$P1[i], RenList$P2[i])
    }
    
    if(!is.null(input$regimen_rename)){
      RenList = data.frame(NULL)
      for(i in 1:length(input$regimen_rename[,1])){
        RenList <- rbind(RenList,
                                  read.csv(header = TRUE,
                                           file(input$regimen_rename[[i, 'datapath']],
                                                encoding='UTF-8-BOM')))
      }
      for(i in 1:length(RenList$P1)){
        clin_tmp = clin_tmp %>% dplyr::mutate(
          症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = case_when(
            症例.EP前レジメン情報.薬剤名.YJ一般名.EN. == "" &
              症例.EP前レジメン情報.化学療法レジメン名称 == RenList$P1[i] ~ RenList$P2[i],
            TRUE ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN.
          ))
      }
    }
    if(!is.null(input$drug_rename)){
      drug_rename_list = data.frame(NULL)
      for(i in 1:length(input$drug_rename[,1])){
        drug_rename_list <- rbind(drug_rename_list,
                                  read.csv(header = TRUE,
                                    file(input$drug_rename[[i, 'datapath']],
                                         encoding='UTF-8-BOM')))
      }
      clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp = unlist(lapply(list(clin_tmp$症例.EP前レジメン情報.薬剤名.YJ一般名.EN.), function(x) {
        as.vector(drug_rename_list$Rename[match(x, drug_rename_list$Drug)])}))
      clin_tmp = clin_tmp %>% dplyr::mutate(
        症例.EP前レジメン情報.薬剤名.YJ一般名.EN. = case_when(
          !is.na(症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp) ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN._tmp,
          TRUE ~ 症例.EP前レジメン情報.薬剤名.YJ一般名.EN.
        )
      )
    }
    clin_tmp = clin_tmp %>%
      dplyr::mutate(EP_option = case_when(
        症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. ==
          "はい" ~ 1,
        TRUE ~ 0)) %>%
      dplyr::mutate(EP_treat = case_when(
        症例.EP後レジメン情報.提示された治療薬を投与した.名称. ==
          "投与した" ~ 1,
        TRUE ~ 0))
    clin_tmp = clin_tmp %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                    症例.基本情報.年齢,
                    Lymph_met,
                    Brain_met,
                    Lung_met,
                    Bone_met,
                    Liver_met,
                    Other_met,
                    EP_option,
                    EP_treat,
                    症例.基本情報.性別.名称.,
                    症例.基本情報.がん種.OncoTree.,
                    症例.基本情報.がん種.OncoTree..名称.,
                    症例.基本情報.がん種.OncoTree.LEVEL1.,
                    症例.検体情報.パネル.名称.,
                    症例.背景情報.ECOG.PS.名称.,
                    症例.背景情報.喫煙歴有無.名称.,
                    症例.背景情報.アルコール多飲有無.名称.,
                    症例.背景情報.重複がん有無.異なる臓器..名称.,
                    症例.背景情報.多発がん有無.同一臓器..名称.,
                    症例.がん種情報.登録時転移部位.名称.,
                    症例.検体情報.腫瘍細胞含有割合,
                    症例.検体情報.検体採取部位.名称.,
                    症例.EP前レジメン情報.治療ライン.名称.,
                    症例.EP前レジメン情報.実施目的.名称.,
                    症例.EP前レジメン情報.化学療法レジメン名称,
                    症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                    症例.EP前レジメン情報.投与開始日,
                    症例.EP前レジメン情報.投与終了日,
                    症例.EP前レジメン情報.終了理由.名称.,
                    症例.EP前レジメン情報.レジメン継続区分.名称.,
                    症例.EP前レジメン情報.最良総合効果.名称.,
                    症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                    症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                    症例.EP後レジメン情報.治療ライン,
                    症例.EP後レジメン情報.治療ライン.名称.,
                    症例.EP後レジメン情報.化学療法レジメン名称,
                    症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                    症例.EP後レジメン情報.投与開始日,
                    症例.EP後レジメン情報.投与終了日,
                    症例.EP後レジメン情報.終了理由.名称.,
                    症例.EP後レジメン情報.レジメン継続区分.名称.,
                    症例.EP後レジメン情報.最良総合効果.名称.,
                    症例.転帰情報.転帰.名称.,
                    症例.背景情報.診断日,
                    症例.管理情報.登録日,
                    症例.転帰情報.最終生存確認日,
                    症例.転帰情報.死亡日
      )
    return(clin_tmp)
  })

  Data_report =  reactive({
    clin_tmp = data.frame(NULL)
    for(i in 1:length(input$report_files[,1])){
      Encode = guess_encoding(input$report_files[[i, 'datapath']])[[1]][[1]]
      if(Encode == "Shift_JIS"){
        Encode = "CP932"
      }
      clin_tmp <- rbind(clin_tmp,
                        read.csv(header = TRUE,
                          file(input$report_files[[i, 'datapath']],
                               encoding=Encode)))
    }
    Data_MAF = clin_tmp
    Data_MAF$C.CAT調査結果.変異情報.物理位置2 =
      Data_MAF$C.CAT調査結果.変異情報.物理位置
    Data_MAF = Data_MAF %>%
      dplyr::select(C.CAT調査結果.変異情報.マーカー,
                    C.CAT調査結果.変異情報.クロモソーム番号,
                    C.CAT調査結果.変異情報.物理位置,
                    C.CAT調査結果.変異情報.物理位置2,
                    C.CAT調査結果.変異情報.リファレンス塩基,
                    C.CAT調査結果.変異情報.塩基変化,
                    C.CAT調査結果.変異情報.変異種類,
                    C.CAT調査結果.エビデンス.エビデンスレベル,
                    C.CAT調査結果.エビデンス.薬剤,
                    C.CAT調査結果.基本項目.ハッシュID,
                    C.CAT調査結果.変異情報.変異アレル頻度,
                    C.CAT調査結果.変異情報.変異内容,
                    C.CAT調査結果.変異情報TMB.TMB)
    colnames(Data_MAF) = c("Hugo_Symbol",
                           "Chromosome",
                           "Start_Position",
                           "End_Position",
                           "Reference_Allele",
                           "Tumor_Seq_Allele2",
                           "Variant_Classification",
                           "Evidence_level",
                           "Drug",
                           "Tumor_Sample_Barcode",
                           "VAF",
                           "amino.acid.change",
                           "TMB")
    Data_MAF = Data_MAF %>% dplyr::mutate(
      Variant_Classification = case_when(
        Variant_Classification == "rearrangement" &
          amino.acid.change == "rearrangements" ~ "rearrangement",
        Variant_Classification == "rearrangement" &
          amino.acid.change == "long deletion" ~ "deletion",
        Variant_Classification == "rearrangement" ~ amino.acid.change,
        Variant_Classification == "copy_number_alteration" ~ amino.acid.change,
        Variant_Classification == "small_scale_variant" ~ "small_scale_variant",
        Variant_Classification == "other_biomarker" ~ "TMB_high",
        TRUE ~ Variant_Classification
      ))
    Data_MAF = Data_MAF %>% dplyr::mutate(
      Variant_Type = case_when(
        nchar(Reference_Allele) == 1 &
          nchar(Tumor_Seq_Allele2) == 1 ~ "SNP",
        nchar(Reference_Allele) == 2 &
          nchar(Tumor_Seq_Allele2) == 2 ~ "DNP",
        nchar(Reference_Allele) == 3 &
          nchar(Tumor_Seq_Allele2) == 3 ~ "TNP",
        nchar(Reference_Allele) == 1 &
          Reference_Allele != "-" &
          nchar(Tumor_Seq_Allele2) > 1 ~ "INS",
        nchar(Reference_Allele) > 1 &
          Tumor_Seq_Allele2 != "-" ~ Variant_Classification,
        TRUE ~ "Other"
      ))
    Data_MAF = Data_MAF %>%
      dplyr::filter(
        !str_detect(Hugo_Symbol, ",") &
          Hugo_Symbol != "" &
          Variant_Classification != "expression"
      )
    Data_MAF = Data_MAF %>%
      dplyr::mutate(
        Hugo_Symbol = str_replace(Hugo_Symbol, "-", "_")
      )
    if(!is.null(input$mutation_rename)){
      mutation_rename_list = data.frame(NULL)
      for(i in 1:length(input$mutation_rename[,1])){
        mutation_rename_list <- rbind(mutation_rename_list,
                                      read.csv(header = TRUE,
                                        file(input$mutation_rename[[i, 'datapath']],
                                             encoding='UTF-8-BOM')))
      }
      Gene_list = sort(unique(mutation_rename_list$Gene))
      Data = Data_MAF %>% dplyr::filter(!Hugo_Symbol %in% Gene_list)
      for(i in 1:length(Gene_list)){
        mutation_rename_list_tmp = mutation_rename_list[mutation_rename_list$Gene == Gene_list[i],]
        Data_MAF2 = Data_MAF %>% dplyr::filter(Hugo_Symbol == Gene_list[i])
        Data_MAF2$C.CAT調査結果.変異情報.変異内容_tmp = unlist(lapply(list(Data_MAF2$amino.acid.change), function(x) {
          as.vector(mutation_rename_list_tmp$Rename[match(x, mutation_rename_list_tmp$Mutation)])}))
        Data_MAF2 = Data_MAF2 %>% dplyr::mutate(
          amino.acid.change = case_when(
            !is.na(C.CAT調査結果.変異情報.変異内容_tmp) ~ C.CAT調査結果.変異情報.変異内容_tmp,
            TRUE ~ amino.acid.change
          )
        )
        Data_MAF2 = Data_MAF2 %>% dplyr::select(-C.CAT調査結果.変異情報.変異内容_tmp)
        Data = rbind(Data, Data_MAF2)
      }
      Data_MAF = Data
    }
    return(Data_MAF)}
  )
  
  observeEvent(input$start_setting, {
    Data_case_tmp = Data_case()
    Data_report_tmp = Data_report()
      output$select_histology = renderUI({ 
      pickerInput("histology", "Filter by histology",
                  choices = sort(unique(Data_case_tmp$症例.基本情報.がん種.OncoTree..名称.)), 
                  selected = sort(unique(Data_case_tmp$症例.基本情報.がん種.OncoTree..名称.)), multiple = TRUE)
    })
    output$select_histology_group_1 = renderUI({ 
      pickerInput("histology_group_1", "まとめて解析する組織型1(なければ未選択)",
                  input$histology, multiple = TRUE)
    })
    output$select_histology_group_1_name = renderUI({ 
      pickerInput("histology_group_1_name", "まとめて解析する組織型1の名前",
                  input$histology_group_1, multiple = FALSE)
    })
    output$select_histology_group_2 = renderUI({ 
      pickerInput("histology_group_2", "まとめて解析する組織型2(なければ未選択)",
                  input$histology[-which(input$histology %in%
                                           input$histology_group_1)], multiple = TRUE)
    })
    output$select_histology_group_2_name = renderUI({ 
      pickerInput("histology_group_2_name", "まとめて解析する組織型2の名前",
                  input$histology_group_2, multiple = FALSE)
    })
    output$select_histology_group_3 = renderUI({ 
      pickerInput("histology_group_3", "まとめて解析する組織型3(なければ未選択)",
                  input$histology[-which(input$histology %in%
                                           c(input$histology_group_1,
                                             input$histology_group_2))], multiple = TRUE)
    })
    output$select_histology_group_3_name = renderUI({ 
      pickerInput("histology_group_3_name", "まとめて解析する組織型3の名前",
                  input$histology_group_3, multiple = FALSE)
    })
    output$select_histology_group_4 = renderUI({ 
      pickerInput("histology_group_4", "まとめて解析する組織型4(なければ未選択)",
                  input$histology[-which(input$histology %in%
                                           c(input$histology_group_1,
                                             input$histology_group_2,
                                             input$histology_group_3))], multiple = TRUE)
    })
    output$select_histology_group_4_name = renderUI({ 
      pickerInput("histology_group_4_name", "まとめて解析する組織型4の名前",
                  input$histology_group_4, multiple = FALSE)
    })
    output$select_sex = renderUI({ 
      pickerInput("sex", "Filter by sex",
                  choices = sort(unique(Data_case_tmp$症例.基本情報.性別.名称.)), 
                  selected = sort(unique(Data_case_tmp$症例.基本情報.性別.名称.)), multiple = TRUE)
    })
    output$select_minimum_pts = renderUI({ 
      numericInput("minimum_pts", "Minimum patients for each histology",
                   value = 1,
                   min = 1,
                   max = length((Data_case_tmp %>% dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID))$C.CAT調査結果.基本項目.ハッシュID),
                   step = 1)
    })
    output$select_eps = renderUI({ 
      numericInput("eps", "Distance value for DBSCAN clustering",
                   value = 1.0,
                   min = 0,
                   max = 10,
                   step = 1)
    })
    output$select_panel = renderUI({ 
      pickerInput("panel", "Filter by panel",
                  choices = sort(unique(Data_case_tmp$症例.検体情報.パネル.名称.)), 
                  selected = sort(unique(Data_case_tmp$症例.検体情報.パネル.名称.)), multiple = TRUE)
    })
    output$select_age = renderUI({ 
      sliderInput(inputId = "age", label = "Age for analysis",
                  value = c(
                    min(Data_case_tmp$症例.基本情報.年齢, na.rm = TRUE),
                    max(Data_case_tmp$症例.基本情報.年齢, na.rm = TRUE)),
                  min = min(Data_case_tmp$症例.基本情報.年齢, na.rm = TRUE),
                  max = max(Data_case_tmp$症例.基本情報.年齢, na.rm = TRUE),
                  step = 1)
    })
    output$select_mid_age = renderUI({ 
      sliderInput(inputId = "mid_age", label = "Threshold age for oncoprint",
                  value = median(Data_case_tmp$症例.基本情報.年齢, na.rm = TRUE),
                  min = min(Data_case_tmp$症例.基本情報.年齢, na.rm = TRUE),
                  max = max(Data_case_tmp$症例.基本情報.年齢, na.rm = TRUE),
                  step = 1)
    })
    output$select_PS = renderUI({ 
      pickerInput("PS", "Filter by performance status",
                  choices = sort(unique(Data_case_tmp$症例.背景情報.ECOG.PS.名称.)), 
                  selected = sort(unique(Data_case_tmp$症例.背景情報.ECOG.PS.名称.)), multiple = TRUE)
    })
    output$select_smoking = renderUI({ 
      pickerInput("smoking", "Filter by smoking status",
                  choices = sort(unique(Data_case_tmp$症例.背景情報.喫煙歴有無.名称.)), 
                  selected = sort(unique(Data_case_tmp$症例.背景情報.喫煙歴有無.名称.)), multiple = TRUE)
    })
    output$select_gene = renderUI({ 
      pickerInput("gene", "注目する遺伝子(なければ未選択)", sort(unique(Data_report_tmp$Hugo_Symbol)), multiple = TRUE)
    })
    output$select_gene_group_1 = renderUI({ 
      pickerInput("gene_group_1", "注目する遺伝子セット1(なければ未選択)",
                  input$gene, multiple = TRUE)
    })
    output$select_gene_group_2 = renderUI({ 
      pickerInput("gene_group_2", "注目する遺伝子セット2(なければ未選択)",
                  input$gene[-which(input$gene %in% input$gene_group_1)], multiple = TRUE)
    })
    output$select_gene_no = renderUI({ 
      numericInput(inputId = "gene_no", label = "Gene number for oncoprint",
                   value = min(30, length(sort(unique(Data_report_tmp$Hugo_Symbol)))),
                   min = max(1, length(input$gene)),
                   max = length(sort(unique(Data_report_tmp$Hugo_Symbol))),
                   step = 1)
    })
    output$select_patho = renderUI({ 
      radioButtons(
        "patho", "Variants for analysis",
        choices = c("Only pathogenic muts", "All muts"),
        selected = "Only pathogenic muts")
    })
    output$select_oncoprint_option = renderUI({ 
      radioButtons(
        "oncoprint_option", "Oncoprintの表示",
        choices = c("Sort by mutation frequency", "Sort by pathology", "Sort by age"),
        selected = "Sort by mutation frequency")
    })
  })
  output$download_ID_histology = downloadHandler(
    filename = "ID_histology.csv",
    content = function(file) {
      csv_file = read.csv("source/ID_histology.csv", fileEncoding = "UTF-8")
      write_excel_csv(csv_file, file)
    }
  )
  output$download_ID_drug_pre_CGP = downloadHandler(
    filename = "ID_drug_pre_CGP.csv",
    content = function(file) {
      csv_file = read.csv("source/ID_drug_pre_CGP.csv", fileEncoding = "UTF-8")
      write_excel_csv(csv_file, file)
    }
  )
  output$download_ID_drug_post_CGP = downloadHandler(
    filename = "ID_drug_post_CGP.csv",
    content = function(file) {
      csv_file = read.csv("source/ID_drug_post_CGP.csv", fileEncoding = "UTF-8")
      write_excel_csv(csv_file, file)
    }
  )
  output$download_drug_rename = downloadHandler(
    filename = "table_drug_rename.csv",
    content = function(file) {
      csv_file = read.csv("source/table_drug_rename.csv", fileEncoding = "UTF-8")
      write_excel_csv(csv_file, file)
    }
  )
  output$download_regimen_rename = downloadHandler(
    filename = "table_regimen_rename.csv",
    content = function(file) {
      csv_file = read.csv("source/table_regimen_rename.csv", fileEncoding = "UTF-8")
      write_excel_csv(csv_file, file)
    }
  )
  output$download_histology_rename = downloadHandler(
    filename = "table_histology_rename.csv",
    content = function(file) {
      csv_file = read.csv("source/table_histology_rename.csv", fileEncoding = "UTF-8")
      write_excel_csv(csv_file, file)
    }
  )
  output$download_mutation_rename = downloadHandler(
    filename = "table_mutation_rename.csv",
    content = function(file) {
      csv_file = read.csv("source/table_mutation_rename.csv", fileEncoding = "UTF-8")
      write_excel_csv(csv_file, file)
    }
  )

  observeEvent(input$summary_base, {
    Data_case_target = Data_case() %>%
      dplyr::filter(
        症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
          症例.検体情報.パネル.名称. %in% input$panel &
          症例.背景情報.ECOG.PS.名称. %in% input$PS &
          症例.基本情報.性別.名称. %in% input$sex &
          症例.背景情報.喫煙歴有無.名称. %in% input$smoking
      )
    if(!all(input$age != c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                           max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
      Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
      Data_case_target = Data_case_target %>% dplyr::filter(
        症例.基本情報.年齢 >= input$age[1] &
          症例.基本情報.年齢 <= input$age[2]
      )
    }
    Data_case_target = Data_case_target %>% dplyr::mutate(YoungOld = case_when(
      症例.基本情報.年齢 <= input$mid_age ~ "Younger",
      TRUE ~ "Older"))
    
    Data_summary = Data_case_target %>%
      dplyr::filter(
        症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
          症例.検体情報.パネル.名称. %in% input$panel &
          症例.基本情報.性別.名称. %in% input$sex &
          症例.背景情報.ECOG.PS.名称. %in% input$PS &
          症例.背景情報.喫煙歴有無.名称. %in% input$smoking
      ) %>% 
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID,.keep_all=TRUE) %>%
      dplyr::select(
        症例.基本情報.がん種.OncoTree..名称.,
        症例.基本情報.性別.名称.,
        症例.基本情報.年齢,
        症例.背景情報.喫煙歴有無.名称.,
        症例.背景情報.アルコール多飲有無.名称.,
        症例.背景情報.ECOG.PS.名称.,
        症例.背景情報.重複がん有無.異なる臓器..名称.,
        症例.背景情報.多発がん有無.同一臓器..名称.,
        症例.検体情報.パネル.名称.,
        症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
        症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
        Lymph_met,
        Brain_met,
        Lung_met,
        Bone_met,
        Liver_met,
        Other_met)

    output$table_summary <- render_gt({
      Data_summary %>%
        tbl_summary(    statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                              "{mean} ({sd})",
                                                              "{median} ({p25}, {p75})", 
                                                              "{min}, {max}"),
                                         all_categorical() ~ "{n} / {N} ({p}%)"),
                        type = all_continuous() ~ "continuous2",
                        digits = all_continuous() ~ 2,
                        missing = "ifany") %>%
        modify_caption("**Patient Characteristics** (N = {N})") %>%
        bold_labels() %>% as_gt()
    })
  })

  observeEvent(input$oncoprint, {
   Data_case_target = Data_case() %>%
     dplyr::filter(
       症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
         症例.検体情報.パネル.名称. %in% input$panel &
         症例.基本情報.性別.名称. %in% input$sex &
         症例.背景情報.ECOG.PS.名称. %in% input$PS &
         症例.背景情報.喫煙歴有無.名称. %in% input$smoking
     )
   if(!all(input$age == c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                         max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
     Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
     Data_case_target = Data_case_target %>% dplyr::filter(
       症例.基本情報.年齢 >= input$age[1] &
         症例.基本情報.年齢 <= input$age[2]
     )
   }
   Data_case_target = Data_case_target %>% dplyr::mutate(
     YoungOld = case_when(
     症例.基本情報.年齢 <= input$mid_age ~ "Younger",
     TRUE ~ "Older"))
   Data_MAF = Data_report() %>%
     dplyr::filter(
       !str_detect(Hugo_Symbol, ",") &
       Hugo_Symbol != "" &
       Evidence_level %in% c("","A","B","C","D","E","F") &
       Variant_Classification != "expression"
     ) %>% 
     dplyr::arrange(desc(Evidence_level)) %>%
     dplyr::distinct(Tumor_Sample_Barcode,
                     Hugo_Symbol,
                     Start_Position,
                     .keep_all = TRUE)
   Data_MAF$TMB = as.numeric(str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1])
   if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
     Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
   }
   if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
     Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
   }
   Data_report_TMB = Data_MAF %>%
     dplyr::filter(Hugo_Symbol == "TMB") %>%
     dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
     dplyr::arrange(Tumor_Sample_Barcode) %>%
     dplyr::mutate(Evidence_level = case_when(
       TMB < 10 ~ "",
       TMB >= 10 ~ "F",
       TRUE ~ ""
     ))
   Data_MAF = Data_MAF %>%
     dplyr::arrange(Tumor_Sample_Barcode) %>%
     dplyr::filter(Hugo_Symbol != "TMB")
   Data_MAF = rbind(Data_MAF, Data_report_TMB)

   Data_MAF_target = Data_MAF %>%
     dplyr::filter(Tumor_Sample_Barcode %in%
                     Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
   if(input$patho == "Only pathogenic muts"){
     Data_MAF_target = Data_MAF_target %>%
       dplyr::filter(Evidence_level == "F")
   } else {
     Data_MAF_target = Data_MAF_target %>%
       dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
   }
   Data_MAF_target_tmp = Data_MAF_target %>%
     dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change, .keep_all = T) %>%
     dplyr::arrange(Tumor_Sample_Barcode, Hugo_Symbol, amino.acid.change)
   Data_MAF_target = Data_MAF_target %>%
     dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, .keep_all = T) %>%
     dplyr::arrange(Hugo_Symbol, Tumor_Sample_Barcode)
   output$figure_oncoprint = renderPlot({
     fun_oncoprint(Data_MAF_target,
                   Data_case_target,
                   names(sort(table(Data_MAF_target$Hugo_Symbol),
                              decreasing = T)),
                   input$gene,
                   input$gene_no,
                   input$gene_group_1,
                   input$gene_group_2,
                   input$oncoprint_option,
                   input$mid_age)
   })
   Data_case_target = Data_case_target %>%
     dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE) %>%
     dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                   症例.基本情報.年齢,
                   YoungOld,
                   Lymph_met,
                   Brain_met,
                   Lung_met,
                   Bone_met,
                   Liver_met,
                   Other_met,
                   EP_option,
                   EP_treat,
                   症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称.,
                   症例.EP後レジメン情報.提示された治療薬を投与した.名称.,
                   症例.基本情報.性別.名称.,
                   症例.基本情報.がん種.OncoTree.,
                   症例.基本情報.がん種.OncoTree..名称.,
                   症例.基本情報.がん種.OncoTree.LEVEL1.,
                   症例.検体情報.パネル.名称.,
                   症例.背景情報.ECOG.PS.名称.,
                   症例.背景情報.喫煙歴有無.名称.,
                   症例.背景情報.アルコール多飲有無.名称.,
                   症例.背景情報.重複がん有無.異なる臓器..名称.,
                   症例.背景情報.多発がん有無.同一臓器..名称.,
                   症例.がん種情報.登録時転移部位.名称.,
                   症例.検体情報.腫瘍細胞含有割合,
                   症例.検体情報.検体採取部位.名称.,
                   症例.転帰情報.転帰.名称.,
                   症例.背景情報.診断日,
                   症例.管理情報.登録日,
                   症例.転帰情報.最終生存確認日,
                   症例.転帰情報.死亡日
                   ) %>%
     dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE) %>%
     dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
   gene_list = unique(c(input$gene,
                 names(sort(table(Data_MAF_target$Hugo_Symbol),
                          decreasing = T))))
   gene_list = gene_list[1:min(input$gene_no, length(gene_list))]
   gene_table = data.frame(matrix(rep(rep("", length(gene_list)),
                                      length(Data_case_target$C.CAT調査結果.基本項目.ハッシュID)),
                                  nrow=length(Data_case_target$C.CAT調査結果.基本項目.ハッシュID)))
   rownames(gene_table) = Data_case_target$C.CAT調査結果.基本項目.ハッシュID
   colnames(gene_table) = gene_list
   for(i in 1:length(gene_list)){
     tmp_mut = Data_MAF_target_tmp %>%
       dplyr::filter(Hugo_Symbol == gene_list[i])
     ID_mut = tmp_mut$Tumor_Sample_Barcode
     Variant_mut = tmp_mut$amino.acid.change
     for(j in 1:length(ID_mut)){
       if(gene_table[ID_mut[j],i] == ""){
         gene_table[ID_mut[j],i] = Variant_mut[j]
       } else{
         gene_table[ID_mut[j],i] = paste(gene_table[ID_mut[j],i], Variant_mut[j], sep=",")
       }
     }
   }
   gene_table$C.CAT調査結果.基本項目.ハッシュID = rownames(gene_table)
   Data_case_target = left_join(Data_case_target,
                                gene_table,
                                by = "C.CAT調査結果.基本項目.ハッシュID")
   output$table_patient = DT::renderDataTable(Data_case_target,
                                              server = FALSE,
                                              filter = 'top', 
                                              extensions = c('Buttons'), 
                                              options = list(pageLength = 100, 
                                                             scrollX = TRUE,
                                                             scrollY = "1000px",
                                                             scrollCollapse = TRUE,
                                                             dom="Blfrtip",
                                                             buttons = c('csv', 'copy')))
  })
  
  # Mutually exclusive or co-occurrence
  observeEvent(input$mutually_exclusive, {
    output$figure_mutually_exclusive = renderPlot({
      Data_case_target = Data_case() %>%
        dplyr::filter(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
            症例.検体情報.パネル.名称. %in% input$panel &
            症例.基本情報.性別.名称. %in% input$sex &
            症例.背景情報.ECOG.PS.名称. %in% input$PS &
            症例.背景情報.喫煙歴有無.名称. %in% input$smoking
        )
      if(!all(input$age == c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                            max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
        Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
        Data_case_target = Data_case_target %>% dplyr::filter(
          症例.基本情報.年齢 >= input$age[1] &
            症例.基本情報.年齢 <= input$age[2]
        )
      }
      Data_case_target = Data_case_target %>% dplyr::mutate(YoungOld = case_when(
        症例.基本情報.年齢 <= input$mid_age ~ "Younger",
        TRUE ~ "Older"))
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
      Data_MAF$TMB = as.numeric(str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1])
      if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
        Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
      }
      if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }
      Data_report_TMB = Data_MAF %>%
        dplyr::filter(Hugo_Symbol == "TMB") %>%
        dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
        dplyr::arrange(Tumor_Sample_Barcode) %>%
        dplyr::mutate(Evidence_level = case_when(
          TMB < 10 ~ "",
          TMB >= 10 ~ "F",
          TRUE ~ ""
        ))
      Data_MAF = Data_MAF %>%
        dplyr::arrange(Tumor_Sample_Barcode) %>%
        dplyr::filter(Hugo_Symbol != "TMB")
      Data_MAF = rbind(Data_MAF, Data_report_TMB)
      
      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      } else {
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
        
      }
      Data_MAF_target = Data_MAF_target  %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        .keep_all = TRUE)
      Gene_names = unique(c(input$gene,
                            names(sort(table(Data_MAF_target$Hugo_Symbol),
                                       decreasing = T))))
      Gene_names = Gene_names[1:min(length(unique(Data_MAF_target$Hugo_Symbol)),input$gene_no)]
      Patient_names = unique(Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      Mutation_matrix = matrix(rep(0, length(Gene_names) * length(Patient_names)),
                               nrow = length(Gene_names),
                               ncol = length(Patient_names))
      rownames(Mutation_matrix) = Gene_names
      colnames(Mutation_matrix) = Patient_names
      
      Mutation_list_for_matrix = Data_MAF_target %>%
        dplyr::filter(Hugo_Symbol %in% Gene_names)
      for(i in 1:length(Mutation_list_for_matrix$Hugo_Symbol)){
        Mutation_matrix[Mutation_list_for_matrix$Hugo_Symbol[i],
                        Mutation_list_for_matrix$Tumor_Sample_Barcode[i]] = 1
      }
      PMA <- getPM(Mutation_matrix)
      mutually_exclusive <- getMutex(A=Mutation_matrix,PM=PMA)
      colnames(mutually_exclusive) = Gene_names
      rownames(mutually_exclusive) = Gene_names
      mutually_exclusive[lower.tri(mutually_exclusive,diag=TRUE)] <- NA
      Data_mut_ex = expand.grid(Gene_names, Gene_names)
      colnames(Data_mut_ex) = c("Gene_1", "Gene_2")
      Data_mut_ex$P_value = mutually_exclusive@x
      Data_mut_ex = Data_mut_ex %>%
        dplyr::mutate(P_value = case_when(
          P_value > 1-10^-10 ~ 1-10^-10,
          P_value < 10^-10 ~ 10^-10,
          TRUE ~ P_value
        ))
      Data_mut_ex = Data_mut_ex %>%
        dplyr::mutate(P_co_or_ex = case_when(
          P_value > 0.5 ~ log(1-P_value,base=10),
          TRUE ~ -log(P_value,base=10)
        ))
      Data_mut_ex = Data_mut_ex %>%
        dplyr::mutate(P_figure = case_when(
          P_co_or_ex > 3 ~ 3,
          P_co_or_ex < -3 ~ -3,
          TRUE ~ P_co_or_ex
        ))
      Data_mut_ex = Data_mut_ex %>%
        dplyr::mutate(P_signif = case_when(
          P_value <= 0.001 | P_value >= 0.999 ~ "*",
          TRUE ~ ""
        ))
      
      Data_mut_ex$Gene_1 <- factor(Data_mut_ex$Gene_1, levels = Gene_names)
      Data_mut_ex$Gene_2 <- factor(Data_mut_ex$Gene_2, levels = Gene_names)
      
      Data_mut_ex %>% 
        ggplot(aes(x = Gene_1, y = Gene_2, fill = P_figure)) + 
        geom_tile(color = "white") + 
        scale_fill_gradient2(low = "red", high = "blue", mid = "white", 
                             midpoint = 0, limit = c(-3, 3), 
                             breaks = -3:3,
                             labels = c(3,2,1,0,1,2,3),
                             name = "-log10(P-value)", space = "Lab",
                             na.value = "white") +
        geom_text(aes(label = P_signif),
                  color = "black", size = 4)+
        scale_y_discrete(limits = rev(levels(Data_mut_ex$Gene_2))) +
        theme_classic() +
        ggtitle("Mutually exclusive (blue) or co-occurrence (red)\n*: p<0.001, estimated with Rediscover package") +
        theme(axis.text.x = element_text(angle = 45, hjust = 1))
    })
  })

  observeEvent(input$mut_subtype, {
    output$figure_mut_subtype = renderPlot({
      Data_case_target = Data_case() %>%
        dplyr::filter(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
            症例.検体情報.パネル.名称. %in% input$panel &
            症例.基本情報.性別.名称. %in% input$sex &
            症例.背景情報.ECOG.PS.名称. %in% input$PS &
            症例.背景情報.喫煙歴有無.名称. %in% input$smoking
        )
      if(!all(input$age == c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                             max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
        Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
        Data_case_target = Data_case_target %>% dplyr::filter(
          症例.基本情報.年齢 >= input$age[1] &
            症例.基本情報.年齢 <= input$age[2]
        )
      }
      Data_case_target = Data_case_target %>% dplyr::mutate(
        YoungOld = case_when(
          症例.基本情報.年齢 <= input$mid_age ~ "Younger",
          TRUE ~ "Older"))
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
      Data_MAF$TMB = as.numeric(str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1])
      if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
        Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
      }
      if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }
      Data_report_TMB = Data_MAF %>%
        dplyr::filter(Hugo_Symbol == "TMB") %>%
        dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
        dplyr::arrange(Tumor_Sample_Barcode) %>%
        dplyr::mutate(Evidence_level = case_when(
          TMB < 10 ~ "",
          TMB >= 10 ~ "F",
          TRUE ~ ""
        ))
      Data_MAF = Data_MAF %>%
        dplyr::arrange(Tumor_Sample_Barcode) %>%
        dplyr::filter(Hugo_Symbol != "TMB")
      Data_MAF = rbind(Data_MAF, Data_report_TMB)
      
      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      } else {
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
        
      }
      Data_MAF_target = Data_MAF_target  %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        .keep_all = TRUE)
      gene_to_analyze = unique(c(input$gene,
                            names(sort(table(Data_MAF_target$Hugo_Symbol),
                                       decreasing = T))))
      gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_MAF_target$Hugo_Symbol)),input$gene_no)]
      Diseases = sort(unique(Data_case_target$症例.基本情報.がん種.OncoTree.))
      Summary_Gene_alteration = data.frame(matrix(0,
                                                  nrow=length(Diseases),
                                                  ncol=length(gene_to_analyze)))
      colnames(Summary_Gene_alteration) = gene_to_analyze
      rownames(Summary_Gene_alteration) = Diseases
      
      for(i in Diseases){
        Data_tmp = Data_case_target %>%
          dplyr::filter(症例.基本情報.がん種.OncoTree. == i)
        Data_tmp = unique(Data_tmp$C.CAT調査結果.基本項目.ハッシュID)
        patient_no = length(Data_tmp)
        for(j in gene_to_analyze){
          Summary_Gene_alteration[i,j] =
            length((Data_MAF_target %>% dplyr::filter(
              Hugo_Symbol == j &
                Tumor_Sample_Barcode %in% Data_tmp))$Hugo_Symbol) / patient_no * 100
        }
      }
      
      Data_tmp = Summary_Gene_alteration
      Data_tmp$Disease = rownames(Data_tmp)
      Data_tmp = Data_tmp %>% gather(value = "freq", key = Gene, -Disease)
      Data_tmp <- transform(Data_tmp, Disease= factor(Disease, levels = sort(unique(Disease), decreasing = TRUE)))
      ggplot(Data_tmp, aes(as.factor(Gene), as.factor(Disease))) +
        geom_tile(aes(fill = freq), color = "black",
                  #            lwd = 1,
                  linetype = 1) + 
        geom_text(aes(label = round(freq, 0))) +
        scale_fill_gradient(low = "white", high = "red") +
        theme_classic() +
        labs(title = "Frequently mutated genes and diagnoses") +
        theme(axis.text.x = element_text(angle = 45, hjust = 1),
              axis.title.x = element_blank(),
              axis.title.y = element_blank(),
              axis.ticks.x = element_blank(),
              axis.ticks.y = element_blank(),
              axis.line.x = element_blank(),
              axis.line.y = element_blank())
    })
  })

  
  observeEvent(input$custering_analysis, {
    Data_case_target = Data_case() %>%
      dplyr::filter(
        症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
          症例.検体情報.パネル.名称. %in% input$panel &
          症例.基本情報.性別.名称. %in% input$sex &
          症例.背景情報.ECOG.PS.名称. %in% input$PS &
          症例.背景情報.喫煙歴有無.名称. %in% input$smoking
      )
    if(!all(input$age == c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                           max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
      Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
      Data_case_target = Data_case_target %>% dplyr::filter(
        症例.基本情報.年齢 >= input$age[1] &
          症例.基本情報.年齢 <= input$age[2]
      )
    }
    
    Data_case_target$Cancers = Data_case_target$症例.基本情報.がん種.OncoTree.
    Cancername = sort(unique(Data_case_target$Cancers))
    Total_pts = as.vector(table((Data_case_target %>%
                  dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = T))$Cancers))
    Data_survival = Data_case_target %>%
      dplyr::mutate(final_observe = case_when(
        症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
        症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
        症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
        TRUE ~ 症例.管理情報.登録日))
    Data_survival = Data_survival %>%
      dplyr::arrange(desc(final_observe)) %>%
      dplyr::mutate(censor = case_when(
        症例.転帰情報.死亡日 != "" ~ 1,
        TRUE ~ 0)) %>%
      dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
    
    Data_survival = Data_survival %>%
      dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
      dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
    
    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, censor) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_survival = Data_survival %>%
      dplyr::mutate(final_observe = as.Date(Data_survival$final_observe)) %>%
      dplyr::mutate(症例.管理情報.登録日 =
                      as.Date(Data_survival$症例.管理情報.登録日)) %>%
      dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                      as.Date(症例.EP前レジメン情報.投与開始日))
    
    Data_survival = Data_survival %>%
      dplyr::mutate(time_enroll_final =
                      as.integer(difftime(Data_survival$final_observe,
                                          Data_survival$症例.管理情報.登録日,
                                          units = "days")))
    Data_survival = Data_survival %>%
      dplyr::mutate(time_palliative_final =
                      as.integer(difftime(Data_survival$final_observe,
                                          Data_survival$症例.EP前レジメン情報.投与開始日,
                                          units = "days")))
    Data_survival = Data_survival %>%
      dplyr::mutate(time_palliative_enroll =
                      Data_survival$time_palliative_final -
                      Data_survival$time_enroll_final)

    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, final_observe) %>%
      dplyr::arrange(desc(final_observe)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")

    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_enroll_final) %>%
      dplyr::arrange(desc(time_enroll_final)) %>%
      dplyr::filter(time_enroll_final > 0 & !is.na(time_enroll_final) & is.finite(time_enroll_final)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")

    Data_survival_tmp = Data_survival %>%
      dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                      c("その他", "緩和")) %>%
      dplyr::arrange(症例.EP前レジメン情報.投与開始日) %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_palliative_enroll, time_palliative_final) %>%
      dplyr::filter(time_palliative_enroll > 0 & time_palliative_enroll < 10000 & !is.na(time_palliative_enroll) & is.finite(time_palliative_enroll)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")

    Data_case_target = Data_case_target %>% dplyr::mutate(
      YoungOld = case_when(
        症例.基本情報.年齢 <= input$mid_age ~ "Younger",
        TRUE ~ "Older")) %>%
      dplyr::distinct(.keep_all = TRUE, C.CAT調査結果.基本項目.ハッシュID)
    Cancername = sort(unique(Data_case_target$Cancers))
    Data_MAF = Data_report() %>%
      dplyr::filter(
        !str_detect(Hugo_Symbol, ",") &
          Hugo_Symbol != "" &
          Evidence_level %in% c("","A","B","C","D","E","F") &
          Variant_Classification != "expression"
      ) %>% 
      dplyr::arrange(desc(Evidence_level)) %>%
      dplyr::distinct(Tumor_Sample_Barcode,
                      Hugo_Symbol,
                      Start_Position,
                      .keep_all = TRUE)
    Data_MAF$TMB = as.numeric(str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1])
    if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
      Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
    }
    if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
      Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
    }
    Data_report_TMB = Data_MAF %>%
      dplyr::filter(Hugo_Symbol == "TMB") %>%
      dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::mutate(Evidence_level = case_when(
        TMB < 10 ~ "",
        TMB >= 10 ~ "F",
        TRUE ~ ""
      ))
    Data_MAF = Data_MAF %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::filter(Hugo_Symbol != "TMB")
    Data_MAF = rbind(Data_MAF, Data_report_TMB)
    Data_report_TMB = Data_report_TMB %>%
      dplyr::filter(Tumor_Sample_Barcode %in%
                      Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
      dplyr::select(Tumor_Sample_Barcode, TMB)
    colnames(Data_report_TMB) = c("C.CAT調査結果.基本項目.ハッシュID", "TMB")
    Data_case_target = left_join(Data_case_target, Data_report_TMB,
                                 by = "C.CAT調査結果.基本項目.ハッシュID")
    
    Data_MAF_target = Data_MAF %>%
      dplyr::filter(Tumor_Sample_Barcode %in%
                      Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
    if(input$patho == "Only pathogenic muts"){
      Data_MAF_target = Data_MAF_target %>%
        dplyr::filter(Evidence_level == "F")
    } else {
      Data_MAF_target = Data_MAF_target %>%
        dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
      
    }
    Data_MAF_target = Data_MAF_target  %>%
      dplyr::distinct(Tumor_Sample_Barcode,
                      Hugo_Symbol,
                      .keep_all = TRUE)
    Gene_list = unique(names(sort(table(Data_MAF_target$Hugo_Symbol),
                                    decreasing = T)))
    Data_mutation = data.frame(matrix(0,
                                      nrow=length(Data_case_target$C.CAT調査結果.基本項目.ハッシュID),
                                      ncol=length(Gene_list)))
    colnames(Data_mutation) = Gene_list
    rownames(Data_mutation) = Data_case_target$C.CAT調査結果.基本項目.ハッシュID
    for(i in 1:length(Data_MAF_target$Hugo_Symbol)){
      Data_mutation[Data_MAF_target$Tumor_Sample_Barcode[i],
                    Data_MAF_target$Hugo_Symbol[i]] = 1
    }
    if(length(Data_mutation[is.na(Data_mutation)])> 0){
      Data_mutation[is.na(Data_mutation)] <- 0
    }
    set.seed(1)
    Data_mutation_umap = umap(Data_mutation, random_state=1)
    Data_mutation_cord = Data_mutation_umap$layout %>% as.data.frame()
    EPS = input$eps
    MINPTS = 3
    dbscan_res_changed <- dbscan(Data_mutation_cord, eps = EPS, minPts = MINPTS)
    if(min(dbscan_res_changed$cluster) == 0){
      dbscan_res_changed$cluster = (dbscan_res_changed$cluster + 1)
    }
    Data_case_target$driver_mutations = rowSums(Data_mutation)
    
    Data_report_tmp = Data_report() %>%
      dplyr::filter(
        !str_detect(Hugo_Symbol, ",") &
          Hugo_Symbol != "" &
          Variant_Classification != "expression"
      )
    Data_report_tmp$TMB = as.numeric(str_split(Data_report_tmp$TMB, "Muts", simplify = TRUE)[,1])
    if(length(Data_report_tmp[is.na(Data_report_tmp$TMB),]$TMB) > 0){
      Data_report_tmp[is.na(Data_report_tmp$TMB),]$TMB = 0
    }
    Data_report_TMB = Data_report_tmp %>%
      dplyr::filter(Hugo_Symbol == "TMB") %>%
      dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::mutate(Evidence_level = case_when(
        TMB < 10 ~ "",
        TMB >= 10 ~ "F",
        TRUE ~ ""
      ))
    Data_report_tmp = Data_report_tmp %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::filter(Hugo_Symbol != "TMB")
    Data_report_tmp = rbind(Data_report_tmp, Data_report_TMB)
    
    Data_report_tmp = Data_report_tmp %>%
      dplyr::filter(Tumor_Sample_Barcode %in%
                      Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
    
    Data_disease = (Data_case_target %>%
                  dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID,
                                  症例.基本情報.がん種.OncoTree.))
    colnames(Data_disease) = c("Tumor_Sample_Barcode", "Cancers")
    Data_MAF_target = left_join(Data_MAF_target,
                                Data_disease,
                                by = "Tumor_Sample_Barcode")
    Data_MAF_target$Cancers = as.factor(Data_MAF_target$Cancers)
    Data_report_tmp = left_join(Data_report_tmp,
                                Data_disease,
                               by = "Tumor_Sample_Barcode")
    Data_report_tmp$Cancers = as.factor(Data_report_tmp$Cancers)
    Data_report_tmp = Data_report_tmp %>% dplyr::mutate(
      Evidence_level = case_when(
        Evidence_level == "F" & Hugo_Symbol == "TMB" ~ "A",
        Evidence_level == "" ~ "G",
        TRUE ~ Evidence_level)
      ) %>% dplyr::mutate(Drug = case_when(
        Evidence_level == "A" &
          Hugo_Symbol == "TMB" &
          Drug == "" ~ "pembrolizumab",
          TRUE ~ Drug)
      ) %>% dplyr::mutate(Resistance = case_when(
        Evidence_level %in% c("R2*","R1*","R3*","R2","R3","R","R1") ~ 1,
        TRUE ~ 0)
      ) %>%
      dplyr::distinct(Tumor_Sample_Barcode, Evidence_level, Drug, .keep_all = T)

    Data_report_tmp = Data_report_tmp  %>%
      dplyr::arrange(desc(Evidence_level)) %>%
      dplyr::filter(Resistance != 1) %>%
      dplyr::filter(!Evidence_level %in% c("F", "G")) %>%
      dplyr::distinct(Tumor_Sample_Barcode, .keep_all = T)
    Data_report_tmp$Level = as.factor(Data_report_tmp$Evidence_level)
    data_figure = Data_report_tmp %>% dplyr::select(Cancers,Level) %>% dplyr::filter(!is.na(Cancers)&!is.na(Level))
    Num_A = rep(0, length(Cancername))
    names(Num_A) = Cancername
    Num_tmp = table((data_figure %>% dplyr::filter(Level == "A"))$Cancers)
    if(length(Num_tmp) > 0){
      for(i in 1:length(Num_tmp)){
        Num_A[names(Num_tmp)[i]] = Num_tmp[i]
      }
      Num_A = fun_zero(Num_A, Total_pts)
    }
    Num_B = rep(0, length(Cancername))
    names(Num_B) =  Cancername
    Num_tmp = table((data_figure %>% dplyr::filter(Level == "B"))$Cancers)
    if(length(Num_tmp) > 0){
      for(i in 1:length(Num_tmp)){
        Num_B[names(Num_tmp)[i]] = Num_tmp[i]
      }
      Num_B = fun_zero(Num_B, Total_pts)
    }
    Num_C = rep(0, length(Cancername))
    names(Num_C) =  Cancername
    Num_tmp = table((data_figure %>% dplyr::filter(Level == "C"))$Cancers)
    if(length(Num_tmp) > 0){
      for(i in 1:length(Num_tmp)){
        Num_C[names(Num_tmp)[i]] = Num_tmp[i]
      }
      Num_C = fun_zero(Num_C, Total_pts)
    }
    Num_D = rep(0, length(Cancername))
    names(Num_D) =  Cancername
    Num_tmp = table((data_figure %>% dplyr::filter(Level == "D"))$Cancers)
    if(length(Num_tmp) > 0){
      for(i in 1:length(Num_tmp)){
        Num_D[names(Num_tmp)[i]] = Num_tmp[i]
      }
      Num_D = fun_zero(Num_D, Total_pts)
    }
    Num_E = rep(0, length(Cancername))
    names(Num_E) =  Cancername
    Num_tmp = table((data_figure %>% dplyr::filter(Level == "E"))$Cancers)
    if(length(Num_tmp) > 0){
      for(i in 1:length(Num_tmp)){
        Num_E[names(Num_tmp)[i]] = Num_tmp[i]
      }
      Num_E = fun_zero(Num_E, Total_pts)
    }
    Num_Option = rep(0, length(Cancername))
    names(Num_Option) =  Cancername
    Num_tmp = table((Data_case_target %>% dplyr::filter(症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. == "はい"))$Cancers)
    if(length(Num_tmp) > 0){
      for(i in 1:length(Num_tmp)){
        Num_Option[names(Num_tmp)[i]] = Num_tmp[i]
      }
    }
    Num_Option = fun_zero(Num_Option, Total_pts)
    Num_Receive_Tx = rep(0, length(Cancername))
    names(Num_Receive_Tx) =  Cancername
    Num_tmp =table((Data_case_target %>% dplyr::filter(症例.EP後レジメン情報.提示された治療薬を投与した.名称. == "投与した"))$Cancers)
    if(length(Num_tmp) > 0){
      for(i in 1:length(Num_tmp)){
        Num_Receive_Tx[names(Num_tmp)[i]] = Num_tmp[i]
      }
    }
    Num_Receive_Tx = fun_zero(Num_Receive_Tx, Total_pts)
    Num_Receive_Tx_per_Option = fun_zero(Num_Receive_Tx, Num_Option)
    Total_pts_short = rep(0, length(Cancername))
    Total_pts_long = rep(0, length(Cancername))
    Num_pre_CGP = rep(0, length(Cancername))
    Num_post_CGP = rep(0, length(Cancername))

    Total_pts_Bone_no = rep(0, length(Cancername))
    Total_pts_Bone = rep(0, length(Cancername))
    Total_pts_Brain_no = rep(0, length(Cancername))
    Total_pts_Brain = rep(0, length(Cancername))
    Total_pts_Lung_no = rep(0, length(Cancername))
    Total_pts_Lung = rep(0, length(Cancername))
    Total_pts_Liver_no = rep(0, length(Cancername))
    Total_pts_Liver = rep(0, length(Cancername))

    Data_case_target$cluster = dbscan_res_changed$cluster
    Disease_cluster = data.frame(matrix(rep(0, length(Cancername) * max(Data_case_target$cluster)),
                                        ncol = max(Data_case_target$cluster)))
    colnames(Disease_cluster) = seq(1,max(Data_case_target$cluster))
    rownames(Disease_cluster) = Cancername
    
    Data_case_target$diagnosis = Data_case_target$症例.基本情報.がん種.OncoTree.
    Data_survival = Data_case_target

    for(i in 1:length(Cancername)){
      Data_survival_tmp = Data_survival %>%
        dplyr::filter(Cancers == Cancername[i])
      if(length(Data_survival_tmp$Cancers) > 0){
        if(sum(Data_survival_tmp$time_palliative_enroll, na.rm = TRUE) > 0){
          survival_simple = survfit(Surv(time_palliative_enroll,
                                         rep(1, length(time_palliative_enroll)))~1,
                                    data=Data_survival_tmp)
          Num_pre_CGP[i] = median(survival_simple)[[1]]
        } else{
          Num_pre_CGP[i] = 0
        }
        if(sum(Data_survival_tmp$time_enroll_final, na.rm = TRUE) > 0){
          survival_simple = survfit(Surv(time_enroll_final,
                                       censor)~1,
                                  data=Data_survival_tmp)
          Num_post_CGP[i] = median(survival_simple)[[1]]
        } else{
          Num_post_CGP[i] = 0
        }

        Data_survival_tmp2 = Data_survival_tmp %>%
          dplyr::filter(Bone_met == "Yes")
        Total_pts_Bone[i] = dim(Data_survival_tmp2)[1]
        Data_survival_tmp2 = Data_survival_tmp %>%
          dplyr::filter(Bone_met == "No")
        Total_pts_Bone_no[i] = dim(Data_survival_tmp2)[1]
        Data_survival_tmp2 = Data_survival_tmp %>%
          dplyr::filter(Brain_met == "Yes")
        Total_pts_Brain[i] = dim(Data_survival_tmp2)[1]
        Data_survival_tmp2 = Data_survival_tmp %>%
          dplyr::filter(Brain_met == "No")
        Total_pts_Brain_no[i] = dim(Data_survival_tmp2)[1]
        Data_survival_tmp2 = Data_survival_tmp %>%
          dplyr::filter(Lung_met == "Yes")
        Total_pts_Lung[i] = dim(Data_survival_tmp2)[1]
        Data_survival_tmp2 = Data_survival_tmp %>%
          dplyr::filter(Lung_met == "No")
        Total_pts_Lung_no[i] = dim(Data_survival_tmp2)[1]
        Data_survival_tmp2 = Data_survival_tmp %>%
          dplyr::filter(Liver_met == "Yes")
        Total_pts_Liver[i] = dim(Data_survival_tmp2)[1]
        Data_survival_tmp2 = Data_survival_tmp %>%
          dplyr::filter(Liver_met == "No")
        Total_pts_Liver_no[i] = dim(Data_survival_tmp2)[1]
      }
    }
    Data_survival$timing = "Pre"
    for(i in 1:length(Cancername)){
      Data_survival[Data_survival$Cancers == unique(Data_survival$Cancers)[i],]$timing = ifelse(
        Data_survival[Data_survival$Cancers == unique(Data_survival$Cancers)[i],]$time_palliative_enroll < Num_pre_CGP[i],
        "Pre", "Post"
      )
    }
    Diseases = Cancername
    Summary_Table = data.frame(Diseases)
    Summary_Table$sample_is_primary_tumor = 0
    Summary_Table$sample_is_metastatic_tumor = 0
    Summary_Table$sample_is_unknown_tumor = 0
    Summary_Table$tumor_purity_0_25 = 0
    Summary_Table$tumor_purity_25_50 = 0
    Summary_Table$tumor_purity_50_75 = 0
    Summary_Table$tumor_purity_75_100 = 0
    Summary_Table$tumor_purity_NA = 0
    Summary_Table$age_median = 0
    Summary_Table$age_lowest = 0
    Summary_Table$age_highest = 0
    Summary_Table$age_range_25 = 0
    Summary_Table$age_range_75 = 0
    Summary_Table$male = 0
    Summary_Table$female = 0
    Summary_Table$sex_unknown = 0
    Summary_Table$oncogenic_driver_plus = 0
    Summary_Table$oncogenic_driver_minus = 0
    Summary_Table$TMB_median = 0
    Summary_Table$TMB_lowest = 0
    Summary_Table$TMB_highest = 0
    Summary_Table$TMB_range_25 = 0
    Summary_Table$TMB_range_75 = 0
    Summary_Table$entropy = 0

    Summary_Table$brain = Total_pts_Brain
    Summary_Table$brain_no = Total_pts_Brain_no
    Summary_Table$bone = Total_pts_Bone
    Summary_Table$bone_no = Total_pts_Bone_no
    Summary_Table$lung = Total_pts_Lung
    Summary_Table$lung_no = Total_pts_Lung_no
    Summary_Table$liver = Total_pts_Liver
    Summary_Table$liver_no = Total_pts_Liver_no

    Summary_Table$option = Num_Option * 100
    Summary_Table$treat = Num_Receive_Tx * 100
    Summary_Table$time_before_CGP = Num_pre_CGP
    Summary_Table$time_after_CGP = Num_post_CGP


    for(i in 1:length(Diseases)){
      Summary_Table$sample_is_primary_tumor[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  症例.検体情報.検体採取部位.名称. == "原発巣"))$症例.検体情報.検体採取部位.名称.)
      Summary_Table$sample_is_metastatic_tumor[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  症例.検体情報.検体採取部位.名称. == "転移巣"))$症例.検体情報.検体採取部位.名称.)
      Summary_Table$sample_is_unknown_tumor[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  症例.検体情報.検体採取部位.名称. %in% c("不明","")))$症例.検体情報.検体採取部位.名称.)
      Summary_Table$tumor_purity_0_25[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  !is.na(症例.検体情報.腫瘍細胞含有割合) &
                                  症例.検体情報.腫瘍細胞含有割合 < 25))$症例.検体情報.腫瘍細胞含有割合)
      Summary_Table$tumor_purity_25_50[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  !is.na(症例.検体情報.腫瘍細胞含有割合) &
                                  症例.検体情報.腫瘍細胞含有割合 >= 25 &
                                  症例.検体情報.腫瘍細胞含有割合 < 50))$症例.検体情報.腫瘍細胞含有割合)
      Summary_Table$tumor_purity_50_75[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  !is.na(症例.検体情報.腫瘍細胞含有割合) &
                                  症例.検体情報.腫瘍細胞含有割合 >= 50 &
                                  症例.検体情報.腫瘍細胞含有割合 < 75))$症例.検体情報.腫瘍細胞含有割合)
      Summary_Table$tumor_purity_75_100[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  !is.na(症例.検体情報.腫瘍細胞含有割合) &
                                  症例.検体情報.腫瘍細胞含有割合 >= 75 &
                                  症例.検体情報.腫瘍細胞含有割合 <= 100))$症例.検体情報.腫瘍細胞含有割合)
      Summary_Table$tumor_purity_NA[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  is.na(症例.検体情報.腫瘍細胞含有割合)))$症例.検体情報.腫瘍細胞含有割合)
      Summary_Table$age_median[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[3]]
      Summary_Table$age_lowest[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[1]]
      Summary_Table$age_highest[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[5]]
      Summary_Table$age_range_25[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[2]]
      Summary_Table$age_range_75[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(症例.基本情報.年齢)))$症例.基本情報.年齢)[[4]]
      Summary_Table$male[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  !is.na(症例.基本情報.性別.名称.) &
                                  症例.基本情報.性別.名称. == "男"))$症例.基本情報.性別.名称.)
      Summary_Table$female[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  !is.na(症例.基本情報.性別.名称.) &
                                  症例.基本情報.性別.名称. == "女"))$症例.基本情報.性別.名称.)
      Summary_Table$sex_unknown[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  is.na(症例.基本情報.性別.名称.)))$症例.基本情報.性別.名称.)
      Summary_Table$oncogenic_driver_plus[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  driver_mutations > 0))$driver_mutations)
      Summary_Table$oncogenic_driver_minus[i] =
        length((Data_case_target %>%
                  dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                  driver_mutations == 0))$driver_mutations)
      Summary_Table$TMB_median[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(TMB)))$TMB)[[3]]
      Summary_Table$TMB_lowest[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(TMB)))$TMB)[[1]]
      Summary_Table$TMB_highest[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(TMB)))$TMB)[[5]]
      Summary_Table$TMB_range_25[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(TMB)))$TMB)[[2]]
      Summary_Table$TMB_range_75[i] =
        quantile((Data_case_target %>%
                    dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i] &
                                    !is.na(TMB)))$TMB)[[4]]
      tmp_cluster = as.data.frame(table((Data_case_target %>%
                                           dplyr::filter(症例.基本情報.がん種.OncoTree. == Diseases[i]))$cluster))
      Summary_Table$entropy[i] =
        shannon.entropy(as.numeric(as.character(tmp_cluster[,2])), max(Data_case_target$cluster))
      for(j in 1:length(tmp_cluster[,1])){
        Disease_cluster[i,as.numeric(as.character(tmp_cluster[j,1]))] =
          as.numeric(as.character(tmp_cluster[j,2]))
      }
    }
    
    testSummary = data.frame(as.vector(t(matrix(rep(1:max(Data_case_target$cluster),
                                                    length(Diseases)),
                                                    ncol =length(Diseases)))))
    colnames(testSummary) = "Cluster"
    testSummary$Histology = rep(Diseases, max(Data_case_target$cluster))
    testSummary$All_patients = rep(rep(0, length(Diseases)), max(Data_case_target$cluster))
    testSummary$Positive_patients = rep(rep(0, length(Diseases)), max(Data_case_target$cluster))
    testSummary$OddsRatio = rep(rep(1, length(Diseases)), max(Data_case_target$cluster))
    testSummary$Pvalue = rep(rep(1, length(Diseases)), max(Data_case_target$cluster))
    
    selected_genes = rep("", max(Data_survival$cluster))
    for(i in 1:max(Data_survival$cluster)){
      pos_num = data.frame(Diseases)
      pos_num$n = 0
      colnames(pos_num) = c("diagnosis", "n")
      Data_cluster_plus = Data_survival %>%
        dplyr::filter(cluster == i) %>%
        dplyr::count(diagnosis) %>%
        dplyr::arrange(-n)
      Data_cluster_plus = dplyr::full_join(Data_cluster_plus, pos_num, by = join_by(diagnosis))
      Data_cluster_plus = Data_cluster_plus[,1:2]
      colnames(Data_cluster_plus) = c("diagnosis", "n")
      Data_cluster_plus$n = replace_na(Data_cluster_plus$n, 0)
      Data_cluster_plus = Data_cluster_plus %>% dplyr::arrange(diagnosis)
      Data_cluster_plus = Data_cluster_plus$n
      pos_num = data.frame(Diseases)
      pos_num$n = 0
      colnames(pos_num) = c("diagnosis", "n")
      Data_cluster_minus = Data_survival %>%
        dplyr::filter(cluster != i) %>%
        dplyr::count(diagnosis) %>%
        dplyr::arrange(-n)
      Data_cluster_minus = dplyr::full_join(Data_cluster_minus, pos_num, by = join_by(diagnosis))
      Data_cluster_minus = Data_cluster_minus[,1:2]
      colnames(Data_cluster_minus) = c("diagnosis", "n")
      Data_cluster_minus$n = replace_na(Data_cluster_minus$n, 0)
      Data_cluster_minus = Data_cluster_minus %>% dplyr::arrange(diagnosis)
      Data_cluster_minus = Data_cluster_minus$n
      No_plus_neg = length((Data_survival %>% dplyr::filter(cluster == i))[,1]) -
        Data_cluster_plus
      No_minus_neg = length((Data_survival %>% dplyr::filter(cluster != i))[,1]) -
        Data_cluster_minus
      testSummary[((1+(i-1)*length(Diseases)):(i*length(Diseases))),3] = length((Data_survival %>% dplyr::filter(cluster == i))[,1])
      testSummary[((1+(i-1)*length(Diseases)):(i*length(Diseases))),4] = Data_cluster_plus
      for(j in 1:length(Data_cluster_plus)){
        mutation_matrix = matrix(c(Data_cluster_plus[j],
                                   Data_cluster_minus[j],
                                   No_plus_neg[j],
                                   No_minus_neg[j]),
                                 nrow = 2,
                                 dimnames = list(Cancer = c("CancerType", "OtherCancerType"),
                                                 Cluster = c(paste("cluster", i), "Other clusters")))
        testSummary[(j+(i-1)*length(Diseases)),5] =
          round(fisher.test(mutation_matrix)$estimate[[1]], digits = 3)
        testSummary[(j+(i-1)*length(Diseases)),6] =
          round(fisher.test(mutation_matrix)$p.value, digits = 3)
      }
      top_genes = testSummary[((1+(i-1)*length(Diseases)):(i*length(Diseases))),] %>%
        dplyr::arrange(desc(OddsRatio)) %>%
        dplyr::filter(OddsRatio > 1 & Pvalue < 0.05) 
      if(length(top_genes$OddsRatio) >= 1){
        top_genes = top_genes[1:min(3, length(top_genes$OddsRatio)),]$Histology
      } else{
        top_genes = ""
      }
      selected_genes[i] = paste0(i, ":", paste(top_genes,collapse = ";"))
    }
    testSummary[,"OddsRatio"] = ifelse(is.infinite(testSummary[,"OddsRatio"]), 99999, testSummary[,"OddsRatio"])
    testSummary_disease = testSummary
    

    for(i in 1:length(Data_MAF_target$Hugo_Symbol)){
      Data_mutation[Data_MAF_target$Tumor_Sample_Barcode[i],
                    Data_MAF_target$Hugo_Symbol[i]] = 1
    }

    Data_cluster = Data_case_target %>% dplyr::select(C.CAT調査結果.基本項目.ハッシュID, cluster)
    colnames(Data_cluster) = c("Tumor_Sample_Barcode", "cluster")
    Data_MAF_target = left_join(Data_MAF_target, Data_cluster, by = "Tumor_Sample_Barcode")
    Mutations = sort(unique(Data_MAF_target$Hugo_Symbol))
    testSummary = data.frame(as.vector(t(matrix(rep(1:max(Data_MAF_target$cluster),
                                                    length(Mutations)),
                                                ncol =length(Mutations)))))
    colnames(testSummary) = "Cluster"
    testSummary$mutation = rep(Mutations, max(Data_MAF_target$cluster))
    testSummary$All_patients = rep(rep(0, length(Mutations)), max(Data_MAF_target$cluster))
    testSummary$Positive_patients = rep(rep(0, length(Mutations)), max(Data_MAF_target$cluster))
    testSummary$OddsRatio = rep(rep(1, length(Mutations)), max(Data_MAF_target$cluster))
    testSummary$Pvalue = rep(rep(1, length(Mutations)), max(Data_MAF_target$cluster))
    
    for(i in 1:max(Data_MAF_target$cluster)){
      pos_num = data.frame(Mutations)
      pos_num$n = 0
      colnames(pos_num) = c("Hugo_Symbol", "n")
      Data_cluster_plus = Data_MAF_target %>%
        dplyr::filter(cluster == i) %>%
        dplyr::count(Hugo_Symbol) %>%
        dplyr::arrange(-n)
      Data_cluster_plus = dplyr::full_join(Data_cluster_plus, pos_num, by = join_by(Hugo_Symbol))
      Data_cluster_plus = Data_cluster_plus[,1:2]
      colnames(Data_cluster_plus) = c("Hugo_Symbol", "n")
      Data_cluster_plus$n = replace_na(Data_cluster_plus$n, 0)
      Data_cluster_plus = Data_cluster_plus %>% dplyr::arrange(Hugo_Symbol)
      Data_cluster_plus = Data_cluster_plus$n
      pos_num = data.frame(Mutations)
      pos_num$n = 0
      colnames(pos_num) = c("Hugo_Symbol", "n")
      Data_cluster_minus = Data_MAF_target %>%
        dplyr::filter(cluster != i) %>%
        dplyr::count(Hugo_Symbol) %>%
        dplyr::arrange(-n)
      Data_cluster_minus = dplyr::full_join(Data_cluster_minus, pos_num, by = join_by(Hugo_Symbol))
      Data_cluster_minus = Data_cluster_minus[,1:2]
      colnames(Data_cluster_minus) = c("Hugo_Symbol", "n")
      Data_cluster_minus$n = replace_na(Data_cluster_minus$n, 0)
      Data_cluster_minus = Data_cluster_minus %>% dplyr::arrange(Hugo_Symbol)
      Data_cluster_minus = Data_cluster_minus$n
      No_plus_neg = length((Data_MAF_target %>%
                              dplyr::filter(cluster == i) %>%
                              dplyr::distinct(Tumor_Sample_Barcode))[,1]) -
        Data_cluster_plus
      No_minus_neg = length((Data_MAF_target %>%
                               dplyr::filter(cluster != i) %>%
                               dplyr::distinct(Tumor_Sample_Barcode))[,1]) -
        Data_cluster_minus
      testSummary[((1+(i-1)*length(Mutations)):(i*length(Mutations))),3] = length((Data_MAF_target %>%
                                                                                     dplyr::filter(cluster == i) %>%
                                                                                     dplyr::distinct(Tumor_Sample_Barcode))[,1])
      testSummary[((1+(i-1)*length(Mutations)):(i*length(Mutations))),4] = Data_cluster_plus
      for(j in 1:length(Data_cluster_plus)){
        mutation_matrix = matrix(c(Data_cluster_plus[j],
                                   Data_cluster_minus[j],
                                   No_plus_neg[j],
                                   No_minus_neg[j]),
                                 nrow = 2,
                                 dimnames = list(Cancer = c("CancerType", "OtherCancerType"),
                                                 Cluster = c(paste("cluster", i), "Other clusters")))
        testSummary[(j+(i-1)*length(Mutations)),5] =
          round(fisher.test(mutation_matrix)$estimate[[1]], digits = 3)
        testSummary[(j+(i-1)*length(Mutations)),6] =
          round(fisher.test(mutation_matrix)$p.value, digits = 3)
      }
      top_genes = testSummary[((1+(i-1)*length(Mutations)):(i*length(Mutations))),] %>%
        dplyr::arrange(desc(OddsRatio)) %>%
        dplyr::filter(OddsRatio > 1 & Pvalue < 0.05) 
      if(length(top_genes$OddsRatio) >= 1){
        top_genes = top_genes[1:min(3, length(top_genes$OddsRatio)),]$mutation
      } else{
        top_genes = ""
      }
      selected_genes[i] = paste0(selected_genes[i], "/", paste(top_genes,collapse = ";"))
    }
    testSummary[,"OddsRatio"] = ifelse(is.infinite(testSummary[,"OddsRatio"]), 99999, testSummary[,"OddsRatio"])
    testSummary_mutation = testSummary
    
    output$table_disease = DT::renderDataTable(testSummary_disease,
                                               server = FALSE,
                                               filter = 'top', 
                                               extensions = c('Buttons'), 
                                       options = list(pageLength = 100, 
                                                      scrollX = TRUE,
                                                      scrollY = "1000px",
                                                      scrollCollapse = TRUE,
                                                      dom="Blfrtip",
                                                      buttons = c('csv', 'copy')))
    output$table_mutation = DT::renderDataTable(testSummary_mutation,
                                               server = FALSE,
                                               filter = 'top', 
                                               extensions = c('Buttons'), 
                                               options = list(pageLength = 100, 
                                                              scrollX = TRUE,
                                                              scrollY = "1000px",
                                                              scrollCollapse = TRUE,
                                                              dom="Blfrtip",
                                                              buttons = c('csv', 'copy')))
    
    Disease_cluster$Disease = rownames(Disease_cluster)
    Disease_cluster <- transform(Disease_cluster, Disease= factor(Disease, levels = sort(unique(Disease_cluster$Disease), decreasing = TRUE)))
    colnames(Disease_cluster) = c(seq(1,max(Data_survival$cluster)), "Disease")
    Data_entropy = gather(Disease_cluster, key = cluster, value = samples, -Disease)
    Data_entropy$cluster = as.numeric(Data_entropy$cluster)
    Summary_Table = transform(Summary_Table, Diseases= factor(Diseases, levels = sort(unique(Disease_cluster$Disease), decreasing = FALSE)))
    Data_entropy = transform(Data_entropy, Disease= factor(Disease, levels = sort(unique(Disease_cluster$Disease), decreasing = FALSE)))
    
    x <- data.frame(
      Cancers   = Diseases,
      Patients = Total_pts,
      Level_A = (Num_A * 100),
      Level_AB = (Num_A + Num_B) * 100,
      Level_ABC = (Num_A + Num_B + Num_C) * 100,
      Treatment_option = Num_Option * 100,
      Receive_Recom_Tx = Num_Receive_Tx * 100,
      Receive_Tx_rate_with_opt = Num_Receive_Tx_per_Option * 100,
      Survival_pre_CGP = Num_pre_CGP,
      Survival_post_CGP = Num_post_CGP
    )
    x$Cancers = factor(x$Cancers)
    
    
    y <- data.frame(
      Cancers   = rep(Diseases,5),
      Level = c(rep("A", length(Diseases)),
                rep("B", length(Diseases)),
                rep("C", length(Diseases)),
                rep("D", length(Diseases)),
                rep("E", length(Diseases))),
      weight = c(Num_A, Num_B, Num_C, Num_D, Num_E)
    )
    y$Cancers = factor(y$Cancers)
    y$Level = factor(y$Level)
    
    output$figure_entropy = renderPlot({
      g1 = ggplot(Summary_Table, aes(x=Diseases, y=entropy, fill="black")) +
        geom_point(stat = "identity") +
        coord_flip() +
        theme_classic() +
        theme(legend.position = "none")
      
      # g2 = ggplot(Data_entropy, aes(x=Disease, y=samples, fill=cluster)) +
      #   geom_bar(stat = "identity") +
      #   scale_fill_gradientn(colours = c("green", "black", "magenta", "darkred", "orange", "blue", "yellow")) +
      #   coord_flip() +
      #   theme_classic()
      g3 = ggplot(Data_entropy, aes(x=Disease, y=samples, fill=cluster)) +
        geom_bar(stat = "identity", position = "fill") +
        scale_fill_gradientn(colours = c("green", "black", "magenta", "darkred", "orange", "blue", "yellow")) +
        coord_flip() +
        theme_classic()
      grid.arrange(g1, g3, ncol = 2)
    })
    output$figure_base = renderPlot({
      Data_tmp_1 =data.frame(Summary_Table$Diseases)
      Data_tmp_1$primary = Summary_Table$sample_is_primary_tumor
      Data_tmp_1$Primary = "Yes"
      Data_tmp_2 =data.frame(Summary_Table$Diseases)
      Data_tmp_2$primary = Summary_Table$sample_is_metastatic_tumor
      Data_tmp_2$Primary = "No"
      Data_tmp_3 =data.frame(Summary_Table$Diseases)
      Data_tmp_3$primary = Summary_Table$sample_is_unknown_tumor
      Data_tmp_3$Primary = "Unknown"
      Data_tmp = rbind(Data_tmp_1, Data_tmp_2, Data_tmp_3)
      cancer_freq_order = c("Unknown", "No", "Yes")
      Data_tmp <- transform(Data_tmp, Primary= factor(Primary, levels = cancer_freq_order))
      #Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Diseases), decreasing = TRUE)))
      
      chart_1 = ggplot(data = Data_tmp, aes(x = Diseases, y = primary, fill=Primary)) +
        geom_col(position="fill") +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp_1 =data.frame(Summary_Table$Diseases)
      Data_tmp_1$purity = Summary_Table$tumor_purity_0_25
      Data_tmp_1$Purity = "0-25%"
      Data_tmp_2 =data.frame(Summary_Table$Diseases)
      Data_tmp_2$purity = Summary_Table$tumor_purity_25_50
      Data_tmp_2$Purity = "25-49%"
      Data_tmp_3 =data.frame(Summary_Table$Diseases)
      Data_tmp_3$purity = Summary_Table$tumor_purity_50_75
      Data_tmp_3$Purity = "50-74%"
      Data_tmp_4 =data.frame(Summary_Table$Diseases)
      Data_tmp_4$purity = Summary_Table$tumor_purity_75_100
      Data_tmp_4$Purity = "75-100%"
      Data_tmp_5 =data.frame(Summary_Table$Diseases)
      Data_tmp_5$purity = Summary_Table$tumor_purity_NA
      Data_tmp_5$Purity = "NA"
      Data_tmp = rbind(Data_tmp_1, Data_tmp_2, Data_tmp_3, Data_tmp_4, Data_tmp_5)
      cancer_freq_order = c("NA", "75-100%", "50-74%", "25-49%", "0-25%")
      Data_tmp <- transform(Data_tmp, Purity= factor(Purity, levels = cancer_freq_order))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Diseases), decreasing = TRUE)))
      
      chart_2 = ggplot(data = Data_tmp, aes(x = Diseases, y = purity, fill=Purity)) +
        geom_col(position="fill") +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp = Data_case_target
      Data_tmp$Age = Data_tmp$症例.基本情報.年齢
      Data_tmp <- transform(Data_tmp, diagnosis= factor(diagnosis, levels = sort(unique(Data_tmp$diagnosis), decreasing = TRUE)))
      
      chart_3 = ggplot(data = Data_tmp, aes(x = diagnosis, y = Age)) +
        geom_boxplot(outlier.colour = NA) +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              #axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp_1 =data.frame(Summary_Table$Diseases)
      Data_tmp_1$sex = Summary_Table$male
      Data_tmp_1$Sex = "Male"
      Data_tmp_2 =data.frame(Summary_Table$Diseases)
      Data_tmp_2$sex = Summary_Table$female
      Data_tmp_2$Sex = "Female"
      Data_tmp_3 =data.frame(Summary_Table$Diseases)
      Data_tmp_3$sex = Summary_Table$sex_unknown
      Data_tmp_3$Sex = "Unknown"
      Data_tmp = rbind(Data_tmp_1, Data_tmp_2, Data_tmp_3)
      cancer_freq_order = c("Unknown", "Female", "Male")
      Data_tmp <- transform(Data_tmp, Sex= factor(Sex, levels = cancer_freq_order))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Diseases), decreasing = TRUE)))
      
      chart_4 = ggplot(data = Data_tmp, aes(x = Diseases, y = sex, fill=Sex)) +
        geom_col(position="fill") +
        coord_flip() +
        theme_classic() + 
        theme(#legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp_1 =data.frame(Summary_Table$Diseases)
      Data_tmp_1$driver = Summary_Table$oncogenic_driver_plus
      Data_tmp_1$Driver = "Yes"
      Data_tmp_2 =data.frame(Summary_Table$Diseases)
      Data_tmp_2$driver = Summary_Table$oncogenic_driver_minus
      Data_tmp_2$Driver = "No"
      Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
      cancer_freq_order = c("Unknown", "No", "Yes")
      Data_tmp <- transform(Data_tmp, Driver= factor(Driver, levels = cancer_freq_order))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Diseases), decreasing = TRUE)))
      
      chart_5 = ggplot(data = Data_tmp, aes(x = Diseases, y = driver, fill=Driver)) +
        geom_col(position="fill") +
        coord_flip() +
        theme_classic() + 
        theme(#legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp = Data_case_target
      Data_tmp <- transform(Data_tmp, diagnosis= factor(diagnosis, levels = sort(unique(Diseases), decreasing = TRUE)))
      chart_6 = ggplot(data = Data_tmp, aes(x = diagnosis, y = TMB)) +
        geom_boxplot(outlier.colour = NA) +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank()) +
        scale_y_continuous(limits = c(0, 15))
      
      Data_tmp_1 =data.frame(Summary_Table$Diseases)
      Data_tmp_1$brain_meta = Summary_Table$brain
      Data_tmp_1$Brain_meta = "(+)"
      Data_tmp_2 =data.frame(Summary_Table$Diseases)
      Data_tmp_2$brain_meta = Summary_Table$brain_no
      Data_tmp_2$Brain_meta = "(-)"
      Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
      cancer_freq_order = c("(-)", "(+)")
      Data_tmp <- transform(Data_tmp, Brain_meta= factor(Brain_meta, levels = cancer_freq_order))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
      
      chart_7 = ggplot(data = Data_tmp, aes(x = Diseases, y = brain_meta, fill=Brain_meta)) +
        geom_col(position="fill") +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              #axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp_1 =data.frame(Summary_Table$Diseases)
      Data_tmp_1$bone_meta = Summary_Table$bone
      Data_tmp_1$Bone_meta = "(+)"
      Data_tmp_2 =data.frame(Summary_Table$Diseases)
      Data_tmp_2$bone_meta = Summary_Table$bone_no
      Data_tmp_2$Bone_meta = "(-)"
      Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
      cancer_freq_order = c("(-)", "(+)")
      Data_tmp <- transform(Data_tmp, Bone_meta= factor(Bone_meta, levels = cancer_freq_order))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
      
      chart_8 = ggplot(data = Data_tmp, aes(x = Diseases, y = bone_meta, fill=Bone_meta)) +
        geom_col(position="fill") +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp_1 =data.frame(Summary_Table$Diseases)
      Data_tmp_1$lung_meta = Summary_Table$lung
      Data_tmp_1$Lung_meta = "(+)"
      Data_tmp_2 =data.frame(Summary_Table$Diseases)
      Data_tmp_2$lung_meta = Summary_Table$lung_no
      Data_tmp_2$Lung_meta = "(-)"
      Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
      cancer_freq_order = c("(-)", "(+)")
      Data_tmp <- transform(Data_tmp, Lung_meta= factor(Lung_meta, levels = cancer_freq_order))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
      
      chart_9 = ggplot(data = Data_tmp, aes(x = Diseases, y = lung_meta, fill=Lung_meta)) +
        geom_col(position="fill") +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp_1 =data.frame(Summary_Table$Diseases)
      Data_tmp_1$liver_meta = Summary_Table$liver
      Data_tmp_1$Liver_meta = "(+)"
      Data_tmp_2 =data.frame(Summary_Table$Diseases)
      Data_tmp_2$liver_meta = Summary_Table$liver_no
      Data_tmp_2$Liver_meta = "(-)"
      Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
      cancer_freq_order = c("(-)", "(+)")
      Data_tmp <- transform(Data_tmp, Liver_meta= factor(Liver_meta, levels = cancer_freq_order))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
      
      chart_10 = ggplot(data = Data_tmp, aes(x = Diseases, y = liver_meta, fill=Liver_meta)) +
        geom_col(position="fill") +
        coord_flip() +
        theme_classic() + 
        theme(# legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp =data.frame(Summary_Table$Diseases)
      Data_tmp$option = Summary_Table$option
      Data_tmp$Option = "(+)"
      Data_tmp <- transform(Data_tmp, Option= factor(Option))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
      
      chart_11 = ggplot(data = Data_tmp, aes(x = Diseases, y = option, fill=Option)) +
        geom_point() +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              #axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp =data.frame(Summary_Table$Diseases)
      Data_tmp$treat = Summary_Table$treat
      Data_tmp$Treat = "(+)"
      Data_tmp <- transform(Data_tmp, Treat= factor(Treat))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
      
      chart_12 = ggplot(data = Data_tmp, aes(x = Diseases, y = treat, fill=Treat)) +
        geom_point() +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())
        

      Data_tmp =data.frame(Summary_Table$Diseases)
      Data_tmp$time_before_CGP = Summary_Table$time_before_CGP
      Data_tmp$Time_before_CGP = "(+)"
      Data_tmp <- transform(Data_tmp, Time_before_CGP= factor(Time_before_CGP))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
      
      chart_13 = ggplot(data = Data_tmp, aes(x = Diseases, y = time_before_CGP, fill=Time_before_CGP)) +
        geom_col() +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      Data_tmp =data.frame(Summary_Table$Diseases)
      Data_tmp$time_after_CGP = Summary_Table$time_after_CGP
      Data_tmp$Time_after_CGP = "(+)"
      Data_tmp <- transform(Data_tmp, Time_after_CGP= factor(Time_after_CGP))
      Data_tmp <- transform(Data_tmp, Diseases= factor(Diseases, levels = sort(unique(Data_case_target$diagnosis), decreasing = TRUE)))
      
      chart_14 = ggplot(data = Data_tmp, aes(x = Diseases, y = time_after_CGP, fill=Time_after_CGP)) +
        geom_col() +
        coord_flip() +
        theme_classic() + 
        theme(legend.position = "none",
              axis.ticks.y =  element_blank(),
              axis.text.y = element_blank(),
              axis.title.y = element_blank(),
              axis.line.y = element_blank())

      grid.arrange(chart_3, chart_4, chart_5, chart_6, chart_7, chart_8, chart_9, chart_10, chart_11, chart_12, chart_13, chart_14, ncol = 4)
    })

    output$figure_drug_evidence = renderPlot({
      h = list()
      g <- ggplot(y, aes(x= reorder(Cancers, desc(Cancers)), y = weight, fill = reorder(Level, desc(Level))))
      g <- g + geom_bar(stat = "identity")
      g <- g + scale_y_continuous(labels = percent)
      g <- g + scale_fill_nejm()
      g <- g + theme_bw()
      g <- g + labs(y = "Frequency of druggable mutation",x = "Cancer type", fill = "Evidence level")
      g <- g + coord_flip()
      h[[1]] = g
      
      cor_A = x %>% 
        summarize(cor = round(cor.test(Survival_pre_CGP, Survival_post_CGP)$estimate,3), p = round(cor.test(Survival_pre_CGP, Survival_post_CGP)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      g <- ggplot(x, aes(x = Survival_pre_CGP, y = Survival_post_CGP, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + theme_bw()
      g <- g + coord_cartesian(xlim = c(0, 1000), ylim = c(0, 1000))
      g <- g + labs(x = "Survival before CGP (days)",y = "Survival after CGP (days)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_A, mapping = aes(x = 500, y = 30, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[2]] = g
      grid.arrange(h[[1]], h[[2]], ncol = 2)
    })
    
    output$figure_patient_treatment = renderPlot({
      cor_A = x %>% 
        summarize(cor = round(cor.test(Patients, Level_A)$estimate,3), p = round(cor.test(Patients, Level_A)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_AB = x %>% 
        summarize(cor = round(cor.test(Patients, Level_AB)$estimate,3), p = round(cor.test(Patients, Level_AB)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_ABC = x %>% 
        summarize(cor = round(cor.test(Patients, Level_ABC)$estimate,3), p = round(cor.test(Patients, Level_ABC)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      MAX_pt = max(x$Patients) * 1.05
      h = list()
      g <- ggplot(x, aes(x = Patients, y = Level_A, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_pt), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Patients",y = "Frequency of Evidence level A (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_A, mapping = aes(x = 0.3*MAX_pt, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[1]] = g
      
      g <- ggplot(x, aes(x = Patients, y = Level_AB, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_pt), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Patients",y = "Frequency of Evidence level A/B (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_AB, mapping = aes(x = 0.3*MAX_pt, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[2]] = g
      
      g <- ggplot(x, aes(x = Patients, y = Level_ABC, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_pt), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Patients",y = "Frequency of Evidence level A/B/C (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_ABC, mapping = aes(x = 0.3*MAX_pt, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[3]] = g
      
      cor_A = x %>% 
        summarize(cor = round(cor.test(Patients, Treatment_option)$estimate,3), p = round(cor.test(Patients, Treatment_option)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_AB = x %>% 
        summarize(cor = round(cor.test(Patients, Receive_Recom_Tx)$estimate,3), p = round(cor.test(Patients, Receive_Recom_Tx)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_ABC = x %>% 
        summarize(cor = round(cor.test(Patients, Receive_Tx_rate_with_opt)$estimate,3), p = round(cor.test(Patients, Receive_Tx_rate_with_opt)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      g <- ggplot(x, aes(x = Patients, y = Treatment_option, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_pt), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Patients",y = "Patients with treatment option (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_A, mapping = aes(x = 0.3*MAX_pt, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[4]] = g
      
      g <- ggplot(x, aes(x = Patients, y = Receive_Recom_Tx, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_pt), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Patients",y = "Patients received recommended treatment (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_AB, mapping = aes(x = 0.3*MAX_pt, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[5]] = g
      
      g <- ggplot(x, aes(x = Patients, y = Receive_Tx_rate_with_opt, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_pt), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Patients",y = "Rate of receiving recommended treatment (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_ABC, mapping = aes(x = 0.3*MAX_pt, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[6]] = g
      grid.arrange(h[[1]], h[[2]], h[[3]], h[[4]], h[[5]], h[[6]], ncol = 2)
    })
    
    output$figure_Pre_CGP_treatment = renderPlot({
       cor_A = x %>% 
        summarize(cor = round(cor.test(Survival_pre_CGP, Level_A)$estimate,3), p = round(cor.test(Survival_pre_CGP, Level_A)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_AB = x %>% 
        summarize(cor = round(cor.test(Survival_pre_CGP, Level_AB)$estimate,3), p = round(cor.test(Survival_pre_CGP, Level_AB)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_ABC = x %>% 
        summarize(cor = round(cor.test(Survival_pre_CGP, Level_ABC)$estimate,3), p = round(cor.test(Survival_pre_CGP, Level_ABC)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      h = list()
      MAX_days = max(x$Survival_pre_CGP) * 1.05
      g <- ggplot(x, aes(x = Survival_pre_CGP, y = Level_A, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival before CGP (days)",y = "Frequency of Evidence level A (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_A, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[1]] = g
      
      g <- ggplot(x, aes(x = Survival_pre_CGP, y = Level_AB, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival before CGP (days)",y = "Frequency of Evidence level A/B (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_AB, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[2]] = g
      
      g <- ggplot(x, aes(x = Survival_pre_CGP, y = Level_ABC, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival before CGP (days)",y = "Frequency of Evidence level A/B/C (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_ABC, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[3]] = g
      
      
      cor_A = x %>% 
        summarize(cor = round(cor.test(Survival_pre_CGP, Treatment_option)$estimate,3), p = round(cor.test(Survival_pre_CGP, Treatment_option)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_AB = x %>% 
        summarize(cor = round(cor.test(Survival_pre_CGP, Receive_Recom_Tx)$estimate,3), p = round(cor.test(Survival_pre_CGP, Receive_Recom_Tx)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_ABC = x %>% 
        summarize(cor = round(cor.test(Survival_pre_CGP, Receive_Tx_rate_with_opt)$estimate,3), p = round(cor.test(Survival_pre_CGP, Receive_Tx_rate_with_opt)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      g <- ggplot(x, aes(x = Survival_pre_CGP, y = Treatment_option, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival before CGP (days)",y = "Patients with treatment option (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_A, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[4]] = g
      
      g <- ggplot(x, aes(x = Survival_pre_CGP, y = Receive_Recom_Tx, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, 1000), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival before CGP (days)",y = "Patients received recommended treatment (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_AB, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[5]] = g
      
      g <- ggplot(x, aes(x = Survival_pre_CGP, y = Receive_Tx_rate_with_opt, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival before CGP (days)",y = "Rate of receiving recommended treatment (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_ABC, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[6]] = g
      grid.arrange(h[[1]], h[[2]], h[[3]], h[[4]], h[[5]], h[[6]], ncol = 2)
    })
    
    
    output$figure_Post_CGP_treatment = renderPlot({
      cor_A = x %>% 
        summarize(cor = round(cor.test(Survival_post_CGP, Level_A)$estimate,3), p = round(cor.test(Survival_post_CGP, Level_A)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_AB = x %>% 
        summarize(cor = round(cor.test(Survival_post_CGP, Level_AB)$estimate,3), p = round(cor.test(Survival_post_CGP, Level_AB)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_ABC = x %>% 
        summarize(cor = round(cor.test(Survival_post_CGP, Level_ABC)$estimate,3), p = round(cor.test(Survival_post_CGP, Level_ABC)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      h = list()
      MAX_days = max(x$Survival_post_CGP) * 1.05
      g <- ggplot(x, aes(x = Survival_post_CGP, y = Level_A, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival after CGP (days)",y = "Frequency of Evidence level A (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_A, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[1]] = g
      
      g <- ggplot(x, aes(x = Survival_post_CGP, y = Level_AB, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival after CGP (days)",y = "Frequency of Evidence level A/B (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_AB, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[2]] = g
      
      g <- ggplot(x, aes(x = Survival_post_CGP, y = Level_ABC, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival after CGP (days)",y = "Frequency of Evidence level A/B/C (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_ABC, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[3]] = g
      
      
      cor_A = x %>% 
        summarize(cor = round(cor.test(Survival_post_CGP, Treatment_option)$estimate,3), p = round(cor.test(Survival_post_CGP, Treatment_option)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_AB = x %>% 
        summarize(cor = round(cor.test(Survival_post_CGP, Receive_Recom_Tx)$estimate,3), p = round(cor.test(Survival_post_CGP, Receive_Recom_Tx)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      cor_ABC = x %>% 
        summarize(cor = round(cor.test(Survival_post_CGP, Receive_Tx_rate_with_opt)$estimate,3), p = round(cor.test(Survival_post_CGP, Receive_Tx_rate_with_opt)$p.value,3)) %>% 
        as.data.frame() #%>% mutate(p = ifelse(p < 0.05, "p < 0.05", paste("p =", p )))
      
      g <- ggplot(x, aes(x = Survival_post_CGP, y = Treatment_option, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival after CGP (days)",y = "Patients with treatment option (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_A, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[4]] = g
      
      g <- ggplot(x, aes(x = Survival_post_CGP, y = Receive_Recom_Tx, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival after CGP (days)",y = "Patients received recommended treatment (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_AB, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[5]] = g
      
      g <- ggplot(x, aes(x = Survival_post_CGP, y = Receive_Tx_rate_with_opt, color = Cancers))
      g <- g + geom_point(size = 3, alpha = .5)
      g <- g + scale_fill_nejm()
      g <- g + coord_cartesian(xlim = c(0, MAX_days), ylim = c(0, 100))
      g <- g + theme_bw()
      g <- g + labs(x = "Survival after CGP (days)",y = "Rate of receiving recommended treatment (%)", color = "Cancer type")
      g <- g + geom_smooth(method = lm, se = FALSE, na.rm = T, colour = "red")
      g <- g + geom_text(data=cor_ABC, mapping = aes(x = 0.3*MAX_days, y = 3, color = "red", label = paste("r =",cor, ", p =",p)))
      h[[6]] = g
      grid.arrange(h[[1]], h[[2]], h[[3]], h[[4]], h[[5]], h[[6]], ncol = 2)
    })
    
    output$figure_cluster_subtype = renderPlot({
      ggplot(Data_mutation_cord, aes(V1,V2,color = Data_case_target$Cancers)) +
        geom_point() + 
        labs(x = "UMAP 1", y = "UMAP 2",
             title = "Unsupervised clustering of oncogenic alterations") +
        theme_classic() + labs(color = "組織型")
    })
    output$figure_cluster_age = renderPlot({
      ggplot(Data_mutation_cord, aes(V1,V2,color = Data_case_target$YoungOld)) +
        geom_point() + 
        labs(x = "UMAP 1", y = "UMAP 2",
             title = "Unsupervised clustering of oncogenic alterations") +
        theme_classic() + labs(color = "年齢")
    })
    output$figure_cluster = renderPlot({
      if(min(dbscan_res_changed$cluster) == 0){
        dbscan_res_changed$cluster = (dbscan_res_changed$cluster + 1)
        plot(Data_mutation_cord, col=(dbscan_res_changed$cluster %% 29 + 1),
             pch = (dbscan_res_changed$cluster %% 26), main=paste(
               "DBSCAN clustering, cluster-1 is NOT-ASSIGNED, EPS:",
               EPS, ", minPts:", MINPTS, sep=""))
        labels <- selected_genes#1:(max(dbscan_res_changed$cluster))
        legend("topleft", legend = labels,
               pch=(1:(max(dbscan_res_changed$cluster)) %% 26),
               col= (1:(max(dbscan_res_changed$cluster)) %% 29 + 1))
      } else{
        plot(Data_mutation_cord, col=(dbscan_res_changed$cluster %% 29 + 1),
             pch = (dbscan_res_changed$cluster %% 26), main=paste(
               "DBSCAN clustering, EPS:",
               EPS, ", minPts:", MINPTS, sep=""))
        labels <- selected_genes#1:(max(dbscan_res_changed$cluster))
        legend("topleft", legend = labels,
               pch=(1:(max(dbscan_res_changed$cluster)) %% 26),
               col= (1:(max(dbscan_res_changed$cluster)) %% 29 + 1))
      }
    })
  })
  
  
  
  observeEvent(input$survival_CGP_analysis, {
    Data_case_target = Data_case() %>%
      dplyr::filter(
        症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
          症例.検体情報.パネル.名称. %in% input$panel &
          症例.基本情報.性別.名称. %in% input$sex &
          症例.背景情報.ECOG.PS.名称. %in% input$PS &
          症例.背景情報.喫煙歴有無.名称. %in% input$smoking
      )
    if(!all(input$age == c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                           max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
      Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
      Data_case_target = Data_case_target %>% dplyr::filter(
        症例.基本情報.年齢 >= input$age[1] &
          症例.基本情報.年齢 <= input$age[2]
      )
    }
    
    Data_case_target$Cancers = Data_case_target$症例.基本情報.がん種.OncoTree.
    Total_pts = as.vector(table((Data_case_target %>%
                                   dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = T))$Cancers))
    Data_survival = Data_case_target %>%
      dplyr::mutate(final_observe = case_when(
        症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
        症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
        症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
        TRUE ~ 症例.管理情報.登録日))
    Data_survival = Data_survival %>%
      dplyr::arrange(desc(final_observe)) %>%
      dplyr::mutate(censor = case_when(
        症例.転帰情報.死亡日 != "" ~ 1,
        TRUE ~ 0)) %>%
      dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
    
    Data_survival = Data_survival %>%
      dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
      dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
    
    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, censor) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_survival = Data_survival %>%
      dplyr::mutate(final_observe = as.Date(Data_survival$final_observe)) %>%
      dplyr::mutate(症例.管理情報.登録日 =
                      as.Date(Data_survival$症例.管理情報.登録日)) %>%
      dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                      as.Date(症例.EP前レジメン情報.投与開始日))
    
    Data_survival = Data_survival %>%
      dplyr::mutate(time_enroll_final =
                      as.integer(difftime(Data_survival$final_observe,
                                          Data_survival$症例.管理情報.登録日,
                                          units = "days")))
    Data_survival = Data_survival %>%
      dplyr::mutate(time_palliative_final =
                      as.integer(difftime(Data_survival$final_observe,
                                          Data_survival$症例.EP前レジメン情報.投与開始日,
                                          units = "days")))
    Data_survival = Data_survival %>%
      dplyr::mutate(time_palliative_enroll =
                      Data_survival$time_palliative_final -
                      Data_survival$time_enroll_final)
    
    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, final_observe) %>%
      dplyr::arrange(desc(final_observe)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_enroll_final) %>%
      dplyr::arrange(desc(time_enroll_final)) %>%
      dplyr::filter(time_enroll_final > 0 & !is.na(time_enroll_final) & is.finite(time_enroll_final)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_survival_tmp = Data_survival %>%
      dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                      c("その他", "緩和")) %>%
      dplyr::arrange(症例.EP前レジメン情報.投与開始日) %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_palliative_enroll, time_palliative_final) %>%
      dplyr::filter(time_palliative_enroll > 0 & time_palliative_enroll < 10000 & !is.na(time_palliative_enroll) & is.finite(time_palliative_enroll)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_case_target = Data_case_target %>% dplyr::mutate(
      YoungOld = case_when(
        症例.基本情報.年齢 <= input$mid_age ~ "Younger",
        TRUE ~ "Older")) %>%
      dplyr::distinct(.keep_all = TRUE, C.CAT調査結果.基本項目.ハッシュID)
    Data_MAF = Data_report() %>%
      dplyr::filter(
        !str_detect(Hugo_Symbol, ",") &
          Hugo_Symbol != "" &
          Evidence_level %in% c("","A","B","C","D","E","F") &
          Variant_Classification != "expression"
      ) %>% 
      dplyr::arrange(desc(Evidence_level)) %>%
      dplyr::distinct(Tumor_Sample_Barcode,
                      Hugo_Symbol,
                      Start_Position,
                      .keep_all = TRUE)
    Data_MAF$TMB = as.numeric(str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1])
    if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
      Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
    }
    if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
      Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
    }
    Data_report_TMB = Data_MAF %>%
      dplyr::filter(Hugo_Symbol == "TMB") %>%
      dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::mutate(Evidence_level = case_when(
        TMB < 10 ~ "",
        TMB >= 10 ~ "F",
        TRUE ~ ""
      ))
    Data_MAF = Data_MAF %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::filter(Hugo_Symbol != "TMB")
    Data_MAF = rbind(Data_MAF, Data_report_TMB)
    Data_report_TMB = Data_report_TMB %>%
      dplyr::filter(Tumor_Sample_Barcode %in%
                      Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
      dplyr::select(Tumor_Sample_Barcode, TMB)
    colnames(Data_report_TMB) = c("C.CAT調査結果.基本項目.ハッシュID", "TMB")
    Data_case_target = left_join(Data_case_target, Data_report_TMB,
                                 by = "C.CAT調査結果.基本項目.ハッシュID")
    
    Data_MAF_target = Data_MAF %>%
      dplyr::filter(Tumor_Sample_Barcode %in%
                      Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
    if(input$patho == "Only pathogenic muts"){
      Data_MAF_target = Data_MAF_target %>%
        dplyr::filter(Evidence_level == "F")
    }
    Data_MAF_target = Data_MAF_target %>%
      dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, .keep_all = T)
    Gene_list = unique(names(sort(table(Data_MAF_target$Hugo_Symbol),
                                  decreasing = T)))
    Data_mutation = data.frame(matrix(0,
                                      nrow=length(Data_case_target$C.CAT調査結果.基本項目.ハッシュID),
                                      ncol=length(Gene_list)))
    colnames(Data_mutation) = Gene_list
    rownames(Data_mutation) = Data_case_target$C.CAT調査結果.基本項目.ハッシュID
    for(i in 1:length(Data_MAF_target$Hugo_Symbol)){
      Data_mutation[Data_MAF_target$Tumor_Sample_Barcode[i],
                    Data_MAF_target$Hugo_Symbol[i]] = 1
    }
    if(length(Data_mutation[is.na(Data_mutation)])> 0){
      Data_mutation[is.na(Data_mutation)] <- 0
    }
    if(length(Data_case_target$censor[is.na(Data_case_target$censor)])> 0){
      Data_case_target$censor[is.na(Data_case_target$censor)] = 0
    }
    
    Data_case_target = Data_case_target %>%
    dplyr::mutate(EP_option = case_when(
      症例.EP後レジメン情報.EPの結果新たな治療薬の選択肢が提示された.名称. ==
        "はい" ~ 1,
      TRUE ~ 0)) %>%
    dplyr::mutate(EP_treat = case_when(
      症例.EP後レジメン情報.提示された治療薬を投与した.名称. ==
        "投与した" ~ 1,
      TRUE ~ 0))
    
    Data_tmp = Data_case_target %>% dplyr::select(
      C.CAT調査結果.基本項目.ハッシュID,
      症例.EP後レジメン情報.治療ライン,
      症例.EP後レジメン情報.化学療法レジメン名称,
      症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
      症例.EP後レジメン情報.提示された治療薬を投与した.名称.
      ) %>%
      dplyr::distinct()
    Data_tmp = tidyr::replace_na(Data_tmp,
                                 replace = list(症例.EP後レジメン情報.治療ライン = 0,
                                                症例.EP後レジメン情報.化学療法レジメン名称 = "",
                                                症例.EP後レジメン情報.薬剤名.YJ一般名.EN. = "",
                                                症例.EP後レジメン情報.提示された治療薬を投与した.名称. = "不明"))
    Data_tmp = Data_tmp %>%
      dplyr::filter(症例.EP後レジメン情報.治療ライン != 0 &(
        症例.EP後レジメン情報.化学療法レジメン名称 != "" |
          症例.EP後レジメン情報.薬剤名.YJ一般名.EN. != "" |
          症例.EP後レジメン情報.提示された治療薬を投与した.名称. == "投与した"))
    ID_tmp = unique(Data_tmp$C.CAT調査結果.基本項目.ハッシュID)
    Data_survival = Data_case_target %>% dplyr::filter(
        !is.na(time_enroll_final) &
        is.finite(time_enroll_final) & 
        time_enroll_final > 0 &
        !is.na(censor) &
        is.finite(censor)
    )  
    Data_survival$afterCGPtreat = Data_survival$EP_treat
    for(i in ID_tmp){
      Data_survival[Data_survival$C.CAT調査結果.基本項目.ハッシュID == i, "afterCGPtreat"] = 1
    }
    Data_survival = Data_survival %>%
      dplyr::mutate(treat_group = case_when(
        afterCGPtreat == 1 & EP_treat == 1 ~ "Option(+)RecomTreat(+)",
        afterCGPtreat == 1 & EP_option == 1 ~ "Option(+)UnrecomTreat(+)",
        afterCGPtreat == 1 & EP_option == 0 ~ "Option(-)UnrecomTreat(+)",
        afterCGPtreat == 0 & EP_option == 1 ~ "Option(+)Treat(-)",
        afterCGPtreat == 0 & EP_option == 0 ~ "Option(-)Treat(-)"
      ))
    Data_survival = Data_survival %>%
      dplyr::mutate(treat_group_2 = case_when(
        afterCGPtreat == 1 & EP_treat == 1 ~ "RecomTreat(+)",
        afterCGPtreat == 1 & EP_option == 1 ~ "UnrecomTreat(+)",
        afterCGPtreat == 1 & EP_option == 0 ~ "UnrecomTreat(+)",
        afterCGPtreat == 0 & EP_option == 1 ~ "Treat(-)",
        afterCGPtreat == 0 & EP_option == 0 ~ "Treat(-)"
      ))
    Data_survival = Data_survival %>%
      dplyr::mutate(treat_group_3 = case_when(
        afterCGPtreat == 1 & EP_treat == 1 ~ "Treat(+)",
        afterCGPtreat == 1 & EP_option == 1 ~ "Treat(+)",
        afterCGPtreat == 1 & EP_option == 0 ~ "Treat(+)",
        afterCGPtreat == 0 & EP_option == 1 ~ "Treat(-)",
        afterCGPtreat == 0 & EP_option == 0 ~ "Treat(-)"
      ))
    Data_survival = Data_survival %>%
      dplyr::filter(time_enroll_final > 0 & !is.na(time_enroll_final) & is.finite(time_enroll_final))
    Cancername = sort(unique(Data_survival$Cancers))
    
    output$figure_survival_CGP_1 = renderPlot({
      g = list()
      # Survival analysis for all patients
      survival_simple = survfit(Surv(time_enroll_final, censor)~1,
                                data=Data_survival,conf.type = "log-log")
      g[[1]] = surv_curv_entry(survival_simple, Data_survival, paste(survival_simple[[1]], "patients"), "All enrolled patients", NULL, NULL)
      
      # Survival analysis for EP recommendation
      survival_simple = survfit(Surv(time_enroll_final, censor)~EP_option,
                                data=Data_survival)
      if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~EP_option, data=Data_survival, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~EP_option, data=Data_survival, rho=1)
        g[[2]] = surv_curv_entry(survival_simple, Data_survival, paste("EP option existed for", 
                                                                   (survival_simple)[[1]][[2]], "patients"), paste("Expert panel recommended option existed:",
                                                                                                                   c("No", "Yes"), sep=""), diff_0, diff_1)
      }
      
      # Survival analysis for EP recommended treatment
      survival_simple = survfit(Surv(time_enroll_final, censor)~EP_treat,
                                data=Data_survival)
      if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~EP_treat,
                          data=Data_survival, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~EP_treat,
                          data=Data_survival, rho=1)
        g[[3]] = surv_curv_entry(survival_simple, Data_survival, paste("Recommended treatment done for", 
                                                                   (survival_simple)[[1]][[2]], "patients"),
                             paste("Recommended treatment done: ",
                                   c("No", "Yes"), sep=""), diff_0, diff_1)
      }
      
      # Survival analysis for EP recommended treatment only patients with treatment option
      Data_survival_option = Data_survival %>%
        dplyr::filter(EP_option == 1)
      survival_simple = survfit(Surv(time_enroll_final, censor)~EP_treat,
                                data=Data_survival_option)
      if(length(Data_survival_option[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~EP_treat,
                          data=Data_survival_option, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~EP_treat,
                          data=Data_survival_option, rho=1)
        g[[4]] = surv_curv_entry(survival_simple, Data_survival_option,  paste("Recommended treatment done for", 
                                                                           (survival_simple)[[1]][[2]], "patients with treatment option"), c("EP option exists but recommended treatment not done",
                                                                                                                                             "EP option exists and recommended treatment done"), diff_0, diff_1)
      }
      
      # Survival analysis for EP recommended treatment
      survival_simple = survfit(Surv(time_enroll_final, censor)~treat_group,
                                data=Data_survival)
      if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~treat_group,
                          data=Data_survival, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~treat_group,
                          data=Data_survival, rho=1)
        g[[5]] = surv_curv_entry(survival_simple, Data_survival,  paste("EP option and treatment"), NULL, diff_0, diff_1)
      }
      
      # Survival analysis for EP recommended treatment
      survival_simple = survfit(Surv(time_enroll_final, censor)~treat_group_2,
                                data=Data_survival)
      if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~treat_group_2,
                          data=Data_survival, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~treat_group_2,
                          data=Data_survival, rho=1)
        #summary(survival_simple)
        g[[6]] = surv_curv_entry(survival_simple, Data_survival, paste("EP option and treatment"), NULL, diff_0, diff_1)
      }
      
      arrange_ggsurvplots(g,print=TRUE,ncol=2,nrow=3)
    })
    output$figure_survival_CGP_2 = renderPlot({
      g = list()
      # Survival analysis for EP recommended treatment
      Data_survival_treated = Data_survival %>%
        dplyr::filter(treat_group_2 != "Treat(-)")
      survival_simple = survfit(Surv(time_enroll_final, censor)~treat_group_2,
                                data=Data_survival_treated)
      if(length(Data_survival_treated[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~treat_group_2,
                          data=Data_survival_treated, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~treat_group_2,
                          data=Data_survival_treated, rho=1)
        g[[1]] = surv_curv_entry(survival_simple, Data_survival_treated, paste("EP option and treatment"), NULL, diff_0, diff_1)
      }
      
      # Survival analysis for EP recommended treatment
      survival_simple = survfit(Surv(time_enroll_final, censor)~treat_group_3,
                                data=Data_survival)
      if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~treat_group_3,
                          data=Data_survival, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~treat_group_3,
                          data=Data_survival, rho=1)
        #summary(survival_simple)
        g[[2]] = surv_curv_entry(survival_simple, Data_survival, paste("EP option and treatment"), NULL, diff_0, diff_1)
      }
      
      # Survival analysis for ECOG performance status
      survival_simple = survfit(Surv(time_enroll_final, censor)~症例.背景情報.ECOG.PS.名称.,
                                data=Data_survival)
      if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~症例.背景情報.ECOG.PS.名称.,
                          data=Data_survival, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~症例.背景情報.ECOG.PS.名称.,
                          data=Data_survival, rho=1)
        g[[3]] = surv_curv_entry(survival_simple, Data_survival, "ECOG PS", paste("Performance status:",
                                                                                                 sort(unique(Data_survival$症例.背景情報.ECOG.PS.名称.)),
                                                                                                 sep=""), diff_0, diff_1)
      }
      
      # Survival analysis for ECOG performance status, PS 0 vs 1 vs 2/3/4
      Data_survival_PS = Data_survival %>%
        dplyr::filter(症例.背景情報.ECOG.PS.名称. != "不明") %>%
        dplyr::mutate(PS_modified = case_when(
          症例.背景情報.ECOG.PS.名称. == "0" ~ "PS 0",
          症例.背景情報.ECOG.PS.名称. == "1" ~ "PS 1",
          TRUE ~ "PS 2-4"
        ))
      survival_simple = survfit(Surv(time_enroll_final, censor)~PS_modified,
                                data=Data_survival_PS)
      if(length(Data_survival_PS[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~PS_modified,
                          data=Data_survival_PS, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~PS_modified,
                          data=Data_survival_PS, rho=1)
        g[[4]] = surv_curv_entry(survival_simple, Data_survival_PS, paste("ECOG PS (PS unknown patients excluded)"), paste("Performance status:",
                                                                                                                        sort(unique(Data_survival_PS$PS_modified)),
                                                                                                                        sep=""), diff_0, diff_1)
      }
      
      
      # Survival analysis for diagnosis
      Data_survival_tmp = Data_survival %>% dplyr::filter(
        Cancers %in% sort(names(table(Data_survival$Cancers)))[1:min(8,length(unique(Data_survival$Cancers)))])
      if(length(unique(Data_survival_tmp$Cancers))>1){
        survival_simple = survfit(Surv(time_enroll_final, censor)~Cancers,
                                  data=Data_survival_tmp)
        if(length(Data_survival_tmp[,1]) != survival_simple[[1]][[1]]){
          diff_0 = survdiff(Surv(time_enroll_final, censor)~Cancers,
                            data=Data_survival_tmp, rho=0)
          diff_1 = survdiff(Surv(time_enroll_final, censor)~Cancers,
                            data=Data_survival_tmp, rho=1)
          g[[5]] = surv_curv_entry(survival_simple, Data_survival_tmp, paste("diagnosis"), sort(unique(Data_survival_tmp$Cancers)), diff_0, diff_1)
        }
      } else{
        survival_simple = survfit(Surv(time_enroll_final, censor)~1,
                                  data=Data_survival_tmp)
        g[[5]] = surv_curv_entry(survival_simple, Data_survival_PS, paste("Only 1 diagnosis"), unique(Data_survival_tmp$Cancers)[[1]], diff_0, diff_1)
      }
      
      # Survival analysis for mutation
      if(is.null(input$gene)){
        mut_gene = "TP53"
      } else{
        mut_gene = input$gene
      }
      ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode
      Data_survival = Data_survival %>% dplyr::mutate(
        mutation = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ 0,
          TRUE ~ 1
        )
      )
      survival_simple = survfit(Surv(time_enroll_final, censor)~mutation,
                                data=Data_survival)
      if(length(Data_survival[,1]) != survival_simple[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~mutation,
                          data=Data_survival, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~mutation,
                          data=Data_survival, rho=1)
        g[[6]] = surv_curv_entry(survival_simple, Data_survival, paste(paste(mut_gene, collapse = "/")),
                              c(paste0(paste(mut_gene, collapse = "/"), " mut"), "Not mut"), diff_0, diff_1)
      }
      
      arrange_ggsurvplots(g,print=TRUE,ncol=2,nrow=3)
    })
    # analysis for common oncogenic mutations
    h = list()
    hs = list()
    oncogenic_genes = Data_MAF_target %>%
      dplyr::select(Tumor_Sample_Barcode, Hugo_Symbol) %>%
      dplyr::distinct() %>%
      dplyr::count(Hugo_Symbol) %>%
      dplyr::arrange(-n)
    colnames(oncogenic_genes) = c("gene_mutation", "all_patients")
    oncogenic_genes = oncogenic_genes[1:min(length(oncogenic_genes$all_patients), input$gene_no),]
    
    gene_table = data.frame(oncogenic_genes$gene_mutation)
    colnames(gene_table) = c("Gene")
    gene_table$positive_patients = oncogenic_genes$all_patients
    gene_table$positive_freq = round(1000 * gene_table$positive_patients / length(Data_survival$C.CAT調査結果.基本項目.ハッシュID)) / 10
    gene_table$positive_median = 0
    gene_table$positive_LL = 0
    gene_table$positive_UL = 0
    gene_table$negative_median = 0
    gene_table$negative_LL = 0
    gene_table$negative_UL = 0
    k = 1
    for(i in 1:length(oncogenic_genes$all_patients)){
      ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% oncogenic_genes$gene_mutation[i]))$Tumor_Sample_Barcode
      Data_survival = Data_survival %>% dplyr::mutate(
        gene_select = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ 0,
          TRUE ~ 1
        )
      )
      traditional_fit = survfit(Surv(event = censor,
                                     time = time_enroll_final) ~ gene_select, 
                                data = Data_survival)
      if(length(Data_survival[,1]) != traditional_fit[[1]][[1]]){
        diff_0 = survdiff(Surv(time_enroll_final, censor)~gene_select,
                          data=Data_survival, rho=0)
        diff_1 = survdiff(Surv(time_enroll_final, censor)~gene_select,
                          data=Data_survival, rho=1)
        mut_gene = paste(oncogenic_genes$gene_mutation[i],
                         ", top ", i, " gene with oncogenic mutations", sep="")
        tmp = data.frame(summary(traditional_fit)$table)
        gene_table$positive_median[i] = tmp$median[1]
        gene_table$positive_LL[i] = tmp$X0.95LCL[1]
        gene_table$positive_UL[i] = tmp$X0.95UCL[1]
        gene_table$negative_median[i] = tmp$median[2]
        gene_table$negative_LL[i] = tmp$X0.95LCL[2]
        gene_table$negative_UL[i] = tmp$X0.95UCL[2]
        hs[[k]] = surv_curv_entry(traditional_fit, Data_survival, "Oncogenic mut",
                                 c(paste0(oncogenic_genes$gene_mutation[i], " mut"), "Not mut"), diff_0, diff_1)
      } else{
        tmp = summary(traditional_fit)$table
        legends = paste0(tmp[[7]], " (", tmp[[8]], "-", tmp[[9]],")")
        gene_table$negative_median[i] = tmp[[7]]
        gene_table$negative_LL[i] = tmp[[8]]
        gene_table$negative_UL[i] = tmp[[9]]
      }
      k = k + 1
    }
    Gene_arrange = gene_table$Gene
    Gene_data = gene_table
    gene_table = gene_table %>% dplyr::mutate(
      Gene = factor(gene_table$Gene, levels = Gene_arrange))
    p <- 
      gene_table |>
      ggplot(aes(y = fct_rev(Gene))) + 
      theme_classic()
    p <- p +
      geom_point(aes(x=positive_median, colour = "blue"), shape=15, size=3) +
      geom_linerange(aes(xmin=positive_LL, xmax=positive_UL, colour = "blue"))
    p <- p +
      geom_point(aes(x=negative_median, colour = "red"), shape=15, size=3) +
      geom_linerange(aes(xmin=negative_LL, xmax=negative_UL, colour = "red"))
    p <- p +
      geom_vline(xintercept = 0, linetype="dashed") +
      labs(x="Median OS, red:mut (+), blue:mut (-)", y="Genes with oncogenic alteration")
    p <- p +
      coord_cartesian(ylim=c(1,length(Gene_arrange) + 1), xlim=c( - 15, max(gene_table$negative_UL, gene_table$positive_UL) + 15))
    p_mid <- p + 
      theme(legend.position = "none",
            axis.line.y = element_blank(),
            axis.ticks.y= element_blank(),
            axis.text.y= element_blank(),
            axis.title.y= element_blank())
    gene_table <- gene_table %>%
      dplyr::mutate(
        estimate_lab_1 = paste0(positive_median, " (", positive_LL, "-", positive_UL, ")")) %>%
      dplyr::mutate(
        estimate_lab_2 = paste0(negative_median, " (", negative_LL, "-", negative_UL, ")")) %>%
      dplyr::mutate(
        patients = paste0(positive_patients, " (", positive_freq, "%)"))
    gene_table = 
      dplyr::bind_rows(
        data.frame(
          Gene = "Gene",
          estimate_lab_1 = "Survival, mut (+)",
          estimate_lab_2 = "Survival, mut (-)",
          patients = "Patients"
        ), gene_table  )
    Gene_arrange = gene_table$Gene
    gene_table = gene_table %>% dplyr::mutate(
      Gene = factor(gene_table$Gene, levels = Gene_arrange))
    
    p_left <- gene_table  %>% ggplot(aes(y = fct_rev(Gene)))
    p_left <- p_left + geom_text(aes(x = 0, label = Gene), hjust = 0,
                                 fontface = ifelse(gene_table$Gene == "Gene", "bold", "bold.italic"))
    p_left <- p_left + geom_text(aes(x = 1.4, label = estimate_lab_1), hjust = 0,
                                 fontface = ifelse(gene_table$estimate_lab_1 == "Survival, mut (+)", "bold", "plain"))
    p_left <- p_left + geom_text(aes(x = 2.6, label = estimate_lab_2), hjust = 0,
                                 fontface = ifelse(gene_table$estimate_lab_2 == "Survival, mut (-)", "bold", "plain"))
    p_left <- p_left + theme_void() + coord_cartesian(xlim = c(0, 5.5))
    
    # right side of plot - pvalues
    p_right <- gene_table  |> ggplot() +
      geom_text(aes(x = 0, y = fct_rev(Gene), label = patients), hjust = 0,
                fontface = ifelse(gene_table$patients == "Patients", "bold", "plain")) +
      theme_void()
    
    # final plot arrangement
    layout <- c(area(t = 0, l = 0, b = 30, r = 5.5),
                area(t = 1, l = 5.5, b = 30, r = 10.5),
                area(t = 0, l = 10.5, b = 30, r = 12))
    h[[1]] = p_left + p_mid + p_right + plot_layout(design = layout)
    
    output$figure_survival_CGP_3 = renderPlot({
      h[[1]]
    })
    output$figure_survival_CGP_4 = renderPlot({
      arrange_ggsurvplots(hs,print=TRUE,ncol=4,nrow=ceiling((k-1)/4))
    })
    
    Data_forest = Data_survival %>%
        dplyr::select(C.CAT調査結果.基本項目.ハッシュID,
                      症例.基本情報.年齢,
                      Lymph_met,
                      Brain_met,
                      Lung_met,
                      Bone_met,
                      Liver_met,
                      #Other_met,
                      EP_option,
                      EP_treat,
                      症例.基本情報.性別.名称.,
                      症例.基本情報.がん種.OncoTree.,
                      症例.基本情報.がん種.OncoTree.LEVEL1.,
                      症例.背景情報.ECOG.PS.名称.,
                      #症例.背景情報.喫煙歴有無.名称.,
                      #症例.背景情報.アルコール多飲有無.名称.,
                      time_enroll_final,
                      censor)
    colnames(Data_forest) = 
        c('ID', 'Age',
          'Lymph_met',
          'Brain_met',
          'Lung_met',
          'Bone_met',
          'Liver_met',
          #'Other_met',
          'EP_option',
          'EP_treat',
          'Sex', 'Histology', 'Histology_dummy', 'PS',
          #'Smoking_history', 'Alcoholic_history',
          'time_enroll_final', 'censor')
    Data_forest = Data_forest %>%
      dplyr::filter(PS != "不明" & Sex != "未入力・不明") %>%
      dplyr::mutate(PS = case_when(
        PS == 0 ~ "PS 0",
        TRUE ~ "PS 1-4"
    ))
    gene_names = unique(c(input$gene,
                        as.character((Gene_data %>% dplyr::arrange(positive_UL))$Gene)))
    gene_names = gene_names[1:min(8, length(gene_names))]
    for(i in 1:length(gene_names)){
      ID_mutation = unique((Data_MAF_target %>% dplyr::filter(Hugo_Symbol == gene_names[i]))$Tumor_Sample_Barcode)
      Data_forest_tmp = Data_forest %>% 
        dplyr::select(ID,Age) %>% dplyr::mutate(
        XXX = case_when(
          ID %in% ID_mutation ~ "mut(+)",
          TRUE ~ "mut(-)"
        )
      )
      colnames(Data_forest_tmp) = c("ID", "Age", gene_names[i])
      Data_forest = left_join(Data_forest, Data_forest_tmp, by=c("ID", "Age"))
    }
    Factor_names = colnames(Data_forest)
    Factor_names = Factor_names[!Factor_names %in% c('ID', 'time_enroll_final', 'censor', 'EP_treat')]
    
    Data_forest_tmp = Data_forest
    Disease_tmp = unique(sort(Data_forest_tmp$Histology))
    for(i in length(gene_names):1){
      if(sum(Data_forest_tmp[,15+i] == "mut(+)" & Data_forest_tmp$censor == 1) < 2){
        Factor_names = Factor_names[-(11+i)]
      }
    }
    for(i in 1:length(Disease_tmp)){
      Data_forest_tmp2 = Data_forest_tmp %>% dplyr::filter(Histology == Disease_tmp[i])
      if(sum(Data_forest_tmp2$censor == 1) < 2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::mutate(Histology = case_when(
            Histology == Disease_tmp[i] ~ Histology_dummy,
            TRUE ~ Histology
          )
        )
      }
    }
    if(length(unique(Data_forest_tmp$Histology))<2){
      Factor_names = Factor_names[!Factor_names %in% c('Histology')]
    }
    if(sum(Data_forest_tmp$EP_option == 0 & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('EP_option')]
    }
    if(sum(Data_forest_tmp$EP_option == 1 & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('EP_option')]
    }
    if(sum(Data_forest_tmp$PS == "PS 1-4" & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('PS')]
    }
    if(sum(Data_forest_tmp$PS == "PS 0" & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('PS')]
    }
    if(sum(Data_forest_tmp$Lymph_met == "Yes" & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('Lymph_met')]
    }
    if(sum(Data_forest_tmp$Lung_met == "Yes" & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('Lung_met')]
    }
    if(sum(Data_forest_tmp$Brain_met == "Yes" & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('Brain_met')]
    }
    if(sum(Data_forest_tmp$Bone_met == "Yes" & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('Bone_met')]
    }
    if(sum(Data_forest_tmp$Liver_met == "Yes" & Data_forest_tmp$censor == 1) < 2){
      Factor_names = Factor_names[!Factor_names %in% c('Liver_met')]
    }
    Factor_names = Factor_names[!Factor_names %in% c('Histology_dummy')]
    Formula = as.formula(paste0("Surv(time_enroll_final, censor) ~ ",
                       paste(Factor_names, collapse = "+")))
    linelistsurv_cox <-  coxph(Formula, data = Data_forest_tmp)
    output$figure_survival_CGP_5 = renderPlot({
      ggforest(main = "Hazard ratio for Death after CGP", linelistsurv_cox, data = Data_forest_tmp)
    })
    
    output$figure_survival_CGP_6 = renderPlot({
      Data_forest_tmp = Data_forest  %>%
        dplyr::filter(EP_option == 1) %>%
        dplyr::select(-time_enroll_final, -censor, -EP_option, -ID)
      Disease_tmp = unique(sort(Data_forest_tmp$Histology))
      for(i in 1:length(Disease_tmp)){
        Data_forest_tmp2 = Data_forest_tmp %>% dplyr::filter(Histology == Disease_tmp[i])
        if(sum(Data_forest_tmp2$EP_treat == 1) < 2){
          Data_forest_tmp = Data_forest_tmp %>%
            dplyr::mutate(Histology = case_when(
              Histology == Disease_tmp[i] ~ Histology_dummy,
              TRUE ~ Histology
            )
          )
        }
      }
      for(i in length(gene_names):1){
       if(sum(Data_forest_tmp[,11+i] == "mut(+)" & Data_forest_tmp$EP_treat == 1) < 2){
          Data_forest_tmp = Data_forest_tmp[,-(11+i)]
        }
      }
      if(sum(Data_forest_tmp$PS == "PS 0" & Data_forest_tmp$EP_treat == 1) < 2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::select(-PS)
      }
      if(sum(Data_forest_tmp$PS == "PS 1-4" & Data_forest_tmp$EP_treat == 1) < 2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::select(-PS)
      }
      if(sum(Data_forest_tmp$Lymph_met == "Yes" & Data_forest_tmp$EP_treat == 1) < 2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::select(-Lymph_met)
      }
      if(sum(Data_forest_tmp$Lung_met == "Yes" & Data_forest_tmp$EP_treat == 1) < 2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::select(-Lung_met)
      }
      if(sum(Data_forest_tmp$Brain_met == "Yes" & Data_forest_tmp$EP_treat == 1) < 2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::select(-Brain_met)
      }
      if(sum(Data_forest_tmp$Bone_met == "Yes" & Data_forest_tmp$EP_treat == 1) < 2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::select(-Bone_met)
      }
      if(sum(Data_forest_tmp$Liver_met == "Yes" & Data_forest_tmp$EP_treat == 1) < 2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::select(-Liver_met)
      }
      if(length(unique(Data_forest_tmp$Histology))<2){
        Data_forest_tmp = Data_forest_tmp %>%
          dplyr::select(-Histology)
      }
      Data_forest_tmp = Data_forest_tmp %>%
        dplyr::select(-Histology_dummy)
      
      theme_set(theme_sjplot())
      set_label(Data_forest_tmp$EP_treat) <- "Receiving recommended targeted therapy"
      m1 <- glm(EP_treat ~., data = Data_forest_tmp, family = binomial(link = "logit"))
      plot_model(m1, show.values = TRUE, sort.est = TRUE, value.offset = .3,axis.lim = c(0.01, 100))
    })
  })
  
  
  observeEvent(input$survival_CTx_analysis, {
    Data_case_target = Data_case() %>%
      dplyr::filter(
        症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
          症例.検体情報.パネル.名称. %in% input$panel &
          症例.基本情報.性別.名称. %in% input$sex &
          症例.背景情報.ECOG.PS.名称. %in% input$PS &
          症例.背景情報.喫煙歴有無.名称. %in% input$smoking
      )
    if(!all(input$age == c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                           max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
      Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
      Data_case_target = Data_case_target %>% dplyr::filter(
        症例.基本情報.年齢 >= input$age[1] &
          症例.基本情報.年齢 <= input$age[2]
      )
    }
    
    Data_case_target$Cancers = Data_case_target$症例.基本情報.がん種.OncoTree.
    Cancername = sort(unique(Data_case_target$Cancers))
    Total_pts = as.vector(table((Data_case_target %>%
                                   dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = T))$Cancers))
    Data_survival = Data_case_target %>%
      dplyr::mutate(final_observe = case_when(
        症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
        症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
        症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
        TRUE ~ 症例.管理情報.登録日))
    Data_survival = Data_survival %>%
      dplyr::arrange(desc(final_observe)) %>%
      dplyr::mutate(censor = case_when(
        症例.転帰情報.死亡日 != "" ~ 1,
        TRUE ~ 0)) %>%
      dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
    
    Data_survival = Data_survival %>%
      dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
      dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
    
    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, censor) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_survival = Data_survival %>%
      dplyr::mutate(final_observe = as.Date(Data_survival$final_observe)) %>%
      dplyr::mutate(症例.管理情報.登録日 =
                      as.Date(Data_survival$症例.管理情報.登録日)) %>%
      dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                      as.Date(症例.EP前レジメン情報.投与開始日))
    
    Data_survival = Data_survival %>%
      dplyr::mutate(time_enroll_final =
                      as.integer(difftime(Data_survival$final_observe,
                                          Data_survival$症例.管理情報.登録日,
                                          units = "days")))
    Data_survival = Data_survival %>%
      dplyr::mutate(time_palliative_final =
                      as.integer(difftime(Data_survival$final_observe,
                                          Data_survival$症例.EP前レジメン情報.投与開始日,
                                          units = "days")))
    Data_survival = Data_survival %>%
      dplyr::mutate(time_palliative_enroll =
                      Data_survival$time_palliative_final -
                      Data_survival$time_enroll_final)
    
    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, final_observe) %>%
      dplyr::arrange(desc(final_observe)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_survival_tmp = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_enroll_final) %>%
      dplyr::arrange(desc(time_enroll_final)) %>%
      dplyr::filter(time_enroll_final > 0 & !is.na(time_enroll_final) & is.finite(time_enroll_final)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_survival_tmp = Data_survival %>%
      dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                      c("その他", "緩和")) %>%
      dplyr::arrange(症例.EP前レジメン情報.投与開始日) %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, time_palliative_enroll, time_palliative_final) %>%
      dplyr::filter(time_palliative_enroll > 0 & time_palliative_enroll < 10000 & !is.na(time_palliative_enroll) & is.finite(time_palliative_enroll)) %>%
      dplyr::distinct(C.CAT調査結果.基本項目.ハッシュID, .keep_all = TRUE)
    Data_case_target = left_join(Data_case_target, Data_survival_tmp, by="C.CAT調査結果.基本項目.ハッシュID")
    
    Data_case_target = Data_case_target %>% dplyr::mutate(
      YoungOld = case_when(
        症例.基本情報.年齢 <= input$mid_age ~ "Younger",
        TRUE ~ "Older")) %>%
      dplyr::distinct(.keep_all = TRUE, C.CAT調査結果.基本項目.ハッシュID)
    Data_MAF = Data_report() %>%
      dplyr::filter(
        !str_detect(Hugo_Symbol, ",") &
          Hugo_Symbol != "" &
          Evidence_level %in% c("","A","B","C","D","E","F") &
          Variant_Classification != "expression"
      ) %>% 
      dplyr::arrange(desc(Evidence_level)) %>%
      dplyr::distinct(Tumor_Sample_Barcode,
                      Hugo_Symbol,
                      Start_Position,
                      .keep_all = TRUE)
    Data_MAF$TMB = as.numeric(str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1])
    if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
      Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
    }
    if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
      Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
    }
    Data_report_TMB = Data_MAF %>%
      dplyr::filter(Hugo_Symbol == "TMB") %>%
      dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::mutate(Evidence_level = case_when(
        TMB < 10 ~ "",
        TMB >= 10 ~ "F",
        TRUE ~ ""
      ))
    Data_MAF = Data_MAF %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::filter(Hugo_Symbol != "TMB")
    Data_MAF = rbind(Data_MAF, Data_report_TMB)
    Data_report_TMB = Data_report_TMB %>%
      dplyr::filter(Tumor_Sample_Barcode %in%
                      Data_case_target$C.CAT調査結果.基本項目.ハッシュID) %>%
      dplyr::select(Tumor_Sample_Barcode, TMB)
    colnames(Data_report_TMB) = c("C.CAT調査結果.基本項目.ハッシュID", "TMB")
    Data_case_target = left_join(Data_case_target, Data_report_TMB,
                                 by = "C.CAT調査結果.基本項目.ハッシュID")
    
    Data_MAF_target = Data_MAF %>%
      dplyr::filter(Tumor_Sample_Barcode %in%
                      Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
    if(input$patho == "Only pathogenic muts"){
      Data_MAF_target = Data_MAF_target %>%
        dplyr::filter(Evidence_level == "F")
    }
    Data_MAF_target = Data_MAF_target %>%
      dplyr::distinct(Tumor_Sample_Barcode, Hugo_Symbol, .keep_all = T)
    Gene_list = unique(names(sort(table(Data_MAF_target$Hugo_Symbol),
                                  decreasing = T)))
    Data_mutation = data.frame(matrix(0,
                                      nrow=length(Data_case_target$C.CAT調査結果.基本項目.ハッシュID),
                                      ncol=length(Gene_list)))
    colnames(Data_mutation) = Gene_list
    rownames(Data_mutation) = Data_case_target$C.CAT調査結果.基本項目.ハッシュID
    for(i in 1:length(Data_MAF_target$Hugo_Symbol)){
      Data_mutation[Data_MAF_target$Tumor_Sample_Barcode[i],
                    Data_MAF_target$Hugo_Symbol[i]] = 1
    }
    if(length(Data_mutation[is.na(Data_mutation)])> 0){
      Data_mutation[is.na(Data_mutation)] <- 0
    }
    if(length(Data_case_target$censor[is.na(Data_case_target$censor)])> 0){
      Data_case_target$censor[is.na(Data_case_target$censor)] = 0
    }
    Data_survival = Data_case_target %>% dplyr::filter(
      !is.na(time_palliative_enroll) &
      !is.na(time_enroll_final) &
      is.finite(time_palliative_enroll) &
      is.finite(time_enroll_final) & 
      time_palliative_enroll > 0 &
      time_enroll_final > 0 &
      !is.na(censor) &
      is.finite(censor)
    )  
    Median_entry = median(Data_survival_tmp$time_palliative_enroll)
    
    Data_survival = Data_survival %>%
      dplyr::mutate(delay_1 = case_when(
        Data_survival$time_palliative_enroll <= Median_entry ~ "SPT to entry early",
        TRUE ~ "SPT to entry later"))
    Cancername = sort(unique(Data_survival$Cancers))
    
    stan_weibull_survival_model_data <-
      list(
        Median = as.integer(Median_entry),
        Nobs = sum(Data_survival$censor == 1),
        Ncen = sum(Data_survival$censor == 0),
        Ntot = length(Data_survival$censor),
        M_bg = 1,
        Nexp = length(Data_survival_tmp$time_palliative_enroll),
        ybef_exp = Data_survival_tmp$time_palliative_enroll,
        yobs = Data_survival$time_enroll_final[Data_survival$censor == 1],
        ycen = Data_survival$time_enroll_final[Data_survival$censor == 0],
        Xobs_bg = matrix(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 1], ncol = 1),
        Xcen_bg = matrix(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 0], ncol = 1)
      )
    
    stan_weibull_survival_model_fit <-
      rstan::stan(file = "source/Stan_code_loglog_weibull.stan",
                  data = stan_weibull_survival_model_data,
                  control=list(adapt_delta=0.99, max_treedepth = 10),
                  seed=1234, chains=4, iter=3000, warmup=1000, thin=1, refresh=500, verbose = FALSE)
    
    stan_weibull_survival_model_draws <- tidybayes::tidy_draws(stan_weibull_survival_model_fit)
    stan_weibull_survival_model_draws_total_exp <-
      stan_weibull_survival_model_draws %>%
      dplyr::select(.chain, .iteration, .draw, starts_with("yhat_exp_total")) %>%
      tidyr::gather(key = key, value = yhat_total_exp, starts_with("yhat_exp_total")) %>%
      dplyr::select(-key) 
    stan_weibull_survival_model_draws_bef_exp <-
      stan_weibull_survival_model_draws %>%
      dplyr::select(.chain, .iteration, .draw, starts_with("y_exptmp")) %>%
      tidyr::gather(key = key, value = yhat_bef_exp, starts_with("y_exptmp")) %>%
      dplyr::select(-key) 
    stan_weibull_survival_model_draws_aft_exp <-
      stan_weibull_survival_model_draws %>%
      dplyr::select(.chain, .iteration, .draw, starts_with("yhat_exp_uncens")) %>%
      tidyr::gather(key = key, value = yhat_aft_exp, starts_with("yhat_exp_uncens")) %>%
      dplyr::select(-key) 
    stan_weibull_survival_model_draws_ear <-
      stan_weibull_survival_model_draws %>%
      dplyr::select(.chain, .iteration, .draw, starts_with("yhat_early")) %>%
      tidyr::gather(key = key, value = yhat_ear, starts_with("yhat_early")) %>%
      dplyr::select(-key) 
    stan_weibull_survival_model_draws_lat <-
      stan_weibull_survival_model_draws %>%
      dplyr::select(.chain, .iteration, .draw, starts_with("yhat_late")) %>%
      tidyr::gather(key = key, value = yhat_lat, starts_with("yhat_late")) %>%
      dplyr::select(-key) 
    
    median_os_list_weibull_total_exp = matrix(stan_weibull_survival_model_draws_total_exp$yhat_total_exp, ncol=8000)
    median_os_list_weibull_total_exp = colMedians(median_os_list_weibull_total_exp,na.rm = T)

    median_os_summary_weibull_total_exp = quantile(median_os_list_weibull_total_exp, probs = c(0.025, 0.5, 0.975))
    yhat_weibull_sort_total_exp = sort(stan_weibull_survival_model_draws_total_exp$yhat_total_exp)
    yhat_weibull_sort_average_total_exp = yhat_weibull_sort_total_exp[1:length(Data_survival$censor) * 8000]

    Data_survival$left_adj = yhat_weibull_sort_average_total_exp
    Data_survival$left_adj[Data_survival$left_adj > 10000] = 10000

    
    independence_check = with(Data_survival, cKendall(
      trun = time_palliative_enroll,
      obs = time_palliative_final,
      delta = censor,
      trans = "linear"))
    
    
    traditional_fit = survfit(Surv(event = censor,
                                   time = time_palliative_final) ~ 1, 
                              data = Data_survival)
    delayed_entry_fit = survfit(Surv(event = censor,
                                     time = time_palliative_enroll,
                                     time2 = time_palliative_final) ~ 1,
                                data = Data_survival)
    simulation_fit_2 = survfit(Surv(event = rep(1,length(Data_survival$left_adj)),
                                    time = left_adj) ~ 1, 
                               data = Data_survival)
    tmp_num = 18
    if(length(summary(delayed_entry_fit)[[18]]) == 1){
     tmp_num = 17
    }
    g = list()
    g[[1]] = ggsurvplot(
      fit = list(traditional_fit = traditional_fit,
                 delayed_entry_fit = delayed_entry_fit,
                 simulation_fit_2 = simulation_fit_2
      ),
      combine = TRUE,
      data = Data_survival,
      xlab = "Time from SPT to final observation (days)",
      ylab = "Survival Probability",
      censor = TRUE,
      conf.int = FALSE,
      font.title = 8,
      font.subtitle = 8,
      font.main = 8,
      font.submain = 8,
      font.caption = 8,
      font.legend = 8,
      pval = FALSE,
      surv.median.line = "hv",
      risk.table = TRUE,
      risk.table.y.text = FALSE,
      tables.theme = clean_theme(), 
      legend = c(0.8,0.90),
      xlim = c(0, max(Data_survival$time_palliative_final) * 1.05),
      break.x.by = ceiling(max(Data_survival$time_palliative_final) / 500) * 100,
      legend.labs = c("All patients, Unadjusted",
                      "All patients, Number at risk adjusted",
                      "All patients, Adj. right cens. & left trunc.")
    ) + 
      labs(title = paste(traditional_fit[[1]], " patients; Median OS ",
                         as.integer(summary(traditional_fit)[[17]][[7]])," (",
                         as.integer(summary(traditional_fit)[[17]][[8]]),"-",
                         as.integer(summary(traditional_fit)[[17]][[9]]),") (unadj.)/",
                         as.integer(summary(delayed_entry_fit)[[tmp_num]][[7]]), " (",
                         as.integer(summary(delayed_entry_fit)[[tmp_num]][[8]]),"-",
                         as.integer(summary(delayed_entry_fit)[[tmp_num]][[9]]),") (risk adj.)/\n",
                         as.integer(median_os_summary_weibull_total_exp[[2]]), " (",
                         as.integer(median_os_summary_weibull_total_exp[[1]]), "-",
                         as.integer(median_os_summary_weibull_total_exp[[3]]),
                         ") (adj. right & left) days",
                         sep=""),
           subtitle = paste(2, "-year rate ",
                            format(summary(traditional_fit, time = 2 * 365)$surv * 100,digits=3),
                            "% (unadj.)/",
                             format(summary(delayed_entry_fit, time = 2 * 365)$surv * 100,digits=3),
                             "% (risk adj.)/",
                            format(summary(simulation_fit_2, time = 2 * 365)$surv * 100,digits=3),
                            "% (adj. right & left), ",
                            "cKendall tau= ", format(independence_check$PE,digits=2),
                            ", SE= ", format(independence_check$SE,digits=2),
                            ", p= ", format(independence_check$p.value,digits=2), sep=""))
    
    # Survival analysis for mutation
    if(is.null(input$gene)){
      mut_gene = "TP53"
    } else{
      mut_gene = input$gene
    }
    ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode
    Data_survival = Data_survival %>% dplyr::mutate(
      mutation = case_when(
        C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ paste(mut_gene, collapse = ";"),
        TRUE ~ "no-mut"
      )
    )
    traditional_fit = survfit(Surv(event = censor,
                                   time = time_palliative_final) ~ mutation, 
                              data = Data_survival)
    if(length(Data_survival[,1]) != traditional_fit[[1]][[1]]){
      name_1 = paste("mutation", sort(unique(Data_survival$mutation))[[1]])
      name_2 = paste("mutation", sort(unique(Data_survival$mutation))[[2]])
      name_1_short = sort(unique(Data_survival$mutation))[[1]]
      name_2_short = sort(unique(Data_survival$mutation))[[2]]
      
      Data_survival$gene_select = Data_survival$mutation == sort(unique(Data_survival$mutation))[[2]]
      Data_survival_tmp_pos = Data_survival %>%
        dplyr::filter(gene_select == TRUE)
      
      Data_survival_tmp = Data_survival_tmp_pos
      Median_entry_pos = median(Data_survival_tmp$time_palliative_enroll)
            Data_survival_tmp_neg = Data_survival %>%
        dplyr::filter(gene_select == FALSE)
      
      Data_survival_tmp3 = Data_survival_tmp_neg
      Median_entry_neg = median(Data_survival_tmp3$time_palliative_enroll)
      Data_survival_tmp = rbind(Data_survival_tmp, Data_survival_tmp3)  
      
      Data_survival = Data_survival %>%
        dplyr::mutate(delay_1 = case_when(
          Data_survival$time_palliative_enroll <= Median_entry_pos &
            gene_select == TRUE ~ "SPT to entry early",
          Data_survival$time_palliative_enroll > Median_entry_pos &
            gene_select == TRUE ~ "SPT to entry later",
          Data_survival$time_palliative_enroll <= Median_entry_neg &
            gene_select == FALSE ~ "SPT to entry early",
          Data_survival$time_palliative_enroll > Median_entry_neg &
            gene_select == FALSE ~ "SPT to entry later"))
      
      if(sum((Data_survival %>% dplyr::filter(gene_select == TRUE & delay_1 == "SPT to entry later"))$censor) >= 1 &
         sum((Data_survival %>% dplyr::filter(gene_select == FALSE & delay_1 == "SPT to entry later"))$censor) >= 1 &
         sum((Data_survival %>% dplyr::filter(gene_select == TRUE & delay_1 != "SPT to entry later"))$censor) >= 1 &
         sum((Data_survival %>% dplyr::filter(gene_select == FALSE & delay_1 != "SPT to entry later"))$censor) >= 1){
        
        stan_weibull_survival_model_data <-
          list(
            Median_pos = as.integer(Median_entry_pos),
            Median_neg = as.integer(Median_entry_neg),
            Nobs = sum(Data_survival$censor == 1),
            Ncen = sum(Data_survival$censor == 0),
            Ntot = length(Data_survival$censor),
            M_bg = 2,
            Nexp = length(Data_survival_tmp$time_palliative_enroll),
            ybef_exp = Data_survival_tmp$time_palliative_enroll,
            xfactor = as.numeric(Data_survival_tmp$gene_select),
            yobs = Data_survival$time_enroll_final[Data_survival$censor == 1],
            ycen = Data_survival$time_enroll_final[Data_survival$censor == 0],
            Xobs_bg = matrix(c(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 1],
                               as.numeric(Data_survival$gene_select)[Data_survival$censor == 1]),ncol = 2),
            Xcen_bg = matrix(c(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 0],
                               as.numeric(Data_survival$gene_select)[Data_survival$censor == 0]),ncol = 2)
          )
        
        stan_weibull_survival_model_fit <-
          rstan::stan(file = "source/Stan_code_loglog_weibull_factor.stan",
                      data = stan_weibull_survival_model_data,
                      control=list(adapt_delta=0.99, max_treedepth = 10),
                      seed=1234, chains=4, iter=3000, warmup=1000, thin=1, refresh=500, verbose = FALSE,
                      pars = c("alpha","mu", "shape_exp", "scale_exp", "factor",
                               "yhat_total", "yhat_factor_total"))
        
       stan_weibull_survival_model_draws <- tidybayes::tidy_draws(stan_weibull_survival_model_fit)
        stan_weibull_survival_model_draws_total <-
          stan_weibull_survival_model_draws %>%
          dplyr::select(.chain, .iteration, .draw, starts_with("yhat_total")) %>%
          tidyr::gather(key = key, value = yhat_total, starts_with("yhat_total")) %>%
          dplyr::select(-key) 
        stan_weibull_survival_model_draws_total_exp <-
          stan_weibull_survival_model_draws %>%
          dplyr::select(.chain, .iteration, .draw, starts_with("yhat_factor_total")) %>%
          tidyr::gather(key = key, value = yhat_total_exp, starts_with("yhat_factor_total")) %>%
          dplyr::select(-key) 
        
        median_os_list_weibull_total_exp = matrix(stan_weibull_survival_model_draws_total_exp$yhat_total_exp, ncol=8000)
        median_os_list_weibull_total_exp = colMedians(median_os_list_weibull_total_exp,na.rm = T)
        
        median_os_list_weibull_total = matrix(stan_weibull_survival_model_draws_total$yhat_total, ncol=8000)
        median_os_list_weibull_total = colMedians(median_os_list_weibull_total,na.rm = T)
        
        median_os_list_weibull_bias = median_os_list_weibull_total - median_os_list_weibull_total_exp

        median_os_summary_weibull_total = quantile(median_os_list_weibull_total, probs = c(0.025, 0.5, 0.975))
        median_os_summary_weibull_total_exp = quantile(median_os_list_weibull_total_exp, probs = c(0.025, 0.5, 0.975))
        median_os_summary_weibull_bias = quantile(median_os_list_weibull_bias, probs = c(0.025, 0.5, 0.975))
        yhat_weibull_sort_total = sort(stan_weibull_survival_model_draws_total$yhat_total)
        yhat_weibull_sort_total_exp = sort(stan_weibull_survival_model_draws_total_exp$yhat_total_exp)
        yhat_weibull_sort_average_total = yhat_weibull_sort_total[1:length(Data_survival$censor) * 8000]
        yhat_weibull_sort_average_total_exp = yhat_weibull_sort_total_exp[1:length(Data_survival$censor) * 8000]
        
        Data_survival$factor_neg = yhat_weibull_sort_average_total
        Data_survival$factor_pos = yhat_weibull_sort_average_total_exp
        Data_survival$factor_neg[Data_survival$factor_neg > 10000] = 10000
        Data_survival$factor_pos[Data_survival$factor_pos > 10000] = 10000

        traditional_fit = survfit(Surv(event = censor,
                                       time = time_palliative_final) ~ gene_select,
                                  data = Data_survival)
        simulation_fit_neg = survfit(Surv(event = rep(1,length(Data_survival$factor_neg)),
                                          time = factor_neg) ~ 1, 
                                     data = Data_survival)
        simulation_fit_pos = survfit(Surv(event = rep(1,length(Data_survival$factor_pos)),
                                          time = factor_pos) ~ 1, 
                                     data = Data_survival)
        
        g[[2]] = ggsurvplot(
          fit = list(traditional_fit = traditional_fit,
                     simulation_fit_neg = simulation_fit_neg,
                     simulation_fit_pos = simulation_fit_pos),
          combine = TRUE,
          data = Data_survival,
          xlab = "Time from SPT to final observation (days)",
          ylab = "Survival Probability",
          censor = TRUE,
          font.title = 8,
          font.subtitle = 8,
          font.main = 8,
          font.submain = 8,
          font.caption = 8,
          font.legend = 8,
          surv.median.line = "hv",
          conf.int = FALSE,
          pval = FALSE,
          risk.table = TRUE,
          risk.table.y.text = FALSE,
          tables.theme = clean_theme(), 
          legend = c(0.8,0.8),
          xlim = c(0, max(Data_survival$time_palliative_final) * 1.05),
          break.x.by = ceiling(max(Data_survival$time_palliative_final) / 500) * 100,
          legend.labs = c(paste(name_1, ", Unadjusted"),
                          paste(name_2, ", Unadjusted"),
                          paste(name_1, ", Adjusted for Delayed Entry"),
                          paste(name_2, ", Adjusted for Delayed Entry"))
        ) +   
          labs(title = paste(sum(traditional_fit[[1]]), " patients ",
                             "Median OS ",
                             as.integer(summary(traditional_fit)[[18]][[13]])," (",
                             as.integer(summary(traditional_fit)[[18]][[15]]),"-",
                             as.integer(summary(traditional_fit)[[18]][[17]]),") (",
                             name_1_short,", unadj.)/",
                             as.integer(summary(traditional_fit)[[18]][[14]]), " (",
                             as.integer(summary(traditional_fit)[[18]][[16]]),"-",
                             as.integer(summary(traditional_fit)[[18]][[18]]),") (",
                             name_2_short,", unadj.)/",
                             as.integer(median_os_summary_weibull_total[[2]]), 
                             " (", as.integer(median_os_summary_weibull_total[[1]]), "-",
                             as.integer(median_os_summary_weibull_total[[3]]), ") (",
                             name_1_short,", adj.)/",
                             as.integer(median_os_summary_weibull_total_exp[[2]]), " (",
                             as.integer(median_os_summary_weibull_total_exp[[1]]), "-",
                             as.integer(median_os_summary_weibull_total_exp[[3]]),
                             ") (", name_2_short,", adj.) days",
                             sep=""),
               subtitle = paste("Survival difference, ",name_1_short, "-", name_2_short, ": ",
                                as.integer(median_os_summary_weibull_bias[[2]]), " (",
                                as.integer(median_os_summary_weibull_bias[[1]]), "-", 
                                as.integer(median_os_summary_weibull_bias[[3]]), 
                                ") days, median (95% CI)",
                                sep=""))
      }
    }
    
    # analysis for common oncogenic mutations
    h = list()
    hs=list()
    k = 1
    oncogenic_genes = Data_MAF_target %>%
      dplyr::select(Tumor_Sample_Barcode, Hugo_Symbol) %>%
      dplyr::distinct() %>%
      dplyr::count(Hugo_Symbol) %>%
      dplyr::arrange(-n)
    colnames(oncogenic_genes) = c("gene_mutation", "all_patients")
    oncogenic_genes = oncogenic_genes[1:min(length(oncogenic_genes$all_patients), input$gene_no),]
    
    gene_table = data.frame(oncogenic_genes$gene_mutation)
    colnames(gene_table) = c("Gene")
    gene_table$positive_patients = oncogenic_genes$all_patients
    gene_table$positive_freq = round(1000 * gene_table$positive_patients / length(Data_survival$C.CAT調査結果.基本項目.ハッシュID)) / 10
    gene_table$positive_median = 0
    gene_table$positive_LL = 0
    gene_table$positive_UL = 0
    gene_table$negative_median = 0
    gene_table$negative_LL = 0
    gene_table$negative_UL = 0
    gene_table$diff_median = 0
    gene_table$diff_LL = 0
    gene_table$diff_UL = 0
    gene_table$positive_mortal_event = 0
    gene_table$negative_mortal_event = 0
    for(i in 1:length(oncogenic_genes$all_patients)){
      ID_mutation = (Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% oncogenic_genes$gene_mutation[i]))$Tumor_Sample_Barcode
      Data_survival = Data_survival %>% dplyr::mutate(
        gene_select = case_when(
          C.CAT調査結果.基本項目.ハッシュID %in% ID_mutation ~ TRUE,
          TRUE ~ FALSE
        )
      )
      
      mut_gene = paste(oncogenic_genes$gene_mutation[i],
                       ", top ", i, " gene with oncogenic mut", sep="")
      traditional_fit = survfit(Surv(event = censor,
                                     time = time_palliative_final) ~ gene_select, 
                                data = Data_survival)
      if(length(Data_survival[,1]) != traditional_fit[[1]][[1]]){
        gene_table$negative_mortal_event[i] = summary(traditional_fit)[[18]][7]
        gene_table$positive_mortal_event[i] = summary(traditional_fit)[[18]][8]
        Data_survival_tmp_pos = Data_survival %>%
          dplyr::filter(gene_select == TRUE)
        
        Data_survival_tmp = Data_survival_tmp_pos
        Median_entry_pos = median(Data_survival_tmp$time_palliative_enroll)
        
        Data_survival_tmp_neg = Data_survival %>%
          dplyr::filter(gene_select == FALSE)
        
        Data_survival_tmp3 = Data_survival_tmp_neg

        Median_entry_neg = median(Data_survival_tmp3$time_palliative_enroll)
        Data_survival_tmp = rbind(Data_survival_tmp, Data_survival_tmp3)  
        
        Data_survival = Data_survival %>%
          dplyr::mutate(delay_1 = case_when(
            Data_survival$time_palliative_enroll <= Median_entry_pos &
              gene_select == TRUE ~ "SPT to entry early",
            Data_survival$time_palliative_enroll > Median_entry_pos &
              gene_select == TRUE ~ "SPT to entry later",
            Data_survival$time_palliative_enroll <= Median_entry_neg &
              gene_select == FALSE ~ "SPT to entry early",
            Data_survival$time_palliative_enroll > Median_entry_neg &
              gene_select == FALSE ~ "SPT to entry later"))
        
        if(sum((Data_survival %>% dplyr::filter(gene_select == TRUE & delay_1 == "SPT to entry later"))$censor) >= 1 &
           sum((Data_survival %>% dplyr::filter(gene_select == FALSE & delay_1 == "SPT to entry later"))$censor) >= 1 &
           sum((Data_survival %>% dplyr::filter(gene_select == TRUE & delay_1 != "SPT to entry later"))$censor) >= 1 &
           sum((Data_survival %>% dplyr::filter(gene_select == FALSE & delay_1 != "SPT to entry later"))$censor) >= 1){
          
          stan_weibull_survival_model_data <-
            list(
              Median_pos = as.integer(Median_entry_pos),
              Median_neg = as.integer(Median_entry_neg),
              Nobs = sum(Data_survival$censor == 1),
              Ncen = sum(Data_survival$censor == 0),
              Ntot = length(Data_survival$censor),
              M_bg = 2,
              Nexp = length(Data_survival_tmp$time_palliative_enroll),
              ybef_exp = Data_survival_tmp$time_palliative_enroll,
              xfactor = as.numeric(Data_survival_tmp$gene_select),
              yobs = Data_survival$time_enroll_final[Data_survival$censor == 1],
              ycen = Data_survival$time_enroll_final[Data_survival$censor == 0],
              Xobs_bg = matrix(c(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 1],
                                 as.numeric(Data_survival$gene_select)[Data_survival$censor == 1]),ncol = 2),
              Xcen_bg = matrix(c(as.numeric(Data_survival$delay_1 == "SPT to entry later")[Data_survival$censor == 0],
                                 as.numeric(Data_survival$gene_select)[Data_survival$censor == 0]),ncol = 2)
            )
          
          stan_weibull_survival_model_fit <-
            rstan::stan(file = "source/Stan_code_loglog_weibull_factor.stan",
                        data = stan_weibull_survival_model_data,
                        control=list(adapt_delta=0.99, max_treedepth = 10),
                        seed=1234, chains=4, iter=3000, warmup=1000, thin=1, refresh=500, verbose = FALSE,
                        pars = c("alpha","mu", "shape_exp", "scale_exp", "factor",
                                 "yhat_total", "yhat_factor_total"))
          stan_weibull_survival_model_draws <- tidybayes::tidy_draws(stan_weibull_survival_model_fit)
          stan_weibull_survival_model_draws_total <-
            stan_weibull_survival_model_draws %>%
            dplyr::select(.chain, .iteration, .draw, starts_with("yhat_total")) %>%
            tidyr::gather(key = key, value = yhat_total, starts_with("yhat_total")) %>%
            dplyr::select(-key) 
          stan_weibull_survival_model_draws_total_exp <-
            stan_weibull_survival_model_draws %>%
            dplyr::select(.chain, .iteration, .draw, starts_with("yhat_factor_total")) %>%
            tidyr::gather(key = key, value = yhat_total_exp, starts_with("yhat_factor_total")) %>%
            dplyr::select(-key) 
          
          median_os_list_weibull_total_exp = matrix(stan_weibull_survival_model_draws_total_exp$yhat_total_exp, ncol=8000)
          median_os_list_weibull_total_exp = colMedians(median_os_list_weibull_total_exp,na.rm = T)
          
          median_os_list_weibull_total = matrix(stan_weibull_survival_model_draws_total$yhat_total, ncol=8000)
          median_os_list_weibull_total = colMedians(median_os_list_weibull_total,na.rm = T)
          
          median_os_list_weibull_bias = median_os_list_weibull_total - median_os_list_weibull_total_exp
          
          
          median_os_summary_weibull_total = quantile(median_os_list_weibull_total, probs = c(0.025, 0.5, 0.975))
          median_os_summary_weibull_total_exp = quantile(median_os_list_weibull_total_exp, probs = c(0.025, 0.5, 0.975))
          median_os_summary_weibull_bias = quantile(median_os_list_weibull_bias, probs = c(0.025, 0.5, 0.975))
          yhat_weibull_sort_total = sort(stan_weibull_survival_model_draws_total$yhat_total)
          yhat_weibull_sort_total_exp = sort(stan_weibull_survival_model_draws_total_exp$yhat_total_exp)
          yhat_weibull_sort_average_total = yhat_weibull_sort_total[1:length(Data_survival$censor) * 8000]
          yhat_weibull_sort_average_total_exp = yhat_weibull_sort_total_exp[1:length(Data_survival$censor) * 8000]
          
          Data_survival$factor_neg = yhat_weibull_sort_average_total
          Data_survival$factor_pos = yhat_weibull_sort_average_total_exp
          Data_survival$factor_neg[Data_survival$factor_neg > 10000] = 10000
          Data_survival$factor_pos[Data_survival$factor_pos > 10000] = 10000
          
          traditional_fit = survfit(Surv(event = censor,
                                         time = time_palliative_final) ~ gene_select,
                                    data = Data_survival)
          simulation_fit_neg = survfit(Surv(event = rep(1,length(Data_survival$factor_neg)),
                                            time = factor_neg) ~ 1, 
                                       data = Data_survival)
          simulation_fit_pos = survfit(Surv(event = rep(1,length(Data_survival$factor_pos)),
                                            time = factor_pos) ~ 1, 
                                       data = Data_survival)
          hs[[k]] = ggsurvplot(
            fit = list(traditional_fit = traditional_fit,
                       simulation_fit_neg = simulation_fit_neg,
                       simulation_fit_pos = simulation_fit_pos),
            combine = TRUE,
            data = Data_survival,
            xlab = "Time from SPT to final observation (days)",
            ylab = "Survival Probability",
            censor = TRUE,
            surv.scale = "percent",
            font.title = 8,
            font.subtitle = 8,
            font.main = 8,
            font.submain = 8,
            font.caption = 8,
            font.legend = 8,
            surv.median.line = "v",
            palette = "Dark2",
            conf.int = FALSE,
            pval = FALSE,
            risk.table = TRUE,
            risk.table.y.text = FALSE,
            tables.theme = clean_theme(), 
            legend = c(0.8,0.8),
            xlim = c(0, max(Data_survival$time_palliative_final) * 1.05),
            break.x.by = ceiling(max(Data_survival$time_palliative_final) / 500) * 100,
            legend.labs = c(paste(mut_gene, "(-), Unadjusted"),
                            paste(mut_gene, "(+), Unadjusted"),
                            paste(mut_gene, "(-), Adjusted for Delayed Entry"),
                            paste(mut_gene, "(+), Adjusted for Delayed Entry"))
          ) +   
            labs(title = paste(sum(traditional_fit[[1]]), " patients ",
                               "Median OS ",
                               as.integer(summary(traditional_fit)[[18]][[13]])," (",
                               as.integer(summary(traditional_fit)[[18]][[15]]),"-",
                               as.integer(summary(traditional_fit)[[18]][[17]]),") (mut(-), unadj.)/",
                               as.integer(summary(traditional_fit)[[18]][[14]]), " (",
                               as.integer(summary(traditional_fit)[[18]][[16]]),"-",
                               as.integer(summary(traditional_fit)[[18]][[18]]),") (mut(+), unadj.)/\n",
                               as.integer(median_os_summary_weibull_total[[2]]), 
                               " (", as.integer(median_os_summary_weibull_total[[1]]), "-",
                               as.integer(median_os_summary_weibull_total[[3]]), ") (mut(-), adj.)/",
                               as.integer(median_os_summary_weibull_total_exp[[2]]), " (",
                               as.integer(median_os_summary_weibull_total_exp[[1]]), "-",
                               as.integer(median_os_summary_weibull_total_exp[[3]]),
                               ") (mut(+), adj.) days",
                               sep=""),
                 subtitle = paste("Survival difference with gene mutation: ",
                                  as.integer(median_os_summary_weibull_bias[[2]]), " (",
                                  as.integer(median_os_summary_weibull_bias[[1]]), "-", 
                                  as.integer(median_os_summary_weibull_bias[[3]]), 
                                  ") days, median (95% CI)",
                                  sep=""))
          k = k + 1
          gene_table$positive_median[i] = as.integer(median_os_summary_weibull_total_exp[[2]])
          gene_table$positive_LL[i] = as.integer(median_os_summary_weibull_total_exp[[1]])
          gene_table$positive_UL[i] = as.integer(median_os_summary_weibull_total_exp[[3]])
          gene_table$negative_median[i] = as.integer(median_os_summary_weibull_total[[2]])
          gene_table$negative_LL[i] = as.integer(median_os_summary_weibull_total[[1]])
          gene_table$negative_UL[i] = as.integer(median_os_summary_weibull_total[[3]])
          gene_table$diff_median[i] = -as.integer(median_os_summary_weibull_bias[[2]])
          gene_table$diff_LL[i] = -as.integer(median_os_summary_weibull_bias[[3]])
          gene_table$diff_UL[i] = -as.integer(median_os_summary_weibull_bias[[1]])
          
        }
      }
    }
    
    Gene_arrange = gene_table$Gene
    gene_table = gene_table %>% dplyr::mutate(
      Gene = factor(gene_table$Gene, levels = Gene_arrange))
    p <- 
      gene_table |>
      ggplot(aes(y = fct_rev(Gene))) + 
      theme_classic()
    p <- p +
      geom_point(aes(x=diff_median), shape=15, size=3) +
      geom_linerange(aes(xmin=diff_LL, xmax=diff_UL)) 
    p <- p +
      geom_vline(xintercept = 0, linetype="dashed") +
      labs(x="Survival difference by mutation", y="Genes with oncogenic alteration")
    p <- p +
      coord_cartesian(ylim=c(1,length(Gene_arrange) + 1), xlim=c(min(gene_table$diff_LL) - 15, max(gene_table$diff_UL) + 15))
    p <- p +
      annotate("text", x = min(gene_table$diff_LL)/2 - 15, y = length(Gene_arrange) + 1, label = "mut=short survival") +
      annotate("text", x = max(gene_table$diff_UL)/2 + 15, y = length(Gene_arrange) + 1, label = "mut=long survival")
    p_mid <- p + 
      theme(axis.line.y = element_blank(),
            axis.ticks.y= element_blank(),
            axis.text.y= element_blank(),
            axis.title.y= element_blank())
    
    gene_table <- gene_table %>%
      dplyr::mutate(
        estimate_lab = paste0(diff_median, " (", diff_LL, "-", diff_UL, ")")) %>%
      dplyr::mutate(
        patients = paste0(positive_patients, " (", positive_freq, "%)"))
    gene_table = 
      dplyr::bind_rows(
        data.frame(
          Gene = "Gene",
          estimate_lab = "Survival difference",
          patients = "Patients"
        ), gene_table  )
    Gene_arrange = gene_table$Gene
    gene_table = gene_table %>% dplyr::mutate(
      Gene = factor(gene_table$Gene, levels = Gene_arrange))
    
    p_left <- gene_table  %>% ggplot(aes(y = fct_rev(Gene)))
    p_left <- p_left + geom_text(aes(x = 0, label = Gene), hjust = 0,
                                 fontface = ifelse(gene_table$Gene == "Gene", "bold", "bold.italic"))
    p_left <- p_left + geom_text(aes(x = 1.4, label = estimate_lab), hjust = 0,
                                 fontface = ifelse(gene_table$estimate_lab == "Survival difference", "bold", "plain"))
    p_left <- p_left + theme_void() + coord_cartesian(xlim = c(0, 4))
    
    # right side of plot - pvalues
    p_right <- gene_table  |> ggplot() +
      geom_text(aes(x = 0, y = fct_rev(Gene), label = patients), hjust = 0,
                fontface = ifelse(gene_table$patients == "Patients", "bold", "plain")) +
      theme_void()
    
    # final plot arrangement
    layout <- c(area(t = 0, l = 0, b = 30, r = 4),
                area(t = 1, l = 4, b = 30, r = 9),
                area(t = 0, l = 9, b = 30, r = 11))
    h[[1]] = p_left + p_mid + p_right + plot_layout(design = layout)

    output$figure_survival_CTx_1 = renderPlot({
      arrange_ggsurvplots(g,print=TRUE,ncol=1,nrow=2)
    })
    
    output$figure_survival_CTx_2 = renderPlot({
      h[[1]]#arrange_ggsurvplots(g,print=TRUE,ncol=1,nrow=2)
    })
    output$figure_survival_CTx_3 = renderPlot({
      arrange_ggsurvplots(hs,print=TRUE,ncol=4,nrow=ceiling((k-1)/4))
    })
  })

  observeEvent(input$drug_table, {
      Data_case_target = Data_case() %>%
        dplyr::filter(
          症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
            症例.基本情報.性別.名称. %in% input$sex &
            症例.検体情報.パネル.名称. %in% input$panel &
            症例.背景情報.ECOG.PS.名称. %in% input$PS &
            症例.背景情報.喫煙歴有無.名称. %in% input$smoking
        )
      if(!all(input$age == c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                             max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
        Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
        Data_case_target = Data_case_target %>% dplyr::filter(
          症例.基本情報.年齢 >= input$age[1] &
            症例.基本情報.年齢 <= input$age[2]
        )
      }
      Data_case_target = Data_case_target %>% dplyr::mutate(YoungOld = case_when(
        症例.基本情報.年齢 <= input$mid_age ~ "Younger",
        TRUE ~ "Older"))
      Data_MAF = Data_report() %>%
        dplyr::filter(
          !str_detect(Hugo_Symbol, ",") &
            Hugo_Symbol != "" &
            Evidence_level %in% c("","A","B","C","D","E","F") &
            Variant_Classification != "expression"
        ) %>% 
        dplyr::arrange(desc(Evidence_level)) %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        Start_Position,
                        .keep_all = TRUE)
      Data_MAF$TMB = as.numeric(str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1])
      if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
        Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
      }
      if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
        Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
      }
      Data_report_TMB = Data_MAF %>%
        dplyr::filter(Hugo_Symbol == "TMB") %>%
        dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
        dplyr::arrange(Tumor_Sample_Barcode) %>%
        dplyr::mutate(Evidence_level = case_when(
          TMB < 10 ~ "",
          TMB >= 10 ~ "F",
          TRUE ~ ""
        ))
      Data_MAF = Data_MAF %>%
        dplyr::arrange(Tumor_Sample_Barcode) %>%
        dplyr::filter(Hugo_Symbol != "TMB")
      Data_MAF = rbind(Data_MAF, Data_report_TMB)
      
      Data_MAF_target = Data_MAF %>%
        dplyr::filter(Tumor_Sample_Barcode %in%
                        Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
      if(input$patho == "Only pathogenic muts"){
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(Evidence_level == "F")
      } else {
        Data_MAF_target = Data_MAF_target %>%
          dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
        
      }
      Data_MAF_target = Data_MAF_target  %>%
        dplyr::distinct(Tumor_Sample_Barcode,
                        Hugo_Symbol,
                        .keep_all = TRUE)
      
  if(length(Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.化学療法レジメン名称),]$症例.EP前レジメン情報.化学療法レジメン名称) != 0){
    Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.化学療法レジメン名称),]$症例.EP前レジメン情報.化学療法レジメン名称 = ""
  }
  if(length(Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.化学療法レジメン名称),]$症例.EP後レジメン情報.化学療法レジメン名称) != 0){
    Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.化学療法レジメン名称),]$症例.EP後レジメン情報.化学療法レジメン名称 = ""
  }
  if(length(Data_case_target[(Data_case_target$症例.EP前レジメン情報.最良総合効果.名称.)== "NoData",]$症例.EP前レジメン情報.最良総合効果.名称.) != 0){
    Data_case_target[(Data_case_target$症例.EP前レジメン情報.最良総合効果.名称.)== "NoData",]$症例.EP前レジメン情報.最良総合効果.名称. = "NE"}
  if(length(Data_case_target[(Data_case_target$症例.EP後レジメン情報.最良総合効果.名称.)== "NoData",]$症例.EP後レジメン情報.最良総合効果.名称.) != 0){
    Data_case_target[(Data_case_target$症例.EP後レジメン情報.最良総合効果.名称.)== "NoData",]$症例.EP後レジメン情報.最良総合効果.名称. = "NE"}
  
  Data_survival = Data_case_target %>%
    dplyr::mutate(final_observe = case_when(
      症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
      症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
      症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
      TRUE ~ 症例.管理情報.登録日))
  Data_survival = Data_survival %>%
    dplyr::arrange(desc(final_observe)) %>%
    dplyr::mutate(censor = case_when(
      症例.転帰情報.死亡日 != "" ~ 1,
      TRUE ~ 0)) %>%
    dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
  
  Data_survival = Data_survival %>%
    dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
    dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
  tmp1 = Data_survival %>%
    dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                    c("その他", "緩和")) %>%
    dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                  症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                  症例.EP前レジメン情報.化学療法レジメン名称,
                  症例.EP前レジメン情報.治療ライン.名称.,
                  症例.EP前レジメン情報.投与開始日,
                  症例.EP前レジメン情報.投与終了日,
                  症例.EP前レジメン情報.レジメン継続区分.名称.,
                  症例.管理情報.登録日,
                  症例.EP前レジメン情報.実施目的.名称.,
                  final_observe,
                  censor,
                  症例.EP前レジメン情報.終了理由.名称.,
                  症例.EP前レジメン情報.最良総合効果.名称.) %>%
    dplyr::distinct()
  tmp1 = tmp1 %>%
    dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                    as.Date(tmp1$症例.EP前レジメン情報.投与開始日)) %>%
    dplyr::mutate(症例.EP前レジメン情報.投与終了日 =
                    as.Date(tmp1$症例.EP前レジメン情報.投与終了日)) %>%
    dplyr::mutate(症例.管理情報.登録日 =
                    as.Date(tmp1$症例.管理情報.登録日))
  tmp1 = tmp1 %>%
    dplyr::mutate(Drug_length =
                    as.integer(difftime(tmp1$症例.EP前レジメン情報.投与終了日,
                                        tmp1$症例.EP前レジメン情報.投与開始日,
                                        units = "days")))
  colnames(tmp1) = c("ID",
                     "Drug",
                     "レジメン",
                     "治療ライン",
                     "投与開始日",
                     "投与終了日",
                     "Ongoing",
                     "登録日",
                     "実施目的",
                     "final_observe",
                     "censor",
                     "終了理由",
                     "最良総合効果",
                     "Drug_length")
  tmp1$TxCGP = "Pre"
  tmp2 = Data_survival %>%
    dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                  症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                  症例.EP後レジメン情報.化学療法レジメン名称,
                  症例.EP後レジメン情報.治療ライン.名称.,
                  症例.EP後レジメン情報.投与開始日,
                  症例.EP後レジメン情報.投与終了日,
                  症例.EP後レジメン情報.レジメン継続区分.名称.,
                  症例.管理情報.登録日,
                  症例.EP前レジメン情報.実施目的.名称.,
                  final_observe,
                  censor,
                  症例.EP後レジメン情報.終了理由.名称.,
                  症例.EP後レジメン情報.最良総合効果.名称.) %>%
    dplyr::distinct()
  tmp2$症例.EP前レジメン情報.実施目的.名称. = "緩和"
  tmp2 = tmp2 %>%
    dplyr::mutate(症例.EP後レジメン情報.投与開始日 =
                    as.Date(tmp2$症例.EP後レジメン情報.投与開始日)) %>%
    dplyr::mutate(症例.EP後レジメン情報.投与終了日 =
                    as.Date(tmp2$症例.EP後レジメン情報.投与終了日)) %>%
    dplyr::mutate(症例.管理情報.登録日 =
                    as.Date(tmp2$症例.管理情報.登録日))
  
  tmp2 = tmp2 %>%
    dplyr::mutate(Drug_length =
                    as.integer(difftime(tmp2$症例.EP後レジメン情報.投与終了日,
                                        tmp2$症例.EP後レジメン情報.投与開始日,
                                        units = "days")))
  colnames(tmp2) = c("ID",
                     "Drug",
                     "レジメン",
                     "治療ライン",
                     "投与開始日",
                     "投与終了日",
                     "Ongoing",
                     "登録日",
                     "実施目的",
                     "final_observe",
                     "censor",
                     "終了理由",
                     "最良総合効果",
                     "Drug_length")
  tmp2$TxCGP = "Post"
  Data_drug = rbind(tmp1, tmp2)
  
  if(!is.null(input$ID_drug)){
    Data_drug = data.frame(NULL)
    for(i in 1:length(input$ID_drug[,1])){
      tmp = read.csv(header = TRUE, file(input$ID_drug[[i, 'datapath']],
                               encoding='UTF-8-BOM'))
      if("症例.EP前レジメン情報.投与開始日" %in% colnames(tmp)){
        colnames(tmp) = c("ID",
                           "登録日",
                           "治療ライン",
                           "実施目的",
                           "レジメン",
                           "Drug",
                           "投与開始日",
                           "投与終了日",
                           "Ongoing",
                           "終了理由",
                           "最良総合効果",
                           "最終生存確認日",
                           "死亡日")
        tmp = tmp %>%
          dplyr::mutate(
            Drug_length = as.integer(difftime(tmp$投与終了日,
                                              tmp$投与開始日,
                                              units = "days")),
            censor = case_when(
              死亡日 != "" ~ 1,
              TRUE ~ 0
            ),
            final_observe = case_when(
              最終生存確認日 == "           " ~ 死亡日,
              最終生存確認日 != "" ~ 最終生存確認日,
              死亡日 != "" ~ 死亡日,
              TRUE ~ 登録日)
          )
        tmp = tmp %>%
          dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
          dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
        tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
        tmp$TxCGP = "Pre"
      } else{
        colnames(tmp) = c("ID",
                          "登録日",
                          "治療ライン",
                          "レジメン",
                          "Drug",
                          "投与開始日",
                          "投与終了日",
                          "Ongoing",
                          "終了理由",
                          "最良総合効果",
                          "最終生存確認日",
                          "死亡日")
        tmp = tmp %>%
          dplyr::mutate(
            Drug_length = as.integer(difftime(tmp$投与終了日,
                                              tmp$投与開始日,
                                              units = "days")),
            censor = case_when(
              死亡日 != "" ~ 1,
              TRUE ~ 0
            ),
            final_observe = case_when(
              最終生存確認日 == "           " ~ 死亡日,
              最終生存確認日 != "" ~ 最終生存確認日,
              死亡日 != "" ~ 死亡日,
              TRUE ~ 登録日)
          )
        tmp = tmp %>%
          dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
          dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
        tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
        tmp$実施目的 = "緩和"
        tmp$TxCGP = "Post"
      }
      Data_drug = rbind(Data_drug, tmp)
    }
  }
  
  
  Data_drug = Data_drug %>%
    dplyr::mutate(final_observe =
                    as.Date(Data_drug$final_observe))
  Data_drug = Data_drug %>%
    dplyr::arrange(投与開始日) %>%
    dplyr::arrange(治療ライン) %>%
    dplyr::arrange(ID)
  
  Data_drug = Data_drug %>% dplyr::mutate(RECIST = case_when(
    最良総合効果 == "CR" ~ "5",
    最良総合効果 == "PR" ~ "4",
    最良総合効果 == "SD" ~ "3",
    最良総合効果 == "PD" ~ "2",
    最良総合効果 == "NE" ~ "1",
    最良総合効果 == "NoData" ~ "0",
    TRUE ~ "0"
  ))
  Data_drug = Data_drug %>%
    dplyr::filter(治療ライン %in% c("１次治療","２次治療","３次治療","４次治療"))

  Data_drug_Start = (Data_drug %>%
                       dplyr::arrange(投与開始日) %>%
                       dplyr::arrange(ID,desc(レジメン),治療ライン,実施目的) %>%
                       dplyr::distinct(ID,レジメン,治療ライン,実施目的, .keep_all = T)) %>%
                       dplyr::select(ID,レジメン,治療ライン,実施目的, 投与開始日)
  Data_drug_End = (Data_drug %>%
                       dplyr::arrange(desc(投与終了日)) %>%
                       dplyr::arrange(ID,desc(レジメン),治療ライン,実施目的) %>%
                       dplyr::distinct(ID,レジメン,治療ライン,実施目的, .keep_all = T)) %>%
                       dplyr::select(ID,レジメン,治療ライン,実施目的, 投与終了日)
  Data_drug_RECIST = (Data_drug %>%
                     dplyr::arrange(desc(RECIST)) %>%
                     dplyr::arrange(ID,desc(レジメン),治療ライン,実施目的) %>%
                     dplyr::distinct(ID,レジメン,治療ライン,実施目的, .keep_all = T)) %>%
                     dplyr::select(ID,レジメン,治療ライン,実施目的, RECIST)
  Data_drug_Ongoing = (Data_drug %>%
                        dplyr::arrange(desc(Ongoing)) %>%
                        dplyr::arrange(ID,desc(レジメン),治療ライン,実施目的) %>%
                        dplyr::distinct(ID,レジメン,治療ライン,実施目的, .keep_all = T)) %>%
                        dplyr::select(ID,レジメン,治療ライン,実施目的, Ongoing)
  Data_drug_Ongoing$Drug = ""
  for(samples in 1:length(Data_drug_Ongoing$ID)){
    tmp = sort(unique(str_split(Data_drug[Data_drug$ID == Data_drug_Ongoing$ID[samples] &
                                          Data_drug$レジメン == Data_drug_Ongoing$レジメン[samples] &
                                          Data_drug$治療ライン == Data_drug_Ongoing$治療ライン[samples] &
                                          Data_drug$実施目的 == Data_drug_Ongoing$実施目的[samples],]$Drug, ",", simplify = T)[,1]))
    if("" %in% tmp){
      tmp = tmp[tmp != ""]
    }
    Data_drug_Ongoing$Drug[samples] = paste0(tmp, collapse = ",")
  }
  if(length(Data_drug_Ongoing[Data_drug_Ongoing$Drug == "",]$Drug)>0){
    Data_drug_Ongoing$Drug[Data_drug_Ongoing$Drug == ""] = "NoData"
  }

  if(length(Data_drug_Start[is.na(Data_drug_Start$投与開始日),]$投与開始日)>0){
    Data_drug_Start[is.na(Data_drug_Start$投与開始日),]$投与開始日 <- -Inf
  }
  if(length(Data_drug_End[is.na(Data_drug_End$投与終了日),]$投与終了日)>0){
    Data_drug_End[is.na(Data_drug_End$投与終了日),]$投与終了日 <- -Inf
  }

  Data_drug = Data_drug %>% dplyr::select(-投与開始日, -投与終了日, -RECIST, -Ongoing, -Drug)
  Data_drug = left_join(Data_drug, Data_drug_Start, by = c('ID','レジメン','治療ライン','実施目的'))
  Data_drug = left_join(Data_drug, Data_drug_End, by = c('ID','レジメン','治療ライン','実施目的'))
  Data_drug = left_join(Data_drug, Data_drug_RECIST, by = c('ID','レジメン','治療ライン','実施目的'))
  Data_drug = left_join(Data_drug, Data_drug_Ongoing, by = c('ID','レジメン','治療ライン','実施目的'))
  Data_drug = Data_drug %>%
    dplyr::arrange(desc(レジメン), desc(実施目的)) %>%
    dplyr::distinct(ID,治療ライン, .keep_all = T)
  
  Data_drug = Data_drug %>% dplyr::mutate(TTF_censor = case_when(
    投与終了日 < 0 & Ongoing == "継続中" & TxCGP =="Pre" ~ 0,
    TRUE ~ 1
  ))
  Data_drug = Data_drug %>% dplyr::mutate(投与終了日 = case_when(
    投与終了日 < 0 & Ongoing == "継続中" & TxCGP =="Pre" ~ 登録日,
    TRUE ~ 投与終了日
  ))
  Data_drug = Data_drug %>% dplyr::filter(投与開始日 >=0 & 投与終了日 >= 0)
  Data_drug = Data_drug %>%
    dplyr::mutate(Drug_length = Data_drug$投与終了日 - Data_drug$投与開始日)
  Data_drug = Data_drug %>% dplyr::filter(Drug_length>0 & !is.na(Drug_length) & is.finite(Drug_length))
  
  Data_drug = Data_drug %>% dplyr::mutate(最良総合効果 = case_when(
    RECIST == "5" ~ "CR",
    RECIST == "4" ~ "PR",
    RECIST == "3" ~ "SD",
    RECIST == "2" ~ "PD",
    RECIST == "1" ~ "NE",
    RECIST == "0" ~ "NE",
    TRUE ~ "NE"
  ))
  

  Data_drug = Data_drug %>%
    dplyr::mutate(Effect_OR = case_when(
      最良総合効果 %in% c("CR", "PR") ~ 1,
      TRUE ~ 0
    ))
  Data_drug = Data_drug %>%
      dplyr::mutate(Effect_DC = case_when(
        最良総合効果 %in% c("CR", "PR", "SD") ~ 1,
        TRUE ~ 0
    ))

  Data_drug$治療ライン = as.character(Data_drug$治療ライン)
  Drug_summary =  Data_drug %>%
    dplyr::select(
      Drug,
      治療ライン,
      最良総合効果,
      終了理由,
      Drug_length,
      TTF_censor,
    )
    colnames(Drug_summary)=
      c("治療薬", "治療ライン", "RECIST", "終了理由", "Time on treatment", "打ち切り0,終了1")
    Drug_summary$終了理由[Drug_summary$終了理由 == ""] = "入力なし"
    
    output$table_drug <- render_gt({
      Drug_summary %>%
        tbl_summary(    statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                              "{mean} ({sd})",
                                                              "{median} ({p25}, {p75})", 
                                                              "{min}, {max}"),
                                         all_categorical() ~ "{n} / {N} ({p}%)"),
                        type = all_continuous() ~ "continuous2",
                        digits = all_continuous() ~ 2,
                        missing = "ifany") %>%
        modify_caption("**Palliative CTx with treatment duration information, 1st-4th lines**") %>%
        bold_labels() %>% as_gt()
    })
    output$select_drug = renderUI({ 
      pickerInput("drug", "Select regimens of interest",
                  choices = sort(unique(Drug_summary$治療薬)), 
                  selected = names(sort(table(Drug_summary$治療薬), decreasing = TRUE))[[1]], multiple = TRUE)
    })
  })

  observeEvent(input$drug_analysis, {
    Data_case_target = Data_case() %>%
      dplyr::filter(
        症例.基本情報.がん種.OncoTree..名称. %in% input$histology &
          症例.基本情報.性別.名称. %in% input$sex &
          症例.検体情報.パネル.名称. %in% input$panel &
          症例.背景情報.ECOG.PS.名称. %in% input$PS &
          症例.背景情報.喫煙歴有無.名称. %in% input$smoking
      )
    if(!all(input$age == c(min(Data_case_target$症例.基本情報.年齢, na.rm = TRUE),
                           max(Data_case_target$症例.基本情報.年齢, na.rm = TRUE)))){
      Data_case_target$症例.基本情報.年齢 = tidyr::replace_na(Data_case_target$症例.基本情報.年齢, -1) 
      Data_case_target = Data_case_target %>% dplyr::filter(
        症例.基本情報.年齢 >= input$age[1] &
          症例.基本情報.年齢 <= input$age[2]
      )
    }
    Data_case_target = Data_case_target %>% dplyr::mutate(YoungOld = case_when(
      症例.基本情報.年齢 <= input$mid_age ~ "Younger",
      TRUE ~ "Older"))
    Data_MAF = Data_report() %>%
      dplyr::filter(
        !str_detect(Hugo_Symbol, ",") &
          Hugo_Symbol != "" &
          Evidence_level %in% c("","A","B","C","D","E","F") &
          Variant_Classification != "expression"
      ) %>% 
      dplyr::arrange(desc(Evidence_level)) %>%
      dplyr::distinct(Tumor_Sample_Barcode,
                      Hugo_Symbol,
                      Start_Position,
                      .keep_all = TRUE)
    Data_MAF$TMB = as.numeric(str_split(Data_MAF$TMB, "Muts", simplify = TRUE)[,1])
    if(length(Data_MAF[is.na(Data_MAF$TMB),]$TMB) > 0){
      Data_MAF[is.na(Data_MAF$TMB),]$TMB = 0
    }
    if(length(Data_MAF[Data_MAF$TMB > 30,]$TMB) > 0){
      Data_MAF[Data_MAF$TMB > 30,]$TMB = 30
    }
    Data_report_TMB = Data_MAF %>%
      dplyr::filter(Hugo_Symbol == "TMB") %>%
      dplyr::distinct(Tumor_Sample_Barcode, TMB, .keep_all = T) %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::mutate(Evidence_level = case_when(
        TMB < 10 ~ "",
        TMB >= 10 ~ "F",
        TRUE ~ ""
      ))
    Data_MAF = Data_MAF %>%
      dplyr::arrange(Tumor_Sample_Barcode) %>%
      dplyr::filter(Hugo_Symbol != "TMB")
    Data_MAF = rbind(Data_MAF, Data_report_TMB)
    
    Data_MAF_target = Data_MAF %>%
      dplyr::filter(Tumor_Sample_Barcode %in%
                      Data_case_target$C.CAT調査結果.基本項目.ハッシュID)
    if(input$patho == "Only pathogenic muts"){
      Data_MAF_target = Data_MAF_target %>%
        dplyr::filter(Evidence_level == "F")
    } else {
      Data_MAF_target = Data_MAF_target %>%
        dplyr::filter(!Hugo_Symbol %in% c("TMB", "MSI") | Evidence_level == "F")
      
    }
    Data_MAF_target = Data_MAF_target  %>%
      dplyr::distinct(Tumor_Sample_Barcode,
                      Hugo_Symbol,
                      .keep_all = TRUE)
    
    if(length(Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.化学療法レジメン名称),]$症例.EP前レジメン情報.化学療法レジメン名称) != 0){
      Data_case_target[is.na(Data_case_target$症例.EP前レジメン情報.化学療法レジメン名称),]$症例.EP前レジメン情報.化学療法レジメン名称 = ""
    }
    if(length(Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.化学療法レジメン名称),]$症例.EP後レジメン情報.化学療法レジメン名称) != 0){
      Data_case_target[is.na(Data_case_target$症例.EP後レジメン情報.化学療法レジメン名称),]$症例.EP後レジメン情報.化学療法レジメン名称 = ""
    }
    if(length(Data_case_target[(Data_case_target$症例.EP前レジメン情報.最良総合効果.名称.)== "NoData",]$症例.EP前レジメン情報.最良総合効果.名称.) != 0){
      Data_case_target[(Data_case_target$症例.EP前レジメン情報.最良総合効果.名称.)== "NoData",]$症例.EP前レジメン情報.最良総合効果.名称. = "NE"}
    if(length(Data_case_target[(Data_case_target$症例.EP後レジメン情報.最良総合効果.名称.)== "NoData",]$症例.EP後レジメン情報.最良総合効果.名称.) != 0){
      Data_case_target[(Data_case_target$症例.EP後レジメン情報.最良総合効果.名称.)== "NoData",]$症例.EP後レジメン情報.最良総合効果.名称. = "NE"}
    
    Data_survival = Data_case_target %>%
      dplyr::mutate(final_observe = case_when(
        症例.転帰情報.最終生存確認日 == "           " ~ 症例.転帰情報.死亡日,
        症例.転帰情報.最終生存確認日 != "" ~ 症例.転帰情報.最終生存確認日,
        症例.転帰情報.死亡日 != "" ~ 症例.転帰情報.死亡日,
        TRUE ~ 症例.管理情報.登録日))
    Data_survival = Data_survival %>%
      dplyr::arrange(desc(final_observe)) %>%
      dplyr::mutate(censor = case_when(
        症例.転帰情報.死亡日 != "" ~ 1,
        TRUE ~ 0)) %>%
      dplyr::arrange(C.CAT調査結果.基本項目.ハッシュID)
    
    Data_survival = Data_survival %>%
      dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
      dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
    tmp1 = Data_survival %>%
      dplyr::filter(症例.EP前レジメン情報.実施目的.名称. %in%
                      c("その他", "緩和")) %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                    症例.EP前レジメン情報.薬剤名.YJ一般名.EN.,
                    症例.EP前レジメン情報.化学療法レジメン名称,
                    症例.EP前レジメン情報.治療ライン.名称.,
                    症例.EP前レジメン情報.投与開始日,
                    症例.EP前レジメン情報.投与終了日,
                    症例.EP前レジメン情報.レジメン継続区分.名称.,
                    症例.管理情報.登録日,
                    症例.EP前レジメン情報.実施目的.名称.,
                    final_observe,
                    censor,
                    症例.EP前レジメン情報.終了理由.名称.,
                    症例.EP前レジメン情報.最良総合効果.名称.) %>%
      dplyr::distinct()
    tmp1 = tmp1 %>%
      dplyr::mutate(症例.EP前レジメン情報.投与開始日 =
                      as.Date(tmp1$症例.EP前レジメン情報.投与開始日)) %>%
      dplyr::mutate(症例.EP前レジメン情報.投与終了日 =
                      as.Date(tmp1$症例.EP前レジメン情報.投与終了日)) %>%
      dplyr::mutate(症例.管理情報.登録日 =
                      as.Date(tmp1$症例.管理情報.登録日))
    tmp1 = tmp1 %>%
      dplyr::mutate(Drug_length =
                      as.integer(difftime(tmp1$症例.EP前レジメン情報.投与終了日,
                                          tmp1$症例.EP前レジメン情報.投与開始日,
                                          units = "days")))
    colnames(tmp1) = c("ID",
                       "Drug",
                       "レジメン",
                       "治療ライン",
                       "投与開始日",
                       "投与終了日",
                       "Ongoing",
                       "登録日",
                       "実施目的",
                       "final_observe",
                       "censor",
                       "終了理由",
                       "最良総合効果",
                       "Drug_length")
    tmp1$TxCGP = "Pre"
    tmp2 = Data_survival %>%
      dplyr::select(C.CAT調査結果.基本項目.ハッシュID, 
                    症例.EP後レジメン情報.薬剤名.YJ一般名.EN.,
                    症例.EP後レジメン情報.化学療法レジメン名称,
                    症例.EP後レジメン情報.治療ライン.名称.,
                    症例.EP後レジメン情報.投与開始日,
                    症例.EP後レジメン情報.投与終了日,
                    症例.EP後レジメン情報.レジメン継続区分.名称.,
                    症例.管理情報.登録日,
                    症例.EP前レジメン情報.実施目的.名称.,
                    final_observe,
                    censor,
                    症例.EP後レジメン情報.終了理由.名称.,
                    症例.EP後レジメン情報.最良総合効果.名称.) %>%
      dplyr::distinct()
    tmp2$症例.EP前レジメン情報.実施目的.名称. = "緩和"
    tmp2 = tmp2 %>%
      dplyr::mutate(症例.EP後レジメン情報.投与開始日 =
                      as.Date(tmp2$症例.EP後レジメン情報.投与開始日)) %>%
      dplyr::mutate(症例.EP後レジメン情報.投与終了日 =
                      as.Date(tmp2$症例.EP後レジメン情報.投与終了日)) %>%
      dplyr::mutate(症例.管理情報.登録日 =
                      as.Date(tmp2$症例.管理情報.登録日))
    
    tmp2 = tmp2 %>%
      dplyr::mutate(Drug_length =
                      as.integer(difftime(tmp2$症例.EP後レジメン情報.投与終了日,
                                          tmp2$症例.EP後レジメン情報.投与開始日,
                                          units = "days")))
    colnames(tmp2) = c("ID",
                       "Drug",
                       "レジメン",
                       "治療ライン",
                       "投与開始日",
                       "投与終了日",
                       "Ongoing",
                       "登録日",
                       "実施目的",
                       "final_observe",
                       "censor",
                       "終了理由",
                       "最良総合効果",
                       "Drug_length")
    tmp2$TxCGP = "Post"
    Data_drug = rbind(tmp1, tmp2)
    if(!is.null(input$ID_drug)){
      Data_drug = data.frame(NULL)
      for(i in 1:length(input$ID_drug[,1])){
        tmp = read.csv(header = TRUE, file(input$ID_drug[[i, 'datapath']],
                                           encoding='UTF-8-BOM'))
        if("症例.EP前レジメン情報.投与開始日" %in% colnames(tmp)){
          colnames(tmp) = c("ID",
                            "登録日",
                            "治療ライン",
                            "実施目的",
                            "レジメン",
                            "Drug",
                            "投与開始日",
                            "投与終了日",
                            "Ongoing",
                            "終了理由",
                            "最良総合効果",
                            "最終生存確認日",
                            "死亡日")
          tmp = tmp %>%
            dplyr::mutate(
              Drug_length = as.integer(difftime(tmp$投与終了日,
                                                tmp$投与開始日,
                                                units = "days")),
              censor = case_when(
                死亡日 != "" ~ 1,
                TRUE ~ 0
              ),
              final_observe = case_when(
                最終生存確認日 == "           " ~ 死亡日,
                最終生存確認日 != "" ~ 最終生存確認日,
                死亡日 != "" ~ 死亡日,
                TRUE ~ 登録日)
            )
          tmp = tmp %>%
            dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
            dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
          tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
          tmp$TxCGP = "Pre"
        } else{
          colnames(tmp) = c("ID",
                            "登録日",
                            "治療ライン",
                            "レジメン",
                            "Drug",
                            "投与開始日",
                            "投与終了日",
                            "Ongoing",
                            "終了理由",
                            "最良総合効果",
                            "最終生存確認日",
                            "死亡日")
          tmp = tmp %>%
            dplyr::mutate(
              Drug_length = as.integer(difftime(tmp$投与終了日,
                                                tmp$投与開始日,
                                                units = "days")),
              censor = case_when(
                死亡日 != "" ~ 1,
                TRUE ~ 0
              ),
              final_observe = case_when(
                最終生存確認日 == "           " ~ 死亡日,
                最終生存確認日 != "" ~ 最終生存確認日,
                死亡日 != "" ~ 死亡日,
                TRUE ~ 登録日)
            )
          tmp = tmp %>%
            dplyr::mutate(censor = ifelse(is.na(censor), 0, censor)) %>%
            dplyr::mutate(final_observe = ifelse(is.na(final_observe), 症例.管理情報.登録日, final_observe))
          tmp = tmp %>% dplyr::select(-最終生存確認日, -死亡日)
          tmp$実施目的 = "緩和"
          tmp$TxCGP = "Post"
        }
        Data_drug = rbind(Data_drug, tmp)
      }
    }
    
    Data_drug = Data_drug %>%
      dplyr::mutate(final_observe =
                      as.Date(Data_drug$final_observe))
    Data_drug = Data_drug %>%
      dplyr::arrange(ID,治療ライン,投与開始日)
    
    Data_drug = Data_drug %>% dplyr::mutate(RECIST = case_when(
      最良総合効果 == "CR" ~ "5",
      最良総合効果 == "PR" ~ "4",
      最良総合効果 == "SD" ~ "3",
      最良総合効果 == "PD" ~ "2",
      最良総合効果 == "NE" ~ "1",
      最良総合効果 == "NoData" ~ "0",
      TRUE ~ "0"
    ))
    Data_drug = Data_drug %>%
      dplyr::filter(治療ライン %in% c("１次治療","２次治療","３次治療","４次治療"))
    
    Data_drug_Start = (Data_drug %>%
                         dplyr::arrange(投与開始日) %>%
                         dplyr::arrange(ID,desc(レジメン),治療ライン,実施目的) %>%
                         dplyr::distinct(ID,レジメン,治療ライン,実施目的, .keep_all = T)) %>%
      dplyr::select(ID,レジメン,治療ライン,実施目的, 投与開始日)
    Data_drug_End = (Data_drug %>%
                       dplyr::arrange(desc(投与終了日)) %>%
                       dplyr::arrange(ID,desc(レジメン),治療ライン,実施目的) %>%
                       dplyr::distinct(ID,レジメン,治療ライン,実施目的, .keep_all = T)) %>%
      dplyr::select(ID,レジメン,治療ライン,実施目的, 投与終了日)
    Data_drug_RECIST = (Data_drug %>%
                          dplyr::arrange(desc(RECIST)) %>%
                          dplyr::arrange(ID,desc(レジメン),治療ライン,実施目的) %>%
                          dplyr::distinct(ID,レジメン,治療ライン,実施目的, .keep_all = T)) %>%
      dplyr::select(ID,レジメン,治療ライン,実施目的, RECIST)
    Data_drug_Ongoing = (Data_drug %>%
                           dplyr::arrange(desc(Ongoing)) %>%
                           dplyr::arrange(ID,desc(レジメン),治療ライン,実施目的) %>%
                           dplyr::distinct(ID,レジメン,治療ライン,実施目的, .keep_all = T)) %>%
      dplyr::select(ID,レジメン,治療ライン,実施目的, Ongoing)
    Data_drug_Ongoing$Drug = ""
    for(samples in 1:length(Data_drug_Ongoing$ID)){
      tmp = sort(unique(str_split(Data_drug[Data_drug$ID == Data_drug_Ongoing$ID[samples] &
                                              Data_drug$レジメン == Data_drug_Ongoing$レジメン[samples] &
                                              Data_drug$治療ライン == Data_drug_Ongoing$治療ライン[samples] &
                                              Data_drug$実施目的 == Data_drug_Ongoing$実施目的[samples],]$Drug, ",", simplify = T)[,1]))
      if("" %in% tmp){
        tmp = tmp[tmp != ""]
      }
      Data_drug_Ongoing$Drug[samples] = paste0(tmp, collapse = ",")
    }
    if(length(Data_drug_Ongoing[Data_drug_Ongoing$Drug == "",]$Drug)>0){
      Data_drug_Ongoing$Drug[Data_drug_Ongoing$Drug == ""] = "NoData"
    }
    
    if(length(Data_drug_Start[is.na(Data_drug_Start$投与開始日),]$投与開始日)>0){
      Data_drug_Start[is.na(Data_drug_Start$投与開始日),]$投与開始日 <- -Inf
    }
    if(length(Data_drug_End[is.na(Data_drug_End$投与終了日),]$投与終了日)>0){
      Data_drug_End[is.na(Data_drug_End$投与終了日),]$投与終了日 <- -Inf
    }
    
    Data_drug = Data_drug %>% dplyr::select(-投与開始日, -投与終了日, -RECIST, -Ongoing, -Drug)
    Data_drug = left_join(Data_drug, Data_drug_Start, by = c('ID','レジメン','治療ライン','実施目的'))
    Data_drug = left_join(Data_drug, Data_drug_End, by = c('ID','レジメン','治療ライン','実施目的'))
    Data_drug = left_join(Data_drug, Data_drug_RECIST, by = c('ID','レジメン','治療ライン','実施目的'))
    Data_drug = left_join(Data_drug, Data_drug_Ongoing, by = c('ID','レジメン','治療ライン','実施目的'))
    Data_drug = Data_drug %>%
      dplyr::arrange(ID, desc(レジメン), desc(実施目的)) %>%
      dplyr::distinct(ID, 治療ライン, .keep_all = T)
    
    Data_drug = Data_drug %>% dplyr::mutate(TTF_censor = case_when(
      is.infinite(投与終了日) & Ongoing == "継続中" & TxCGP =="Pre" ~ 0,
      TRUE ~ 1
    ))
    Data_drug = Data_drug %>% dplyr::mutate(投与終了日 = case_when(
      is.infinite(投与終了日) & Ongoing == "継続中" & TxCGP =="Pre" ~ 登録日,
      TRUE ~ 投与終了日
    ))
    Data_drug = Data_drug %>% dplyr::filter(投与開始日 >=0 & 投与終了日 >= 0)
    Data_drug = Data_drug %>%
      dplyr::mutate(Drug_length = 投与終了日 - 投与開始日)
    Data_drug = Data_drug %>% dplyr::filter(Drug_length>0 & !is.na(Drug_length) & is.finite(Drug_length))
    Data_drug$治療ライン = as.character(Data_drug$治療ライン)
    Data_drug = Data_drug %>%
      dplyr::arrange(ID, 治療ライン)
    
    Data_drug$TTF_pre_censor = -1
    Data_drug$TTF_pre = -1
    Data_drug$TTF_post = -1
    if(Data_drug[1,]$ID == Data_drug[2,]$ID){
      Data_drug[1,]$TTF_post = Data_drug[2,]$Drug_length
    }
    for(tx in 2:(length(Data_drug$ID) - 1)){
      if(Data_drug[tx,]$ID == Data_drug[tx-1,]$ID){
        Data_drug[tx,]$TTF_pre = Data_drug[tx-1,]$Drug_length
        Data_drug[tx,]$TTF_pre_censor = Data_drug[tx-1,]$TTF_censor
      }
      if(Data_drug[tx,]$ID == Data_drug[tx+1,]$ID){
        Data_drug[tx,]$TTF_post = Data_drug[tx+1,]$Drug_length
      }
    }
    if(Data_drug[length(Data_drug$ID),]$ID == Data_drug[length(Data_drug$ID) - 1,]$ID){
      Data_drug[length(Data_drug$ID),]$TTF_pre = Data_drug[length(Data_drug$ID) - 1,]$Drug_length
      Data_drug[length(Data_drug$ID),]$TTF_pre_censor = Data_drug[length(Data_drug$ID) - 1,]$TTF_censor
    }
    
    Data_drug = Data_drug %>% dplyr::mutate(最良総合効果 = case_when(
      最良総合効果 == "5" ~ "CR",
      最良総合効果 == "4" ~ "PR",
      最良総合効果 == "3" ~ "SD",
      最良総合効果 == "2" ~ "PD",
      最良総合効果 == "1" ~ "NE",
      最良総合効果 == "0" ~ "NoData",
      TRUE ~ 最良総合効果
    ))
    
    Data_drug = Data_drug %>%
      dplyr::mutate(Effect_OR = case_when(
        最良総合効果 %in% c("CR", "PR") ~ 1,
        TRUE ~ 0
      ))
    Data_drug = Data_drug %>%
      dplyr::mutate(Effect_DC = case_when(
        最良総合効果 %in% c("CR", "PR", "SD") ~ 1,
        TRUE ~ 0
      ))
    
    Data_drug$serial = 1:length(Data_drug$ID)

    Data_drug_TTF = Data_drug %>% dplyr::distinct(ID, Drug, .keep_all = T)
    
    Data_TTF_compare = Data_drug_TTF %>% dplyr::filter(TTF_pre>0)
    Data_TTF_compare$Drug_length = as.numeric(Data_TTF_compare$Drug_length)
    Data_TTF_compare$TTF_pre = as.numeric(Data_TTF_compare$TTF_pre)
    Data_TTF_compare$TTF_censor_shape = as.character(4 + 16 * Data_TTF_compare$TTF_censor)
    Data_TTF_compare$TTF_pre_censor_shape = as.character(4 + 16 * Data_TTF_compare$TTF_pre_censor)
    Data_TTF_compare = Data_TTF_compare %>% dplyr::mutate(
      TTF_censor_color = case_when(
        TTF_censor == 0 ~ "red",
        TRUE ~ "blue"
      )
    )
    Data_TTF_compare = Data_TTF_compare %>% dplyr::mutate(
      TTF_pre_censor_color = case_when(
        TTF_pre_censor == 0 ~ "red",
        TRUE ~ "blue"
      )
    )
    Data_TTF_compare = Data_TTF_compare %>% dplyr::mutate(
      TTF_censor_double_color = case_when(
        TTF_censor == 0  & TTF_pre_censor == 0 ~ "target:censored, previous:censored",
        TTF_censor == 1  & TTF_pre_censor == 0 ~ "target:finished, previous:censored",
        TTF_censor == 0  & TTF_pre_censor == 1 ~ "target:censored, previous:finished",
        TRUE ~ "target:finished, previous:finished"
      )
    )
    ga = list()
    gb = list()
    gc = list()
    Data_TTF_compare_tmp = Data_TTF_compare %>% dplyr::filter(Drug %in% input$drug) %>%
      dplyr::arrange(Drug_length)
    Data_TTF_compare_tmp$ind <- factor(seq(1:length(Data_TTF_compare_tmp$ID)))
    Data_TTF_compare_tmp = Data_TTF_compare_tmp %>%
      dplyr::arrange(TTF_pre)
    Data_TTF_compare_tmp$ind2 <- factor(seq(1:length(Data_TTF_compare_tmp$ID)))
    g.mid<-ggplot(Data_TTF_compare_tmp,aes(x=1,y=ind))+
      geom_segment(aes(x=0.94,xend=0.96,yend=ind))+
      geom_segment(aes(x=1.04,xend=1.065,yend=ind))+
      ggtitle("")+
      ylab(NULL)+
      scale_x_continuous(expand=c(0,0),limits=c(0.94,1.065))+
      theme(axis.title=element_blank(),
            legend.position = 'none',
            panel.grid=element_blank(),
            axis.text.y=element_blank(),
            axis.ticks.y=element_blank(),
            panel.background=element_blank(),
            axis.text.x=element_text(color=NA),
            axis.ticks.x=element_line(color=NA),
            plot.margin = unit(c(1,-1,1,-1), "mm"))
    g1 <- ggplot(data = Data_TTF_compare_tmp, aes(x = ind, y = TTF_pre)) +
      geom_bar(stat = "identity") + ggtitle("Previous line") +
      geom_point(aes(x = ind, y = TTF_pre,shape = TTF_pre_censor_shape,colour = TTF_pre_censor_color),size=2)+
      theme(axis.title.x = element_blank(),
            legend.position = 'none',
            axis.title.y = element_blank(),
            axis.text.y = element_blank(),
            axis.ticks.y = element_blank(),
            plot.margin = unit(c(1,-1,1,0), "mm")) +
      scale_y_reverse() + coord_flip()
    g2 <- ggplot(data = Data_TTF_compare_tmp, aes(x = ind, y = Drug_length)) +xlab(NULL)+
      geom_bar(stat = "identity") + ggtitle(paste0("Time on treatment: ", paste(input$drug, collapse = ";"))) +
      geom_point(aes(x = ind, y = Drug_length,shape = TTF_censor_shape,colour = TTF_censor_color),size=2)+
      theme(axis.title.x = element_blank(), axis.title.y = element_blank(),
            legend.position = 'none',
            axis.text.y = element_blank(), axis.ticks.y = element_blank(),
            plot.margin = unit(c(1,0,1,-1), "mm")) +
      coord_flip()
    gg1 <- ggplot_gtable(ggplot_build(g1))
    gg2 <- ggplot_gtable(ggplot_build(g2))
    gg.mid <- ggplot_gtable(ggplot_build(g.mid))
    ga[[1]] = grid.arrange(gg1,gg.mid,gg2,ncol=3,widths=c(4/9,1/9,4/9))

    Data_tmp_1 = Data_TTF_compare_tmp %>% dplyr::select(
      Drug_length, TTF_censor)
    Data_tmp_2 = Data_TTF_compare_tmp %>% dplyr::select(
      TTF_pre, TTF_pre_censor)
    colnames(Data_tmp_2) = colnames(Data_tmp_1)
    Data_tmp_1$line = "Time on treatment"
    Data_tmp_2$line = "Time on treatment, previous-line"
    Data_tmp = rbind(Data_tmp_1, Data_tmp_2)
    survfit_t <- survfit(Surv(Drug_length, TTF_censor)~line, data=Data_tmp,type = "kaplan-meier", conf.type = "log-log")
    diff_0 = survdiff(Surv(Drug_length, TTF_censor)~line,
                      data=Data_tmp, rho=0)
    diff_1 = survdiff(Surv(Drug_length, TTF_censor)~line,
                      data=Data_tmp, rho=1)
    gb[[1]] = surv_curv_drug(survfit_t, Data_tmp, paste0("Time on treatment, ", paste(input$drug, collapse = ";")), diff_0, diff_1)

    Data_TTF_compare_tmp = Data_TTF_compare_tmp %>% dplyr::filter(TTF_pre_censor == 1 & TTF_censor == 1)

    RegModel.1 <- lm(TTF_pre~Drug_length, data=Data_TTF_compare_tmp)
    equation <- sprintf("Y = %.3g + %.3g * X", coef(RegModel.1)[1], coef(RegModel.1)[2])
    if(length(Data_TTF_compare_tmp$TTF_pre)>2){
      res <- cor.test(Data_TTF_compare_tmp$TTF_pre, Data_TTF_compare_tmp$Drug_length, alternative="two.sided", method="pearson")
      res_1 = round(res$estimate,3)
      res_2 = round(res$conf.int[1],3)
      res_3 = round(res$conf.int[2],3)
    } else {
      res_1 = "NA"
      res_2 = "NA"
      res_3 = "NA"
    }
    equation = paste0("r=", res_1, " (", res_2, "-", res_3, "), ", equation)
    ga[[2]] = Data_TTF_compare_tmp %>%
      ggplot(aes(x = Drug_length, y = TTF_pre, colour = TTF_censor_double_color)) +
      geom_point()+
      geom_smooth(method=lm, se=FALSE, color="black", show.legend=FALSE)+
      theme_classic()+
      annotate("text", x = max(Data_TTF_compare_tmp$Drug_length)/2, y=0, label=equation, parse=F) +
      labs(x = "Time on treatment", y = "Previous line", title = paste0("ToT of target-line/previous-line:",paste(input$drug, collapse = ";")))

    survfit_t <- survfit(Surv(Drug_length, TTF_censor)~1, data=Data_drug_TTF,type = "kaplan-meier", conf.type = "log-log")
    gb[[2]] = surv_curv_drug(survfit_t, Data_drug_TTF, paste0("Time on treatment, all drugs"), NULL, NULL)

    if(is.null(input$gene)){
      mut_gene = "TP53"
    } else{
      mut_gene = input$gene
    }

    Data_drug_TTF = Data_drug_TTF %>% dplyr::mutate(mut = case_when(
      ID %in% unique((Data_MAF_target %>% dplyr::filter(Hugo_Symbol %in% mut_gene))$Tumor_Sample_Barcode) ~ "+",
      TRUE ~ "-"))
    survfit_t <- survfit(Surv(Drug_length, TTF_censor)~mut, data=Data_drug_TTF,type = "kaplan-meier", conf.type = "log-log")

    diff_0 = survdiff(Surv(Drug_length, TTF_censor)~mut,
                      data=Data_drug_TTF, rho=0)
    diff_1 = survdiff(Surv(Drug_length, TTF_censor)~mut,
                      data=Data_drug_TTF, rho=1)
    gb[[3]] = surv_curv_drug(survfit_t, Data_drug_TTF, paste("Time on treatment, all drugs,", paste0(collapse = ";", mut_gene) , "mut"), diff_0, diff_1)

    Data_drug_TTF = Data_drug_TTF %>% dplyr::mutate(Regimen_type = case_when(
      Drug %in% input$drug ~ paste(input$drug, collapse = ";"),
      TRUE ~ "Other drugs"))
    survfit_t <- survfit(Surv(Drug_length, TTF_censor)~Regimen_type, data=Data_drug_TTF,type = "kaplan-meier", conf.type = "log-log")
    diff_0 = survdiff(Surv(Drug_length, TTF_censor)~Regimen_type,
                      data=Data_drug_TTF, rho=0)
    diff_1 = survdiff(Surv(Drug_length, TTF_censor)~Regimen_type,
                      data=Data_drug_TTF, rho=1)
    gb[[4]] = surv_curv_drug(survfit_t, Data_drug_TTF, paste0("Time on treatment, ", paste(input$drug, collapse = ";")), diff_0, diff_1)

    survfit_t <- survfit(Surv(Drug_length, TTF_censor)~mut+Regimen_type, data=Data_drug_TTF,type = "kaplan-meier", conf.type = "log-log")
    diff_0 = survdiff(Surv(Drug_length, TTF_censor)~mut+Regimen_type,
                      data=Data_drug_TTF, rho=0)
    diff_1 = survdiff(Surv(Drug_length, TTF_censor)~mut+Regimen_type,
                      data=Data_drug_TTF, rho=1)
    gb[[5]] = surv_curv_drug(survfit_t, Data_drug_TTF, paste("Time on treatment,", paste0(collapse = ";", mut_gene), "and", paste(input$drug, collapse = ";")), diff_0, diff_1)

    Data_drug_TTF$diagnosis = ""
    for(target_diseases in unique(Data_case_target$症例.基本情報.がん種.OncoTree.)){
      Data_drug_TTF = Data_drug_TTF %>% dplyr::mutate(diagnosis = case_when(
        ID %in% unique((Data_case_target %>% dplyr::filter(症例.基本情報.がん種.OncoTree. == target_diseases))$C.CAT調査結果.基本項目.ハッシュID) ~ target_diseases,
        TRUE ~ diagnosis))
    }
    

    output$figure_drug_1 = renderPlot({
      grid.arrange(ga[[1]], ga[[2]], nrow=2,  ncol = 1)
    })

    output$figure_drug_2 = renderPlot({
      arrange_ggsurvplots(gb,print=TRUE,ncol=2,nrow=3)
    })
      output$figure_drug_3 = renderPlot({
        if(length(unique(Data_drug_TTF$diagnosis)) > 1){
          Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::filter(
            diagnosis %in% sort(names(table(Data_drug_TTF$diagnosis)))[1:min(8,length(unique(diagnosis)))])
          survfit_t <- survfit(Surv(Drug_length, TTF_censor)~diagnosis, data=Data_drug_TTF_tmp,type = "kaplan-meier", conf.type = "log-log")
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~diagnosis,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~diagnosis,
                            data=Data_drug_TTF_tmp, rho=1)
          gc[[1]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp, paste0("Time on treatment, diagnosis, all drugs"), diff_0, diff_1)
          
          Data_drug_TTF_tmp = Data_drug_TTF %>% dplyr::filter(Drug %in% input$drug)
          Data_drug_TTF_tmp = Data_drug_TTF_tmp %>% dplyr::filter(
            diagnosis %in% sort(names(table(Data_drug_TTF_tmp$diagnosis)))[1:min(8,length(unique(diagnosis)))])
          survfit_t <- survfit(Surv(Drug_length, TTF_censor)~diagnosis, data=Data_drug_TTF_tmp,type = "kaplan-meier", conf.type = "log-log")
          diff_0 = survdiff(Surv(Drug_length, TTF_censor)~diagnosis,
                            data=Data_drug_TTF_tmp, rho=0)
          diff_1 = survdiff(Surv(Drug_length, TTF_censor)~diagnosis,
                            data=Data_drug_TTF_tmp, rho=1)
          gc[[2]] = surv_curv_drug(survfit_t, Data_drug_TTF_tmp, paste0("Time on treatment, diagnosis, treated with ", paste(input$drug, collapse = ";")), diff_0, diff_1)
          arrange_ggsurvplots(gc,print=TRUE,ncol=1,nrow=2)
      }
    })
  })
}
# Run the application 
shinyApp(ui = ui, server = server)
